


CREATE PROCEDURE [dbo].[csp_Get_BookOrder_Task_NBO] @wh_id NVARCHAR(10) 
	,@order_number NVARCHAR(30)
    ,@pick_id int
	,@employee_id NVARCHAR(30)
	,@item_number NVARCHAR(30) OUTPUT
	,@sto_att BIGINT OUTPUT	
	,@alloc_lot_number nvarchar(30) OUTPUT
	,@expiration_date DATETIME OUTPUT
	,@location_id nvarchar(30) OUTPUT
	,@hu_id nvarchar(30) OUTPUT
	,@leave_allocate_qty float OUTPUT
	,@error_code varchar(10) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from    
	SET NOCOUNT ON;	

	DECLARE @alloc_qty float
	DECLARE @lot_number nvarchar(30) 
	DECLARE @nvch_pack_uid NVARCHAR(30)
	DECLARE @int_err_num NVARCHAR(30)
	DECLARE @nvch_log_msg NVARCHAR(30)     	

	SELECT TOP 1 @item_number = item_number 
		,@lot_number = lot_number 
		,@leave_allocate_qty = planned_quantity - picked_quantity
		,@sto_att = stored_attribute_id 
		FROM t_pick_detail  
		where wh_id = @wh_id 
		and order_number = @order_number 
		and type = 'PO' 
		and status = 'RELEASED'
		and pick_id = @pick_id		

		if @@ROWCOUNT=0
		begin
			set @error_code='1'
		end
		else
		begin
			EXEC csp_Item_Dynamic_Allocation_NBO @wh_id
				,@item_number 
				,@lot_number 
				,@leave_allocate_qty 
				,@sto_att 	
				,@alloc_lot_number OUTPUT
				,@expiration_date OUTPUT
				,@location_id OUTPUT
				,@hu_id OUTPUT
				,@alloc_qty OUTPUT

			SET @leave_allocate_qty=ISNULL(@alloc_qty,0)
			set @error_code='0'
		end

	RETURN	
END




