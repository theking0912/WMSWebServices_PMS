
CREATE PROCEDURE usp_rcpt_ship_reconcile
@in_vchWarehouse      NVARCHAR(20),    
@in_vchShipmentNumber NVARCHAR(60),
@in_vchUserID         NVARCHAR(10),
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contains "SUCCESS" or the message to be displayed.

AS

DECLARE 
    -- Error handling variables
    @c_vchObjName           NVARCHAR(30), -- The name that uniquely tags this object.
    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER,
    @v_vchMessage           NVARCHAR(500),
    @v_nReturn              INTEGER,

    -- Local Variables
    @v_nCount               INTEGER,
    @v_chStatus             NCHAR(1),
    @v_vchItem              NVARCHAR(30),
    @v_nSeq                 INTEGER
    
    -- Tables
    DECLARE @tblItems TABLE
        (
        seq          INTEGER IDENTITY(1,1),
        item_number  NVARCHAR(30),                            
        PRIMARY KEY CLUSTERED (seq)
        )
        
    SET NOCOUNT ON
    
    -- Set Constants
    SET @c_vchObjName = 'usp_rcpt_ship_reconcile'    

    -- Intialize Variables
    SET @out_vchMessage = 'SUCCESS'
    SET @v_nSeq         = 1    
   
    SELECT @v_chStatus = status
    FROM t_rcpt_ship
    WHERE   shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouse

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @out_vchMessage = 'A SQL error occured while retrieving status from t_rcpt_ship.'
        GOTO ERROR_HANDLER
    END
    IF @v_nRowCount = 0
    BEGIN
        SET @out_vchMessage = 'Shipment [' + @in_vchShipmentNumber + '] does not exist.'
        GOTO ERROR_HANDLER
    END

    -- Check Shipment status
    IF @v_chStatus <> 'C'
    BEGIN  
        SET @out_vchMessage = 'Shipment [' + @in_vchShipmentNumber + '] not completed or has been reconciled.'
        GOTO EXIT_LABEL
    END

    INSERT INTO @tblItems 
    (
        item_number
    )
    SELECT DISTINCT item_number
    FROM t_rcpt_ship_po_detail
    WHERE   shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouse
        AND status          = 'O'

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @out_vchMessage   = 'A SQL error occured while retrieving items from t_rcpt_ship_po_detail'
        GOTO ERROR_HANDLER
    END
    IF @v_nRowCount = 0
    BEGIN
        SET @out_vchMessage = 'No items to reconcile for Shipment Number [' + @in_vchShipmentNumber + '].'
        GOTO EXIT_LABEL
    END

    -- Set v_nCount because v_nRowCount will be used again.
    SET @v_nCount = @v_nRowCount

    WHILE @v_nSeq <= @v_nCount
    BEGIN
        SELECT @v_vchItem = item_number
        FROM @tblItems    
        WHERE seq = @v_nSeq
         
        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_vchSqlErrorNumber <> 0
        BEGIN 
            SET @out_vchMessage   = 'A SQL error occured while retrieving an item from @tblItems.'
            GOTO ERROR_HANDLER
        END
        IF @v_nRowCount = 0
        BEGIN
            BREAK
        END            
    
        EXECUTE usp_rcpt_ship_reconcile_item @in_vchWarehouse, @in_vchShipmentNumber, @v_vchItem, @in_vchUserID, @v_vchMessage OUTPUT
        
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0
        BEGIN 
            SET @out_vchMessage = 'A SQL error occured while executing usp_rcpt_ship_reconcile_item.'
            GOTO ERROR_HANDLER
        END            
      
        IF @v_vchMessage <> 'SUCCESS'
        BEGIN
            SET @out_vchMessage = @v_vchMessage
            GOTO ERROR_HANDLER
        END
          
        SET @v_nSeq = @v_nSeq + 1  
    END
    
    SET @out_vchMessage = 'SUCCESS'

    GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    
    SET @out_vchMessage = @c_vchObjName + ': ' + @out_vchMessage + '. SQL Error ['
                          + @v_vchSqlErrorNumber + '].'

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

    RETURN
