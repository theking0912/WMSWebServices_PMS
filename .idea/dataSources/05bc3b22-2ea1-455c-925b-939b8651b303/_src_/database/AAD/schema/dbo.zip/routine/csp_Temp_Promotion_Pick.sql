-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: promotion pick	  
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Promotion_Pick]    
     @wh_id					NVARCHAR(10)  
	,@order_number			Nvarchar(30)  
	,@user_id				nvarchar(30)
	,@passornot				nvarchar(1)		output
	,@msg					nvarchar(200)	output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @pick_id		bigint
		DECLARE @ref_number		nvarchar(30)
		DECLARE @shipping_label	nvarchar(30)
		DECLARE @route			nvarchar(30)
		DECLARE @carrier		nvarchar(30)
		DECLARE @door_loc		nvarchar(30)
		DECLARE @node			nvarchar(30)
		DECLARE @event_data		nvarchar(1000)
	
		--Check 
		IF NOT EXISTS ( SELECT 1 FROM tbl_allocation
						WHERE wh_id = @wh_id
						and order_number = @order_number)
			BEGIN
				SET @msg = 'No Released Order:' + @order_number
				SET @passornot =1
				
				RETURN
			END

		IF EXISTS ( SELECT 1 FROM tbl_allocation
						WHERE wh_id = @wh_id
						and order_number = @order_number
						and shipping_label is null)
			BEGIN
				SET @msg = 'No Shipping Label:' + @order_number
				SET @passornot = 1
				RETURN
			END

		IF EXISTS ( SELECT 1 FROM tbl_allocation
						WHERE wh_id = @wh_id
						and order_number = @order_number
						and status = 'C')
			BEGIN
				SET @msg = 'Order :' + @order_number + 'Has been Picked'
				SET @passornot = 1
				RETURN
			END
		
		BEGIN TRANSACTION
		--Get the shipping information
		SELECT @shipping_label = ship_label_barcode
			,@route = [route]
			,@carrier = carrier
		FROM tbl_shipping_label
		WHERE wh_id = @wh_id
		AND order_number = @order_number
		--Get the door location
		SELECT @node = node
		FROM tbl_ship_node_route
		WHERE wh_id = @wh_id
		AND route = @route
		AND carrier = @carrier

		SET @door_loc = @node
		
		--create the stock for shipping label
		INSERT INTO t_hu_master(wh_id, hu_id, location_id, type, status, control_number,load_id, reserved_for)
        VALUES (@wh_id, @shipping_label, @door_loc, 'LO', 'A', @order_number,@shipping_label,@door_loc) 

		INSERT INTO t_stored_item
		(wh_id,location_id,hu_id,item_number,lot_number,stored_attribute_id,actual_qty,[type],status,shipment_number)
		SELECT wh_id,@door_loc,@shipping_label,item_number,lot_number,stored_attribute_id,sum(allocated_qty), pick_id,'A',order_number
		FROM tbl_allocation
		WHERE wh_id = @wh_id
		and order_number = @order_number
		GROUP BY wh_id,item_number,lot_number,stored_attribute_id, pick_id,order_number

		--Decreament Order
		UPDATE t_stored_item 
		SET actual_qty = actual_qty - ( SELECT sum(a.allocated_qty) FROM tbl_allocation a
										WHERE a.wh_id = t_stored_item.wh_id
										AND a.item_number = t_stored_item.item_number
										and isnull(a.lot_number,'0') = isnull(t_stored_item.lot_number,'0')
										and a.location_id = t_stored_item.location_id
										and isnull(t_stored_item.stored_attribute_id,'0') = isnull(t_stored_item.stored_attribute_id,'0')
										and a.order_number = @order_number)
		WHERE exists ( SELECT 1 FROM tbl_allocation a
						WHERE a.wh_id = t_stored_item.wh_id
						AND a.item_number = t_stored_item.item_number
						and isnull(a.lot_number,'0') = isnull(t_stored_item.lot_number,'0')
						and a.location_id = t_stored_item.location_id
						and isnull(t_stored_item.stored_attribute_id,'0') = isnull(t_stored_item.stored_attribute_id,'0')
						and a.order_number = @order_number)
		
		--Update t_allocation status
		UPDATE tbl_allocation
		SET status = 'C'
		WHERE wh_id = @wh_id
		and order_number = @order_number
		--Update t_pick_detail status
		UPDATE t_pick_detail
		SET status = 'LOADED'
			,loaded_quantity = planned_quantity
			,picked_quantity = planned_quantity
			,packed_quantity = planned_quantity
			,staged_quantity = planned_quantity
		WHERE wh_id = @wh_id
		and order_number = @order_number
		--Update tbl_shipping_label status
		UPDATE tbl_shipping_label
		SET status = 'LOADED'
		WHERE wh_id = @wh_id
		and order_number = @order_number
		--Update t_order status
		UPDATE t_order
		SET status = 'LOADED'
		WHERE wh_id = @wh_id
		and order_number = @order_number
		--Create Tran log

		--Send Socket
		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
			,wh_id_2,location_id_2,hu_id_2
			,generic_attribute_1,
			generic_attribute_2,
			generic_attribute_3,
			generic_attribute_4,
			generic_attribute_5,
			generic_attribute_6,
			generic_attribute_7,
			generic_attribute_8,
			generic_attribute_9,
			generic_attribute_10,
			generic_attribute_11)
		select 
			'316','Promotion Picking',getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@pick_id
			,@wh_id,allo.location_id,allo.hu_id,allo.item_number,allo.lot_number,allo.allocated_qty
			,@wh_id,@door_loc,@shipping_label
			,(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_1),    
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_2), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_3), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_4), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_5), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_6), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_7), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_8), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_9), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_10), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = allo.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_11)
		FROM tbl_allocation allo
		WHERE allo.wh_id = @wh_id
		AND allo.order_number = @order_number 

		--Print Shipping label

		--Send Socket to conveyor
		SET @event_data = 'TRAN|CREA|'+@shipping_label+'|'+@node;
		exec [ADV].[dbo].[usp_AdvAddEvent] 4,'SEND SORKET',@event_data,50

		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		IF @@TRANCOUNT > 0 
			ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END
