
CREATE PROCEDURE dbo.usp_insert_ea_event
	@in_vchEventID		NVARCHAR(30),    
	@in_vchEventData	TEXT,
	@in_vchWhID			NVARCHAR(10),
	@in_vchEmpID		NVARCHAR(10)

AS
DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_SprocError               INT,
       
    -- Local Variables
	@c_nEventClass	  			INT,
	@c_nEventType	  			INT,
	@c_nRetryCount	  			INT,
	@c_nPriority	  			INT
	
    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 5        -- This # must be unique per object.

	SET @c_nRetryCount = 100
	SET @c_nPriority = 50
	SET @c_nEventType = 0
	SET @c_nEventClass = 4
    
    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    
    SET NOCOUNT ON

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END
    
    -- Clear the t_employee.sp_return field used to communicate with the WA application.
    EXECUTE @v_nReturn = usp_clear_emp @in_vchWhID, @in_vchEmpID
    IF @v_nReturn <> 0
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END
     
    -- Insert the event 
    EXECUTE @v_nReturn = ADV.dbo.usp_AdvAddEvent @c_nEventClass, @in_vchEventID, @in_vchEventData, @c_nPriority
    IF @v_nReturn <> 0
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END

    SELECT @v_nErrorNumber = @@ERROR
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
    
    GOTO ExitLabel

ErrorHandler:
----------------------------------------------------------------------------------------------------
-- Delete these comments, they are only reminders...
-- Add each log message to the ...\RequiredData\InsertLogMap.sql script.
----------------------------------------------------------------------------------------------------

    -- Log the error message in ADV.t_log
    -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- This is the application's way of knowing there was an error in this sproc.  Be sure the app
    -- looks at this field immediately after running the sproc.
    UPDATE t_employee SET sp_return = 'PROC ERROR' WHERE id = @in_vchEmpID AND @in_vchWhID = wh_id
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    


ExitLabel:

    -- Always leave the stored procedure from here.
    RETURN
