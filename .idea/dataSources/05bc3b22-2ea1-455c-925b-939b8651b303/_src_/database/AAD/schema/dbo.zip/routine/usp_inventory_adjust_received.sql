-- =============================================
-- Author:		Peter
-- Create date: 2016-02-27
-- Description:	
-- =============================================


CREATE  PROCEDURE [dbo].[usp_inventory_adjust_received]
    @in_vchWhID                NVARCHAR(10),
    @in_vchItemNumber          NVARCHAR(30),
    @in_vchLocationID          NVARCHAR(50),
    @in_nType                  BIGINT, 
    @in_vchHUID                NVARCHAR(22),
    @in_vchLotNumber           NVARCHAR(15),
    @in_nStoredAttributeID     BIGINT, 
    @in_fQty                   FLOAT,
    @in_dtFifoDate             DATETIME,
    @in_dtExpirationDate       DATETIME,
    @in_vchHUType              NVARCHAR(10),
	@in_dQty                   FLOAT,
    @out_vchCode               uddt_output_code   OUTPUT,
    @out_vchMsg                uddt_output_msg    OUTPUT

AS

-- ********************************************************************************
--                             Copyright ⌐ 2013.
--                           All Rights Reserved.
--                            HighJump Software
--                        Minneapolis, Minnesota, USA
-- ********************************************************************************
-- 
--    PURPOSE:
--          The purpose of this stored procedure is to adjust inventory.
--
--    INPUT:
--
--    OUTPUT:
--        out_vchCode - Contains 'SUCCESS' or Error Code.
--        out_vchMsg - Contains the error message or informational log message.:
--      
--  TARGET: SQL Server 2005
--
-- *********************************************************************************
DECLARE
    -- Error handling variables
    @c_vchObjName                   uddt_obj_name,  -- The name that uniquely tags this object.
    @v_vchCode                      uddt_output_code,
    @v_vchMsg                       uddt_output_msg,
    @v_nSysErrorNum                 INT,

    -- Local Variables
    @v_nExists                      BIT,
    @v_nRowCount                    INT,
    @v_fActualQty                   FLOAT,
    @v_fUnavailableQty              FLOAT, 
    @v_nSequence                    INT,
	@zone_group			NVARCHAR(30),
	@zone				NVARCHAR(10),
	@type					   Nvarchar(30)='N', --D:Damage;  N:Normal
	@shipment_number      NVARCHAR(30),
    @damage_flag		NVARCHAR(1) = 'N', -- Normal=0, Damage>0

   @passornot int,
   @outmsg nvarchar(200),
   @seq_id	   nvarchar(30),
   @current_date nvarchar(10)

   SELECT @current_date = CONVERT(NVARCHAR(10), GETDATE(),112)
   EXEC csp_Get_AutoSeqNo_ByWH  @in_vchWhID,'VirtualPOSeqNo',@current_date,@seq_id output, @passornot output, @outmsg output
   select @shipment_number=@current_date + @seq_id
       
    -- Set Constants
    SET @c_vchObjName = N'usp_inventory_adjust_received'   
    SET @v_vchCode = N'SUCCESS'
    SET @v_vchMsg  = N'NONE'
    SET @v_nSysErrorNum = 0
    SET @v_nSequence = 0
	-- Handle NULLS and Implicit NULLS (01/01/1900)
	SET @in_dtFifoDate = CASE WHEN @in_dtFifoDate IS NULL OR @in_dtFifoDate = '01/01/1900' THEN GETDATE() ELSE @in_dtFifoDate END
	-- SET @in_dtExpirationDate = CASE @in_dtExpirationDate WHEN '01/01/1900' THEN null ELSE @in_dtExpirationDate END
	SET @in_dtExpirationDate = CASE @in_dtExpirationDate WHEN '01/01/1900' THEN convert(datetime,@in_vchLotNumber) ELSE @in_dtExpirationDate END 
      IF @in_dtExpirationDate is not null
			BEGIN				
				SELECT @in_dtExpirationDate = DATEADD(DAY,shelf_life,@in_dtExpirationDate) FROM t_item_master
				WHERE wh_id = @in_vchWhID 
				AND item_number = @in_vchItemNumber											
			END 
    SET NOCOUNT ON

-----------------------------------------------------------------------------------
--                  Update STO Record
-----------------------------------------------------------------------------------  
BEGIN TRY  
    UPDATE t_stored_item
       SET @v_fActualQty  = actual_qty = actual_qty + @in_fQty
	  ,unavailable_qty = CASE WHEN status = N'H' THEN actual_qty + @in_fQty  ELSE unavailable_qty END 	  
          ,fifo_date       = CASE WHEN fifo_date < @in_dtFifoDate THEN fifo_date ELSE @in_dtFifoDate END
          ,expiration_date = CASE WHEN @in_dtExpirationDate IS NULL THEN expiration_date ELSE @in_dtExpirationDate END
          ,sequence        = @v_nSequence
     WHERE wh_id       = @in_vchWhID
       AND item_number = @in_vchItemNumber
       AND location_id = @in_vchLocationID
       AND type        = @in_nType
       AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'-1') = ISNULL(@in_vchHUID,'-1')))
       AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'-1') = ISNULL(@in_vchLotNumber,'-1')))
       AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'-1') = ISNULL(@in_nStoredAttributeID,'-1')))
       
       SET @v_nRowCount = @@ROWCOUNT
END TRY

BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
    SET @v_vchCode = N'-20001'
    SET @v_vchMsg = N'A SQL error occured while attempting to update STO records.'
    GOTO ERROR_HANDLER
END CATCH



IF @v_nRowCount > 0 SET @v_nExists = 1 ELSE SET @v_nExists = 0

IF @v_nExists = 0 
BEGIN --1
    IF @in_vchHUID IS NOT NULL 
    BEGIN--2
        -----------------------------------------------------------------------------------
        --                  Update HUM Record
        ----------------------------------------------------------------------------------- 
        BEGIN TRY
            UPDATE t_hu_master 
                SET location_id = @in_vchLocationID, type = @in_vchHUType
            WHERE wh_id = @in_vchWhID
                AND hu_id = @in_vchHUID
                
            SET @v_nRowCount = @@ROWCOUNT
        END TRY

        BEGIN CATCH    
            SET @v_nSysErrorNum = ERROR_NUMBER()
            SET @v_vchCode = N'-20002'
            SET @v_vchMsg = N'A SQL error occured while attempting to update HUM record.'
            GOTO ERROR_HANDLER
        END CATCH
 
        IF @v_nRowCount <= 0 
        BEGIN--3 
            -----------------------------------------------------------------------------------
            --                  Insert HUM Record
            -----------------------------------------------------------------------------------        
            BEGIN TRY 
			SET @zone_group = dbo.fn_Get_StorageType_ByItem(@in_vchWhID,@in_vchItemNumber,@type)
					SELECT TOP 1 @zone = zone 
					FROM t_zone 
					WHERE zone_type = @type and wh_id = @in_vchWhID and zone_group = @zone_group

					INSERT INTO t_hu_master
					(wh_id,hu_id,type,control_number,location_id,subtype
					,status, fifo_date,zone)
					VALUES
					(@in_vchWhID,@in_vchHUID,@in_vchHUType,@shipment_number,@in_vchLocationID,@type + @zone_group
					,'A',GETDATE(),@zone)					                          
            END TRY
    
            BEGIN CATCH    
                SET @v_nSysErrorNum = ERROR_NUMBER()
                SET @v_vchCode = N'-20003'
                SET @v_vchMsg = N'A SQL error occured while attempting to insert HUM record.'
                GOTO ERROR_HANDLER
            END CATCH               
        END--3           
    END--2        
    -----------------------------------------------------------------------------------
    --                 Create STO Record
    ----------------------------------------------------------------------------------- 
    BEGIN TRY
        INSERT INTO t_stored_item(
            wh_id, item_number, location_id, type, hu_id, lot_number, stored_attribute_id, 
            actual_qty, unavailable_qty, status, fifo_date, expiration_date, sequence,
            shipment_number,damage_flag)
        VALUES(
            @in_vchWhID, @in_vchItemNumber, @in_vchLocationID, @in_nType, @in_vchHUID, 
            @in_vchLotNumber, @in_nStoredAttributeID, @in_fQty, 0, N'A', @in_dtFifoDate, 
            @in_dtExpirationDate, @v_nSequence,
            @shipment_number,@damage_flag)  
       INSERT INTO t_receipt(receipt_id,line_number,receipt_date,status,item_number,lot_number,qty_received,
	   hu_id,shipment_number,wh_id,qty_discount,expiration_date,production_date)
	    values(CONVERT(NVARCHAR,@in_dtFifoDate,112),'1',@in_dtFifoDate,N'O',@in_vchItemNumber,@in_vchLotNumber,@in_fQty,@in_vchHUID,
		@shipment_number,@in_vchWhID,@in_dQty,@in_dtExpirationDate,convert(datetime,@in_vchLotNumber) )
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
        SET @v_vchCode = N'-20004'
        SET @v_vchMsg = N'A SQL error occured while attempting to update STO record.'
        GOTO ERROR_HANDLER
    END CATCH 
END--1

-----------------------------------------------------------------------------------
--                Delete STO Record
----------------------------------------------------------------------------------- 
IF @v_nExists = 1 AND @v_fActualQty = 0 
BEGIN--1
    BEGIN TRY
        DELETE t_stored_item
            WHERE wh_id       = @in_vchWhID
                AND item_number = @in_vchItemNumber
                AND location_id = @in_vchLocationID
                AND type        = @in_nType
                AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'-1') = ISNULL(@in_vchHUID,'-1')))
                AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'-1') = ISNULL(@in_vchLotNumber,'-1')))
                AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'-1') = ISNULL(@in_nStoredAttributeID,'-1')))
                AND actual_qty = 0
                AND unavailable_qty = 0
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
        SET @v_vchCode = N'-20005'
        SET @v_vchMsg = N'A SQL error occured while attempting to delete STO record.'
        GOTO ERROR_HANDLER
    END CATCH    

    -----------------------------------------------------------------------------------
    --                 Delete HUM Record
    ----------------------------------------------------------------------------------- 
    IF @in_vchHUID IS NOT NULL 
    BEGIN--2   
        IF NOT EXISTS (SELECT N'TRUE'
                         FROM t_stored_item
                        WHERE wh_id = @in_vchWhID
                          AND hu_id = @in_vchHUID) 
        BEGIN--3
            BEGIN TRY              
                DELETE FROM t_hu_master
                    WHERE wh_id = @in_vchWhID
                        AND hu_id = @in_vchHUID
            END TRY

            BEGIN CATCH    
                SET @v_nSysErrorNum = ERROR_NUMBER()
                SET @v_vchCode = N'-20006'
                SET @v_vchMsg = N'A SQL error occured while attempting to delete HUM record.'
                GOTO ERROR_HANDLER
            END CATCH    
        END--3
    END--2
END--1

GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + N'Deadlock error: 40001 ' 
                    + @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE() + N'.'
    ELSE    
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + @v_vchMsg
                    + N' SQL Error = ' + ERROR_MESSAGE() + N'.'

    RAISERROR(@v_vchMsg, 11, 1)
   
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

	-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

    -- Always leave the stored procedure from here.
RETURN


