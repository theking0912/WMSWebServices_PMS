
CREATE FUNCTION [dbo].[csf_getUserValuesToTmpTable]
(
	@in_vchIdentifier	VARCHAR(36),   
	@in_nInformationCollectionID	INT,
	@in_nSequenceId			INT
)
RETURNS NVARCHAR(250)
AS
BEGIN

   -- Declare local and return variables here.
   DECLARE @v_nSysRowCount INT,
           @out_nchResult NVARCHAR(250)
 
   SET @out_nchResult = NULL;

   SELECT @v_nSysRowCount = COUNT(*) 
   FROM tbl_user_entered_information
   WHERE identifier = @in_vchIdentifier;

   IF @v_nSysRowCount = 0
     GOTO EXIT_LABEL

        
   SELECT @out_nchResult = tmp.information_value  
    FROM tbl_user_entered_information tmp,
         tbl_information_collection_detail attd  
    WHERE attd.information_id = tmp.information_id  
      AND tmp.identifier = @in_vchIdentifier
      AND attd.information_collection_id = @in_nInformationCollectionID
      AND attd.sequence_id = @in_nSequenceId;
      
EXIT_LABEL:
     RETURN @out_nchResult
END
