
CREATE PROCEDURE usp_Put_FEFOLikeLot
    @in_vchItem		NVARCHAR(30),
    @in_vchLot		NVARCHAR(30),
    @in_nQty		INT,
    @in_dtFIFODate	DATETIME,
    @in_vchForkZone	NVARCHAR(10),
    @in_vchWhID		NVARCHAR(10),
	@in_nStoAttID	BIGINT,
    @out_vchLoc		NVARCHAR(50) = NULL OUTPUT

AS
DECLARE 
	@v_nStdHandQty INT,
	@c_nStorageType	INT

-- Set Constants
SET @c_nStorageType = 0
		
    -- Retreive the std_hand_qty from t_item_uom.
    -- Only a single t_item_uom record may be used.  This is determined by taking the
    -- greatest conversion factor less than or equal to the quantity passed in.
    SELECT TOP 1 @v_nStdHandQty = itu.std_hand_qty
    FROM t_item_uom itu
    WHERE itu.conversion_factor <= @in_nQty
        AND itu.item_number = @in_vchItem
        AND itu.wh_id = @in_vchWhID
    ORDER BY itu.conversion_factor DESC

	IF @in_nStoAttID IS NULL 
	   OR NOT EXISTS (SELECT * 
					  FROM t_item_master itm
					  INNER JOIN t_attribute_collection_detail acd
							ON itm.attribute_collection_id = acd.attribute_collection_id
					  INNER JOIN t_attribute_type tat
							ON acd.attribute_id = tat.attribute_id	
					  WHERE itm.item_number = @in_vchItem
  					      AND itm.wh_id = @in_vchWhID	
  						  AND tat.allow_mix = 'N'
					  )
	BEGIN
		SELECT TOP 1 @out_vchLoc = loc.location_id
		FROM t_location loc
		INNER JOIN t_stored_item sto
		  ON loc.location_id = sto.location_id
		  AND loc.wh_id = sto.wh_id
		INNER JOIN t_pick_area pka
          ON pka.pick_area = loc.pick_area
          AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND @in_nStoAttID IS NULL AND @in_vchLot IS NULL) )
          AND pka.wh_id = loc.wh_id
          AND (pka.pick_area_type = 'R' OR (pka.pick_area_type = 'V' and @in_nStoAttID IS NULL))
		INNER JOIN t_zone_loca zlc
		  ON loc.location_id = zlc.location_id
		 AND loc.wh_id = zlc.wh_id
		INNER JOIN t_item_master itm
		  ON sto.item_number = itm.item_number
		  AND sto.wh_id = itm.wh_id
		WHERE sto.item_number = @in_vchItem
		  AND sto.wh_id = @in_vchWhID
		  AND zlc.zone = @in_vchForkZone
		  AND @in_vchLot IS NOT NULL
		  AND ISNULL(sto.lot_number,'*') = ISNULL(@in_vchLot,'*')
		  AND loc.status <> 'F'
		  AND loc.status <> 'I'
		  AND ( (itm.inspection_code = 'H' 
      			AND sto.status = 'H')		-- Look for other items on hold?
         		 OR (itm.inspection_code <> 'H'
      			   AND sto.status = 'A'
      			   AND sto.expiration_date <= @in_dtFIFODate	-- Upper FIFO Date
      			   AND sto.expiration_date >=	DATEADD(day, - itm.shelf_life, @in_dtFIFODate)) )  -- Lower FIFO
		-- Factor Simple Cubing for location's capacity_qty muliplied by the standard
		-- handling quantity (i.e. Pallets) of the item's selected uom.
		  AND ( (loc.type = 'M') 
         		OR (loc.type = 'I' 
         			AND (ISNULL(loc.capacity_qty,0)= 0 OR @v_nStdHandQty = 0))
         		OR (loc.type = 'I'
             		AND ((ISNULL(loc.capacity_qty,0) * @v_nStdHandQty) >= 
		          			(SELECT SUM(actual_qty) + @in_nQty
		          			   FROM t_stored_item s
		          			   WHERE s.item_number = @in_vchItem
		          				 AND s.type = @c_nStorageType
		          				 AND s.location_id = loc.location_id
		          				 AND s.wh_id = loc.wh_id))) )
		  AND sto.actual_qty > 0
		  AND sto.type = @c_nStorageType
		ORDER BY loc.type, loc.user_count, sto.expiration_date DESC, loc.picking_flow, loc.location_id 
	END
	ELSE
	BEGIN
		SELECT TOP 1 @out_vchLoc = loc.location_id
		FROM t_location loc
		INNER JOIN t_stored_item sto
		  ON loc.location_id = sto.location_id
		  AND loc.wh_id = sto.wh_id
		INNER JOIN t_pick_area pka
          ON pka.pick_area = loc.pick_area
          AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND @in_nStoAttID IS NULL AND @in_vchLot IS NULL) )
          AND pka.wh_id = loc.wh_id
          AND (pka.pick_area_type = 'R' OR (pka.pick_area_type = 'V' and @in_nStoAttID IS NULL))
		INNER JOIN t_zone_loca zlc
		  ON loc.location_id = zlc.location_id
		 AND loc.wh_id = zlc.wh_id
		INNER JOIN t_item_master itm
		  ON sto.item_number = itm.item_number
		  AND sto.wh_id = itm.wh_id
		WHERE sto.item_number = @in_vchItem
			AND sto.wh_id = @in_vchWhID
			AND zlc.zone = @in_vchForkZone
			AND @in_vchLot IS NOT NULL
			AND ISNULL(sto.lot_number,'*') = ISNULL(@in_vchLot,'*')
			AND loc.status <> 'F'
			AND loc.status <> 'I'
			AND ( (itm.inspection_code = 'H' 
      			AND sto.status = 'H')		-- Look for other items on hold?
         		 OR (itm.inspection_code <> 'H'
      			   AND sto.status = 'A'
      			   AND sto.expiration_date <= @in_dtFIFODate	-- Upper FIFO Date
      			   AND sto.expiration_date >=	DATEADD(day, - itm.shelf_life, @in_dtFIFODate)) )  -- Lower FIFO
			-- Factor Simple Cubing for location's capacity_qty muliplied by the standard
			-- handling quantity (i.e. Pallets) of the item's selected uom.
			AND ( (loc.type = 'M') 
         		OR (loc.type = 'I' 
         			AND (ISNULL(loc.capacity_qty,0)= 0 OR @v_nStdHandQty = 0))
         		OR (loc.type = 'I'
             		AND ((ISNULL(loc.capacity_qty,0) * @v_nStdHandQty) >= 
		          			(SELECT SUM(actual_qty) + @in_nQty
		          			   FROM t_stored_item s
		          			   WHERE s.item_number = @in_vchItem
		          				 AND s.type = @c_nStorageType
		          				 AND s.location_id = loc.location_id
		          				 AND s.wh_id = loc.wh_id))) )
			AND sto.actual_qty > 0
			AND sto.type = @c_nStorageType
			AND NOT EXISTS (
							SELECT * 
							FROM t_item_master itm
							INNER JOIN t_attribute_collection_detail acd
								ON itm.attribute_collection_id = acd.attribute_collection_id
							INNER JOIN t_attribute_type tat
								ON acd.attribute_id = tat.attribute_id	
							INNER JOIN t_sto_attrib_collection_detail sad
								ON sad.attribute_id = tat.attribute_id
							INNER JOIN t_stored_item sto1
								ON sto1.stored_attribute_id = sad.stored_attribute_id
							INNER JOIN t_sto_attrib_collection_detail sad1
								ON sad.attribute_id = sad1.attribute_id
							WHERE itm.item_number = @in_vchItem
		      					  AND itm.wh_id = @in_vchWhID	
		      					  AND sad1.stored_attribute_id = @in_nStoAttID
		      					  AND tat.allow_mix = 'N'
		      					  AND sto.wh_id = sto1.wh_id
            					  AND sto.location_id = sto1.location_id
            					  AND sad.attribute_value <> sad1.attribute_value
						  )
		ORDER BY loc.type, loc.user_count, sto.expiration_date DESC, loc.picking_flow, loc.location_id 
	END
ExitLabel:
  RETURN
