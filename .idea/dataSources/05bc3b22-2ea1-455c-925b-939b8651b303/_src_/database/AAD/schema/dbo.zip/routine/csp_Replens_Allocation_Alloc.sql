CREATE PROCEDURE [dbo].[csp_Replens_Allocation_Alloc]    
     @in_vchWhID	    NVARCHAR(10)   
    ,@in_vchWaveID	    NVARCHAR(30) 

AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY

		DECLARE @item_number			NVARCHAR(30)
		DECLARE @lot_number				NVARCHAR(30)
		DECLARE @line_number			NVARCHAR(5)
		DECLARE @planned_qty			float
		DECLARE @picked_qty				float
		DECLARE @leave_allocate_qty		float
		DECLARE @uom_qty				float
		DECLARE @alloc_qty				float
		DECLARE @allocated_qty			float
		DECLARE @pick_id				bigint
		DECLARE @pick_put_id			NVARCHAR(30)
		DECLARE @location_id			NVARCHAR(30)
		DECLARE @zone					NVARCHAR(30)
		DECLARE @pick_seq				NVARCHAR(30)
		DECLARE @carrier				NVARCHAR(30)
		DECLARE @event_data				NVARCHAR(2000)
		DECLARE @result                 INT
		DECLARE @alloc_lot_number       NVARCHAR(30)
		DECLARE @expiration_date        DATETIME
		DECLARE @re_release				NVARCHAR(30)
		DECLARE @is_rollback			NVARCHAR(30)
		DECLARE @stock_flag             NVARCHAR(1)
		DECLARE @v_nRowCount            INT
		DECLARE @v_nErrorNumber         INT
		DECLARE @v_nRuleCntr            INT
		DECLARE @v_nNumOfRules          INT
		DECLARE @gourd_flag             NVARCHAR(1)
		DECLARE @hu_id                  NVARCHAR(22)
		DECLARE @pick_type              NVARCHAR(1)
		DECLARE @damage_flag            NVARCHAR(1)
		DECLARE @stored_attribute_id    BIGINT
		DECLARE @order_number           NVARCHAR(30)
		DECLARE	@v_vchUOM               NVARCHAR(10)
		set @re_release = 'N'

		set @is_rollback = 'N'
		
		BEGIN TRANSACTION

		set @pick_id = 0


		-- Temp table used to hold a list of pick put rules for a given Pick Put ID
		CREATE TABLE #tmp_rule_set (
		   sequence        SMALLINT ,   -- The sequencial order in which to execute the rule
		   pick_put_rule   NVARCHAR(30) COLLATE DATABASE_DEFAULT -- Name of the rule stored procedure to execute
		)

        WHILE ( 1 = 1 )
            BEGIN
                SELECT TOP 1
                        @pick_id = pkd.pick_id ,
                        @order_number = pkd.order_number ,
                        @item_number = pkd.item_number ,
                        @lot_number = pkd.lot_number ,
                        @line_number = pkd.line_number ,
                        @planned_qty = pkd.planned_quantity ,
                        @picked_qty = pkd.picked_quantity ,
                        @stock_flag = itm.stock_flag ,
                        @stored_attribute_id = pkd.stored_attribute_id
                FROM    t_pick_detail pkd ,
                        t_item_master itm
                WHERE   pkd.wh_id = itm.wh_id
                        AND pkd.item_number = itm.item_number
                        AND pkd.type = 'RP'
                        AND pkd.wave_id = @in_vchWaveID
                        AND pkd.wh_id = @in_vchWhID
                        AND pkd.pick_id > @pick_id
                ORDER BY pkd.pick_id

                IF @@ROWCOUNT = 0
                    OR @is_rollback = 'Y'
                    BREAK;

            --牛肉和冬瓜类不需要分配
                IF EXISTS ( SELECT  'x'
                            FROM    t_item_master
                            WHERE   wh_id = @in_vchWhID
                                    AND item_number = @item_number
                                    AND pick_type IN ( 'B', 'M' ) )
                    BEGIN
                        CONTINUE
                    END

                DELETE  FROM tbl_allocation
                WHERE   order_number = @order_number
                        AND item_number = @item_number
                        AND ( @lot_number IS NULL
                              OR lot_number = @lot_number
                            )
                        AND line_number = @line_number
                        AND pick_id = @pick_id
                        AND status = 'E'
                        AND picked_qty = 0

			-- for re-allocation clear allocated qty
                UPDATE  tbl_allocation
                SET     allocated_qty = picked_qty ,
                        status = 'C'
                WHERE   order_number = @order_number
                        AND item_number = @item_number
                        AND ( @lot_number IS NULL
                              OR lot_number = @lot_number
                            )
                        AND pick_id = @pick_id
                        AND status = 'E'
                        AND line_number = @line_number 

                SELECT  @allocated_qty = SUM(allocated_qty - picked_qty)
                FROM    tbl_allocation
                WHERE   wh_id = @in_vchWhID
                        AND order_number = @order_number
                        AND item_number = @item_number
                        AND ( @lot_number IS NULL
                              OR lot_number = @lot_number
                            )
                        AND pick_id = @pick_id
                        AND line_number = @line_number 

			
                SET @leave_allocate_qty = @planned_qty - @picked_qty
                    - ISNULL(@allocated_qty, 0)
                SET @uom_qty = 999999
                WHILE @leave_allocate_qty > 0
                    BEGIN
                        SELECT TOP 1
                                @v_vchUOM = itu.uom ,
                                @uom_qty = itu.conversion_factor
                        FROM    t_item_uom itu
                        WHERE   wh_id = @in_vchWhID
                                AND item_number = @item_number
                                AND status = N'ACTIVE'
                                AND conversion_factor <= @leave_allocate_qty
                                AND conversion_factor < @uom_qty
                        ORDER BY conversion_factor DESC
                        SELECT  @v_nErrorNumber = @@ERROR ,
                                @v_nRowCount = @@ROWCOUNT
                        IF @v_nErrorNumber <> 0
                            OR @v_nRowCount = 0
                            BEGIN
                                BREAK;
                            END
                                

                        INSERT  INTO #tmp_rule_set
                                ( sequence ,
                                  pick_put_rule
                                )
                                SELECT  ppd.sequence ,
                                        ppr.before
                                FROM    t_item_uom itu ,
                                        t_pick_put_master ppm ,
                                        t_pick_put_detail ppd ,
                                        t_pick_put_rules ppr
                                WHERE   itu.pick_put_id = ppm.pick_put_id
                                        AND ppm.pick_put_id = ppd.pick_put_id
                                        AND ppd.rule_id = ppr.rule_id
                                        AND ppd.type = ppr.type
                                        AND ppd.type = 'RPLN'
                                        AND itu.wh_id = @in_vchWhID
                                        AND itu.item_number = @item_number
                                        AND itu.uom = @v_vchUOM
                        SELECT  @v_nErrorNumber = @@ERROR ,
                                @v_nRowCount = @@ROWCOUNT
                        IF @v_nErrorNumber <> 0
                            OR @v_nRowCount = 0
                            BEGIN
                                BREAK;
                            END
                        SET @v_nRuleCntr = 1 
                        SET @v_nNumOfRules = @v_nRowCount
            

                        WHILE @v_nRuleCntr <= @v_nNumOfRules
                            BEGIN
                                SELECT  @pick_put_id = pick_put_rule
                                FROM    #tmp_rule_set
                                WHERE   sequence = @v_nRuleCntr

                                EXEC @pick_put_id 
								@in_vchWhID, 
								@item_number,
                                @lot_number, 
								@leave_allocate_qty,
                                @stored_attribute_id,
                                @alloc_lot_number OUTPUT,
								@expiration_date OUTPUT,
                                @location_id OUTPUT, 
								@hu_id OUTPUT,
                                @alloc_qty OUTPUT,
								@damage_flag OUTPUT
                                IF @location_id IS NULL
                                    OR @alloc_qty = 0
                                    BEGIN
                                        SET @v_nRuleCntr = @v_nRuleCntr + 1
                                        CONTINUE
                                    END

                                SELECT TOP 1
                                        @zone = zone ,
                                        @pick_seq = pick_seq
                                FROM    t_zone_loca
                                WHERE   location_id = @location_id
						
                                SET @leave_allocate_qty = @leave_allocate_qty
                                    - @alloc_qty

                                SET @pick_type = 'R'

                                INSERT  INTO tbl_allocation
                                        ( wave_id ,
                                          order_number ,
                                          pick_id ,
                                          item_number ,
										  expiration_date ,
                                          lot_number ,
                                          stored_attribute_id ,
                                          location_id ,
                                          hu_id ,
                                          allocated_qty ,
                                          picked_qty ,
                                          status ,
                                          released_date ,
                                          ref_number ,
                                          pick_wall_loc ,
                                          pick_wall_slot ,
                                          pick_conveyor_node ,
                                          zone ,
                                          wh_id ,
                                          line_number ,
                                          picking_flow ,
                                          allo_type ,
                                          damage_flag
                                        )
                                        SELECT  pkd.wave_id AS wave_id ,
                                                @order_number AS order_number ,
                                                pkd.pick_id AS pick_id ,
                                                pkd.item_number AS item_number ,
												@expiration_date AS expiration_date ,
                                                @alloc_lot_number AS lot_number ,
                                                pkd.stored_attribute_id AS stored_attribute_id ,
                                                @location_id AS location_id ,
                                                @hu_id AS hu_id ,
                                                @alloc_qty AS allocated_qty ,
                                                0 AS picked_qty ,
                                                'U' AS status ,
                                                GETDATE() AS released_date ,
                                                @order_number AS ref_number ,
                                                NULL AS pick_wall_loc ,
                                                NULL AS pick_wall_slot ,
                                                NULL AS pick_conveyor_node ,
                                                @zone AS zone ,
                                                @in_vchWhID AS wh_id ,
                                                @line_number AS line_number ,
                                                @pick_seq AS picking_flow ,
                                                @pick_type AS allo_type ,
                                                @damage_flag AS damage_flag
                                        FROM    t_pick_detail pkd
                                        WHERE   pkd.pick_id = @pick_id

                            END
                    END



                SELECT  @allocated_qty = SUM(allo.allocated_qty)
                FROM    tbl_allocation allo ,
                        t_pick_detail pkd
                WHERE   allo.pick_id = pkd.pick_id
                        AND pkd.pick_id = @pick_id
                IF @allocated_qty > 0
                    BEGIN
                        UPDATE  t_pick_detail
                        SET     planned_quantity = @allocated_qty
                        WHERE   pick_id = @pick_id
                    END
            END


        IF @is_rollback = 'Y'
            BEGIN
                ROLLBACK;
            END
        ELSE
            BEGIN

                IF EXISTS ( SELECT  1
                            FROM    tbl_allocation alloc
                            WHERE   wh_id = @in_vchWhID
                                    AND order_number = @order_number
                                    AND alloc.allocated_qty - alloc.picked_qty > 0 )
                    BEGIN
                        UPDATE  t_pick_detail
                        SET     status = 'RELEASED'
                        WHERE   wh_id = @in_vchWhID
                                AND order_number = @order_number
                    END			

			
                DECLARE @sum_alloc_qty FLOAT
                DECLARE @sum_planned_qty FLOAT

                SELECT  @sum_alloc_qty = ISNULL(SUM(ABS(allocated_qty)), 0)
                FROM    tbl_allocation
                WHERE   wh_id = @in_vchWhID
                        AND order_number = @order_number

                SELECT  @sum_planned_qty = ISNULL(SUM(pkd.planned_quantity), 0)
                FROM    t_pick_detail pkd
                WHERE   pkd.order_number = @order_number
                        AND pkd.wh_id = @in_vchWhID

                IF @sum_alloc_qty <= @sum_planned_qty
                    COMMIT;

                IF @sum_alloc_qty > @sum_planned_qty
                    ROLLBACK;
            END
				
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        RETURN
    END CATCH
  
END
