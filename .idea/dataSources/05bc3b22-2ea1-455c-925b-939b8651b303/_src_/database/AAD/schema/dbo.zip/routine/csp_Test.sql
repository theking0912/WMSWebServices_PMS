-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Test]
@wh_id								AS	NVARCHAR(30)
AS
	
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @cnt1			int

    BEGIN TRANSACTION
	
	WHILE(1=1)
	BEGIN
		INSERT INTO t_aaa
		VALUES('1','2','3')


	END


	COMMIT
END
