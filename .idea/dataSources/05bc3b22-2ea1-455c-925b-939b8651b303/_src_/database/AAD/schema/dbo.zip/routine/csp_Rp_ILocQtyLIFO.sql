
CREATE PROCEDURE [dbo].[csp_Rp_ILocQtyLIFO]    
		@in_vchWhID NVARCHAR(10)
	,	@in_vchItemID nvarchar(30)
	,	@in_vchLot nvarchar(30)
	,	@in_fQuantiry FLOAT
	,   @in_stored_attribute_id BIGINT
	,	@out_vchLot nvarchar(30) output
	,   @out_expiration_date DATETIME OUTPUT
	,	@out_vchLocationID nvarchar(30) output
	,   @out_vchLp nvarchar(22)output
	,	@out_fAllocatedQty float output
	,   @out_damageflag  nvarchar(1) OUTPUT
AS    
BEGIN 
    DECLARE @Result    NVARCHAR(30)
	DECLARE @c_vchLocTypes    NVARCHAR(30)
	DECLARE @c_nStorageType	INT
	DECLARE @conversion_factor FLOAT
	BEGIN TRY
        SET @out_vchLocationID = ''
        SET @out_fAllocatedQty = 0
        SET @c_nStorageType = 0
        SET @Result = ''
        SET @c_vchLocTypes = 'I'

		SELECT @conversion_factor = ISNULL(iu.conversion_factor,0)
	    FROM   t_item_uom iu WITH(NOLOCK),t_item_master im with(nolock)
	    WHERE  iu.wh_id = im.wh_id
		AND    iu.item_number = im.item_number
	    AND    iu.uom = im.rp_uom
		AND    iu.status = N'ACTIVE'
		AND    im.wh_id = @in_vchWhID
	    AND    im.item_number = @in_vchItemID

        SELECT TOP 1
                @out_vchLocationID = ito.location_id ,
                @out_vchLot = ito.lot_number ,
				@out_expiration_date = ito.expiration_date ,
                @out_vchLp = ito.hu_id ,
                @out_fAllocatedQty = ito.actual_qty - ito.unavailable_qty - ISNULL(alloc.allocated_qty, 0),
                @out_damageflag = ito.damage_flag
        FROM    t_stored_item ito
                INNER JOIN t_zone_loca zl ON ito.wh_id = zl.wh_id
                                             AND ito.location_id = zl.location_id
                INNER JOIN t_location loc ON zl.wh_id = loc.wh_id
                                             AND zl.location_id = loc.location_id
                LEFT JOIN ( SELECT  location_id ,
                                    item_number ,
                                    wh_id ,
                                    SUM(ISNULL(allocated_qty, 0) - ISNULL(picked_qty, 0)) AS allocated_qty ,
                                    lot_number ,
                                    hu_id,
									stored_attribute_id
                            FROM    tbl_allocation
                            WHERE   item_number = @in_vchItemID
                                    AND ( @in_vchLot IS NULL
                                          OR lot_number = @in_vchLot
                                        )
                                    AND wh_id = @in_vchWhID
									AND allocated_qty > 0
									AND status !='C'
                            GROUP BY location_id ,
                                    item_number ,
                                    wh_id ,
                                    lot_number ,
                                    hu_id,
									stored_attribute_id
                          ) alloc ON ito.wh_id = alloc.wh_id
                                     AND ito.item_number = alloc.item_number
                                     AND ito.location_id = alloc.location_id
                                     AND ISNULL(ito.lot_number, '') = ISNULL(alloc.lot_number, '')
                                     AND ISNULL(ito.hu_id, '') = ISNULL(alloc.hu_id, '')
									 AND ISNULL(ito.stored_attribute_id, 0) = ISNULL(alloc.stored_attribute_id, 0)
        WHERE   ito.item_number = @in_vchItemID
                AND CHARINDEX(loc.type, @c_vchLocTypes) > 0
                AND ito.type = @c_nStorageType
                AND ( @in_vchLot IS NULL
                      OR ito.lot_number = @in_vchLot
                    )
                AND ito.wh_id = @in_vchWhID
                AND ito.actual_qty - ito.unavailable_qty >= @in_fQuantiry + ISNULL(alloc.allocated_qty, 0)
                AND ito.actual_qty - ito.unavailable_qty > ISNULL(alloc.allocated_qty, 0)
                AND loc.status NOT IN ( 'I', 'H' )
                AND ito.status = 'A'
                AND ( ito.stored_attribute_id = @in_stored_attribute_id
                      OR @in_stored_attribute_id IS NULL
                      OR EXISTS ( SELECT    fnc.stored_attribute_id
                                  FROM      usf_get_pick_attribute_id(@in_vchItemID,
                                                              @in_stored_attribute_id) fnc
                                  WHERE     fnc.stored_attribute_id = ito.stored_attribute_id )
                    )
        ORDER BY CHARINDEX(loc.type, @c_vchLocTypes) ,
                ito.fifo_date DESC ,
                zl.pick_seq ,
                loc.location_id

       IF @conversion_factor IS NOT NULL AND @conversion_factor != 0
		BEGIN
		   IF @out_fAllocatedQty > CEILING(1.0*@in_fQuantiry/@conversion_factor)*@in_fQuantiry
		    BEGIN
		      SET @out_fAllocatedQty = CEILING(1.0*@in_fQuantiry/@conversion_factor)*@in_fQuantiry
		    END
		    ELSE
		    BEGIN
		      SET @out_fAllocatedQty = @out_fAllocatedQty
		    END
		END
        RETURN
	END TRY

    BEGIN CATCH
        SET @out_vchLocationID = ''
        SET @out_fAllocatedQty = 0
        RETURN
    END CATCH
END

