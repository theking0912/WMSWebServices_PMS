

CREATE PROCEDURE [dbo].[csp_relase_wall_order_pick_status] 
@wave NVARCHAR(20),
@wall_id NVARCHAR(20),
@slot  NVARCHAR(20),
@wh_id NVARCHAR(10),
@user NVARCHAR(10),
@return_value int output

AS
    BEGIN TRAN
	--定义临时变量
	DECLARE @n1 INT, @customerCode NVARCHAR(50);
	--查询该槽位中的订单是否没有完成并且是已装载
	SELECT  @n1 = COUNT(*)
	FROM      (SELECT DISTINCT 
									 ta.wh_id, ta.wave_id, ta.order_number, ta.item_number, detail.wall_id, detail.slot, 
									 ISNULL(dbo.csf_get_lookup(N'tbl_allocation', N'STATUS', '2052', ta.status), '未开始') AS pick_status, 
									 ISNULL(dbo.csf_get_lookup(N't_pick_detail', N'STATUS', '2052', pd.status), '新增') AS order_status,
									 slot.customer_code
					 FROM      tbl_allocation AS ta INNER JOIN
									 tbl_pick_wall_slot_detail AS detail ON ta.order_number = detail.order_number AND 
									 ta.wh_id = detail.wh_id AND ta.ref_number = detail.wall_id AND ta.pick_wall_slot = detail.slot INNER JOIN
									 t_pick_detail AS pd ON detail.order_number = pd.order_number AND 
									 ta.item_number = pd.item_number LEFT JOIN
									 tbl_pick_wall_slot AS slot ON slot.slot = detail.slot AND slot.wall_id = detail.wall_id) AS tb
	WHERE   (slot = @slot) AND (wh_id = @wh_id) AND (wall_id = @wall_id) AND (pick_status = '完成') AND (wave_id = @wave) AND 
					(order_status = '已装载' OR
					order_status = '已暂存');
    IF(@n1 = 0)
        BEGIN
			SELECT  @customerCode = tb.customer_code
			FROM      (SELECT DISTINCT 
											 ta.wh_id, ta.wave_id, ta.order_number, ta.item_number, detail.wall_id, detail.slot, 
											 ISNULL(dbo.csf_get_lookup(N'tbl_allocation', N'STATUS', '2052', ta.status), '未开始') AS pick_status, 
											 ISNULL(dbo.csf_get_lookup(N't_pick_detail', N'STATUS', '2052', pd.status), '新增') AS order_status,
											 slot.customer_code
							 FROM      tbl_allocation AS ta INNER JOIN
											 tbl_pick_wall_slot_detail AS detail ON ta.order_number = detail.order_number AND 
											 ta.wh_id = detail.wh_id AND ta.ref_number = detail.wall_id AND ta.pick_wall_slot = detail.slot INNER JOIN
											 t_pick_detail AS pd ON detail.order_number = pd.order_number AND 
											 ta.item_number = pd.item_number
											 AND  pd.wh_id=ta.wh_id  --add by alice
											  LEFT JOIN
											 tbl_pick_wall_slot AS slot ON slot.slot = detail.slot AND slot.wall_id = detail.wall_id
											 and slot.wh_id=ta.wh_id  --add by alice
											 ) AS tb
			WHERE   (slot = @slot) AND (wh_id = @wh_id) AND (wall_id = @wall_id) AND (pick_status = '完成') AND (wave_id = @wave) AND 
							(order_status = '已装载' OR
							order_status = '已暂存');

			IF(ISNULL(@customerCode,'') != '')
				BEGIN
					INSERT INTO dbo.tbl_inf_dps_order_release
							( order_number ,
							  pick_wall_slot ,
							  create_date ,
							  inf_date ,
							  status ,
							  customer_code ,
							  wave_id
							)
					VALUES  ( N'%' , -- order_number - nvarchar(30)
							  @slot , -- pick_wall_slot - nvarchar(30)
							  GETDATE() , -- create_date - datetime
							  GETDATE() , -- inf_date - datetime
							  0 , -- status - int
							  @customerCode , -- customer_code - nvarchar(30)
							  @wave  -- wave_id - nvarchar(30)
							);

					--调用槽位释放
					EXEC dbo.csp_release_slot @slot = @slot, -- nvarchar(10)
						@wave_id = @wave, -- int
						@customer_code = @customerCode, -- nvarchar(50)
						@user = @user; -- nvarchar(30)
				   
					COMMIT
					SET @return_value = 0
			 END
		ELSE IF (ISNULL(@customerCode,'') = '')
			BEGIN
				ROLLBACK
				RAISERROR(N'释放失败！', 11, 1)    
				SET @return_value  = 1
			END
        END
    ELSE 
		BEGIN
			ROLLBACK
			RAISERROR(N'释放失败！', 11, 1)    
			SET @return_value  = 1
		END
