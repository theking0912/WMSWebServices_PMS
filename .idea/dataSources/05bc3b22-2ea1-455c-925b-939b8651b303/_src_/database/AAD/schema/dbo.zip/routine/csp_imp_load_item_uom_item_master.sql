 

CREATE  PROCEDURE [dbo].[csp_imp_load_item_uom_item_master]
  @DataID varchar(100),
  @process_status varchar(20)='NO',
  @MATNR varchar(100) 
AS
BEGIN Try
        declare @ZPOSITION  varchar(100)
        
        declare @UMREN  varchar(100)
        declare @MEINH  varchar(100)
        declare @UMREZ  varchar(100)
        declare @MEINS  varchar(100)
		declare @status varchar(100)
        declare @minuom varchar(100)
		declare @flag_minuom varchar(100)
		declare @decimal_UMREN float
		declare @decimal_UMREZ float
		declare @sap_base_uom nvarchar(30)
		declare @sapuom nvarchar(30)
		declare @sapuom_convert_factor float
		declare @MSEHL varchar(100)
		declare @MSEHT varchar(100)
    	declare @wh_id nvarchar(10)
		declare @client_code varchar(100)
		declare @retint INT,@retint_all int
		declare @process_msg NVARCHAR(100)  
		set @retint_all=0

		declare @data_idkey bigint

		select top 1 @wh_id= wh_id, @ZPOSITION=zposition,@data_idkey=data_idkey  
		from tbl_inf_imp_master WITH(NOLOCK)  where data_id=@DataID

--		select top 1  @client_code=client_code  from t_client WITH(NOLOCK)  where wh_id=@wh_id
        set @client_code = ''
           WHILE 1=1
	         BEGIN
	         select top 1 @client_code = client_code  from t_client where wh_id=@wh_id and client_code > @client_code order by client_code asc
	        if @@ROWCOUNT = 0
	           break; 
		select  top 1 @sap_base_uom=ISNULL(uom,'') FROM  t_item_master WITH(NOLOCK) 
		where wh_id=@wh_id and item_number=@client_code+'-'+@MATNR
	
		update tbl_inf_imp_item_uom  
		set DATA_IDKEY=@data_idkey  
		where DATA_ID=@DataID and  isnull(DATA_IDKEY,0)=0
 
		IF  (isnull(object_id('tempdb..#returnresult'),0) =0 ) 
		begin
			create table #returnresult(outint1 int,outstr1 nvarchar(64),outstr2 nvarchar(256))
		END

		--1.set status tbl_inf_imp_item_uom ACTION='U'
		update  tbl_inf_imp_item_uom
		set ACTION='U' 
		FROM tbl_inf_imp_item_uom a,
		     tbl_sap_item_uom b
	    where a.MATNR=b.MATNR and a.MEINH=b.MEINH and a.MATNR=@MATNR and a.DATA_ID=@DataID

		--2.update tbl_inf_imp_item_uom ACTION='U'
		update tbl_sap_item_uom 
		set UMREN=b.UMREN,
			UMREZ=b.UMREZ,
			CONVERT_FACTOR=CAST(b.UMREZ AS int)/cast(b.UMREN as int),
			MEINH_PROMPT=b.MSEHL, 
			MEINS_PROMPT=b.MSEHT,
			STATUS='ACTIVE'
		from tbl_sap_item_uom a,
		    (select * from tbl_inf_imp_item_uom where MATNR=@MATNR and DATA_ID=@DataID and ACTION='U') b
	    where a.MATNR=b.MATNR
 
	    --3.add new tbl_inf_imp_item_uom ACTION='A'
		insert into tbl_sap_item_uom(ZPOSITION,wh_id,MATNR,
															UMREN,
															MEINH,
															UMREZ,
															MEINS,
															FLAG_MINUOM,
															CONVERT_FACTOR,
															MEINH_PROMPT,
															MEINS_PROMPT,
															STATUS,
															FLAG_WMS_DELETE)
		select     @ZPOSITION
															,@wh_id
															,MATNR
															,UMREN
															,MEINH
															,UMREZ
															,MEINS
															,'N'
															,CAST(UMREZ AS int)/cast(UMREN as int)
															,MSEHL
															,MSEHT
															,'ACTIVE'
															,'N'
		from  tbl_inf_imp_item_uom 
		where MATNR=@MATNR and DATA_ID=@DataID and ACTION='A'

		--4. add sap base uom
		if not exists(select top 1 * from tbl_inf_imp_item_uom where MATNR=@MATNR  and MEINH=@sap_base_uom)
		BEGIN
			insert into tbl_sap_item_uom(ZPOSITION,wh_id,MATNR,
															UMREN,
															MEINH,
															UMREZ,
															MEINS,
															FLAG_MINUOM,
															CONVERT_FACTOR,
															MEINH_PROMPT,
															MEINS_PROMPT,
															STATUS,
															FLAG_WMS_DELETE)
		    select   top 1  @ZPOSITION
															,@wh_id
															,MATNR
															,1
															,MEINS
															,1
															,MEINS
															,'N'
															,1
															,MSEHT
															,MSEHT
															,'ACTIVE'
															,'N'
			from  tbl_inf_imp_item_uom
			where MATNR=@MATNR and DATA_ID=@DataID
        end

		 

	    --4.set INACTIVE for tbl_sap_item_uom

 
		/*update tbl_inf_imp_item_uom 
		set PROCESS_STATUS='YES' 
		where DATA_ID=@DataID 
				and PROCESS_STATUS=@process_status  
				and MATNR=@MATNR 
				and MEINH=@MEINH 
				and MEINS=@MEINS*/
 
		update tbl_sap_item_uom
		set STATUS='INACTIVE'
		from tbl_sap_item_uom 
		where MATNR=@MATNR  
			        and  MEINH not in (select MEINH  from tbl_inf_imp_item_uom where MATNR=@MATNR and DATA_ID=@DataID)
					and  MEINH<>MEINS and isnull(FLAG_MINUOM,'N')<>'Y'
 
		      --update uom status
			  update t_item_uom
			  set status=b.STATUS
			  from t_item_uom a,tbl_sap_item_uom b
			  where a.wh_id=@wh_id and a.item_number=@client_code+'-'+b.MATNR and a.item_number=@client_code+'-'+@MATNR  and a.uom=b.MEINH

		--
		if not exists(select TOP 1 *  from t_item_master  WITH(NOLOCK) where item_number=@client_code+'-'+@MATNR )
		BEGIN
			select @retint_all=-999,@retint=-101,@process_msg=@process_msg+N';不存在的物料:'+@MATNR
			update tbl_inf_imp_item_uom 
			set SUCCESS_STATUS='NO',PROCESS_MSG=@process_msg 
			where DATA_ID=@DataID  and MATNR=@MATNR
			goto update_item_uom_status
		END

		DECLARE @ret_status VARCHAR(20)
		if exists(  select top 1 * from tbl_sap_item_uom  where MATNR=@MATNR  and isnull(FLAG_MINUOM,'N')='Y' and STATUS='ACTIVE')
		BEGIN
				BEGIN TRY

						exec csp_imp_load_item_uom_conversion  @wh_id,@MATNR,@ret_status OUTPUT,@process_msg OUTPUT,1

						if (@ret_status='S')
							select @retint=1,@process_msg=N'成功.' 
						else
							select @retint_all=-999,@retint=-101,@process_msg=N'同物料批失败;'+@process_msg
				END try
				BEGIN CATCH 
						select @retint_all=-999,@retint=-101,@process_msg=N'执行异常:'+substring(ERROR_MESSAGE(),1,90)
				END CATCH
		END
		ELSE
		BEGIN 
			select  @retint=100,@process_msg=N'提醒:WMS未设置最小单位的物料:'+@MATNR
		END
  

     update_item_uom_status:
	 
	 declare  @target_rows int,@retall int

	select  @target_rows=COUNT(DATA_ID)  from tbl_inf_imp_item_uom  
	where DATA_ID=@DataID and isnull(SUCCESS_STATUS,'NO')='YES'

	 UPDATE tbl_inf_imp_master
	 SET  target_rows=@target_rows,
		  process_status=case WHEN source_rows=@target_rows then 'YES' else 'NO' END,
	      process_msg=case WHEN source_rows=@target_rows THEN N'SAP->WMS单位换算成功'
		                   WHEN @target_rows>0 THEN N'SAP->WMS单位换算部分处理成功,请检查错误日志' 
						   ELSE N'SAP->WMS单位换算全部未处理，请检查错误日志'  end
	 where  data_id=@DataID


	 select top 1 @retall=case when process_status='YES' then 101  else -101 end,
	              @process_msg=process_msg
	 from tbl_inf_imp_master
	 where data_id=@DataID

     insert into #returnresult values(@retall,CAST(@target_rows AS varchar),@process_msg)
   END
END TRY
BEGIN CATCH  -- Outer CATCH
    delete from  #returnresult
	declare  @succes_rows int
	select   @succes_rows=COUNT(DATA_ID)  from tbl_inf_imp_item_uom  
	where DATA_ID=@DataID and isnull(SUCCESS_STATUS,'NO')='YES'

	DECLARE @error NVARCHAR(100)
	print @@ERROR
	print ERROR_MESSAGE()
    SET @error='执行1异常:'+substring(ERROR_MESSAGE(),1,90)
    Update  tbl_inf_imp_master  
	set process_msg=@error,
		target_rows=@succes_rows,
		process_status='NO'  
	where data_id=@DataID

    insert into #returnresult values(-101,'0',@error)
END CATCH 
 



