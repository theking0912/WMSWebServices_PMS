-- =======================================    
-- Author: Tony.chen    
-- Create Date: 13 Nov 2013    
-- Description: check the LP is ok or not for rtn receipt
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_QC_ScanSKU_Check]    
     @wh_id				Nvarchar(10)
	,@control_number	Nvarchar(30)
	,@item_number		Nvarchar(30)
	,@hu_id				Nvarchar(30)
	,@location_id		nvarchar(30)
	,@type				Nvarchar(30)  --D:Damage; B:Blind; N:Normal
	,@locale_id			nvarchar(30)
	,@passornot			Nvarchar(10) OUTPUT
	,@msg				Nvarchar(200) OUTPUT
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @zone_type		nvarchar(30)
		DECLARE @hu_zone_type	nvarchar(10)
		DECLARE @hu_location	nvarchar(30)
		DECLARE @client_code	nvarchar(30)
		DECLARE @special_zone	nvarchar(30)
		DECLARE @cnt			nvarchar(30)

		SET @passornot = 0
		--Check the item is OK or not
		IF @type <> 'B'
			BEGIN
				IF NOT EXISTS( SELECT 1 FROM t_rcpt_ship_po_detail
								WHERE wh_id = @wh_id
								and item_number = @item_number
								and shipment_number = @control_number)
					BEGIN
						SET @passornot = 1
						SET @msg = [dbo].[usf_get_locale_text]( 'ITEM_NOT_ON_PO','constant',@locale_id,'CONSTANT')
						RETURN
					END
			END
		ELSE
			BEGIN
				IF EXISTS( SELECT 1 FROM t_rcpt_ship_po_detail
								WHERE wh_id = @wh_id
								and item_number = @item_number
								and shipment_number = @control_number)
					BEGIN
						SET @passornot = 1
						SET @msg = [dbo].[usf_get_locale_text]( 'ITEM_ON_PO','constant',@locale_id,'CONSTANT')
						RETURN
					END
			END

		--Check the LP has been exists or not
		SELECT @hu_zone_type = subtype
			,@hu_location = location_id
		FROM t_hu_master 
		WHERE wh_id = @wh_id 
		AND hu_id = @hu_id
		
		IF @@ROWCOUNT = 0 
			BEGIN
				SET @passornot = 0
				RETURN
			END 
	
		SET @zone_type = [dbo].[fn_Get_ZoneType_ByItem](@wh_id,@item_number,@type)

		IF @zone_type <> @hu_zone_type
			BEGIN
				SET @passornot = 2
				SET @msg = [dbo].[usf_get_locale_text]( 'CANNOT_USE_CUR_HU','constant',@locale_id,'CONSTANT')
				RETURN
			END
		ELSE
			BEGIN
				IF @hu_zone_type = 'BV' OR @hu_zone_type = 'CV'
					BEGIN
						SELECT @client_code = client_code
						FROM t_item_master
						WHERE wh_id = @wh_id
						AND item_number = @item_number

						IF NOT EXISTS ( SELECT 1
									FROM t_stored_item sto 
										 inner join t_item_master itm on sto.wh_id = itm.wh_id
								          						and sto.item_number = itm.item_number
									WHERE sto.wh_id = @wh_id
									and sto.hu_id = @hu_id
									and itm.client_code = @client_code)
							BEGIN
								SET @passornot = 2
								SET @msg = [dbo].[usf_get_locale_text]( 'CANNOT_USE_CUR_HU','constant',@locale_id,'CONSTANT')
								RETURN
							END
					END
			 END
	


        RETURN

    END TRY

    BEGIN CATCH
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END
