-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Check_Scan_Qty]
(
	@in_qty		AS	DECIMAL(18,2),
	@in_uom_cf	AS	INT
)
RETURNS NVARCHAR(10)
AS
BEGIN
	-- Declare the return variable here
	DECLARE		@max_qty		AS	INT
	DECLARE		@out_result		AS	NVARCHAR(10)
	DECLARE		@barcode_start	AS	INT
	DECLARE		@barcode_length	AS	INT
	DECLARE		@barcode_divide	AS	INT
	
	--SELECT @barcode_start = barcode_start
	--		,@barcode_length = barcode_length
	--		,@barcode_divide = barcode_divide
	--		FROM t_item_master WITH(NOLOCK)
	--		WHERE wh_id = 'HDL01'
	--			AND item_number = ''
	
	--SELECT @in_qty = SUBSTRING(CONVERT(NVARCHAR,@in_qty),@barcode_start,@barcode_length) / @barcode_divide

    SELECT @max_qty = ISNULL(c1,0) FROM t_control WHERE control_type = 'SCAN_MAX_QTY'
	
	IF @in_qty > @max_qty
	BEGIN
		SET @out_result = '1'
		RETURN @out_result
	END

	IF (@in_qty * @in_uom_cf) <> CEILING(@in_qty * @in_uom_cf)
	BEGIN
		SET @out_result = '1'
		RETURN @out_result
	END

	SET @out_result = '0'

	RETURN @out_result
END

