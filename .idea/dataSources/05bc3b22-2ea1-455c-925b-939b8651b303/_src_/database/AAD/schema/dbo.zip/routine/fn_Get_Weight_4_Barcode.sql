
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_Weight_4_Barcode]
(
	@barcode		AS	NVARCHAR(200),
	@item_number	AS	NVARCHAR(30),
	@wh_id			AS	NVARCHAR(20)
)
RETURNS FLOAT
AS
BEGIN
	-- Declare the return variable here
	DECLARE		@flt_qty		AS	FLOAT
	DECLARE		@out_result		AS	NVARCHAR(10)
	DECLARE		@barcode_start	AS	INT
	DECLARE		@barcode_weigth_length	AS	INT
	DECLARE		@barcode_rate	AS	FLOAT
	
	--SELECT @barcode_start = barcode_start
	--		,@barcode_weigth_length = barcode_weight_length
	--		,@barcode_rate = barcode_rate
	--		FROM t_item_master WITH(NOLOCK)
	--		WHERE wh_id = @wh_id
	--			AND item_number = @item_number
	
	--IF ISNULL(@barcode_start,0) <> 0 AND ISNULL(@barcode_weigth_length,0) <> 0 AND ISNULL(@barcode_rate,0) <> 0 
	--BEGIN
	--	SELECT @flt_qty = CONVERT(FLOAT,SUBSTRING(@barcode,@barcode_start,@barcode_weigth_length)) * @barcode_rate

	--	IF @flt_qty = 0
	--	BEGIN
	--		SET @flt_qty = @barcode
	--	END
	--END
	--ELSE
	--BEGIN
	--	SET @flt_qty = @barcode
	--END
	SET @flt_qty = @barcode  ------will add
	    
	RETURN @flt_qty
END


