

CREATE PROCEDURE [dbo].[csp_during_put]
@in_zone_type     NVARCHAR(10),
@in_vchWhID         NVARCHAR(10),
@in_put_type		NVARCHAR(10), -- M:Manual S:System
@out_put_location_id	NVARCHAR(30)	OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @nvch_location_id		AS	NVARCHAR(30)
	DECLARE	@nvch_pick_seq			AS	NVARCHAR(30)

    SELECT  TOP 1  @nvch_location_id = tzl.location_id
				,@nvch_pick_seq = tzl.pick_seq 
		FROM t_zone_loca tzl with(nolock)
		INNER JOIN t_zone tz WITH(NOLOCK)
		ON tzl.wh_id = tz.wh_id
		AND tzl.zone = tz.zone
		INNER JOIN t_location  tl with(nolock)
		ON tzl.location_id = tl.location_id
		AND tzl.wh_id = tl.wh_id
		AND tl.item_hu_indicator = 'H'
		WHERE (NOT EXISTS ( SELECT TOP 1 location_id
							FROM t_stored_item WHERE location_id = tzl.location_id  )
			 OR EXISTS(SELECT location_id FROM dbo.t_hu_master WITH(NOLOCK)
							WHERE location_id = tzl.location_id 
							GROUP BY location_id
							HAVING COUNT(location_id) < ISNULL(tl.hu_count,1))
				)
		AND tz.zone_type + tz.zone_group = @in_zone_type
		AND tl.wh_id = @in_vchWhID		
		AND NOT EXISTS(SELECT 1 FROM tbl_zone_staging WITH(NOLOCK) WHERE wh_id = tl.wh_id AND location_id = tl.location_id)
		ORDER BY pick_seq

		IF ISNULL(@nvch_location_id,'') = ''
		BEGIN
			SELECT  TOP 1  @nvch_location_id = tzl.location_id
						,@nvch_pick_seq = tzl.pick_seq 
				FROM t_zone_loca tzl with(nolock)
				INNER JOIN t_zone tz WITH(NOLOCK)
				ON tzl.wh_id = tz.wh_id
				AND tzl.zone = tz.zone
				INNER JOIN t_location  tl with(nolock)
				ON tzl.location_id = tl.location_id
				AND tzl.wh_id = tl.wh_id
				AND tl.item_hu_indicator = 'I'
				WHERE (NOT EXISTS ( SELECT TOP 1 location_id
									FROM t_stored_item WHERE location_id = tzl.location_id  )					 
						)
				AND tz.zone_type + tz.zone_group = @in_zone_type
				AND tl.wh_id = @in_vchWhID
				ORDER BY pick_seq
		END

	
		--SET @out_put_location_id = @nvch_location_id
		SET @out_put_location_id = ''  -----------

  GOTO ExitLabel

--ErrorHandler:  上架数量

   -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- This is the application's way of knowing there was an error in this sproc.  Be sure the app
    -- looks at this field immediately after running the sproc.
    --UPDATE t_employee SET sp_return = 'PROC ERROR' WHERE id = @in_vchEmpID AND @in_vchWhID = wh_id
    
    -- Raise the error with error message, severity, state
    --SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
    --    + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
    --    + ' ERROR [' + @v_vchErrorMsg + ']'
    --RAISERROR(@v_vchErrorMsg, 11, 1)    

ExitLabel:
  RETURN
END
