-- Procedure
CREATE PROCEDURE [dbo].[csp_ReGenAll_Cycle_Count]    
     @wh_id				    NVARCHAR(10)   
	 ,@user_id				NVARCHAR(30)
AS

DECLARE 
    @v_nErrorNumber	  INT,
    @v_nLogLevel	  TINYINT,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INT,

    @c_nModuleNumber      INT,
    @c_nFileNumber        INT,
    @v_nRaiseErrorNumber  INT,
    @v_nReturn            INT,
    @v_vchErrorMsg        NVARCHAR(200),
	--ADD BY David
	@v_datedue            DATETIME,

-- Error Types
    @e_GenSqlError   	  INT,
    @e_InsWKQFailed       INT,
    @e_SprocError         INT,

    @v_nLoopCount         INT,
    @v_vchDescription     NVARCHAR(30),
    @v_vchWorkqId         NVARCHAR(30),
    @v_vchWhId            NVARCHAR(10),    
    @v_vchLocationId      NVARCHAR(50),
	@loop_loc			  nvarchar(30)

    SET NOCOUNT ON

    SET @c_nModuleNumber = 63
    SET @c_nFileNumber = 8
	SET @v_datedue = GETDATE()
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_InsWKQFailed = 2
    SET @e_SprocError = 3
	
	--2014/03/24 Added by Tony start
	declare @wrok_q_id_start BIGINT
	declare @wrok_q_id_end BIGINT
	declare @loc_qty BIGINT
	
	select @loc_qty = count(1)
	 FROM tbl_cyclecount_history a
		 inner join t_work_q wq on a.wh_id = wq.wh_id and a.work_q_id = wq.work_q_id
     WHERE ISNULL(a.close_sign,'N') = 'N'
	 AND a.wh_id = @wh_id
	 and not exists (select 1 from t_location l
							where a.location_id = l.location_id
							and l.status = 'I')
	 AND NOT EXISTS(SELECT 1 FROM t_work_q b
	                WHERE b.wh_id = wq.wh_id
					and ISNULL(b.item_number,'') = ISNULL(wq.item_number,'')
					AND (b.work_status ='U' OR b.work_status ='A')
					and b.location_id = wq.location_id)
	 group by wq.location_id, wq.item_number
		
	IF @loc_qty > 0 
		BEGIN
			 EXECUTE @v_nReturn = usp_get_next_value_range 'WORK_Q_ID', @loc_qty,@wrok_q_id_start OUTPUT,@wrok_q_id_end OUTPUT,
						@v_nErrorNumber OUTPUT, @v_vchErrorMsg OUTPUT

			SET @v_vchWorkqId = @wrok_q_id_start

			INSERT INTO t_work_q (work_q_id, wh_id, location_id, work_type, work_status, 
							description, priority, workers_required, date_due, time_due)
			select ROW_NUMBER() OVER(ORDER BY wq.location_id) + @v_vchWorkqId -1 , wq.wh_id, wq.location_id,
							 '08', 'U', max(wq.description), '90', 1, @v_datedue, @v_datedue
			FROM tbl_cyclecount_history a
					inner join t_work_q wq on a.wh_id = wq.wh_id and a.work_q_id = wq.work_q_id
			WHERE  ISNULL(a.close_sign,'N') = 'N'
			 AND a.wh_id = @wh_id
			 and a.discrepancy_type = '1'
			 and not exists (select 1 from t_location l
							where a.location_id = l.location_id
							and l.status = 'I')
			 AND NOT EXISTS(SELECT 1 FROM t_work_q b
							WHERE b.wh_id = wq.wh_id
							and ISNULL(b.item_number,'') = ISNULL(wq.item_number,'')
							AND (b.work_status ='U' OR b.work_status ='A')
							and b.location_id = wq.location_id)
			group by wq.wh_id,wq.location_id, wq.item_number
		END

	UPDATE tbl_cyclecount_history
	SET close_by = @user_id
	,close_sign ='Y'
	,close_time = getdate()
	,close_type ='REGEN CC'
	WHERE wh_id = @wh_id
	AND ISNULL(close_sign,'N') = 'N'

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_InsWKQFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An attempt to insert a cycle count task for location ' +
            ISNULL(@v_vchLocationId,'(NULL)') + ' into ' +
            ' the t_work_q table failed.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50002 -- Insert failed
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(varchar(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

ExitLabel:
    SET NOCOUNT OFF
    RETURN
