-- =============================================
-- Author           :Tony.Chen
-- Create date      :Nov 18, 2013
-- Description      :Check Serialno Info for putaway
-- Modification     :
-- =============================================
Create PROCEDURE [dbo].[csp_Check_Serialno_ForPack]
    -- Add the parameters for the stored procedure here
    @wh_id					nvarchar(10),
    @serial_no				nvarchar(30),
    @item_number			nvarchar(30),
	@source_hu_id			nvarchar(30),
    @passornot				int output  ,--0 pass|1 fail
    @msg					nvarchar(200) output

AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    BEGIN TRY
		IF NOT EXISTS ( SELECT 1 FROM tbl_sn_master
					WHERE wh_id = @wh_id
					AND item_number = @item_number
					and serial_number = @serial_no
					)
			BEGIN
				 --Invalid SN
				 SET @passornot = 1
				 RETURN
			END

		IF EXISTS ( SELECT 1 FROM tbl_sn_master
					WHERE wh_id = @wh_id
					AND item_number = @item_number
					AND serial_number = @serial_no
					AND status ='PACK')
			BEGIN
				 --Duplicated scan
				 SET @passornot = 2
				 RETURN
			END

    END TRY

    BEGIN CATCH
        SET NOCOUNT OFF
        SET @msg = ERROR_MESSAGE()
        SET @passornot=1
        RETURN
    END CATCH

END
