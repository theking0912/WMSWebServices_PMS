
-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Allocation Zone for put
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Wave_Release_By_B2C]    
     @wh_id				NVARCHAR(10)   
    ,@wave_id		    NVARCHAR(30) 
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY

		
		DECLARE @wave_type		NVARCHAR(20)
		DECLARE @order_number	NVARCHAR(30)
		DECLARE @status			NVARCHAR(20)
		DECLARE @ptl_percent	float
		DECLARE @cnt_total_slot	float
		DECLARE @cnt_empty_slot	float
		DECLARE @empty_percent	float
		DECLARE @max_allocation	float
		DECLARE @detail_id		int
		DECLARE @cnt			int
		DECLARE @cnt_released	int
		DECLARE @assigned_cnt	int
		DECLARE @cnt_noreleased INT


		select @status = status,@wave_type = wave_type
		from t_wave_master
		where wh_id = @wh_id
		and   wave_id = @wave_id

		select @max_allocation = f1
		from t_control
		where control_type = 'ALLOCATION_QTY'

		if(@status not in ('N','P') or @wave_type <> 'B2C')
			return;
		
		set @detail_id = 0

		while(1=1)
		begin
			
			select top 1 @order_number = o.order_number, @detail_id=wd.wave_detail_id
			from  t_afo_wave_detail wd inner join t_order o on wd.wh_id = o.wh_id and wd.order_number = o.order_number 
			where o.status = 'WAVED' 
			and wd.wh_id = @wh_id 
			and wd.wave_id = @wave_id
			and wd.wave_detail_id > @detail_id
			order by wd.wave_detail_id
			if @@ROWCOUNT = 0
			break;

			-- insert into pkd
			if(not exists(select 1 from t_pick_detail pkd
							where pkd.order_number = @order_number
							and pkd.wh_id = @wh_id))
			INSERT INTO t_pick_detail (
			order_number, line_number, type, status, item_number, 
			lot_number, unplanned_quantity, planned_quantity, picked_quantity, 
			wave_id,wh_id,stored_attribute_id,pick_location)
			SELECT @order_number	AS order_number, 
				wdl.line_number		AS line_number, 
				'BC'				AS type, 
				'UNPLANNED'			AS status,
				wdl.item_number		AS item_number, 
				(CASE when wdl.lot_number='' then null else wdl.lot_number end)		AS lot_number, 
				0					AS unplanned_quantity,
				wdl.planned_qty		AS planned_quantity, 
				0					AS picked_quantity,
				wd.wave_id			AS wave_id,
				@wh_id				AS wh_id,
				null				AS stored_attribute_id,
				''					AS pick_location
			FROM t_afo_wave_detail wd inner join t_afo_wave_detail_line wdl on wdl.wh_id = wd.wh_id and wdl.wave_detail_id = wd.wave_detail_id
			where wd.wh_id = @wh_id
			and wd.order_number = @order_number
			else
			update t_pick_detail
			set wave_id = @wave_id
			where order_number = @order_number
			and wh_id = @wh_id
			and wave_id <> @wave_id
			
			exec csp_Order_Allocation_B2C @wh_id,@order_number

			set @max_allocation = @max_allocation - 1
			if @max_allocation <= 0
			break

		end

		-- update wave status/release date
		--select @cnt = count(0),@cnt_released = sum((case when o.status = 'RELEASED' then 1 else 0 end))
		select @cnt = count(0),@cnt_noreleased = sum((case when o.status = 'WAVED' then 1 else 0 end))
		from  t_afo_wave_detail wd inner join t_order o on wd.wh_id = o.wh_id and wd.order_number = o.order_number 
		where wd.wh_id = @wh_id 
		and wd.wave_id = @wave_id

		--if @cnt = @cnt_released
		if @cnt_noreleased = 0
		update t_wave_master
		set status = 'R'
		,	released_date = getdate()
		where wh_id = @wh_id
		and wave_id = @wave_id

		-- update status to partial
		if @cnt > @cnt_noreleased and @cnt_noreleased > 0
		update t_wave_master
		set status = 'P'
		,	released_date = getdate()
		where wh_id = @wh_id
		and wave_id = @wave_id

		---- check the usable percent of PTL' slots
		--select @ptl_percent = f1
		--from t_control
		--where control_type = 'PTL_PERCENT'

		--select @cnt_total_slot = count(1),@cnt_empty_slot = sum(case when pws.status = 'U' then 1 else '0' end)
		--from tbl_pick_wall_slot pws, tbl_pick_wall pw
		--where pws.wh_id = pw.wh_id
		--and pws.wall_id = pw.wall_id
		--and pw.status = 'A'

		--if @cnt_empty_slot is null or @cnt_empty_slot = 0
		--set @empty_percent = 0
		--else
		--set @empty_percent = (@cnt_empty_slot/@cnt_total_slot)

		--if @empty_percent < @ptl_percent
		--return;

		---- assign order to PTL
		----Exec 
		--exec csp_Assign_Order2PTL @wh_id,@wave_id,@assigned_cnt
			
        RETURN

    END TRY

    BEGIN CATCH
        
        RETURN
    END CATCH
  
END

