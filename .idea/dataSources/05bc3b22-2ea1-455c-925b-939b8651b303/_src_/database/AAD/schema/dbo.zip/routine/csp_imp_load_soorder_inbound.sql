
 

CREATE  PROCEDURE [dbo].[csp_imp_load_soorder_inbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id varchar(100),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG varchar(100)
	   
AS
BEGIN
		/*
		//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //VBAK-VBELN	订单号
        //VBAK-AUART	订单类型
        //VBAK-KUNNR	客户编码
        //VBAK-AUDAT	订单日期
        //VBEP-EDATU    计划行日期
        //VBAK-VKORG	销售组织
        //VBAP-CMPRE	含税单价
        //VBAP-KZWI1	总金额

        //ZFLAG	        出入库标识
        //VBAP-POSNR	行号
        //VBAP-MATNR	物料号
        //VBAP-KWMENG	订单数量
        //VBAP-VRKME	订单单位
        //KONV-NETPR	净价
        //VBAP-KPEIN	价格单位
        //VBAP-WERKS	发货工厂
        //VBAP-UEBTO	过量交货
        //VBAP-UNTTO	交货不足
        //ABGRU         删除标注
		
		*/
        declare @ZPOSITION varchar(100)
        declare @VBELN varchar(100)
        declare @AUART varchar(100)
        declare @KUNNR varchar(100)
        declare @AUDAT varchar(100)
		declare @EDATU varchar(100)

		declare @VKORG varchar(100)
		declare @CMPRE varchar(100)
		declare @KZWI1 varchar(100)
   
        declare @POSNR varchar(100)
        declare @MATNR varchar(100)
        declare @KWMENG varchar(100)
        declare @VRKME varchar(100)
        declare @NETPR varchar(100)
        declare @KPEIN varchar(100)
        declare @WERKS varchar(100)
        declare @UEBTO varchar(100)
        declare @UNTTO varchar(100)
        declare @ABGRU varchar(100)

	    declare @order_typeid int
		declare @order_type varchar(100)
		declare @cancel_flag varchar(100)
		declare @customer_id int
		declare @customer_name varchar(100)
	 
	  	/*if exists(select top 1 * from t_po_master  WITH(NOLOCK) where po_number=@order_no  and status<>'O')
		begin
		   insert into #returnresult values(-101,'Fail','订单号['+@order_no+']订单状态已经变化，不能修改.')
		   return
		end


		if exists(select top 1 * from t_po_detail  WITH(NOLOCK) where po_number=@order_no and line_number=@line_no and complete_flag='Y')
		begin
		   insert into #returnresult values(-101,'Fail','订单号['+@order_no+']-行号['+@line_no+']订单明细处理状态已经完成，不能修改.')
		   return
		end
		*/

		if exists(SELECT 1 from t_rcpt_ship trs WITH(NOLOCK) 
					 INNER JOIN t_rcpt_ship_po rsp WITH(NOLOCK) 
					 ON trs.wh_id = rsp.wh_id
					 AND trs.shipment_number = rsp.shipment_number
					 WHERE   rsp.po_number = @order_no  and  trs.wh_id =@wh_id
					 AND (status <> 'C' 
					      OR (ISNULL(trs.is_confirm,'N') = 'N' 
						       AND EXISTS(SELECT 1 FROM t_control WHERE control_type = 'C_RECEIPT_CONFIRM' AND c1='Y')
						     )
                         )
					)
		begin
				insert into #returnresult values(-101,N'Fail',N'订单号['+@order_no+N'],入库单下存在未关闭的 运单，SAP提示不能更新该入库单')
		         RETURN
		end

		 select top 1    @ZPOSITION = ZPOSITION
						,@VBELN = VBELN
						,@AUART = AUART
						,@KUNNR = KUNNR
						,@AUDAT = AUDAT
						,@ZFLAG = ZFLAG
						,@EDATU=  isnull(EDATU,'') 

						,@VKORG=VKORG
						,@CMPRE=CMPRE
						,@KZWI1=KZWI1

						,@POSNR = POSNR
						,@MATNR = MATNR
						,@KWMENG= KWMENG
						,@VRKME = VRKME
						,@NETPR = NETPR 
						,@KPEIN = KPEIN
						,@WERKS = WERKS
						,@UEBTO = UEBTO
						,@UNTTO = UNTTO
						,@ABGRU = ABGRU
		  from  tbl_inf_imp_soorder   WITH(NOLOCK) 
		  where DATA_ID=@DataID and PROCESS_STATUS=@process_status 
				and VBELN=@order_no and POSNR=@line_no and ZFLAG=@ZFLAG


		 if  (@EDATU='' or @EDATU='00000000') set @EDATU=null

		 select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype   WITH(NOLOCK) 
		 where sap_ordertype=@AUART   and flag_inoutbound=@ZFLAG 

		 if (@ABGRU='X') 
		 begin
		      set @cancel_flag='Y'
		 end
		 else 
		      set @cancel_flag='N'

	

    if not exists(select top 1 po_number from t_po_master  WITH(NOLOCK) where po_number=@order_no)
	    insert into t_po_master( po_number 
							  , type_id 
							  , create_date 
							  , wh_id 
							  , status 
							  , display_po_number 
							  , client_code 
							  , residential_flag 
							  , locked_flag 
							  ,sap_ordertype
							  )
					values( @order_no
					            ,@order_typeid
								,cast(@AUDAT as date)
								,@wh_id
								,'O'
								,@order_no
								,@client_code
								,'N'
								,'N'
								,@AUART)
					 
	else
		   update t_po_master
		   set   type_id=@order_typeid,
				 create_date=cast(@AUDAT as date),
				 sap_ordertype=@AUART
		   from  t_po_master 
		   where  po_number=@order_no 


	declare @storage_location1 nvarchar(30), @storage_location2 nvarchar(30)
	select  @storage_location2=@WERKS, @storage_location1=''
 
	if not exists(select top 1  po_number from t_po_detail WITH(NOLOCK)  where  po_number=@order_no and line_number=@line_no)
	   insert into  t_po_detail(po_number
							  ,line_number
							   ,wh_id
							   ,item_number
							  ,qty
							  ,order_uom
							 -- ,more_qty
							 -- ,less_qty
							 --,upper_percent
							 -- ,lower_percent
							  ,cancel_flag
							  ,price 
							  ,price_uom
							  ,storage_location
							  ,factory
							  ,complete_flag
							  ,delivery_date
							  ,schedule_number
							  )
							  values(@order_no,
							         @line_no, 
									 @wh_id,
									 @WERKS+'-'+@MATNR,
									 cast(@KWMENG as float),
									 @VRKME
									 ,@cancel_flag
									 ,@NETPR
									 ,@KPEIN
									 ,@storage_location1
									 ,@storage_location2
									 ,'N'
									,CAST(@EDATU as DATE)
									,1
									 )
		else 
		    update t_po_detail
			set   
				 item_number=@WERKS+'-'+@MATNR
				,qty= cast(@KWMENG as float)
				,wh_id=@wh_id
				,order_uom=@VRKME
				--,[more_qty]
				--,[less_qty]
				--,[upper_percent]
				--,[lower_percent]
				,cancel_flag=@cancel_flag
				,price=@NETPR
				,price_uom=@KPEIN
				,storage_location=@storage_location1
				,factory=@storage_location2
				,complete_flag='N'
				,delivery_date=cast(@EDATU as DATE)
			where po_number=@order_no and line_number=@line_no

   
    
     insert into #returnresult values(1,N'OK',N'SO Inbound成功.')
END




