




-- =======================================    
-- Author: lis
-- Create Date: 02 15 2016       
-- =======================================  

CREATE PROCEDURE [dbo].[csp_batch_add_po_toasn]  (  
     @wh_id				    NVARCHAR(10),  
	 @user_id               NVARCHAR(30),
	 @po_number				nvarchar(50))
as
DECLARE   
	@current_date			nvarchar(10),
	@seq_id					nvarchar(30),
	@shipment_number		nvarchar(50),
	@const_cmnt				NVARCHAR(100),
	@item_number			nvarchar(50),
	@line_number			nvarchar(50),
	@outmsg					nvarchar(200),
	@out_vchMsg				NVARCHAR(50),
	@status					NVARCHAR(50),
	@control_line_number	int = '',
	@v_ncount				int = 0,
	@passornot				int

	DECLARE @msg AS NVARCHAR(200)
	SELECT @const_cmnt = dbo.usf_get_locale_text(N'COMMENTS', N'CONSTANT', @user_id, N'CONSTANT')
	SELECT @current_date = CONVERT(NVARCHAR(10), GETDATE(),112)
	EXEC csp_Get_AutoSeqNo_ByWH @wh_id,'VirtualPOSeqNo',@current_date,@seq_id output, @passornot output, @outmsg output
	select @shipment_number = @current_date + @seq_id

BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;
	BEGIN TRY
	BEGIN TRANSACTION
	  
	  select top 1 @status = trs.status 
	    from t_rcpt_ship_po trsp 
	   inner join t_rcpt_ship trs 
	      on trsp.shipment_number = trs.shipment_number 
	   where po_number = @po_number order by create_date desc

	  if @status <> 'C'
		begin
		  set @msg= @po_number + '存在未完成的ASN'
		  RAISERROR(@msg, 11, 1)
		end	

	  select @v_ncount = count(1) 
	    from t_po_detail 
	   where po_number = @po_number 
	     and cancel_flag <> 'Y'

	  if @v_ncount <= 0
		begin
		  set @msg= @po_number + '不存在行明细'
		  RAISERROR(@msg, 11, 1)
		end	

	  if @v_ncount > 0	
		begin
	  while 1=1
			begin

			SELECT top 1 @control_line_number = d.line_number,
						 @po_number = d.po_number,
						 @item_number = d.item_number
			  FROM t_po_detail d WITH(NOLOCK)
			 inner join t_item_uom u with (nolock)
				on u.item_number = d.item_number
			   and u.uom = d.order_uom
			   and u.wh_id = d.wh_id
			 WHERE d.po_number = @po_number
			   AND d.wh_id = @wh_id
			   AND ISNULL(d.cancel_flag, 'N') = 'N'
			   AND ISNULL(d.complete_flag, 'N') = 'N'
			   AND ((d.qty - ISNULL(ROUND(lower_percent * d.qty, 0, 1), 0)) *
				   u.conversion_factor - isnull((SELECT SUM(received_qty) received_qty
												   FROM t_rcpt_ship_po_detail WITH(NOLOCK)
												  WHERE po_number = @po_number
													and line_number = d.line_number
													and wh_id = @wh_id), 0)) > 0
			   AND d.line_number > @control_line_number
			 ORDER BY convert(int,d.line_number) ASC

				 if @@ROWCOUNT <= 0 or @control_line_number = ''
				 break;

				 ------执行SP生成预到货通知单
				 EXECUTE csp_add_po_toasn
								@wh_id,
								@user_id,
								@shipment_number,
								'O',
								@const_cmnt,
								@po_number,
								'2052',
								@item_number,
								@control_line_number,
								@out_vchMsg	OUTPUT
				 ------
			END
			COMMIT	TRANSACTION
			RETURN
		end
	   SET @msg= @msg + @out_vchMsg

	   IF @msg IS not NULL 
	     
	     BEGIN
		   ROLLBACK TRANSACTION
		   RAISERROR(@msg, 11, 1)
		 END
	   commit
	   RETURN
    END TRY

    BEGIN CATCH
		SET NOCOUNT OFF
		ROLLBACK
		SET @msg = ERROR_MESSAGE()
		RAISERROR (
				@msg
				,11
				,1
				)

		RETURN
	END CATCH
END




