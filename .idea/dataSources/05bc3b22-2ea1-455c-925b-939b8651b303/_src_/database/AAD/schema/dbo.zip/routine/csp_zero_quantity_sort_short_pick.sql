

CREATE PROCEDURE [dbo].[csp_zero_quantity_sort_short_pick] @wh_id NVARCHAR(10)
	,@pick_loc NVARCHAR(30)
	,@item_number NVARCHAR(30)
	,@pick_key NVARCHAR(30)
	,@hu_id NVARCHAR(30) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from    
	SET NOCOUNT ON;

	DECLARE @wave_id NVARCHAR(30)

	SELECT TOP 1 @wave_id = wave_id
	FROM tbl_pick_list
	WHERE wh_id = @wh_id
		AND shipping_label = @pick_key

	UPDATE tbl_allocation
	SET status = 'C'
	WHERE wave_id = @wave_id
		AND wh_id = @wh_id
		AND location_id = @pick_loc
		AND item_number = @item_number
		AND isnull(hu_id, '0') = isnull(@hu_id, '0')
		AND allo_type = 'S'

	UPDATE pd
	SET pd.status = 'STAGED'
	FROM t_pick_detail pd 
	INNER JOIN tbl_allocation allo on pd.wh_id = allo.wh_id
						AND pd.pick_id = allo.pick_id 
	WHERE pd.wh_id=@wh_id 
		AND pd.wave_id = @wave_id
		AND pd.item_number = @item_number 
		AND pd.type='PP'
		AND NOT EXISTS(select 1 from tbl_allocation al where pd.wh_id = al.wh_id
						AND pd.pick_id = al.pick_id 
						AND al.wh_id=@wh_id 
						AND al.wave_id = @wave_id
						AND al.item_number = @item_number					
						AND al.status <> 'C'
						AND al.allo_type = 'S')

   ------------------------------will add 20160621 start----------------------------------
   INSERT INTO [dbo].[t_exception_log]
           ([tran_type]
           ,[description]
           ,[exception_date]
           ,[exception_time]
           ,[employee_id]
           ,[wh_id]
           ,[suggested_value]
           ,[entered_value]
           ,[location_id]
           ,[item_number]
           ,[lot_number]
           ,[quantity]
           ,[hu_id]
           ,[load_id]
           ,[control_number]
           ,[line_number]
           ,[tracking_number]
           ,[error_code]
           ,[error_message]
           ,[status]
           ,[uom])
    SELECT '1025',
	       N'提总拣选0短拣',
		   GETDATE(),
		   GETDATE(),
		   user_assign,
		   @wh_id,
		   NULL,
		   NULL,
		   @pick_loc,
		   @item_number,
		   lot_number,
		   allocated_qty,
		   isnull(@hu_id,''),
		   NULL,
		   order_number,
		   NULL,
		   NULL,
		   '1025',
		   N'提总拣选0短拣',
		   NULL,
		   NULL
	FROM tbl_allocation 
	WHERE wave_id = @wave_id
		AND wh_id = @wh_id
		AND location_id = @pick_loc
		AND item_number = @item_number
		AND isnull(hu_id, '0') = isnull(@hu_id, '0')
		AND allo_type = 'S'
------------------------------will add 20160621 end----------------------------------

	UPDATE od
	SET od.status = 'STAGED'
	FROM t_order od
	INNER JOIN t_pick_detail pk ON od.wh_id = pk.wh_id
		AND od.order_number = pk.order_number
	WHERE pk.wh_id = @wh_id
		AND pk.wave_id = @wave_id
		AND pk.type = 'PP'
		AND NOT EXISTS (
			SELECT 1
			FROM t_order_detail a
			LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
				AND a.line_number = b.line_number
				AND a.item_number = b.item_number
				AND a.wh_id = b.wh_id 
				AND a.wh_id=od.wh_id 
				AND a.order_number=od.order_number
			WHERE isnull(b.status, '') NOT IN (
					'STAGED','LOADED'
					)
				AND a.wh_id = @wh_id
				AND isnull(b.work_type, '') = ''
			)
		AND EXISTS (
			SELECT 1
			FROM t_order_detail a
			LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
				AND a.line_number = b.line_number
				AND a.item_number = b.item_number
				AND a.wh_id = b.wh_id
				AND a.wh_id=od.wh_id 
				AND a.order_number=od.order_number
			WHERE isnull(b.status, '') IN ('STAGED','LOADED')
				AND a.wh_id = @wh_id
				AND isnull(b.work_type, '') = ''
			)
END

