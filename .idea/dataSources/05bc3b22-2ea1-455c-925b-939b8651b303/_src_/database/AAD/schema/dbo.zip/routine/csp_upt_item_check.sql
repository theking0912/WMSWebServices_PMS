




-- Batch submitted through debugger:


-- Procedure
-- =======================================    
-- Author: Jerry
-- Create Date: 2015-05-13   
-- Description: Return    
--  
    
-- =======================================    
CREATE PROCEDURE [dbo].[csp_upt_item_check]     
	 @item_id			    nvarchar(30)
	,@expiration_control	nvarchar(2)
	,@shelf_life			nvarchar(20)
	,@pick_type				nvarchar(20)
	,@discount_flag			nvarchar(4)
	,@storage_type			nvarchar(20)
	,@pack_flag				nvarchar(2)
	,@pack_pos				nvarchar(20)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    

BEGIN    
	declare @expiration_control_old nvarchar(2),
			@shelf_life_old int,
			@pick_type_old nvarchar(4),
			@storage_type_old nvarchar(4),
			@pack_flag_old nvarchar(4),
			@item_number nvarchar(30)

    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	select @expiration_control_old=expiration_date_control,
		   @shelf_life_old=shelf_life,
		   @pick_type_old =pick_type,
		   @storage_type_old=storage_type,
		   @pack_flag_old=pack_flag,
		   @item_number=item_number
	  from t_item_master
	 where item_master_id=@item_id


	if isnull(@expiration_control,'#') = 'Y' AND isnull(@shelf_life,'0') ='0'
	begin
	set @msg=N'效期控制为是，效期天数不能为空或0'
	GOTO ERRORHANDLE
	end 


	if exists(select 1 from t_stored_item where item_number = @item_number )
	begin
	  if isnull(@expiration_control,'#')<>isnull(@expiration_control_old,'#')
	  begin
		set @msg=N'存在库存，不可更改批次控制属性'
		GOTO ERRORHANDLE
	  end 
	     

	 -- if isnull(@storage_type_old,'#')<>isnull(@storage_type,'#')
	 -- begin
		--set @msg='存在库存，不可更改存储区域'
		--GOTO ERRORHANDLE
	 -- end 

	 -- if isnull(@shelf_life_old,'#')<>isnull(@shelf_life,'#')
	 -- begin
		--set @msg='存在库存，不可更改有效期'
		--GOTO ERRORHANDLE
	 -- end 

	 -- if isnull(@pick_type_old,'#')<> isnull(@pick_type,'#')
	 -- begin
		--set @msg='存在库存，不可更改拣货方式'
		--GOTO ERRORHANDLE
	 -- end 


	  if isnull(@pack_flag_old,'#')<> isnull(@pack_flag,'#')
	  begin
		set @msg=N'存在库存，不可更改打包标志'
		GOTO ERRORHANDLE
	  end 

	  if isnull(@pack_flag,'')='Y' and isnull(@pack_pos,'')=''
	  begin
		set @msg=N'打包标识为Y,请选择打包位置'
		GOTO ERRORHANDLE	    

	  end  

	end 
/*	--add--
	insert into tbl_tran_item_master
select 
    (select top 1 tran_log_id from tbl_web_tran_log order by tran_log_id desc),
     'N',
    [item_master_id],
	[item_number] ,
	[description] ,
	[uom] ,
	[inventory_type],
	[shelf_life] ,
	[alt_item_number],
	[commodity_code] ,
	[nafta_pref_criteria] ,
	[nafta_producer],
	[nafta_net_cost] ,
	[price] ,
	[std_hand_qty] ,
	[std_qty_uom] ,
	[inspection_code] ,
	[serialized] ,
	[lot_control] ,
	[wh_id] ,
	[reorder_point]  ,
	[reorder_qty]  ,
	[cycle_count_class] ,
	[last_count_date]  ,
	[class_id] ,
	[pick_location],
	[stacking_seq] ,
	[comment_flag] ,
	[ver_flag] ,
	[upc] ,
	[unit_weight] ,
	[tare_weight] ,
	[haz_material] ,
	[inv_cat] ,
	[inv_class] ,
	[unit_volume] ,
	[nested_volume] ,
	[xdock_profile_id] ,
	[pick_put_id] ,
	[suggested_disposition] ,
	[length] ,
	[width] ,
	[height],
	[sample_rate] ,
	[compatibility_id] ,
	[commodity_type_id],
	[freight_class_id] ,
	[audit_required] ,
	[msds_url] ,
	[expiration_date_control] ,
	[ucc_company_prefix] ,
	[attribute_collection_id],
	[display_item_number] ,
	[client_code] ,
	[b2b_b2c] ,
	[color],
	[size] ,
	[special_zone] ,
	[style],
	[storage_type] ,
	[quarantine_flag] ,
	[discount_flag] ,
	[pick_type] ,
	[stock_flag] ,
	[pack_flag] ,
	[ed_flag] ,
	[new_flag] ,
	[information_collection_id] ,
	[ship_uom] ,
	[nostock_flag],
	[item_status] ,
	[rp_uom] ,
	[pack_pos] ,
	[barcode_start] ,
	[barcode_length] ,
	[barcode_rate] ,
	[barcode_weight_length] ,
	[action_sapuom] ,
	[item_ABC] ,
	[category] ,
	[full_pallet_qty],
	[full_case_qty]
	from t_item_master
	 where item_master_id=@item_id	
	--------------------------------------------*/

	SET @passornot = 0
	return
	
ERRORHANDLE:
	
    SET @msg = ISNULL(ERROR_MESSAGE(),'')+@msg
    SET @passornot = 1
    RETURN
  
END  



