



-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: promotion pick	  
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_PromotionLoading]    
     @wh_id					NVARCHAR(10)  
	,@shipping_label		Nvarchar(30)  
	,@user_id				nvarchar(30)
	,@passornot				nvarchar(1)		output
	,@msg					nvarchar(200)	output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @pick_id		bigint
		DECLARE @ref_number		nvarchar(30)
		DECLARE @order_number	nvarchar(30)
		DECLARE @route			nvarchar(30)
		DECLARE @carrier		nvarchar(30)
		DECLARE @door_loc		nvarchar(30)
		DECLARE @node			nvarchar(30)
		DECLARE @event_data		nvarchar(1000)
		DECLARE @rec_count		int
		
		BEGIN TRANSACTION
		--Get the shipping information
		SELECT @order_number = order_number
			,@route = [route]
			,@carrier = carrier
		FROM tbl_shipping_label
		WHERE wh_id = @wh_id
		AND ship_label_barcode = @shipping_label
		--Get the door location
		SELECT @node = node
		FROM tbl_ship_node_route
		WHERE wh_id = @wh_id
		AND route = @route
		AND carrier = @carrier

		SET @door_loc = @node
		
		--create the stock for shipping label
		UPDATE t_hu_master
		SET location_id = @door_loc
		   ,[type] ='LO'
		   ,reserved_for = @door_loc
		WHERE wh_id = @wh_id
		AND hu_id = @shipping_label

		update t_stored_item
		SET location_id = @door_loc
		WHERE wh_id = @wh_id
		AND hu_id = @shipping_label

		--Update t_pick_detail status
		UPDATE t_pick_detail
		SET status = 'LOADED'
			,loaded_quantity = planned_quantity
		WHERE wh_id = @wh_id
		and order_number = @order_number
		--Update tbl_shipping_label status
		UPDATE tbl_shipping_label
		SET status = 'LOADED'
		WHERE wh_id = @wh_id
		and order_number = @order_number
		--Update t_order status
		UPDATE t_order
		SET status = 'LOADED'
		WHERE wh_id = @wh_id
		and order_number = @order_number
		--Create Tran log

		--Send Socket
		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
			,wh_id_2,location_id_2,hu_id_2
			,generic_attribute_1,
			generic_attribute_2,
			generic_attribute_3,
			generic_attribute_4,
			generic_attribute_5,
			generic_attribute_6,
			generic_attribute_7,
			generic_attribute_8,
			generic_attribute_9,
			generic_attribute_10,
			generic_attribute_11)
		select 
			'318','Promotion Loading',getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@pick_id
			,@wh_id,sto.location_id,sto.hu_id,sto.item_number,sto.lot_number,sto.actual_qty
			,@wh_id,@door_loc,@shipping_label
			,(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_1),    
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_2), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_3), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_4), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_5), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_6), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_7), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_8), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_9), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id =  sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_10), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = sto.stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_11)
		FROM t_stored_item sto
		WHERE sto.wh_id = @wh_id
		AND sto.hu_id = @shipping_label 

		--Print Shipping label

		--Send Socket to conveyor
		SELECT @rec_count = COUNT(1)
				FROM tbl_out_socket_task
				WHERE lc_id = @shipping_label 
				AND status <> 'COMP'
				AND mode = 'CREA'
				AND msg_type = 'TRAN'
			
		if @rec_count = 0
		begin
			insert tbl_out_socket_msg_queue
				(type,mode,lc_id,node,create_date)
			values('TRAN','CREA',@shipping_label,@node,getdate())
		end
		else
		begin
			-- cancel the exists task
			insert tbl_out_socket_msg_queue
				(type,mode,lc_id,node,create_date)
			values('TRAN','CANC',@shipping_label,@node,getdate())

			-- create new task
			insert tbl_out_socket_msg_queue
				(type,mode,lc_id,node,create_date)
			values('TRAN','CREA',@shipping_label,@node,getdate())
		end

		--SET @event_data = 'TRAN|CREA|'+@shipping_label+'|'+@node;
		--exec [ADV].[dbo].[usp_AdvAddEvent] 4,'SEND SORKET',@event_data,50

		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		IF @@TRANCOUNT > 0 
			ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    




