
CREATE PROCEDURE dbo.ea_usp_GetAlertTransports
    @in_nAlertID    BIGINT
AS
    DECLARE @v_vchAlertName NVARCHAR(256),
            @v_bActive BIT,
            @v_bConfigured BIT,
            @v_vchConfiguration NVARCHAR(30),
            @v_vchTransportType NVARCHAR(20)

    DECLARE @v_t_GetAlertTransports TABLE (
        alert_id BIGINT,
        alert_name NVARCHAR(256),
        transport_type NVARCHAR(20),
        configuration NVARCHAR(30)
    )

    DECLARE @v_t_TransportTypes TABLE (
        transport_type NVARCHAR(20)
    )

    SET NOCOUNT ON

    SELECT @v_vchAlertName = alert_name FROM ea_t_alert WHERE alert_id = @in_nAlertID

    IF NOT @v_vchAlertName IS NULL
    BEGIN

        -- Prepare transport types for loop
        INSERT INTO @v_t_TransportTypes (transport_type) VALUES ('E-mail')
        INSERT INTO @v_t_TransportTypes (transport_type) VALUES ('Fax')
        INSERT INTO @v_t_TransportTypes (transport_type) VALUES ('File')
        INSERT INTO @v_t_TransportTypes (transport_type) VALUES ('FTP')
        INSERT INTO @v_t_TransportTypes (transport_type) VALUES ('HTTP')
        INSERT INTO @v_t_TransportTypes (transport_type) VALUES ('Voice')

        DECLARE cur_TransportTypes CURSOR FOR
        SELECT transport_type FROM @v_t_TransportTypes

        OPEN cur_TransportTypes
        FETCH NEXT FROM cur_TransportTypes INTO @v_vchTransportType

        WHILE @@FETCH_STATUS = 0
        BEGIN

            SET @v_bActive = NULL
            SELECT @v_bActive = active
                FROM ea_t_alert_transport
                WHERE alert_id = @in_nAlertID AND transport_type = @v_vchTransportType
            IF @@ROWCOUNT = 0
            BEGIN
                SET @v_vchConfiguration = 'Not Configured'
            END
            ELSE
            BEGIN
                IF @v_bActive = 1
                BEGIN
                    SET @v_vchConfiguration = 'Active'
                END
                ELSE
                BEGIN
                    SET @v_vchConfiguration = 'Inactive'
                END
            END
            INSERT INTO @v_t_GetAlertTransports
                (
                    alert_id,
                    alert_name,
                    transport_type,
                    configuration
                )
            VALUES
                (
                    @in_nAlertID,
                    @v_vchAlertName,
                    @v_vchTransportType,
                    @v_vchConfiguration
                )

            FETCH NEXT FROM cur_TransportTypes INTO @v_vchTransportType
        END

        CLOSE cur_TransportTypes
        DEALLOCATE cur_TransportTypes

        SELECT * FROM @v_t_GetAlertTransports ORDER BY transport_type
    END
