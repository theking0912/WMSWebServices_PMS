













-- =======================================    
-- Author: Will.Xu
-- Create Date: 02 17 2016    
-- Description: 紧急补货（拣起）
--  
    
-- =======================================    

 
CREATE PROCEDURE [dbo].[Urgency Replenishment Move To Fork_NBO]    
     @wh_id					NVARCHAR(10)
	--,@pick_id				NVARCHAR(30)  
    ,@pick_loc				NVARCHAR(30)  
	,@item_number			NVARCHAR(30)
	,@lot_number			NVARCHAR(30)
	,@attribute_id  		NVARCHAR(30)
	,@qty					FLOAT
	,@fork_id				NVARCHAR(30)
	,@user_id				NVARCHAR(30)
	,@passornot				NVARCHAR(1) output
	,@msg					NVARCHAR(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		--DECLARE @order_number		NVARCHAR(30)
		DECLARE @fifo_date			NVARCHAR(30)
		DECLARE @expiration_date	NVARCHAR(30)
		DECLARE @type				NVARCHAR(30)
		DECLARE @wave_id			NVARCHAR(30)
		DECLARE @HUID               NVARCHAR(30)-----will add
		DECLARE @allocated_qty		FLOAT
		DECLARE @picked_qty			FLOAT
		DECLARE @seq_id				BIGINT
		DECLARE @pick_id			BIGINT
		DECLARE @remove_qty			FLOAT
		DECLARE @damage_flag      NVARCHAR(1)   ---------------正常和货损
		DECLARE	@out_vchCode		uddt_output_code,
				@out_vchMsg			uddt_output_msg
		SET @remove_qty = @qty * -1
		SET @passornot = 0
		SET @msg = ''
		set @wave_id =null   ----will add  
		set @pick_id =''
		SET @damage_flag='N'
		--set @attribute_id =''

		if @attribute_id=0
		begin
		set @attribute_id=NULL
		end

		BEGIN TRANSACTION
			
			SELECT top 1 @fifo_date = fifo_date
				  ,@expiration_date = expiration_date
				  ,@type = type
				  ,@HUID=hu_id  -----will add 
				  ,@attribute_id=stored_attribute_id
			  FROM t_stored_item
			 WHERE wh_id = @wh_id
			   AND item_number = @item_number
			   AND (lot_number = @lot_number OR lot_number IS NULL OR lot_number ='') 
			   AND location_id = @pick_loc 
			   and (stored_attribute_id=@attribute_id OR stored_attribute_id is NULL OR stored_attribute_id='')
			   AND damage_flag=@damage_flag
		
			--Remove the stock from pick location
			--EXEC	[dbo].[usp_inventory_adjust]
			--		@in_vchWhID = @wh_id,
			--		@in_vchItemNumber = @item_number,
			--		@in_vchLocationID = @pick_loc,
			--		@in_nType = @type,
			--		@in_vchHUID = @HUID,
			--		@in_vchLotNumber =@lot_number,
			--		@in_nStoredAttributeID = @attribute_id,
			--		@in_fQty = @remove_qty,
			--		@in_dtFifoDate = NULL,
			--		@in_dtExpirationDate = NULL,
			--		@in_vchHUType = N'IV',
			--		@in_vchShipmentNumber = NULL,
			--		@out_vchCode = @out_vchCode OUTPUT,
			--		@out_vchMsg = @out_vchMsg OUTPUT

		
						EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @pick_loc,
						@in_nType = @type,
						@in_vchHUID = @HUID,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @attribute_id,
						@in_fQty = @remove_qty,
						----@in_dtFifoDate = NULL,@FifoDate
						@in_dtFifoDate =@fifo_date,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = N'IV',
						@in_vchShipmentNumber =NULL,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT



			IF @out_vchCode <> N'SUCCESS'
			BEGIN
				SET @passornot = 1
				SET @msg = @out_vchMsg
			END

			-- Add the stock to fork
			--EXEC	[dbo].[usp_inventory_adjust]
			--		@in_vchWhID = @wh_id,
			--		@in_vchItemNumber = @item_number,
			--		@in_vchLocationID = @fork_id,
			--		@in_nType = 0,
			--		@in_vchHUID = NULL,
			--		@in_vchLotNumber =@lot_number,
			--		@in_nStoredAttributeID = @attribute_id,
			--		@in_fQty = @qty,
			--		@in_dtFifoDate = @fifo_date,
			--		@in_dtExpirationDate = @expiration_date,
			--		@in_vchHUType = N'SO',
			--		@in_vchShipmentNumber = NULL,
			--		@out_vchCode = @out_vchCode OUTPUT,
			--		@out_vchMsg = @out_vchMsg OUTPUT


				EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @fork_id,
						@in_nType = 0,
						@in_vchHUID = NULL,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @attribute_id,
						@in_fQty = @qty,
						----@in_dtFifoDate = NULL,@FifoDate
						@in_dtFifoDate =@fifo_date,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = N'SO',
						@in_vchShipmentNumber =NULL,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT






			IF @out_vchCode <> N'SUCCESS'
			BEGIN
				SET @passornot = 1
				SET @msg = @out_vchMsg
			END

--  select @pick_id =pick_id  from tbl_allocation 
--WHERE status='A' AND item_number =@item_number AND wh_id=@wh_id 
--AND lot_number =@lot_number AND location_id =@pick_loc AND stored_attribute_id =@attribute_id
--AND ISNULL(picked_qty,0 ) + @qty = allocated_qty
-- if @pick_id=''
-- begin
-- SET @passornot = 1
-- end

--			UPDATE tbl_allocation
--			   SET status = (CASE WHEN  ISNULL(picked_qty,0 ) + @qty = allocated_qty
--								THEN 'C'
--							ELSE status END)
--				  ,picked_qty = ISNULL(picked_qty,0 ) + @qty
--			WHERE status='A' AND item_number =@item_number AND wh_id=@wh_id 
--			AND lot_number =@lot_number AND location_id =@pick_loc AND stored_attribute_id =@attribute_id
			--AND pick_id =@pick_id

select @allocated_qty=sum (allocated_qty) from tbl_allocation
 where  status='A' AND item_number =@item_number AND wh_id=@wh_id AND lot_number =@lot_number AND location_id =@pick_loc


 if @allocated_qty<>@qty
 begin
 SET @passornot = 1
 end

 	UPDATE tbl_allocation set 
				  picked_qty = allocated_qty, status='C'
			WHERE status='A' AND item_number =@item_number AND wh_id=@wh_id 
			AND lot_number =@lot_number AND location_id =@pick_loc 



			--Create tran log
			--Insert t_tran_log_holding
			INSERT INTO dbo.t_tran_log_holding
                       (tran_type
                       ,description
                       ,start_tran_date
                       ,start_tran_time
                       ,end_tran_date
                       ,end_tran_time
                       ,employee_id
                       ,control_number
                       ,control_number_2
                       ,wh_id
                       ,location_id
                       ,hu_id
                       ,item_number
                       ,lot_number
                       ,tran_qty
                       ,wh_id_2
                       ,location_id_2
                       ,hu_id_2
                       ,generic_attribute_1
                       ,generic_attribute_2
                       ,generic_attribute_3
                       ,generic_attribute_4
                       ,generic_attribute_5
                       ,generic_attribute_6
                       ,generic_attribute_7
                       ,generic_attribute_8
                       ,generic_attribute_9
                       ,generic_attribute_10
                       ,generic_attribute_11)
                 SELECT '994'
                       ,N'紧急补货（拣起）'
                       ,GETDATE()
                       ,GETDATE()
                       ,GETDATE()
                       ,GETDATE()
                       ,@user_id
                      -- ,@order_number
					   ,NULL
                       ,@pick_id
                       ,@wh_id
                       ,@pick_loc
                       ,NULL
                       ,@item_number
                       ,@lot_number
                      -- ,@picked_qty
					   ,@qty 
                       ,@wh_id
                       ,@fork_id
                      -- ,@wave_id
					   ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL

		IF @passornot = 0
		COMMIT	TRANSACTION
		ELSE
		ROLLBACK TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    
















