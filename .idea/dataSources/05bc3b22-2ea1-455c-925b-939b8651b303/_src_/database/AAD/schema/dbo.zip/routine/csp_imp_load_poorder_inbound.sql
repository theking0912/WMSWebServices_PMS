



 

CREATE  PROCEDURE [dbo].[csp_imp_load_poorder_inbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id varchar(100),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG varchar(100)
AS
BEGIN try
      --declare @client_no varchar(100)
		/*//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //EKKO-EBELN	订单号
        //EKKO-BSART	订单类型
        //EKKO-LIFNR	供应商编码
        //EKKO-BEDAT	订单日期
        //EKET-EINDT    交货日期
        //T024-EKNAM	采购组
        //TCURT-KTEXT	货币
        //EKKO-INCO2	国际贸易条件
        //TVZBT-VTEXT	支付条件的描述
        //ZFLAG	        出入库标识
        //第二级
        //EKPO-EBELP	行号
        //EKPO-MATNR	物料号
        //EKPO-MENGE	订单数量
        //EKPO-MEINS	订单单位
        //EKPO-NETPR	净价
        //EKPO-PEINH	价格单位
        //T006A-MSEHT   价格单位描述
        //EKKO-RESWK	发货工厂
        //EKPO-RESLO	发货库存地点
        //EKPO-WERKS	收货工厂
        //EKPO-LGORT	收货库存地点
        //T001W-KUNNR   工厂的客户号
        //EKPO-UEBTO	过量交货
        //EKPO-UNTTO	交货不足
        //EKPO-LOEKZ	删除标识
        //EKPO-EKLIZ	交货已完成
        //EKPO-MWSKZ	税码
        //KONP-KBETR	税率	
        //第三级（委外）
        //MATNR	组件物料
        //ERFMG	需求数量
        //ERFME	单位
        //BDTER	需求日期*/
      declare @order_typeid int
	  declare @order_type varchar(100)
	  declare @ZPOSITION varchar(100)
      declare @EBELN varchar(100)
      declare @BSART varchar(100)
      declare @LIFNR varchar(100)
      declare @BEDAT varchar(100)
      declare @EINDT varchar(100)

      declare @EBELP varchar(100)
      declare @MATNR varchar(100)
      declare @qty   varchar(100)
      declare @MEINS varchar(100)
      declare @NETPR varchar(100)
      declare @PEINH varchar(100)
      declare @RESWK varchar(100)
      declare @RESLO varchar(100)
      declare @WERKS varchar(100)
      declare @LGORT varchar(100)
	  declare @KUNNR varchar(100)
 
      declare @UEBTO varchar(100)
      declare @UNTTO varchar(100)
      declare @LOEKZ varchar(100)
      declare @EKLIZ varchar(100)
      declare @MWSKZ varchar(100)
      declare @MATNR2 varchar(100)
      declare @ERFMG varchar(100)
      declare @ERFME varchar(100)
      declare @BDTER varchar(100)

		declare @EKNAM varchar(100)
		declare @KTEXT varchar(100)
		declare @INCO2 varchar(100)
		declare @KBETR varchar(100)
		declare @VTEXT varchar(100)
		declare @BPRME varchar(100)
		declare @MSEHT varchar(100)

	  declare @cancel_flag varchar(100)



		if exists(SELECT 1 from t_rcpt_ship trs WITH(NOLOCK) 
					 INNER JOIN t_rcpt_ship_po rsp WITH(NOLOCK) 
					 ON trs.wh_id = rsp.wh_id
					 AND trs.shipment_number = rsp.shipment_number
					 WHERE   rsp.po_number = @order_no  and  trs.wh_id =@wh_id
					 AND (status <> 'C' 
					      OR (ISNULL(trs.is_confirm,'N') = 'N' 
						       AND EXISTS(SELECT 1 FROM t_control with(NOLOCK) WHERE control_type = 'C_RECEIPT_CONFIRM' AND c1='Y')
						     )
                         )
					)

		begin
				insert into #returnresult values(-101,N'Fail',N'订单号['+@order_no+N'],入库单下存在未关闭的 运单，SAP提示不能更新该入库单')
		         RETURN
		end

 
	    select top 1    
						 @ZFLAG = ZFLAG 
						,@ZPOSITION= ZPOSITION
						,@BSART  = BSART
						,@LIFNR  = LIFNR
						,@BEDAT  = BEDAT
						,@EINDT  = isnull(EINDT,'')
						,@ZFLAG  = ZFLAG 
						,@MATNR  = MATNR
						,@qty  = MENGE
						,@MEINS  = MEINS
						,@NETPR  = NETPR
						,@PEINH  = PEINH
						,@RESWK  = RESWK
						,@RESLO  = RESLO
						,@WERKS  = WERKS
						,@LGORT  = LGORT
						,@KUNNR  = KUNNR
						,@UEBTO  = UEBTO
						,@UNTTO  = UNTTO
						,@LOEKZ  = LOEKZ
						,@EKLIZ  = EKLIZ
						,@MWSKZ  = MWSKZ
						,@MATNR2 = isnull(MATNR2,'')
						,@ERFMG  = ERFMG
						,@ERFME  = isnull(ERFME,'')
						,@BDTER  = isnull(BDTER,'')
						,@EKNAM  = EKNAM
						,@KTEXT  = KTEXT
	                   , @INCO2  = INCO2
					   , @KBETR  = KBETR
					   , @VTEXT  = VTEXT
						,@BPRME =BPRME
						,@MSEHT =MSEHT
		 
		  from  tbl_inf_imp_poorder  WITH(NOLOCK) 
		  where DATA_ID=@DataID and PROCESS_STATUS=@process_status
		         and EBELN=@order_no and EBELP=@line_no and ZFLAG=@ZFLAG

		 if  (@EINDT='' or @EINDT='00000000') set @EINDT=null
	 
		 select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype  WITH(NOLOCK) 
		 where rtrim(sap_ordertype)=rtrim(@BSART)   and flag_inoutbound=@ZFLAG 
  
		 if (@LOEKZ='X') 
		      set @cancel_flag='Y'
		 else 
		      set @cancel_flag='N'

		if (rtrim(@LIFNR)='') set @LIFNR=NULL

		set @RESWK=isnull(@RESWK,'')

		if (@BSART='TH')
		BEGIN
			select top 1 @RESWK=isnull(RESWK,'') 
			from tbl_inf_imp_poorder  WITH(NOLOCK) 
			where DATA_ID=@DataID and PROCESS_STATUS=@process_status
		         and EBELN=@order_no and EBELP=@line_no and ZFLAG=@ZFLAG and isnull(RESWK,'')<>''
		end
 
		if not exists(select top 1 po_number from t_po_master WITH(nolock) where po_number=@order_no)
			insert into t_po_master(po_number
							  ,type_id
							  ,vendor_code
							  ,create_date
							  ,wh_id
							  ,status
							  ,display_po_number
							  ,client_code
							  ,residential_flag
							  ,locked_flag
							  ,sap_ordertype
							  ,currency
							  ,purchase_group
							  ,inter_trade
							  ,payment_mode
							  ,customer_code
							  )
					values( @order_no
					            ,@order_typeid
							    ,@LIFNR
								,cast(@BEDAT as date)
								,@wh_id
								,'O'
								,@order_no
								,@client_code
								,'N'
								,'N'
								,@BSART
								,@KTEXT
								,@EKNAM
							    ,@INCO2 
								,@VTEXT
								,@RESWK
								)
	else
		   update t_po_master
		   set		type_id=@order_typeid,
					sap_ordertype=@BSART,
					vendor_code=@LIFNR,
					currency=@KTEXT,
					purchase_group=@EKNAM,
					inter_trade=@INCO2 , 
					create_date=cast(@BEDAT as date),
					payment_mode=@VTEXT,
					customer_code=case when RTRIM(ISNULL(@RESWK,''))='' THEN isnull(customer_code,'')
					                   else @RESWK end
		   from  t_po_master 
		   where  po_number=@order_no 

    declare @dec_qty float
	declare @dec_price float
	declare @dec_taxrate float
	select  @dec_qty=cast(cast(rtrim(@qty) as char) as float)
	select  @dec_price=cast(cast(rtrim(@NETPR) as char) as float)
	select @dec_taxrate=cast(cast(rtrim(@KBETR) as char) as float)
 
	declare @storage_location1 nvarchar(30),@storage_location2 nvarchar(30)
	IF(@RESWK<>'')  select @storage_location1=@WERKS, @storage_location2=@RESWK
	IF(@RESWK='')   select @storage_location1=@LGORT, @storage_location2=@WERKS
	 
	if not exists(select top 1  po_number from t_po_detail WITH(NOLOCK)  where  po_number=@order_no and line_number=@line_no)
	   insert into  t_po_detail([po_number]
							  ,[line_number]
							  ,[item_number]
							  ,[qty]
							  ,[wh_id]
							  ,[order_uom]
							  ,[more_qty]
							  ,[less_qty]
							  ,[upper_percent]
							  ,[lower_percent]
							  ,cancel_flag 
							  ,price
							  ,price_unit  
							  ,price_uom
							  ,price_uom_prompt
							  ,tax_rate
							  ,complete_flag
							  ,storage_location
							  ,factory
							  ,delivery_date
							  ,tax_code
							  ,schedule_number
							  )
							  values(@order_no,
							         @line_no,
									 @client_code+'-'+@MATNR,
									 @dec_qty,
									 @wh_id,
									 @MEINS
									 ,cast((cast(isnull(@UEBTO,0) as float)/100*@dec_qty) as int)
									 ,CAST((cast(isnull(@UNTTO,0) as float)/100*@dec_qty) as int)
									 ,cast(isnull(@UEBTO,0) as float)/100
									 ,cast(isnull(@UNTTO,0) as float)/100
									 ,@cancel_flag
									 ,@dec_price
									 ,@PEINH
									 ,@BPRME
									 ,@MSEHT
									 ,isnull(@dec_taxrate,0)
									 ,'N'
									 ,@storage_location1
									 ,@storage_location2
									 ,CAST(@EINDT as date)
									 ,@MWSKZ
								     ,1
									 )
		else 
		    update t_po_detail
			set  item_number=@client_code+'-'+@MATNR
				,qty=@dec_qty
				,wh_id=@wh_id
				,order_uom=@MEINS
				,more_qty=cast((cast(isnull(@UEBTO,0) as float)/100*@dec_qty)  as int)
				,less_qty=cast((cast(isnull(@UNTTO,0) as float)/100*@dec_qty)  as int)
				,upper_percent= cast(isnull(@UEBTO,0) as float)/100
				,lower_percent= cast(isnull(@UNTTO,0) as float)/100
				,cancel_flag=@cancel_flag
				,price=@dec_price
				,price_unit=@PEINH
				,price_uom=@BPRME
				,price_uom_prompt=@MSEHT
				--,storage_location=CASE when @BSART='TH' AND @storage_location1='' then storage_location
				--                       else @storage_location1
				--				  end 
				,storage_location= @storage_location1
				,tax_rate=@dec_taxrate
				,factory=@storage_location2
				,complete_flag='N'
				,delivery_date=CAST(@EINDT as DATE)
				,tax_code=@MWSKZ
				
			where po_number=@order_no and line_number=@line_no

     insert into #returnresult values(1,N'OK',N'成功.')
END TRY
BEGIN CATCH
	--ROLLBACK TRANSACTION
	DECLARE @error NVARCHAR(100)
    SET @error=N'执行1异常:'+substring(ERROR_MESSAGE(),1,90)
	delete from #returnresult
	insert into #returnresult values(-101,N'fAILE',@error)

END catch







