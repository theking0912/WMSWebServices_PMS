
CREATE TRIGGER tr_t_vas_task_ins ON dbo.t_vas_tasks 
AFTER INSERT AS
DECLARE
    @intTaskID     INT,
    @strTranType   NVARCHAR(20)
BEGIN
    SELECT @intTaskID = vas_task_id,
           @strTranType = vas_task_tran_type
      FROM inserted

    IF @strTranType IS NULL
        BEGIN
	        UPDATE t_vas_tasks
	           SET vas_task_tran_type = '600'
	         WHERE vas_task_id = @intTaskID
		END
 
END
