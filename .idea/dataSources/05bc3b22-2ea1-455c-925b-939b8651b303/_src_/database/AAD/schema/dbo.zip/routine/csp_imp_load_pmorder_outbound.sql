 

CREATE PROCEDURE [dbo].[csp_imp_load_pmorder_outbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id nvarchar(10),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG varchar(100)
AS
BEGIN
		 /*
		//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //AFKO-AUFNR	生产订单号
        //AUFK-AUART	订单类型
        //AUFK-ERDAT	订单日期
        //AUFK-WERKS	工厂
        //ZFLAG	        出入库标识
        //AFPO-POSNR	行号
        //AFPO-MATNR	物料号
        //AFPO-PSMNG	数量
        //AFPO-MEINS	订单单位
        //AFPO-LGORT	库存地点
        //AFPO-UEBTO	过量交货限度
        //AFPO-UETTO	交货不足限度
        //ZCOPRD        联副产品标志
		
		*/
	    declare @ZPOSITION varchar(100)
        declare @AUFNR varchar(100)
        declare @AUART varchar(100)
        declare @ERDAT varchar(100)
		declare @EINDT varchar(100)
        declare @LOEKZ varchar(100)
        declare @WERKS varchar(100)
       
        declare @POSNR varchar(100)
        declare @MATNR varchar(100)
        declare @PSMNG varchar(100)
        declare @MEINS varchar(100)
        declare @LGORT varchar(100)
        declare @UEBTO varchar(100)
        declare @UETTO varchar(100)
		declare @order_typeid int
	    declare @order_type varchar(100)
	    declare @cancel_flag varchar(100)

	  	/*if exists(select top 1 * from t_order WITH(NOLOCK) where order_number=@order_no  and status<>'NEW')
		begin
		   insert into #returnresult values(-101,'Fail','订单号['+@order_no+']订单状态已经变化，不能修改.2')
		   return
		end*/

	    select top 1    @ZPOSITION =ZPOSITION,
						@AUFNR =AUFNR,
						@AUART =AUART,
						@ERDAT =ERDAT,
						@LOEKZ =LOEKZ,
						@WERKS =WERKS,
						@ZFLAG =ZFLAG,
						@POSNR =POSNR,
						@MATNR =MATNR,
						@PSMNG =PSMNG,
						@MEINS =MEINS,
						@LGORT =LGORT,
						@UEBTO =UEBTO,
						@UETTO =UEBTO 
		  from  tbl_inf_imp_pmorder  WITH(NOLOCK) 
		  where DATA_ID=@DataID and PROCESS_STATUS=@process_status
		        and AUFNR=@order_no and POSNR=@line_no and ZFLAG=@ZFLAG 

		  select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype  WITH(NOLOCK) 
		 where sap_ordertype=@AUART  and flag_inoutbound=@ZFLAG 

		 if (@LOEKZ='X') 
		      set @cancel_flag='Y'
		 else 
		      set @cancel_flag='N'
 

    if not exists(select top 1 order_number from t_order WITH(NOLOCK)  where order_number=@order_no)
	    insert into t_order(  wh_id
							  ,order_number
							  ,type_id
							  ,order_type
							  ,display_order_number
							  ,order_date
							  ,client_code
							  ,status
							  ,lock_flag
							  ,sap_ordertype
							  )
					values (     @wh_id
					            ,@order_no
					            ,@order_typeid
								,@order_type
								,@order_no
								,cast(@ERDAT as date)
								,@client_code
								,'NEW'
								,'N'
								, @AUART
					         )
	else
		   update t_order 
		   set   type_id=@order_typeid
				,@order_type=order_type
				,order_date=cast(@ERDAT as date)
			    ,client_code=@client_code
			    ,sap_ordertype=@AUART
		   from  t_order 
		   where  order_number=@order_no
		   
 
		declare @stored_attribute_id bigint
		declare @uom nvarchar(30)
		set @uom=@MEINS
		if exists( select top 1 item_number  from t_item_master WITH(NOLOCK)  where item_number=@WERKS+'-'+@MATNR  and wh_id=@wh_id and pack_flag='Y')
		begin
				SELECT top 1 @stored_attribute_id=CONVERT(INT,tscd.stored_attribute_id)
				FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
				INNER JOIN 
				(SELECT TOP 1 tacd.attribute_id,tiu.uom_prompt, tacd.attribute_collection_id  FROM t_item_master tim WITH(NOLOCK) 
				INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK) 
				ON tim.attribute_collection_id = tacd.attribute_collection_id
				INNER JOIN t_item_uom tiu WITH(NOLOCK)
				ON tim.wh_id = tiu.wh_id
				AND tim.item_number = tiu.item_number
				WHERE tim.item_number = @WERKS+'-'+@MATNR
				AND tim.wh_id = @wh_id
				AND tiu.uom = @uom) a
				ON tscd.attribute_id = a.attribute_id
				AND tscd.attribute_value = a.uom_prompt
				 INNER JOIN t_sto_attrib_collection_master tscm
       on tscd.stored_attribute_id=tscm.stored_attribute_id and tscm.attribute_collection_id=a.attribute_collection_id
		end 

		declare @storage_location1 nvarchar(30), @storage_location2 nvarchar(30)
		select @storage_location2=@WERKS, @storage_location1=@LGORT


		if not exists(select top 1  order_number from t_order_detail WITH(NOLOCK)  where  order_number=@order_no and line_number=@line_no)
		BEGIN
			IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
			WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
			BEGIN
				insert into #returnresult values(-202,N'fail',N'订单已经加入波次，不允许新增行明细') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
				return 
			END
			ELSE
			BEGIN
				insert into  t_order_detail(wh_id
								  ,order_number
								  ,line_number
								  ,item_number
								  ,qty
								  ,order_uom
								  ,stored_attribute_id
								  ,storage_location
								  ,cancel_flag
								  ,factory)
								values(@wh_id,
							         @order_no,
							         @line_no,
									@WERKS+'-'+@MATNR,
									 cast(@PSMNG as float),
									 @MEINS,
									 @stored_attribute_id,
									 @storage_location1,
									 @cancel_flag
									,@storage_location2
									 )
			END
		END
		else 
		BEGIN
			IF @cancel_flag = 'Y'
			BEGIN
				update t_order_detail
				set  cancel_flag=@cancel_flag
				where  order_number=@order_no and line_number=@line_no
			END
			ELSE
			BEGIN
				IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
				WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
				BEGIN
					insert into #returnresult values(-202,N'fail',N'已加入波次，未打删除标记，不允许修改') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
					return 
				END
				ELSE
				BEGIN
					update t_order_detail
					set  wh_id=@wh_id
						,item_number=@WERKS+'-'+@MATNR
						,qty=@PSMNG
						,order_uom=@MEINS
						,stored_attribute_id=@stored_attribute_id
						,storage_location= @storage_location1
						,factory=@storage_location2
						,cancel_flag=@cancel_flag
					where  order_number=@order_no and line_number=@line_no
				END
			END
		END				

     insert into #returnresult values(1,N'OK',N'PM Outbound成功.')
END



