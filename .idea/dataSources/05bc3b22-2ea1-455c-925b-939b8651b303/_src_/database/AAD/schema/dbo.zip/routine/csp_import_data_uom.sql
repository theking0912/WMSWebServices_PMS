



-- ======================================= 
--
-- Description: 

--January 2016 ADD by Peter
-- =======================================


CREATE  PROCEDURE [dbo].[csp_import_data_uom]
@in_number           NVARCHAR(100),
@in_vchWhID              NVARCHAR(10),
@out_vchMsg             NVARCHAR(200) OUTPUT
AS

DECLARE
    @v_nSequence            INTEGER,
	@v_vchPoType            NVARCHAR(10),	
	@client_code			NVARCHAR(50),
	@uom					NVARCHAR(50),
	@item_number            NVARCHAR(30),
	@wh_id                  nvarchar(10)
    SET @v_vchPoType = 'OMO'
	SET @v_nSequence = 0
	SET @client_code = @in_vchWhID

    SET NOCOUNT ON

	BEGIN TRANSACTION

	IF @in_number = N'商品主档导入'
    BEGIN	
	UPDATE tbl_imp_item_master 
			SET 
			item_number = RTRIM(LTRIM(item_number)),
			wh_id = RTRIM(LTRIM(wh_id)),
			youxq = RTRIM(LTRIM(youxq)),
			discount_flag = RTRIM(LTRIM(discount_flag)),
			expiration_date_control = RTRIM(LTRIM(expiration_date_control)),
			information_collection_id = RTRIM(LTRIM(information_collection_id)),
			stock_flag = RTRIM(LTRIM(stock_flag)),
			pick_type = RTRIM(LTRIM(pick_type)),
			pack_flag = RTRIM(LTRIM(pack_flag)),
			ed_flag =RTRIM(LTRIM(ed_flag)),
			tihi_level =RTRIM(LTRIM(tihi_level)),
			tihi_qty = RTRIM(LTRIM(tihi_qty)),
			zone_group =RTRIM(LTRIM(zone_group)),
			descripiton=RTRIM(LTRIM(descripiton)),
			item_ABC=RTRIM(LTRIM(item_ABC)),
			category=RTRIM(LTRIM(category)),
			full_pallet_qty=RTRIM(LTRIM(full_pallet_qty)),
			full_case_qty =RTRIM(LTRIM(full_case_qty)),
			uom=RTRIM(LTRIM(uom)),
			length=RTRIM(LTRIM(length)),
			width=RTRIM(LTRIM(width)),
			height=RTRIM(LTRIM(height)),
			unit_volume=RTRIM(LTRIM(unit_volume)),
			unit_weight=RTRIM(LTRIM(unit_weight)),
			stacking_seq=RTRIM(LTRIM(stacking_seq)),
			audit_required=RTRIM(LTRIM(audit_required)),
			barcode_start=RTRIM(LTRIM(barcode_start)),
			barcode_length=RTRIM(LTRIM(barcode_length)),
			barcode_rate=RTRIM(LTRIM(barcode_rate)),
            barcode_weight_length=RTRIM(LTRIM(barcode_weight_length))
    --    BEGIN		   
    --        SELECT  item_number,wh_id
		  --   FROM    tbl_imp_item_master WITH ( NOLOCK )
			 --GROUP BY wh_id,item_number
			 --ORDER BY wh_id,item_number

		   BEGIN
		     INSERT INTO dbo.t_item_master
		               ( item_number ,
                        description ,
                        uom ,
                        inventory_type ,
                        shelf_life ,
                        price ,
                        std_hand_qty ,
                        inspection_code ,
                        serialized ,
                        lot_control ,
                        wh_id ,
                        reorder_point ,
                        reorder_qty ,
                        last_count_date ,
                        comment_flag ,
                        ver_flag ,
                        unit_weight ,
                        tare_weight ,
                        unit_volume ,
                        nested_volume ,
                        pick_put_id ,
                        length ,
                        width ,
                        height ,
                        sample_rate ,
                        expiration_date_control ,
                        attribute_collection_id ,
                        display_item_number ,
                        client_code ,
                        storage_type ,
                        discount_flag ,
                        pick_type ,
                        stock_flag ,
                        pack_flag ,
                        ed_flag ,
                        new_flag ,
                        information_collection_id ,
                        nostock_flag ,
                        item_status ,
                        pack_pos ,
						--stacking_seq,
						size,
						audit_required,
                        barcode_start ,
                        barcode_length ,
                        barcode_rate ,
                        barcode_weight_length,
						item_ABC,
					    category,
					    full_pallet_qty,
					    full_case_qty
                      )
              SELECT client_code + '-' + item_number ,
					 descripiton,
					 uom,
					 N'FG',
					 case when youxq='NULL' then null  else  isnull(youxq,9999) end ,
					 0,
					 0,
					 N'N',
					 N'N',
					 N'N',
					 wh_id,
					 0,
					 0,
					 GETDATE(),
					 N'N',
					 N'N',
					 unit_weight,
					 0,
					 unit_volume ,
					 0,
					 N'Default',
					 length ,
                     width ,
                     height ,
					 0,
					 expiration_date_control,
					 NULL,
					 item_number,
					 client_code,
					 zone_group,
					 discount_flag,
					 pick_type,
					 stock_flag,
					 pack_flag,
					 ed_flag,
					 'N',
					 CASE WHEN information_collection_id ='A' THEN 30 
											WHEN information_collection_id ='C'THEN 32 
											WHEN information_collection_id ='AC' THEN 33 
											ELSE NULL END,
					 'T',
					 N'ACTIVE',
					 pack_pos,
					 stacking_seq,
				     audit_required,
					 barcode_start,
					 barcode_length,
					 barcode_rate,
					 barcode_weight_length,
					 item_ABC,
					 category,
					 full_pallet_qty,
					 full_case_qty
				from tbl_imp_item_master t1
			   WHERE  NOT EXISTS(SELECT 1 FROM t_item_master  WHERE item_number =(t1.client_code + '-' +  t1.item_number) and wh_id= t1.wh_id)		 
		   END
		   begin
          	 UPDATE  t_item_master
            SET shelf_life=(case when t2.youxq='NULL' then null  else isnull(t2.youxq,9999) end ),
				discount_flag = t2.discount_flag,
				expiration_date_control=t2.expiration_date_control,
				stock_flag = t2.stock_flag,
				pick_type = t2.pick_type,
				pack_flag = t2.pack_flag,
				ed_flag = t2.ed_flag,
				new_flag = 'N',
				pack_pos =  t2.pack_pos,
				storage_type = t2.zone_group,
				description=t2.descripiton,
				item_ABC=t2.item_ABC,
				category=t2.category,
				full_pallet_qty=t2.full_pallet_qty,
				full_case_qty=t2.full_case_qty,
				uom=t2.uom,
				length=t2.length,
				width=t2.width,
				height=t2.height,
				unit_volume=t2.unit_volume,
				unit_weight=t2.unit_weight,
                --stacking_seq=t2.stacking_seq,
				size=t2.stacking_seq,
				audit_required=t2.audit_required,
				barcode_start=t2.barcode_start,
				barcode_length=t2.barcode_length,
				barcode_rate=t2.barcode_rate,
				barcode_weight_length=t2.barcode_weight_length,
				information_collection_id = CASE WHEN t2.information_collection_id ='A' THEN 30 
											WHEN t2.information_collection_id ='C'THEN 32 
											WHEN t2.information_collection_id ='AC' THEN 33 
											ELSE NULL END
	         
			FROM  tbl_imp_item_master as t2
		   WHERE t_item_master.item_number = (t2.client_code + '-' +  t2.item_number)
		     AND t_item_master.wh_id =  t2.wh_id
			 AND t_item_master.client_code = t2.client_code	 
		   end
        --END 
	END

	IF @in_number=N'商品单位主档导入'
	   BEGIN
	   UPDATE tbl_imp_item_uom
			SET
			item_number = RTRIM(LTRIM(item_number)),
			uom = RTRIM(LTRIM(uom)),
			wh_id = RTRIM(LTRIM(wh_id)),
			conversion_factor = RTRIM(LTRIM(conversion_factor)),
			units_per_layer = RTRIM(LTRIM(units_per_layer)),
			layers_per_uom = RTRIM(LTRIM(layers_per_uom)),
			uom_prompt = RTRIM(LTRIM(uom_prompt))
		 --BEGIN		 
		 --  SELECT   item_number, uom,wh_id
		 --     FROM    tbl_imp_item_uom WITH ( NOLOCK )
			-- GROUP BY wh_id,item_number,uom
			-- ORDER BY wh_id,item_number,uom
		   BEGIN
		     INSERT INTO dbo.t_item_uom
		             ( item_number ,
		               wh_id ,
		               uom ,
		               conversion_factor ,
		               package_weight ,
		               units_per_layer ,
		               layers_per_uom ,
		               uom_weight ,
		               pickable ,
		               box_type ,
		               length ,
		               width ,
		               height ,
		               no_overhang_on_top ,
		               stack_code ,
		               batch ,
		               use_orientation_data ,
		               turnable ,
		               on_bottom_ok ,
		               on_side_ok ,
		               on_end_ok ,
		               bottom_only ,
		               top_only ,
		               max_in_layer ,
		               max_support_weight ,
		               stack_index ,
		               container_value ,
		               load_separately ,
		               nesting_height_increase ,
		               nested_volume ,
		               unit_volume ,
		               pattern ,
		               priority ,
		               status ,
		               uom_prompt ,
		               default_receipt_uom ,
		               default_pick_uom ,
		               class_id ,
		               pick_put_id ,
		               conveyable ,
		               std_hand_qty ,
		               min_hand_qty ,
		               max_hand_qty ,
		               default_pick_area ,
		               pick_location ,
		               display_config ,
		               vas_profile ,
		               cartonization_flag ,
		               gtin ,
		               shippable_uom ,
		               units_per_grab
		             )
				SELECT item_number,
					   wh_id,
					   uom,
					   conversion_factor,
					   0,
					   units_per_layer,
					   layers_per_uom,
					   0,
					   N'Y',
					   1,
					   1,
					   1,
					   1,
					   0,
					   -1,
					   0,
					   0,
					   1,
					   0,
					   0,
					   0,
					   0,
					   0,
					   1,
					   1,
					   0,
					   0,
					   0,
					   0,
					   0,
					   0,
					   N'STANDARD',
					   1,
					   N'ACTIVE',
					   uom_prompt,
					   N'NO',
					   N'NO',
					   NULL,
					   CASE WHEN (SELECT expiration_date_control FROM dbo.t_item_master WHERE item_number =t3.item_number
					   AND wh_id = t3.wh_id) = N'Y' THEN N'Default' ELSE 'FIFO'END,
					   N'YES',
					   0,
					   0,
					   0,
					   NULL,
					   NULL,
					   CASE WHEN units_per_layer IS NOT NULL THEN 'YES' ELSE 'NO' END,
					   NULL,
					   N'NO',
					   NULL,
					   N'N',
					   0
				  FROM tbl_imp_item_uom AS t3
				 WHERE item_number =t3.item_number AND wh_id =t3.wh_id
				AND  NOT EXISTS(SELECT 1 FROM t_item_uom WHERE item_number = t3.item_number AND uom =t3.uom AND wh_id =t3.wh_id)
		   AND EXISTS(SELECT 1 FROM t_item_master WHERE item_number = t3.item_number AND wh_id =t3.wh_id AND new_flag = 'N')
		   END
		   begin
		     UPDATE t_item_uom 
            SET conversion_factor=t4.conversion_factor,
				units_per_layer=t4.units_per_layer,
				layers_per_uom=t4.layers_per_uom,
				uom_prompt=t4.uom_prompt				
			FROM  tbl_imp_item_uom as t4
		    WHERE t_item_uom.item_number = t4.item_number
		     AND t_item_uom.wh_id =  t4.wh_id
			 AND t_item_uom.uom = t4.uom
			 AND  EXISTS(SELECT 1 FROM t_item_uom WHERE item_number = t4.item_number AND uom =t4.uom AND wh_id =t4.wh_id)
			  AND NOT EXISTS(SELECT 1 FROM t_item_master WHERE item_number = t4.item_number AND wh_id =t4.wh_id  AND uom =t4.uom)		  
		    END
		 --END
	  END

		IF @out_vchMsg IS NULL 
			BEGIN
				--SET @out_vchMsg = '数据插入成功'

				COMMIT TRANSACTION
			END
		ELSE
		  BEGIN
		   
			 GOTO ErrorHandler
		  END

ErrorHandler:
    RAISERROR(@out_vchMsg,0,0)
    IF @@TRANCOUNT > 0   
	BEGIN
		ROLLBACK TRANSACTION
	END






