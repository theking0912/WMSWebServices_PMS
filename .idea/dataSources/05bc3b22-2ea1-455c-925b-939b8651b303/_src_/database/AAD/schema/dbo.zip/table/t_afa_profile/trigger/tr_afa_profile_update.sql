
CREATE TRIGGER tr_afa_profile_update ON dbo.t_afa_profile FOR UPDATE  AS 
BEGIN

DECLARE	@strErrorMessage		NVARCHAR(200),
        @nErrorNumber			integer,
	@nLogLevel			tinyint,
        @strObjName			NVARCHAR(30),

	@count				integer,
	@rows				integer

  -- Set constant values.
  SET @strObjName = 'tr_afa_profile_update'

  SET NOCOUNT ON

  -- Grab the Database Log Level from t_control.  If it doesn't exist, insert it.
  -- 0 = Off, 1 = On
  SELECT @nLogLevel = next_value FROM t_control WHERE control_type = 'DB OBJ LOG LEVEL'

  IF @@ROWCOUNT = 0
    BEGIN
      INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit)
        VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', '0', 'SHOW_VA', '1')
      SET @nLogLevel = 0
    END

  -- Do not allow changing of the primary key.
  IF UPDATE (sql_statement) OR UPDATE (parameters_1) OR UPDATE (parameters_2)
     OR UPDATE (parameters_3) OR UPDATE (parameters_4) OR UPDATE (parameters_5)
    BEGIN
    	UPDATE     [t_afa_profile]
    	SET        status = N'INACTIVE'
    	FROM       inserted i 
        INNER JOIN [t_afa_profile] tap ON i.afa_profile_id = tap.afa_profile_id 
    END

END
