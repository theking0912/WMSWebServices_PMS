


-- =======================================    
-- Author: LAVER    
-- Create Date: 2014-08-29  
-- Description:         
-- =======================================    
CREATE PROCEDURE [dbo].[csp_XDoc_Allocate_Pick] @wh_id NVARCHAR(10)
	,@pick_loc NVARCHAR(30)
	,@hu_id NVARCHAR(30)
	,@item_number NVARCHAR(30)
	,@lot_number NVARCHAR(30)
	,@stored_attribute_id NVARCHAR(30)
	,@qty FLOAT
	,@put_loc NVARCHAR(30)
	,@put_hu_id NVARCHAR(30)
	,@user_id NVARCHAR(30)
	--,@tran_type				nvarchar(20)
	--,@tran_description		nvarchar(50)
	,@damage_flag NVARCHAR(1)
	,@expiration_date DATETIME
	--,@order_number			NVARCHAR(30)
	--,@line_number			nvarchar(5)
	,@work_q_id NVARCHAR(30)
	,@passornot NVARCHAR(1) OUTPUT
	,@msg NVARCHAR(200) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from    
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @pick_id BIGINT
		DECLARE @allocated_qty FLOAT
		DECLARE @picked_qty FLOAT
		DECLARE @order_number NVARCHAR(30)
		DECLARE @line_number NVARCHAR(5)
		DECLARE @seq_id BIGINT
		DECLARE @remove_qty FLOAT
		DECLARE @out_vchCode uddt_output_code
			,@out_vchMsg uddt_output_msg
		DECLARE @ref_number NVARCHAR(30)
		DECLARE @zone NVARCHAR(30)
		DECLARE @zone_group NVARCHAR(10)
		DECLARE @type NVARCHAR(2)
		DECLARE @pack_flag NVARCHAR(1)
		DECLARE @hu_type NVARCHAR(2)
		DECLARE @stored_type BIGINT
		DECLARE @rec_cnt BIGINT

		SET @put_hu_id = RTRIM(LTRIM(@put_hu_id))
		SET @remove_qty = @qty * - 1

		SELECT @pack_flag = ISNULL(pack_flag, 'N')
		FROM dbo.t_item_master WITH (NOLOCK)
		WHERE wh_id = @wh_id
			AND item_number = @item_number

		BEGIN TRANSACTION

		WHILE (@qty > 0)
		BEGIN
			SELECT TOP 1 @pick_id = al.pick_id
				,@allocated_qty = ABS(allocated_qty) - picked_qty
				,@seq_id = al.seq_id
				,@order_number = al.order_number
				,@line_number = al.line_number
				,@ref_number = al.ref_number
			FROM tbl_allocation al 
			INNER JOIN t_order od on al.wh_id=od.wh_id and al.order_number=od.order_number 
			INNER JOIN t_customer cs on od.customer_id=cs.customer_id 
			INNER JOIN t_wave_master wm on al.wh_id=wm.wh_id and al.wave_id=wm.wave_id 
			WHERE al.wh_id = @wh_id

	---------------will delete 20160810 不分配播种墙的也能越库s---------------------------------------
				--AND (
				--	(
				--		ISNULL(al.pick_wall_slot, '') <> ''
				--		AND EXISTS (
				--			SELECT 1
				--			FROM tbl_pick_wall_slot_detail slot WITH (NOLOCK)
				--			WHERE slot.order_number = al.order_number
				--				AND slot.wh_id = al.wh_id
				--				AND slot.slot = al.pick_wall_slot
				--			)
				--		)
				--	OR EXISTS (
				--		SELECT 1
				--		FROM t_order d WITH (NOLOCK)
				--		INNER JOIN t_customer c WITH (NOLOCK) ON d.customer_id = c.customer_id
				--		WHERE d.order_number = al.order_number
				--			AND d.wh_id = al.wh_id
				--			AND ISNULL(c.customer_type, '') = 'SHWX-ND'
				--		)
				--	)
	---------------will delete 20160810 不分配播种墙的也能越库e---------------------------------------
				AND al.item_number = @item_number
				AND al.allocated_qty < 0
				AND al.status NOT IN (
					'C'
					,'E'
					,'H'
					)
			ORDER BY wm.released_date,cs.pick_seq,al.pick_id

			IF @@ROWCOUNT = 0
			BEGIN
				BREAK
			END

			--check the multi-wall sku into 1 location End
			IF @qty <= @allocated_qty
			BEGIN
				SET @picked_qty = @qty
				SET @qty = 0
			END
			ELSE
			BEGIN
				SET @picked_qty = @allocated_qty
				SET @qty = @qty - @allocated_qty
			END

			IF @pack_flag = 'N'
			BEGIN
				UPDATE dbo.tbl_allocation
				SET picked_qty = picked_qty + @picked_qty
					,allocated_qty = (
						CASE WHEN (allocated_qty + picked_qty + @picked_qty)= 0
								THEN picked_qty + @picked_qty
							ELSE allocated_qty 
							END
						)
					,status = (
						CASE WHEN (allocated_qty + picked_qty + @picked_qty)= 0
								THEN 'C'
							ELSE status
							END
						)
				WHERE wh_id = @wh_id
					AND seq_id = @seq_id
					AND status <> 'C'

				--Updated t_pick_detail(by order pick)
				UPDATE t_pick_detail
				SET status = (
						CASE 
							WHEN picked_quantity + @picked_qty = planned_quantity
								THEN 'STAGED'
							ELSE status
							END
						)
					,picked_quantity = picked_quantity + @picked_qty
					,staged_quantity = staged_quantity + @picked_qty
				WHERE pick_id = @pick_id

				--update pick detail (by move)
				UPDATE dbo.t_pick_detail
				SET picked_quantity = picked_quantity + @picked_qty
				WHERE order_number = @order_number
					AND work_type = '07'
					AND item_number = @item_number
					AND line_number = @line_number
					AND work_q_id = @work_q_id
					AND wh_id = @wh_id

				--update t_order status
	/****** Modified by Trevor on 20160406 started ******/
				--UPDATE t_order
				--SET status = 'PICKED'
				--	,date_picked = getdate()
				--WHERE wh_id = @wh_id
				--	AND order_number = @order_number
				--	AND NOT EXISTS (
				--		SELECT 1
				--		FROM t_pick_detail pkd
				--		WHERE pkd.wh_id = t_order.wh_id
				--			AND pkd.order_number = t_order.order_number
				--			AND pkd.planned_quantity <> pkd.picked_quantity
				--			AND pkd.type = 'PP'
				--		)
		   IF NOT EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') not in ('PICKED','STAGED','LOADED') and  a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
		      and EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') in ('PICKED') and a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
			UPDATE t_order SET status = 'PICKED' where wh_id=@wh_id and order_number=@order_number
				--UPDATE t_order
				--SET status = 'STAGED'
				--WHERE wh_id = @wh_id
				--	AND order_number = @order_number
				--	AND NOT EXISTS (
				--		SELECT 1
				--		FROM t_pick_detail pkd
				--		WHERE pkd.wh_id = t_order.wh_id
				--			AND pkd.order_number = t_order.order_number
				--			AND pkd.planned_quantity <> pkd.staged_quantity
				--			AND pkd.type = 'PP'
				--		)
				--	AND status NOT IN (
				--		'LOADED'
				--		,'SHIPPED'
				--		)
		   IF NOT EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') not in ('STAGED','LOADED') and  a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
		      and EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') in ('STAGED') and a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
			UPDATE t_order SET status = 'STAGED' where wh_id=@wh_id and order_number=@order_number
	/****** Modified by Trevor on 20160406 ended ******/

				SET @hu_type = 'SO'
				--SET @hu_type ='IV'
				SET @stored_type = @pick_id
			END
			ELSE
			BEGIN
				--update pick allocate
				UPDATE tbl_allocation
				SET allocated_qty = allocated_qty + @picked_qty
				WHERE hu_id = @put_hu_id
					AND location_id = @put_loc
					AND wh_id = @wh_id
					AND item_number = @item_number
					AND lot_number = @lot_number
					AND stored_attribute_id = @stored_attribute_id
					AND order_number = @order_number
					AND status <> 'C'

				IF @@ROWCOUNT = 0
				BEGIN
				---	INSERT INTO [dbo].[tbl_allocation]
				INSERT INTO [dbo].[tbl_allocation]  ----MODIFY BY WILL  20160614
           ([wave_id]
           ,[order_number]
           ,[pick_id]
           ,[item_number]
           ,[lot_number]
           ,[stored_attribute_id]
           ,[location_id]
           ,[hu_id]
           ,[allocated_qty]
           ,[picked_qty]
           ,[expected_qty]
           ,[status]
           ,[released_date]
           ,[ref_number]
           ,[pick_wall_loc]
           ,[pick_wall_slot]
           ,[pick_conveyor_node]
           ,[zone]
           ,[wh_id]
           ,[user_assign]
           ,[line_number]
           ,[shipping_label]
           ,[picking_flow]
           ,[allo_type]
           ,[damage_flag]
           ,[expiration_date]
           )
					SELECT [wave_id]
						,[order_number]
						,[pick_id]
						,[item_number]
						,@lot_number
						,@stored_attribute_id
						,@put_loc
						,@put_hu_id
						,@picked_qty
						,0
						,0
						,'U'
						,[released_date]
						,[ref_number]
						,[pick_wall_loc]
						,[pick_wall_slot]
						,[pick_conveyor_node]
						,[zone]
						,[wh_id]
						,@user_id
						,[line_number]
						,[shipping_label]
						,[picking_flow]
						,[allo_type]
						,[damage_flag]
						,@expiration_date
					FROM dbo.tbl_allocation
					WHERE seq_id = @seq_id
				END

				-- update xdoc and rep allocate
				UPDATE dbo.tbl_allocation
				SET picked_qty = picked_qty + @picked_qty
					,allocated_qty = (
						CASE allocated_qty + @picked_qty
							WHEN 0
								THEN picked_qty + @picked_qty
							ELSE allocated_qty + @picked_qty
							END
						)
					,status = (
						CASE allocated_qty + @picked_qty
							WHEN 0
								THEN 'C'
							ELSE status
							END
						)
				WHERE wh_id = @wh_id
					AND seq_id = @seq_id
					AND status <> 'C'

				-- delete finished allocated(xodc,rep)
				DELETE
				FROM tbl_allocation
				WHERE seq_id = @seq_id
					AND allocated_qty = picked_qty

				--update pick detail (by move)
				UPDATE dbo.t_pick_detail
				SET picked_quantity = picked_quantity + @picked_qty
				WHERE order_number = @order_number
					AND work_type = '07'
					AND item_number = @item_number
					AND line_number = @line_number
					AND work_q_id = @work_q_id
					AND wh_id = @wh_id

				SET @hu_type = 'IV'
				SET @stored_type = 0
			END

			--Move the stock to fork
			EXEC [dbo].[csp_Inventory_Adjust] @in_vchWhID = @wh_id
				,@in_vchItemNumber = @item_number
				,@in_vchLocationID = @put_loc
				,@in_nType = @stored_type
				,@in_vchHUID = @put_hu_id
				,@in_vchLotNumber = @lot_number
				,@in_nStoredAttributeID = @stored_attribute_id
				,@in_fQty = @picked_qty
				,@in_dtFifoDate = NULL
				,@in_dtExpirationDate = @expiration_date
				,@in_vchHUType = @hu_type
				,@in_vchShipmentNumber = @ref_number
				,@in_damage_flag = @damage_flag
				,@out_vchCode = @out_vchCode OUTPUT
				,@out_vchMsg = @out_vchMsg OUTPUT

			-- calculate zone
			SET @zone_group = dbo.fn_Get_StorageType_ByItem(@wh_id, @item_number, CASE ISNULL(@damage_flag, 'N')
						WHEN 'Y'
							THEN 'D'
						ELSE 'N'
						END)

			SELECT TOP 1 @zone = zone
			FROM t_zone
			WHERE zone_type = CASE ISNULL(@damage_flag, 'N')
					WHEN 'Y'
						THEN 'D'
					ELSE 'N'
					END
				AND wh_id = @wh_id
				AND zone_group = @zone_group

			UPDATE t_hu_master
			SET zone = @zone
				,subtype = CASE ISNULL(@damage_flag, 'N')
					WHEN 'Y'
						THEN 'D'
					ELSE 'N'
					END + @zone_group
			WHERE wh_id = @wh_id
				AND hu_id = @put_hu_id

			--Create tran log
			--Insert t_tran_log_holding
			INSERT INTO t_tran_log_holding (
				[tran_type]
				,[description]
				,[start_tran_date]
				,[start_tran_time]
				,[end_tran_date]
				,[end_tran_time]
				,[employee_id]
				,[control_number]
				,[control_number_2]
				,[wh_id]
				,[location_id]
				,[hu_id]
				,[item_number]
				,[lot_number]
				,[tran_qty]
				,wh_id_2
				,location_id_2
				,hu_id_2
				,generic_attribute_1
				,generic_attribute_2
				,generic_attribute_3
				,generic_attribute_4
				,generic_attribute_5
				,generic_attribute_6
				,generic_attribute_7
				,generic_attribute_8
				,generic_attribute_9
				,generic_attribute_10
				,generic_attribute_11
				)
			VALUES (
				'128'
				,'XDoc'
				,getdate()
				,getdate()
				,getdate()
				,getdate()
				,@user_id
				,@order_number
				,@pick_id
				,@wh_id
				,@pick_loc
				,@hu_id
				,@item_number
				,@lot_number
				,@picked_qty
				,@wh_id
				,@put_loc
				,@put_hu_id
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_1
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_2
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_3
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_4
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_5
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_6
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_7
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_8
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_9
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_10
					)
				,(
					SELECT a.attribute_value
					FROM t_sto_attrib_collection_detail a
						,t_attribute_legacy_map alm
					WHERE a.stored_attribute_id = @stored_attribute_id
						AND a.attribute_id = alm.generic_attribute_11
					)
				)
		END

		--修改语句，加上TOP 1限制 李嘉 2015年12月4日17:25:28
		IF EXISTS (
				SELECT 1
				FROM t_item_master WITH (NOLOCK)
				WHERE wh_id = @wh_id
					AND item_number = @item_number
					AND pick_type = 'S'
					AND ed_flag = 'Y'
					AND pack_flag = 'N'
				)
		BEGIN
			SELECT @rec_cnt = COUNT(1)
			FROM t_stored_item sto
			INNER JOIN t_item_master itm ON sto.wh_id = itm.wh_id
				AND sto.item_number = itm.item_number
			INNER JOIN t_pick_detail pkd ON pkd.pick_id = sto.[type]
			WHERE sto.wh_id = @wh_id
				AND EXISTS (
					SELECT 1
					FROM t_order WITH (NOLOCK)
					INNER JOIN t_customer c WITH (NOLOCK) ON t_order.customer_id = c.customer_id
					WHERE t_order.order_number = pkd.order_number
						AND t_order.wh_id = pkd.wh_id
						AND ISNULL(c.customer_type, '') <> 'SHWX-ND'
					)
				AND sto.hu_id = @put_hu_id
				--AND CAST((sto.actual_qty / (SELECT TOP 1 tiu.conversion_factor FROM t_order_detail od
				--				INNER JOIN t_item_uom tiu WITH(NOLOCK)
				--				ON od.wh_id = tiu.wh_id
				--				AND od.item_number = tiu.item_number
				--				AND od.order_uom = tiu.uom
				--					WHERE od.wh_id = sto.wh_id
				--					AND od.order_number = pkd.order_number
				--					AND od.item_number = sto.item_number)) as INT) <> (sto.actual_qty / (SELECT TOP 1 tiu.conversion_factor FROM t_order_detail od
				AND ceiling(sto.actual_qty / (
						SELECT TOP 1 tiu.conversion_factor
						FROM t_order_detail od
						INNER JOIN t_item_uom tiu WITH (NOLOCK) ON od.wh_id = tiu.wh_id
							AND od.item_number = tiu.item_number
							AND od.order_uom = tiu.uom
						WHERE od.wh_id = sto.wh_id
							AND od.order_number = pkd.order_number
							AND od.item_number = sto.item_number
						)) <> (
					sto.actual_qty / (
						SELECT TOP 1 tiu.conversion_factor
						FROM t_order_detail od
						INNER JOIN t_item_uom tiu WITH (NOLOCK) ON od.wh_id = tiu.wh_id
							AND od.item_number = tiu.item_number
							AND od.order_uom = tiu.uom
						WHERE od.wh_id = sto.wh_id
							AND od.order_number = pkd.order_number
							AND od.item_number = sto.item_number
						)
					)
			GROUP BY sto.hu_id
				,sto.wh_id
				,sto.shipment_number
				,pkd.order_number
				,sto.item_number
				,sto.stored_attribute_id
			ORDER BY sto.hu_id
				,sto.wh_id
				,sto.shipment_number
				,pkd.order_number
				,sto.item_number
				,sto.stored_attribute_id

			--IF @rec_cnt > 0
			IF isnull(@rec_cnt, 0) > 0
			BEGIN
				ROLLBACK TRANSACTION

				SET @msg = '播种存在小数'
				SET @passornot = 1

				RETURN
			END
		END
		------------------delete will 20160810 s------------------------------
		--EXEC csp_Send_Tote_ToPTW_WITHOUT_TRAN @wh_id
		--	,@put_hu_id
	  ------------------delete will 20160810 s------------------------------
----------------------------------
		--EXEC [csp_Send_Tote_ToPTW]	@wh_id,@put_hu_id, @passornot output, @msg output
		--IF @passornot > 0 
		--BEGIN
		--	ROLLBACK TRANSACTION
		--	RETURN
		--END
		
		SET @remove_qty = @remove_qty + @qty

		IF @remove_qty <> 0
		BEGIN
			--Remove the stock from pick location
			EXEC [dbo].[csp_Inventory_Adjust] @in_vchWhID = @wh_id
				,@in_vchItemNumber = @item_number
				,@in_vchLocationID = @pick_loc
				,@in_nType = 0
				,@in_vchHUID = @hu_id
				,@in_vchLotNumber = @lot_number
				,@in_nStoredAttributeID = @stored_attribute_id
				,@in_fQty = @remove_qty
				,@in_dtFifoDate = NULL
				,@in_dtExpirationDate = @expiration_date
				,@in_vchHUType = N'IV'
				,@in_vchShipmentNumber = NULL
				,@in_damage_flag = @damage_flag
				,@out_vchCode = @out_vchCode OUTPUT
				,@out_vchMsg = @out_vchMsg OUTPUT
		END

		SET @passornot = 0
		SET @msg = ''

		COMMIT TRANSACTION

		RETURN
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION

		SET @msg = ERROR_MESSAGE()
		SET @passornot = 1

		RETURN
	END CATCH
END


