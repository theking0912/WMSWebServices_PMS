
CREATE PROCEDURE usp_add_line_validation
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchWaveId         NVARCHAR(60),
@in_vchItemNumber     NVARCHAR(60),
@in_vchLineNumber     NVARCHAR(20),
@in_vchLotNumber      NVARCHAR(30),
@in_vchOrderNumber    NVARCHAR(60),
@in_nQuantitiy        INTEGER,
@out_vchMessage       NVARCHAR(200) OUTPUT, -- Contians "SUCCESS" or the message to be displayed.
@out_nAllow           INTEGER OUTPUT

AS

DECLARE 
    @v_nErrorNumber		  INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,

    @v_nRemainingQty      INTEGER,

	@e_GenSqlError   	  INTEGER,
    @e_FindOrdFailed      INTEGER,

    @v_nTranCount         INTEGER

    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @out_nAllow = 0 -- success allow to continue is the default 

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    -- Get the quantity that is still available to add to waves
    SELECT @v_nRemainingQty = afo_plan_qty
    FROM t_order_detail 
        WHERE wh_id = @in_vchWarehouseId
        AND order_number = @in_vchOrderNumber
        AND line_number = @in_vchLineNumber
        AND item_number = @in_vchItemNumber
        
    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_FindOrdFailed
        GOTO ErrorHandler
    END

    IF @v_nRemainingQty > 0
         SET @out_vchMessage = 'SUCCESS'

    IF @v_nRemainingQty < = 0
         SET @out_vchMessage = 'NO QTY'    

    -- Add Validation Additional validation Here

    IF @v_nTranCount = 0
        COMMIT TRANSACTION

 
    GOTO ExitLabel 


ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
        SET @out_nAllow = 2 -- Error
    END
    IF @v_nErrorNumber = @e_FindOrdFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'Unable to find t_order_detail record for the order.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50004
        SET @out_nAllow = 2 -- Error
    END

    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    -- Raiserror parameters: Error #, Severity(11=ADO requirement), State(1), Parameter(to be used in error)
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)        

ExitLabel:
    RETURN

