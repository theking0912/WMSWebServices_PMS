
CREATE  PROCEDURE usp_units_of_work

    @in_status      AS NVARCHAR(20),
    @in_WHID        AS NVARCHAR(10)

AS

    --declare variables
    DECLARE
    @n_Count 					INT,


    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_vchLogMsg                NVARCHAR(500),
    @v_vchParam1                NVARCHAR(100),
    @v_nRaiseErrorNumber        INT,
    @v_nErrorNumber             INT,
    @v_vchSqlErrorNumber        INT,
    @v_nCustomError             INT,  
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @e_MissingITUError          INT,
    @v_nTranCount               INT

    SET NOCOUNT ON

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_MissingITUError = 3

	-- create temp table to act as data buffer for operation
	CREATE TABLE #tmp_pick_detail 
    (
        pick_id					INT IDENTITY (1, 1) NOT NULL ,
        order_number 			NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL ,
        line_number 			NVARCHAR(5)		COLLATE DATABASE_DEFAULT NULL ,
        type  					NVARCHAR(2)		COLLATE DATABASE_DEFAULT NULL ,
        uom 					NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL ,
        work_q_id 				NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL ,
        work_type  				NVARCHAR(2)		COLLATE DATABASE_DEFAULT NULL ,
        status 					NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL ,
        item_number 			NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL ,
        lot_number 				NVARCHAR(15)	COLLATE DATABASE_DEFAULT NULL ,
        serial_number 			NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL ,
        unplanned_quantity 		FLOAT NOT NULL  DEFAULT (0),
        planned_quantity 		FLOAT NOT NULL  DEFAULT (0),
        picked_quantity 		FLOAT NOT NULL  DEFAULT (0),
        staged_quantity 		FLOAT NOT NULL  DEFAULT (0),
        loaded_quantity 		FLOAT NOT NULL  DEFAULT (0),
        pick_location 			NVARCHAR(50)	COLLATE DATABASE_DEFAULT NULL ,
        picking_flow 			NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL ,
        staging_location 		NVARCHAR(50)	COLLATE DATABASE_DEFAULT NULL ,
        zone 					NVARCHAR(20)	COLLATE DATABASE_DEFAULT NULL ,
        wave_id 				NVARCHAR(20)	COLLATE DATABASE_DEFAULT NULL  DEFAULT ('0'),
        load_id 				NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL ,
        load_sequence 			INT NULL ,
        stop_id 				NVARCHAR(20)	COLLATE DATABASE_DEFAULT NULL ,
        container_id 			NVARCHAR(22)	COLLATE DATABASE_DEFAULT NULL ,
        pick_category 			NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL ,
        user_assigned 			NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL ,
        bulk_pick_flag 			NCHAR(1)		COLLATE DATABASE_DEFAULT NULL ,
        stacking_sequence 		INT NULL ,
        pick_area 				NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL ,
        wh_id 					NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL ,
        cartonization_batch_id 	NVARCHAR(60)	COLLATE DATABASE_DEFAULT NULL,
	    manifest_batch_id		NVARCHAR(50)	COLLATE DATABASE_DEFAULT NULL,
        manifest_carrier_flag   NCHAR(1)		COLLATE DATABASE_DEFAULT NULL,
		stored_attribute_id		BIGINT			NULL
	)

    -- Create entries for all unplanned ORD records in the Temporary PKD table.  Unplanned ORD records
    -- are identified by ORD lines where t_order_detail.qty <> SUM(t_pick_detail.planned_qty).
    INSERT #tmp_pick_detail 
	( 
	order_number, 
	line_number, 
	type, 
	uom, 
	work_type, 
	status, 
	item_number, 
	lot_number,  
	unplanned_quantity,                
	planned_quantity, 
	pick_location, 
	picking_flow, 
	staging_location, 
    zone, 
	wave_id, 
	load_id, 
	load_sequence, 
	stop_id, 
	pick_area, 
	wh_id,
	manifest_carrier_flag,
	stored_attribute_id
	)
    SELECT
        orm.order_number           AS Order_Number, 
        ord.line_number            AS Line_Number, 
        'PP'                       AS Type, 
        NULL                       AS UOM, 
        NULL                       AS Work_Type, 
        'UNPLANNED'                AS Status,
        item_number                AS item_number, 
        lot_number                 AS Lot_Number, 
        ord.qty                    AS Unplanned_Qty,
        0                          AS Planned_Qty, 
        NULL                       AS Pick_Location, 
        0                          AS Picking_Flow,
        NULL                       AS Staging_location,
        NULL                       AS Zone, 
        ord.host_wave_id           AS Wave_ID, 
        orm.load_id                AS Load_ID, 
        orm.load_seq               AS Load_Sequence, 
        NULL                       AS Stop_ID, 
        NULL                       AS Pick_Area, 
        ord.wh_id                  AS WH_ID,
	    dbo.usf_manifest_carrier_flag ( @in_WHID, orm.order_number, '')
				   AS manifest_carrier_flag,
		ord.stored_attribute_id	   AS Stored_Attribute_Id
    FROM 
        t_order orm, 
        t_order_detail ord
    WHERE 
        orm.order_number = ord.order_number
        AND orm.wh_id = ord.wh_id
        AND orm.status LIKE @in_status
        AND ord.wh_id = @in_WHID
    ORDER BY orm.order_number, ord.line_number
		
	
    IF @@ERROR <> 0
	  BEGIN
		  SET @v_nErrorNumber = @e_SprocError
		  GoTo ErrorHandler
	  END
	
    -- update all selected orders that have been marked for breakdown
    -- set status ='U' from 'N'.  This will remove the posibility of another
    -- call to this sproc selecting same set of orders....
    UPDATE t_order set status = 'U' 
        where status = @in_status
        AND order_number in 
            (SELECT DISTINCT order_number FROM #tmp_pick_detail)
        AND wh_id = @in_WHID
    --  Call usp_breakdown_unplanned to break all the unplanned records into planned
    --  records by uom.

    EXEC usp_breakdown_unplanned

    IF @@ERROR <> 0
	  BEGIN
		  SET @v_nErrorNumber = @e_SprocError
		  GoTo ErrorHandler
	  END
      
    -- insert data back to t_pick_detail
    INSERT t_pick_detail ( 
        order_number, 
        line_number, 
        type, 
        uom, 
        work_type, 
        status, 
        item_number, 
        lot_number,  
        unplanned_quantity, 
        planned_quantity, 
        pick_location, 
        picking_flow, 
        staging_location, 
        zone, 
        wave_id, 
        load_id, 
        load_sequence, 
        stop_id, 
        pick_area, 
        wh_id,
		stored_attribute_id)
    SELECT 
        order_number, 
        line_number, 
 		type,
        uom, 
        work_type, 
        status, 
        item_number, 
        lot_number,  
        unplanned_quantity, 
        planned_quantity,  
        pick_location, 
        picking_flow, 
        staging_location, 
        zone, 
        wave_id, 
        load_id,
        load_sequence,
        stop_id,
        pick_area,
        wh_id,
		stored_attribute_id
        FROM #tmp_pick_detail

    --drop the temp table
    DROP TABLE #tmp_pick_detail
    

    GOTO ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        --EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' --+
                --ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            --ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
       -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(VARCHAR(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN
