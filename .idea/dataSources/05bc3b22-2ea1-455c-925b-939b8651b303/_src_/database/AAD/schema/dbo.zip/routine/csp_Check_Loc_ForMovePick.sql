
-- =======================================    
-- Author: Tony.chen    
-- Create Date: 11 Nov 2013    
-- Description: Get return slot for receipt
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Check_Loc_ForMovePick]    
     @wh_id					NVARCHAR(10)    
    ,@pick_loc				NVARCHAR(30)  
	,@suggest_zone			NVARCHAR(30)  
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @l_count int
		DECLARE @pick_loc_zone nvarchar(30)
		DECLARE @suggest_zone_type nvarchar(30)
		DECLARE @suggest_case_flag nvarchar(30)
		DECLARE @suggest_zone_status nvarchar(30)
		DECLARE @cur_zone_type nvarchar(30)
		DECLARE @cur_case_flag nvarchar(30)
		DECLARE @cur_zone_status nvarchar(30)
		--check zone  add by will

		--IF EXISTS (SELECT 1
  -- FROM t_zone z inner join t_zone_loca zl on z.wh_id = zl.wh_id and z.zone = zl.zone
  -- WHERE zl.location_id = @pick_loc AND zl.wh_id = @wh_id  AND z.zone<>@suggest_zone)
  -- BEGIN
  --    	SET @passornot = 4
		--RETURN
  -- END



		--Check the zone
		SET @pick_loc_zone = (SELECT max(zone)
							FROM t_zone_loca
							WHERE wh_id = @wh_id
							and location_id = @pick_loc)

		IF @pick_loc_zone <> @suggest_zone
			BEGIN
				SELECT @suggest_zone_type = zone_type, 
						@suggest_case_flag = ISNULL(case_flag,'N'),
						@suggest_zone_status = [status]
				FROM t_zone
				WHERE wh_id = @wh_id
				AND zone = @suggest_zone

				IF @@ROWCOUNT = 0
					BEGIN
						SET @passornot = 4
						RETURN
					END 

				IF ISNULL(@suggest_zone_status,'') ='H'
					BEGIN
						SET @passornot = 4
						RETURN
					END  

				SELECT @cur_zone_type = zone_type, 
						@cur_case_flag = ISNULL(case_flag,'N'),
						@cur_zone_status = ISNULL([status],'A')
				FROM t_zone
				WHERE wh_id = @wh_id
				AND zone = @pick_loc_zone

				IF (@suggest_case_flag <> @cur_case_flag 
					OR @suggest_zone_type <> @cur_zone_type)
					BEGIN
						SET @passornot = 4
						RETURN
					END
				--added by tony 2014/02/27
				IF ISNULL(@cur_zone_status,'') ='H'
					BEGIN
						SET @passornot = 4
						RETURN
					END  

				IF (@suggest_zone_type = @cur_zone_type
						AND (@suggest_zone_type = 'CV' OR @suggest_zone_type = 'BV'))
						BEGIN
						IF NOT EXISTS( SELECT 1 FROM tbl_client_zone a
										WHERE a.wh_id = @wh_id
										AND a.zone = @suggest_zone
										AND exists ( select 1 from tbl_client_zone b
													WHERE b.wh_id = @wh_id
													AND b.zone = @pick_loc_zone
													AND b.wh_id = a.wh_id
													AND b.client_code = a.client_code))
							BEGIN
								SET @passornot = 4
								RETURN
							END
						END
			END

		SET @passornot = 0
        RETURN

    END TRY

    BEGIN CATCH
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END

