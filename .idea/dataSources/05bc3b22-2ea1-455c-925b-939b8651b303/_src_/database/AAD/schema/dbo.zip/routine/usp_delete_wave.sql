
CREATE PROCEDURE usp_delete_wave
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchWaveId         NVARCHAR(60),
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contians "SUCCESS" or the message to be displayed.

AS

DECLARE 
    @v_nErrorNumber		  INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,

	@e_GenSqlError   	  INTEGER,
    @e_DelWvmFailed       INTEGER,

    @v_nTranCount         INTEGER


    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'

    SET @c_nModuleNumber = 63
    SET @c_nFileNumber = 5
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_DelWvmFailed = 2

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    -- Delete the record for the wave from the t_wave_master table
    DELETE t_wave_master
    WHERE wave_id = @in_vchWaveId
        AND wh_id = @in_vchWarehouseId
   
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_DelWvmFailed
        GOTO ErrorHandler			
    END

   -- There should be no need to clean up any work q records because it 
   -- is a required that the wave be held before it can be deleted. The
   -- hold function should clean up any oustanding wrok requests.


    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_DelWvmFailed
    BEGIN -- 
        -- Log Error    
        SET @v_vchLogMsg = 'An attempt to delete from the t_wave_master table for wave ' +
            ISNULL(@in_vchWaveId,'(NULL)') + ' failed.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50004 -- Delete Failed
    END

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN
