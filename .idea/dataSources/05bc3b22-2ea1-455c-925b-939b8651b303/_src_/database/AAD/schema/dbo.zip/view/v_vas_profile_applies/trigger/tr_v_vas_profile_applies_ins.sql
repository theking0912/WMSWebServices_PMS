
CREATE TRIGGER tr_v_vas_profile_applies_ins ON v_vas_profile_applies
INSTEAD OF INSERT
AS
BEGIN
SET NOCOUNT ON
   INSERT INTO t_vas_profile_applies
      SELECT vas_profile_id, item_number, uom, inv_class, inv_cat, inventory_type, 
             inbound_order_type, tran_type, vendor_code, carrier_id, 
             gen_attribute_value1, gen_attribute_value2, gen_attribute_value3, 
             gen_attribute_value4, gen_attribute_value5, gen_attribute_value6, 
             gen_attribute_value7, gen_attribute_value8, gen_attribute_value9, 
             gen_attribute_value10, gen_attribute_value11, client_code, display_item_number
      FROM inserted
END



