
CREATE VIEW [dbo].[v_rpt_pod]
AS
    SELECT  top 100 percent
	        convert(char(10),tb.create_date,120) create_date,
            tb.wh_id ,
            tf.name AS wh_name ,
            td.description AS type ,
            te.vendor_code ,
            te.vendor_name ,
            tb.po_number ,
            tc.line_number ,
            tc.item_number ,
            ta.description ,
            ta.uom ,
            tc.qty ,
            tb.create_by
    FROM    t_item_master AS ta
            INNER JOIN t_po_detail AS tc ON ta.wh_id = tc.wh_id
                                            AND ta.item_number = tc.item_number
            INNER JOIN t_po_master AS tb ON tc.wh_id = tb.wh_id
                                            AND tc.po_number = tb.po_number
            INNER JOIN t_lookup AS td ON tb.type_id = td.lookup_id
            INNER JOIN t_vendor AS te ON tb.vendor_code = te.vendor_code
            INNER JOIN t_whse AS tf ON tb.wh_id = tf.wh_id
    WHERE   ( td.lookup_type = 'TYPE' )
            AND ( td.source = 't_po_master' )
    ORDER BY ta.wh_id ,
            tc.po_number ,
            tc.line_number
