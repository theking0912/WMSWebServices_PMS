

CREATE FUNCTION [dbo].[csf_get_the_avg_qty]

(

@wh_id			varchar(100),

@order_number	varchar(100),

@wave_id 		varchar(100),

@item_number 	varchar(100),

@line_number 	varchar(100)

)

RETURNS NVARCHAR(10)

AS

BEGIN


DECLARE



@total_qty			INTEGER,

@planned_quantity	INTEGER,

@picked_quantity	INTEGER,

@staged_quantity	INTEGER,

@loaded_quantity	INTEGER,

@shipped_quantity	INTEGER,

@return_quantity	INTEGER,

@different_count	INTEGER,

@different_flag varchar(50)='R'



DECLARE @temp_data_table table

(wave_id int,order_number nvarchar(50),line_number int,item_number nvarchar(50),total_qty int,planned_quantity int,picked_quantity int,staged_quantity int,loaded_quantity int,shipped_quantity int,return_quantity int)



insert into @temp_data_table

select top 1

       tp.wave_id,

	   t.order_number,

       td.line_number,

       td.item_number,

       isnull(tp.unplanned_quantity * 1 /

              (SELECT TOP(1) tiu.conversion_factor

                 from t_item_uom tiu

                inner join t_order_detail tod

                   on tod.item_number = tiu.item_number

                  and uom = order_uom

                where order_number = t.order_number

                  and tod.item_number = td.item_number

                  and tp.line_number = tod.line_number),

              0) + isnull(tp.planned_quantity * 1 /

                          (select TOP(1) tiu.conversion_factor

                             from t_item_uom tiu

                            inner join t_order_detail tod

                               on tod.item_number = tiu.item_number

                              and uom = order_uom

                            where order_number = t.order_number

                              and tod.item_number = td.item_number

                              and tp.line_number = tod.line_number),

                          0) as total_qty,

       isnull(tp.planned_quantity * 1 /

              (select TOP(1) tiu.conversion_factor

                 from t_item_uom tiu

                inner join t_order_detail tod

                   on tod.item_number = tiu.item_number

                  and uom = order_uom

                where order_number = t.order_number

                  and tod.item_number = td.item_number

                  and tp.line_number = tod.line_number),

              0) as planned_quantity,

       isnull(tp.picked_quantity * 1 /

              (select TOP(1) tiu.conversion_factor

                 from t_item_uom tiu

                inner join t_order_detail tod

                   on tod.item_number = tiu.item_number

                  and uom = order_uom

                where order_number = t.order_number

                  and tod.item_number = td.item_number

                  and tp.line_number = tod.line_number),

              0) as picked_quantity,

       isnull(tp.staged_quantity * 1 /

              (select TOP(1) tiu.conversion_factor

                 from t_item_uom tiu

                inner join t_order_detail tod

                   on tod.item_number = tiu.item_number

                  and uom = order_uom

                where order_number = t.order_number

                  and tod.item_number = td.item_number

                  and tp.line_number = tod.line_number),

              0) as staged_quantity,

       isnull(tp.loaded_quantity * 1 /

              (select TOP(1) tiu.conversion_factor

                 from t_item_uom tiu

                inner join t_order_detail tod

                   on tod.item_number = tiu.item_number

                  and uom = order_uom

                where order_number = t.order_number

                  and tod.item_number = td.item_number

                  and tp.line_number = tod.line_number),

              0) as loaded_quantity,

       isnull(tp.shipped_quantity * 1 /

              (select TOP(1) tiu.conversion_factor

                 from t_item_uom tiu

                inner join t_order_detail tod

                   on tod.item_number = tiu.item_number

                  and uom = order_uom

                where order_number = t.order_number

                  and tod.item_number = td.item_number

                  and tp.line_number = tod.line_number),

              0) as shipped_quantity,

	   isnull((select TOP(1) CAST(ROUND(MENGE,0) AS int) from tbl_inf_exp_inoutbound where EBELN = t.order_number),0) AS return_quantity

  from t_order t

 inner join t_order_detail td

    on t.wh_id = td.wh_id

   and t.order_number = td.order_number

  left join t_pick_detail tp

    on td.wh_id = tp.wh_id

   and td.order_number = tp.order_number

   and tp.line_number = td.line_number

   and td.item_number = tp.item_number

 where t.wh_id = @wh_id

   and t.order_number = @order_number

   and tp.wave_id = @wave_id

   and td.item_number = @item_number

   and td.line_number = @line_number

   and tp.type in ('PP','PO')



   select @different_count = sum(total_qty + planned_quantity + picked_quantity + staged_quantity + loaded_quantity + shipped_quantity + return_quantity)/7 

   from @temp_data_table

   select @total_qty = total_qty from @temp_data_table



    if @different_count <> @total_qty

		begin

			set @different_flag = 'Y'

		end

	else

		begin

			set @different_flag = 'N'

		end



	return @different_flag;





END









