
CREATE PROCEDURE [dbo].[csp_Replenishment_Alloc_PB] 
	@item_number NVARCHAR(50)
	,@put_location NVARCHAR(50)
	,@rep_qty DECIMAL(30, 8)
	,@wh_id NVARCHAR(50)
AS
BEGIN
	DECLARE @damage_flag NVARCHAR(1) 
	DECLARE @pick_location NVARCHAR(50) --从哪个货位拣货
	DECLARE @lot_number NVARCHAR(50) --批次号
	DECLARE @pick_qty DECIMAL(30, 8) --拣货数量
	DECLARE @put_qty DECIMAL(30, 8) --拣货数量
	DECLARE @stored_attribute_id BIGINT --规格
	DECLARE @zone NVARCHAR(50) --区域
	DECLARE @work_q_id NVARCHAR(500) --补货Id
	DECLARE @rep_qty_1 DECIMAL(30, 8)
	DECLARE @full_case_qty DECIMAL(30, 8) --满箱值
	
	SET @damage_flag = 'N'
	SET @rep_qty_1=@rep_qty

	--生成P区的拣货任务
	WHILE @rep_qty > 0
	BEGIN
		SELECT TOP 1 @pick_location = tlo.location_id
			,@lot_number = ts.lot_number
			,@pick_qty = (
				CASE 
					WHEN @rep_qty >= ISNULL(ts.actual_qty, 0) - ISNULL(ts.unavailable_qty, 0) - ISNULL(alloc.allocated_qty, 0)
						THEN ISNULL(ts.actual_qty, 0) - ISNULL(ts.unavailable_qty, 0) - ISNULL(alloc.allocated_qty, 0)
					ELSE @rep_qty
					END
				)
			,@stored_attribute_id = ts.stored_attribute_id
			,@zone = tzl.zone
			,@wh_id = ts.wh_id
		FROM dbo.t_location tlo
		INNER JOIN dbo.t_zone_loca tzl ON tlo.wh_id = tzl.wh_id
			AND tlo.location_id = tzl.location_id
		INNER JOIN t_stored_item ts ON tzl.wh_id = ts.wh_id
			AND tzl.location_id = ts.location_id
		LEFT JOIN (
			SELECT location_id
				,item_number
				,wh_id
				,SUM(ISNULL(allocated_qty, 0) - ISNULL(picked_qty, 0)) AS allocated_qty
				,lot_number
				,hu_id
				,stored_attribute_id
			FROM tbl_allocation
			WHERE item_number = @item_number
				AND wh_id = @wh_id
				AND allocated_qty > 0
				AND status IN (
					'U'
					,'A'
					)
				AND allo_type = 'R1'
			GROUP BY location_id
				,item_number
				,wh_id
				,lot_number
				,hu_id
				,stored_attribute_id
			) alloc ON ts.wh_id = alloc.wh_id
			AND ts.item_number = alloc.item_number
			AND ts.location_id = alloc.location_id
			AND ISNULL(ts.lot_number, '') = ISNULL(alloc.lot_number, '')
			AND ISNULL(ts.hu_id, '') = ISNULL(alloc.hu_id, '')
			AND ISNULL(ts.stored_attribute_id, 0) = ISNULL(alloc.stored_attribute_id, 0)
		WHERE tlo.type IN (
				'P'
				,'L'
				,'H'
				)
			AND (ISNULL(ts.actual_qty, 0) - ISNULL(ts.unavailable_qty, 0)) - ISNULL(alloc.allocated_qty, 0) > 0
			AND ts.item_number = @item_number
			AND ts.wh_id = @wh_id
			AND ISNULL(ts.damage_flag, '') = @damage_flag
			AND ts.status='A'
		ORDER BY ts.lot_number ASC
			,(CASE WHEN (@rep_qty - ISNULL(ts.actual_qty, 0) + ISNULL(ts.unavailable_qty, 0)) + ISNULL(alloc.allocated_qty, 0) >= 0 
			THEN @rep_qty - ISNULL(ts.actual_qty, 0) + ISNULL(ts.unavailable_qty, 0) + ISNULL(alloc.allocated_qty, 0)
			ELSE 99999999 + @rep_qty - ISNULL(ts.actual_qty, 0) + ISNULL(ts.unavailable_qty, 0) + ISNULL(alloc.allocated_qty, 0)
			END
			)
			,tzl.pick_seq ASC;

		IF @@ROWCOUNT = 0
			BREAK

		IF Exists(select 1 from tbl_allocation 
				where wh_id=@wh_id 
				and item_number=@item_number 
				and location_id=@pick_location
				and allo_type='R1' 
				and status='U' 
				and (lot_number=@lot_number or (lot_number is null and @lot_number is null)) 
				and (stored_attribute_id=@stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
				)
		BEGIN
			UPDATE tbl_allocation SET allocated_qty=allocated_qty+@pick_qty
				where wh_id=@wh_id 
				and item_number=@item_number 
				and location_id=@pick_location
				and allo_type='R1' 
				and status='U' 
				and (lot_number=@lot_number or (lot_number is null and @lot_number is null)) 
				and (stored_attribute_id=@stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
		END
		ELSE
		BEGIN
			--新增拣货任务
			INSERT INTO dbo.tbl_allocation (
				item_number
				,lot_number
				,stored_attribute_id
				,location_id
				,allocated_qty
				,picked_qty
				,status
				,zone
				,wh_id
				,allo_type
				,released_date
				,damage_flag
				)
			VALUES (
				@item_number
				,@lot_number
				,@stored_attribute_id
				,@pick_location
				,@pick_qty
				,0
				,N'U'
				,@zone
				,@wh_id
				,N'R1'
				,getdate()
				,N'N'
				);
		END

		SET @rep_qty = @rep_qty - @pick_qty
	END

	--实际拣出的数量
	SET @put_qty = @rep_qty_1 - @rep_qty 

	IF @put_qty>0
	BEGIN
		UPDATE t_control
		SET next_value = next_value + 1
		WHERE control_type = 'WORK_Q_ID'

		SELECT TOP 1 @work_q_id = next_value
		FROM t_control 
		WHERE control_type = 'WORK_Q_ID'

		--新增补货任务
		INSERT INTO dbo.t_work_q (
			work_q_id
			,work_type
			,date_due
			,time_due
			,item_number
			,wh_id
			,location_id
			,work_status
			,qty
			,workers_required
			,workers_assigned
			,zone
			,datetime_stamp
			,lot_number
			,description
			)
		VALUES (
			@work_q_id
			,N'05'
			,GETDATE()
			,GETDATE()
			,@item_number
			,@wh_id
			,@put_location
			,N'U'
			,@put_qty
			,0
			,0
			,@zone
			,GETDATE()
			,@lot_number
			,N'例常补货'
			)	
	END
END

