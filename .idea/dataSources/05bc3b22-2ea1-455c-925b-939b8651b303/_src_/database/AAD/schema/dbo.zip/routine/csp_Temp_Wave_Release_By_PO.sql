
-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Allocation Zone for put
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Wave_Release_By_PO]    
     @wh_id				NVARCHAR(10)   
    ,@wave_id		    NVARCHAR(30) 
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		
		DECLARE @promotion_location	NVARCHAR(30)
		DECLARE @order_number		NVARCHAR(30)
		DECLARE @detail_id			int
		DECLARE @status	NVARCHAR(20)
		DECLARE @wave_type	NVARCHAR(20)
		DECLARE @cnt			int
		DECLARE @cnt_released	int
		DECLARE @cnt_noreleased INT


		select @status = status,@wave_type = wave_type
		from t_wave_master
		where wh_id = @wh_id
		and   wave_id = @wave_id

		if(@status not in ('N','P') or @wave_type <> 'PO')
			return;

		set @detail_id = 0

		while(1=1)
		begin
			
			select top 1 @order_number = o.order_number ,@detail_id=wd.wave_detail_id
			from  t_afo_wave_detail wd, t_order o 
			where wd.wh_id = o.wh_id 
			and wd.order_number = o.order_number 
			and o.status = 'WAVED' 
			and wd.wh_id = @wh_id 
			and wd.wave_id = @wave_id
			and wd.wave_detail_id > @detail_id
			order by wd.wave_detail_id
			if @@ROWCOUNT = 0
				break;

				--print '@order_number ' + @order_number
			/*
			if not exists (select 1
							from t_stored_item sti inner join t_location loc on sti.wh_id = loc.wh_id and sti.location_id = loc.location_id and loc.type = 'P'
													inner join t_afo_wave_detail_line wdl on sti.wh_id = wdl.wh_id and sti.item_number = wdl.item_number 
														and (wdl.lot_number is null or wdl.lot_number = sti.lot_number)
													inner join t_afo_wave_detail wd on wdl.wh_id = wd.wh_id and wdl.wave_detail_id = wd.wave_detail_id 
														and wd.order_number = @order_number and wd.wh_id = @wh_id
							where loc.type = 'P'
							and wd.order_number = @order_number
							and sti.wh_id = @wh_id)
				break;
				
			if exists (select 1
						from t_stored_item sti inner join t_location loc on sti.wh_id = loc.wh_id and sti.location_id = loc.location_id and loc.type = 'P'
												inner join t_afo_wave_detail_line wdl on sti.wh_id = wdl.wh_id and sti.item_number = wdl.item_number 
													and (wdl.lot_number is null or wdl.lot_number = sti.lot_number)
												inner join t_afo_wave_detail wd on wdl.wh_id = wd.wh_id and wdl.wave_detail_id = wd.wave_detail_id 
													and wd.order_number = @order_number and wd.wh_id = @wh_id
						where sti.actual_qty  < (wdl.planned_qty + (select isnull(sum(allocated_qty - isnull(picked_qty,0)),0) 
																	from tbl_allocation alloc 
																	where alloc.wh_id = sti.wh_id
																	and alloc.item_number = sti.item_number
																	and alloc.location_id = sti.location_id
																	and (sti.lot_number is null or alloc.lot_number = sti.lot_number)
																	and (sti.stored_attribute_id is null or alloc.stored_attribute_id = sti.stored_attribute_id)))
						)
				break;*/

			if not exists (select 1 from t_pick_detail where order_number = @order_number and wh_id = @wh_id)
			INSERT INTO t_pick_detail (
                order_number, line_number, type, status, item_number, 
                lot_number, unplanned_quantity, planned_quantity, picked_quantity, 
                wave_id,wh_id,stored_attribute_id,pick_location)
			SELECT @order_number	AS order_number, 
                wdl.line_number		AS line_number, 
                'PO'				AS type, 
                'UNPLANNED'			AS status,
                wdl.item_number		AS item_number, 
                (CASE when wdl.lot_number='' then null else wdl.lot_number end)		AS lot_number, 
                0					AS unplanned_quantity,
                wdl.planned_qty		AS planned_quantity, 
                0					AS picked_quantity,
                @wave_id			AS wave_id,
                @wh_id				AS wh_id,
				null				AS stored_attribute_id,
				@promotion_location AS pick_location
            FROM t_afo_wave_detail_line wdl , t_afo_wave_detail wd
		    where wdl.wh_id = wd.wh_id
		    and wdl.wave_detail_id = wd.wave_detail_id
		    and wd.wh_id = @wh_id
		    and wd.order_number = @order_number

			exec csp_Order_Allocation_PO @wh_id,@order_number

		end

		-- update wave status/release date
		--select @cnt = count(0),@cnt_released = sum((case when o.status = 'RELEASED' then 1 else 0 end))
		select @cnt = count(0), @cnt_noreleased = sum((case when o.status = 'WAVED' then 1 else 0 end))
		from  t_afo_wave_detail wd, t_order o 
		where wd.wh_id = o.wh_id 
		and wd.order_number = o.order_number 
		and wd.wh_id = @wh_id 
		and wd.wave_id = @wave_id

		--if @cnt = @cnt_released
		IF @cnt_noreleased = 0
		update t_wave_master
		set status = 'R'
		,	released_date = getdate()
		where wh_id = @wh_id
		and wave_id = @wave_id

		if @cnt > @cnt_noreleased and @cnt_noreleased > 0
		update t_wave_master
		set status = 'P'
		,	released_date = getdate()
		where wh_id = @wh_id
		and wave_id = @wave_id

        RETURN

    END TRY

    BEGIN CATCH
        RETURN
    END CATCH
  
END

