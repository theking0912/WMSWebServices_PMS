

-- Procedure

-- =======================================    
-- Author: David.Zeng    
-- Create Date: 10 Dec 2013    
-- Description: Insert Cycle Count
--  
    
-- =======================================    
    
CREATE  PROCEDURE [dbo].[csp_Approve_CCDiscrepancy]    
     @wh_id				    NVARCHAR(10)  
	,@ccdiscrepancy_id      NVARCHAR(30)
	,@user_id               NVARCHAR(30)
AS    
 DECLARE  @discrepancy_qty INT
 DECLARE @msg NVARCHAR(200)
 DECLARE @current_date datetime
	,@work_q_id				NVARCHAR(30) 
    ,@location_id		    NVARCHAR(50) 
	,@hu_id                 NVARCHAR(22)
	,@item_number           NVARCHAR(30)
	,@lot_number            NVARCHAR(30)
	,@stored_attribute_id   NVARCHAR(15)
	,@sys_qty				FLOAT
	,@actual_qty			FLOAT
	,@expire_date			DATETIME
	,@zone_type				NVARCHAR(10)
	,@damage_flg			NVARCHAR(10)
	,@dis_wh_id				NVARCHAR(50)
	,@client_code         NVARCHAR(50)
	,@v_qty					FLOAT
	,@erro_msg				NVARCHAR(50) 
	,@storage_location			NVARCHAR(50)    
	,@nostock_flag			NVARCHAR(2)
	,@uom					NVARCHAR(20)
	,@subtype			    NVARCHAR(20)
	,@zone_group 		    NVARCHAR(20)
 DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		BEGIN TRANSACTION
		SELECT @work_q_id = work_q_id
			,@location_id = location_id
			,@hu_id       = sys_hu_id
			,@item_number = sys_item_number
			,@lot_number  = sys_lot_number
			,@stored_attribute_id = sys_stored_attribute_id
			,@sys_qty	= sys_qty
			,@actual_qty = count_qty
			,@expire_date= expiration_date  --获取生产日期 add by Jerry 2014-08-12
			,@dis_wh_id=dis_wh_id
			,@storage_location = storage_location
		FROM tbl_cyclecount_history WITH(NOLOCK) 
		where wh_id = @wh_id
		and record_id = @ccdiscrepancy_id

		--获取client_code
		SELECT @client_code=client_code
		  from dbo.t_item_master WITH(NOLOCK) 
		WHERE item_number=@item_number
		  and wh_id= @wh_id

		--获取damage_flag  add by Jerry 2014-08-12
		SELECT  @zone_type = ta.zone_type,@zone_group=ta.zone_group
		FROM    dbo.t_zone ta WITH (NOLOCK) ,
			t_zone_loca tb WITH (NOLOCK)
		WHERE   ta.zone = tb.zone 
		AND location_id= @location_id


		IF ISNULL(@dis_wh_id,'')='' or ISNULL(@storage_location,'')=''
		BEGIN
		  SET @erro_msg = '商品【'+ @item_number+'】货位【'+ @location_id + '】工厂或库存地点不能为空'
		  RAISERROR(@erro_msg,11,1)

		END 


		--海底捞判断同货位同托盘已经存在其他批次或打包规格的商品 并且没有做报损操作，校验不允许混放
		--SELECT @v_qty = ISNULL(SUM(ta.actual_qty),0) + ISNULL(SUM(tb.count_qty - tb.sys_qty),0)
		--  FROM    dbo.t_stored_item ta WITH(NOLOCK)  LEFT OUTER JOIN
		--		   tbl_cyclecount_history tb WITH(NOLOCK) 
		--      ON   ta.item_number = tb.sys_item_number
		--		AND ta.location_id = tb.location_id
		--		AND ta.hu_id = tb.sys_hu_id
		--		AND ta.lot_number = tb.sys_lot_number
		--		AND ta.stored_attribute_id = tb.sys_stored_attribute_id
		--		AND ISNULL(tb.close_sign,'N')<>'Y'
		--		AND tb.count_qty-tb.sys_qty>0
		-- WHERE    ta.wh_id = @wh_id
		--			and ta.item_number = @item_number
		--			and ta.location_id = @location_id
		--			--and ISNULL(ta.type,0) = ISNULL(@type,0)
		--			and (ISNULL(ta.lot_number,'#') <> ISNULL(@lot_number,'#')
		--				or ISNULL(ta.expiration_date,'1900-01-01') <> ISNULL(@expire_date,'1900-01-01')
		--				or ISNULL(ta.stored_attribute_id,0)<> ISNULL(@stored_attribute_id ,0))
		--			and ISNULL(ta.hu_id,'#') = ISNULL(@hu_id,'#')
		
		   
		--IF @v_qty>0 
		--BEGIN
		--  SET @erro_msg = '商品【'+ @item_number+'】货位【'+ @location_id + '】已存在其他批次的库存，请检查或再次盘点'
		--  RAISERROR(@erro_msg,11,1)

		--END 

		IF SUBSTRING(@zone_type,1,1)='N'OR @zone_type IS NULL
		BEGIN
			SET @damage_flg='N'		
		END
		ELSE 
		BEGIN
			SET @damage_flg='Y'
		END

		SET @subtype=@damage_flg+@zone_group

		SET @discrepancy_qty = @actual_qty - @sys_qty
		SET @current_date = GETDATE()

		IF isnull((SELECT sum(actual_qty) FROM t_stored_item  WITH(NOLOCK) 
						WHERE wh_id = @wh_id 
							AND location_id = @location_id
							AND item_number = @item_number
							AND (ISNULL(lot_number,'#') =ISNULL(@lot_number,'#'))
							AND (ISNULL(expiration_date,'1900-01-01')=ISNULL(@expire_date,'1900-01-01'))
							AND (@hu_id IS NULL OR hu_id=@hu_id)
							AND (@stored_attribute_id is null or stored_attribute_id = @stored_attribute_id)),0) 
			+ @discrepancy_qty >= 0 OR @work_q_id = 'LOSS'
		BEGIN		
		  IF @work_q_id <> 'LOSS'
			EXEC [dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @wh_id,
				@in_vchItemNumber = @item_number,
				@in_vchLocationID = @location_id,
				@in_nType = 0,
				@in_vchHUID = @hu_id,
				@in_vchLotNumber =@lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @discrepancy_qty,
				@in_dtFifoDate =@current_date,
				@in_dtExpirationDate = @expire_date,
				@in_vchHUType = N'IV',
				@in_vchShipmentNumber =NULL,
				@in_damage_flag=@damage_flg,
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT

	-------------------will add 20160622 start------------------
	IF EXISTS (SELECT 1 FROM t_stored_item WHERE wh_id=@wh_id
	                                         AND item_number=@item_number
											 AND location_id=@location_id
											 AND type=0
											 AND (ISNULL(hu_id,'')='' OR hu_id=@hu_id)
											 AND (ISNULL(lot_number,'')='' OR lot_number=@lot_number)
											 AND (ISNULL(stored_attribute_id,'')='' OR stored_attribute_id=@stored_attribute_id)
										--	 AND fifo_date=@current_date
											 AND (ISNULL(expiration_date,'')='' OR expiration_date=@expire_date)
											 AND damage_flag=@damage_flg
											 AND unavailable_qty>0
											 AND status='A'
											 AND actual_qty>0)
	BEGIN
	 
	 UPDATE t_stored_item SET unavailable_qty=0 WHERE wh_id=@wh_id
	                                         AND item_number=@item_number
											 AND location_id=@location_id
											 AND type=0
											 AND (ISNULL(hu_id,'')='' OR hu_id=@hu_id)
											 AND (ISNULL(lot_number,'')='' OR lot_number=@lot_number)
											 AND (ISNULL(stored_attribute_id,'')='' OR stored_attribute_id=@stored_attribute_id)
										--	 AND fifo_date=@current_date
											 AND (ISNULL(expiration_date,'')='' OR expiration_date=@expire_date)
											 AND damage_flag=@damage_flg
											 AND unavailable_qty>0
											 AND status='A'
											 AND actual_qty>0
	 
	END

	IF EXISTS (SELECT 1 FROM t_stored_item WHERE wh_id=@wh_id
	                                         AND item_number=@item_number
											 AND location_id=@location_id
											 AND type=0
											 AND (ISNULL(hu_id,'')='' OR hu_id=@hu_id)
											 AND (ISNULL(lot_number,'')='' OR lot_number=@lot_number)
											 AND (ISNULL(stored_attribute_id,'')='' OR stored_attribute_id=@stored_attribute_id)
										--	 AND fifo_date=@current_date
											 AND (ISNULL(expiration_date,'')='' OR expiration_date=@expire_date)
											 AND damage_flag=@damage_flg
											 AND unavailable_qty>0
											 AND status='A'
											 AND actual_qty=0)
	BEGIN
	 
	 DELETE t_stored_item  WHERE wh_id=@wh_id
	                                         AND item_number=@item_number
											 AND location_id=@location_id
											 AND type=0
											 AND (ISNULL(hu_id,'')='' OR hu_id=@hu_id)
											 AND (ISNULL(lot_number,'')='' OR lot_number=@lot_number)
											 AND (ISNULL(stored_attribute_id,'')='' OR stored_attribute_id=@stored_attribute_id)
										--	 AND fifo_date=@current_date
											 AND (ISNULL(expiration_date,'')='' OR expiration_date=@expire_date)
											 AND damage_flag=@damage_flg
											 AND unavailable_qty>0
											 AND status='A'
											 AND actual_qty=0
	 IF EXISTS ( SELECT 1 FROM t_hu_master WHERE hu_id=@hu_id AND location_id=@location_id
	                                                          AND type='IV'
															  AND status='A'
	                                                          AND NOT EXISTS (SELECT 1 FROM t_stored_item WHERE ISNULL(hu_id,'')=@hu_id))
	  BEGIN
	   DELETE t_hu_master WHERE hu_id=@hu_id AND location_id=@location_id
	                                         AND type='IV'
											 AND status='A'
	                                         AND NOT EXISTS (SELECT 1 FROM t_stored_item WHERE ISNULL(hu_id,'')=@hu_id)
	  END
	END
	-------------------will add 20160622 end------------------	
			
			--Add by George 20160509
			UPDATE t_hu_master SET subtype=@subtype 
			WHERE wh_id=@wh_id 
			AND hu_id=@hu_id 

			 --Close the discrepancy
			 UPDATE tbl_cyclecount_history 
				SET close_sign='Y'
				,close_time = getdate()
				,close_by =@user_id
				,close_type ='APPROVE'
			WHERE wh_id=@wh_id
			  AND record_id = @ccdiscrepancy_id
			--上传ERP/OMS
			SELECT @nostock_flag = nostock_flag
			  FROM dbo.t_item_master
			 WHERE item_number = @item_number
			   AND wh_id = @wh_id

			SELECT @uom =uom from dbo.t_item_uom WHERE item_number = @item_number
			AND wh_id =@wh_id AND conversion_factor=1 

			--生成流水帐页
		    EXEC [dbo].[csp_add_account_page]
			@wh_id  ,
			@item_number  ,
			@lot_number ,
			NULL,
			@discrepancy_qty  ,
			@uom,
			@ccdiscrepancy_id ,
			null  ,
			'INV'  ,
			'INV' 	,			----IN /OUT /INV  帐页类型
			@msg  OUTPUT
			
			IF ISNULL(@nostock_flag,'N')='N'

			INSERT into dbo.tbl_inf_exp_inventory_adj
			        ( transaction_code ,
			          item_number ,
			          display_item_number ,
			          lot_number ,
			          quantity_before ,
			          quantity_after ,
			          quantity_change ,
			          hu_id ,
			          inventory_status_before ,
			          inventory_status_after ,
			          reason_code ,
			          fifo_date ,
			          from_location_id ,
			          to_location_id ,
			          user_id ,
			          warehouse_id ,
			          client_code ,
			          uom ,
			          reference_code ,
			          process_status ,
			          error_msg ,
			          inf_date,
					  damage_flag,
					  dis_wh_id,
					  storage_location
			        )
			VALUES  ( N'N' , -- transaction_code - nvarchar(1)
			          @item_number , -- item_number - nvarchar(30)
			          NULL , -- display_item_number - nvarchar(30)
			          @lot_number , -- lot_number - nvarchar(15)
			          @sys_qty , -- quantity_before - numeric
			          @actual_qty , -- quantity_after - numeric
			          @discrepancy_qty , -- quantity_change - numeric
			          @hu_id , -- hu_id - nvarchar(30)
			          null , -- inventory_status_before - nvarchar(1)
			          null , -- inventory_status_after - nvarchar(1)
			          null , -- reason_code - nvarchar(30)
			          CONVERT(NVARCHAR(100),@current_date,112) , -- fifo_date - nvarchar(8)
			          @location_id , -- from_location_id - nvarchar(50)
			          @location_id , -- to_location_id - nvarchar(50)
			          @user_id , -- user_id - nvarchar(30)
			          @wh_id , -- warehouse_id - nvarchar(10)
			          @client_code , -- client_code - nvarchar(30)
			          (SELECT TOP 1 uom from dbo.t_item_uom WITH (NOLOCK) WHERE item_number = @item_number AND wh_id =@wh_id),--N'EA' , -- uom - nvarchar(30)
			          NULL , -- reference_code - nvarchar(30)
			          N'Ready' , -- process_status - nvarchar(25)
			          null , -- error_msg - nvarchar(2000)
			          GETDATE(),  -- inf_date - datetime
					  @damage_flg,
					  @dis_wh_id,
					  @storage_location
			        )
			
			--Create tran log
			IF @work_q_id <> 'LOSS'
			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
				,generic_attribute_1,
				generic_attribute_2,
				generic_attribute_3,
				generic_attribute_4,
				generic_attribute_5,
				generic_attribute_6,
				generic_attribute_7,
				generic_attribute_8,
				generic_attribute_9,
				generic_attribute_10,
				generic_attribute_11)
			VALUES
				('854','盘点差异承认',getdate(),getdate(),getdate(),getdate(),@user_id,@work_q_id,@ccdiscrepancy_id
				,@wh_id,@location_id,@hu_id,@item_number,@lot_number,@discrepancy_qty,
				(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
				)

			END

			COMMIT
			RETURN
    END TRY

    BEGIN CATCH
        SET NOCOUNT OFF
		ROLLBACK
        SET @msg = ERROR_MESSAGE()
		
		RAISERROR(@msg, 11, 1) 
        RETURN
    END CATCH
  
END


