


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_dps_lp_pick] 

AS
BEGIN
	SET NOCOUNT ON;

	DECLARE 
	@id BIGINT,
	@dps_pickid BIGINT,
	@in_wh_id						NVARCHAR(30),
	@in_order_number				NVARCHAR(30),
	@in_hu_id						NVARCHAR(30),
	@in_put_location				NVARCHAR(30),
	@in_item_number					NVARCHAR(30),
	@in_uom							NVARCHAR(20),
	@in_qty							FLOAT

    DECLARE	@out_vchCode uddt_output_code,
	        @out_vchMsg uddt_output_msg
	
	select @id =max(isnull(id,0))  from tbl_inf_dps_lp_pick x
	 where x.status=0
	 
	 if  @id>0
	 begin 
	 while (1=1)
	   begin  
	     select top 1 @dps_pickid= x.id,
		 @in_order_number=x.order_number,
		 @in_hu_id=x.hu_id,
		 @in_put_location=x.pick_wall_slot,
		 @in_item_number=x.item_number,
		 @in_uom=x.meas,
		 @in_qty=x.actual_qty,
		 @in_wh_id = wh_id
		 from tbl_inf_dps_lp_pick x join t_order y on x.order_number=y.order_number
		 where x.id<=@id and x.status=0
		 -- and not exists (select id from tbl_inf_dps_rexec y where x.id=y.id)
		  order by x.id 
		 		 
		 IF @@rowcount > 0

	     begin 	   
	       EXEC [dbo].[csp_Move_Stock_For_Dps] 
                @dps_pickid,
                @in_wh_id,
                @in_order_number,
                @in_hu_id,
                @in_put_location,
                @in_item_number,
                @in_uom	,
                @in_qty,
                @out_vchMsg,
                @out_vchCode
		   
		   update tbl_inf_dps_lp_pick set status=1 where id=@dps_pickid and status=0
         end
		 ELSE 
		   break
       end
	 end

	 return

END

