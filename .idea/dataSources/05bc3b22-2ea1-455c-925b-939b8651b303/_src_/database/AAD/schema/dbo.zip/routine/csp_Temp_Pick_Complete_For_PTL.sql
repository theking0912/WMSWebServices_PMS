-- Procedure
-- Procedure
-- =============================================
-- Author:		Laver
-- Create date: 2013-12-31
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[csp_Pick_Complete_For_PTL] 
	-- Add the parameters for the stored procedure here
	@In_Nvch_Order_Number				AS	NVARCHAR(30),
	@In_Nvch_Item_Number				AS	NVARCHAR(30),
	@In_Flot_Qty						AS	FLOAT,
	@In_Nvch_Slot						AS	NVARCHAR(30),
	@In_Nvch_Wh_Id						AS	NVARCHAR(10),
	@In_Nvch_Hu_Id						AS	NVARCHAR(30),
	@In_Nvch_Guid						AS	NVARCHAR(40),
	@Out_Nvch_Err_Code					AS	NVARCHAR(1)			OUTPUT,
	@Out_Nvch_Err_Msg					AS	NVARCHAR(200)		OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- SHIPPING INFO
	DECLARE
		@Nvch_Ord_Num				AS	NVARCHAR(30),
		@Nvch_Stod_Item_Num			AS	NVARCHAR(30),
		@Nvch_Stod_Lot_Num			AS	NVARCHAR(30),
		@BInt_Stod_Stored_Att_ID	AS	BIGINT,
		@Nvch_Stod_Location			AS	NVARCHAR(50),
		@Int_Rec_Cnt				AS	INT,
		@BInt_Stod_Type				AS	BIGINT,
		@Nvch_Wall_Location			AS	NVARCHAR(50),
		@Nvch_Shipping_Label		AS	NVARCHAR(30),
		@rtn						as  NVARCHAR(30),
		@guid						as  NVARCHAR(100),
		@Nvch_Msg_Code              uddt_output_code,
		@Nvch_Msg                   uddt_output_msg
	BEGIN TRY
		BEGIN TRANSACTION
		
		UPDATE tbl_if_tote_ptl
			SET status = 'SUCCESS',                    
				exe_date = GETDATE() 
			WHERE job_guid = @In_Nvch_Guid       
			AND item_number = @In_Nvch_Item_Number
			AND order_number = @In_Nvch_Order_Number
			AND wh_id = @In_Nvch_Wh_Id

		exec @rtn = fn_Check_CancelOrder_For_PTW @In_Nvch_Wh_Id,@In_Nvch_Order_Number
		if @rtn = '0'
		begin
			select @guid = job_guid
			from tbl_if_cancel_order_wcs
			where wh_id = @In_Nvch_Wh_Id
			and order_number = @In_Nvch_Order_Number
			and status = 'NEW'      
                      
			   
			insert into tbl_if_wcs_ptl_job_queue(job_type,job_status,job_data,create_date)
			values('WPCANCEL','NEW',@guid,getdate())  

		end

		delete from t_hu_master
		where wh_id = @In_Nvch_Wh_Id
		and hu_id = @In_Nvch_Hu_Id
		and not exists (select 1 
						from t_stored_item 
						where t_hu_master.hu_id = t_stored_item.hu_id
						and t_hu_master.wh_id = t_stored_item.wh_id)
		 		 
		COMMIT

		SET @Out_Nvch_Err_Code = 0

		RETURN
	END TRY
	BEGIN CATCH
		IF @Out_Nvch_Err_Code = '999'
		BEGIN
			RETURN 1	
		END

		ROLLBACK 
		IF ISNULL(@Out_Nvch_Err_Code,'') <> ''
		BEGIN
			RETURN 1
		END
		-- SP ERROR
		SET @Out_Nvch_Err_Code = 3 
		SET @Out_Nvch_Err_Msg = ERROR_MESSAGE()
		RETURN
	END CATCH
END
