
CREATE PROCEDURE usp_afa_units_of_work
	@in_vchLoadID	AS NVARCHAR(60),
	@in_vchWhID	AS NVARCHAR(10),
	@out_vchMessage	AS NVARCHAR(500) OUTPUT

AS

  --declare variables
  DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @v_nTranCount				INT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @e_InsPKDFailed             INT,              
       
    -- Local Variables
    @v_vchItem                  NVARCHAR(30)

	
    SET NOCOUNT ON	    
    
    SET @out_vchMessage = 'SUCCESS'
    SET @v_nReturn = 0
    
    -- Set Constants
    SET @c_nModuleNumber = 63     
    SET @c_nFileNumber = 9        -- This # must be unique per object.
    
    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_InsPKDFailed = 3
	
    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN
	
	IF @v_nTranCount = 0
		BEGIN TRANSACTION
	
    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END
    
	CREATE TABLE #tmp_pick_detail 
    (
          pick_id					INT IDENTITY (1, 1) NOT NULL
        , order_number				NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL
        , line_number				NVARCHAR(5)		COLLATE DATABASE_DEFAULT NULL
        , type						CHAR(2)			COLLATE DATABASE_DEFAULT NULL
        , uom						NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL
        , work_q_id					NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL
        , work_type					NVARCHAR(2)		COLLATE DATABASE_DEFAULT NULL
        , status					NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL
        , item_number				NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL
        , lot_number				NVARCHAR(15)	COLLATE DATABASE_DEFAULT NULL
        , serial_number				NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL
        , unplanned_quantity		FLOAT			NOT NULL  DEFAULT (0)
        , planned_quantity			FLOAT			NOT NULL  DEFAULT (0)
        , picked_quantity			FLOAT			NOT NULL  DEFAULT (0)
        , staged_quantity			FLOAT			NOT NULL  DEFAULT (0)
        , loaded_quantity			FLOAT			NOT NULL  DEFAULT (0)
        , pick_location				NVARCHAR(50)	COLLATE DATABASE_DEFAULT NULL
        , picking_flow				NVARCHAR (10)	COLLATE DATABASE_DEFAULT NULL
        , staging_location			NVARCHAR(50)	COLLATE DATABASE_DEFAULT NULL
        , zone						NVARCHAR(20)	COLLATE DATABASE_DEFAULT NULL 
        , wave_id					NVARCHAR(20)	COLLATE DATABASE_DEFAULT NULL	  DEFAULT ('0')
        , load_id					NVARCHAR(30)	COLLATE DATABASE_DEFAULT NULL 
        , load_sequence				INT				NULL 
        , stop_id					NVARCHAR(20)	COLLATE DATABASE_DEFAULT NULL 
        , container_id				NVARCHAR(22)	COLLATE DATABASE_DEFAULT NULL 
        , pick_category				NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL 
        , user_assigned				NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL 
        , bulk_pick_flag			CHAR(1)			COLLATE DATABASE_DEFAULT NULL 
        , stacking_sequence			INT				NULL 
        , pick_area					NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL 
        , wh_id						NVARCHAR(10)	COLLATE DATABASE_DEFAULT NULL 
        , cartonization_batch_id	NVARCHAR(60)	COLLATE DATABASE_DEFAULT NULL
	    , manifest_batch_id			NVARCHAR(50)	COLLATE DATABASE_DEFAULT NULL
        , manifest_carrier_flag		CHAR(1)			COLLATE DATABASE_DEFAULT NULL
		, stored_attribute_id		BIGINT			NULL  
	)
    
  -- Create entries for all unplanned HUD records into the PKD table.  Unplanned HUD records
  -- are identified by load detail lines where t_ta_load_detail_line.planned_qty <> SUM(t_pick_detail.planned_qty).
  -- The SUM(t_pick_detail.planned_qty) is derived from the view v_pkd_planned_qty
    	
	INSERT INTO #tmp_pick_detail (
	      order_number
	    , line_number
	    , type
	    , uom
	    , work_type
	    , status
	    , item_number
	    , lot_number
	    , unplanned_quantity
	    , planned_quantity
	    , picked_quantity
	    , pick_location
	    , picking_flow
	    , zone
	    , wave_id
	    , load_id
	    , load_sequence
	    , stop_id
	    , pick_area
	    , wh_id
        , manifest_carrier_flag
		, stored_attribute_id
	)
	SELECT  
	      ldd.order_number	AS order_number
	    , ldl.line_number	AS line_number 
	    , 'PP'				AS type 
		, NULL				AS uom 
        , NULL				AS work_type
		, 'UNPLANNED'		AS status
		, ldl.item_number	AS item_number 
		, ldl.lot_number	AS lot_number 
		, (ldl.planned_qty - ISNULL(pkd_planned,0)) AS unplanned_quantity
		, 0					AS planned_quantity 
		, 0					AS picked_quantity
		, NULL				AS pick_location 
		, 0					AS pick_flow 
		, NULL				AS zone 
        , ord.host_wave_id	AS wave_id
		, ldd.load_id		AS load_id 
		, ldd.load_seq		AS load_sequence 
		, ldd.stop_id		AS stop_id 
		, NULL				AS pick_area 
		, ldd.wh_id			AS wh_id
        , dbo.usf_manifest_carrier_flag ( @in_vchWhID, '', @in_vchLoadID )
							AS manifest_carrier_flag
		,ord.stored_attribute_id AS stored_attribute_id
	FROM 
	   t_load_master ldm 
	   INNER JOIN t_afa_load_detail ldd ON ldm.load_id = ldd.load_id 
	      AND ldm.wh_id = ldd.wh_id 
	   INNER JOIN t_afa_load_detail_line ldl ON ldd.load_detail_id = ldl.load_detail_id 
	      AND ldd.wh_id = ldl.wh_id 
       INNER JOIN t_order_detail ord ON ldd.order_number = ord.order_number
          AND ldd.wh_id = ord.wh_id
		  AND ord.item_number = ldl.item_number
          AND ord.line_number = ldl.line_number
	   LEFT OUTER JOIN v_pkd_planned_qty pkd ON pkd.order_number = ldd.order_number
	      AND pkd.load_id = ldd.load_id 
	      AND pkd.line_number = ldl.line_number 
	      AND pkd.wh_id = ldd.wh_id
	WHERE ((ldl.planned_qty > pkd.pkd_planned) OR (pkd.pkd_planned IS NULL))
	    AND (ldm.wh_id = @in_vchWhID) 
	      AND (ldm.load_id = @in_vchLoadID)

    -- update all selected orders that have been marked for breakdown
    -- set status ='U' from 'N'.  This will remove the posibility of another
    -- call to this sproc selecting same set of orders....
    --UPDATE t_order set status = 'U' 
    --    where status = @in_status
    --    AND order_number in 
    --        (SELECT DISTINCT order_number FROM #tmp_pick_detail)

    SELECT @v_nErrorNumber = @@ERROR
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occurred!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandlerCleanup
    END

    -- Call usp_breakdown_unplanned to break all the unplanned records into planned
    -- records by uom.

	EXEC @v_nReturn = usp_breakdown_unplanned -- (Base)

	-- ERROR check the called sproc's results.
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandlerCleanup			
    END

	INSERT INTO t_pick_detail (
	      order_number
	    , line_number
	    , type
	    , uom
	    , work_type
	    , status
	    , item_number
	    , lot_number
	    , unplanned_quantity
	    , planned_quantity
	    , picked_quantity
	    , pick_location
	    , picking_flow
	    , zone
	    , wave_id
	    , load_id
	    , load_sequence
	    , stop_id
	    , pick_area
	    , wh_id
		, stored_attribute_id)
	SELECT  
	      order_number
	    , line_number
	    , type
	    , uom
	    , work_type
	    , status
	    , item_number
	    , lot_number
	    , unplanned_quantity
	    , planned_quantity
	    , picked_quantity
	    , pick_location
	    , picking_flow
	    , zone
	    , wave_id
	    , load_id
	    , load_sequence
	    , stop_id
	    , pick_area
	    , wh_id
		, stored_attribute_id
	FROM #tmp_pick_detail
            
	-- ERROR check the insert into statement's results.
    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occurred!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandlerCleanup
    END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
    BEGIN
        SET @v_vchErrorMsg = 'An insert failed on t_pick_detail for load: ' +
            ISNULL(@in_vchLoadID,'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_InsPKDFailed
        GOTO ErrorHandlerCleanup
    END
	
    DROP TABLE #tmp_pick_detail
	
    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel
    
ErrorHandlerCleanup: 
    DROP TABLE #tmp_pick_detail
    
ErrorHandler:
    -- Log the error message in ADV.t_log
    EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(NVARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(NVARCHAR(3),@c_nFileNumber) + '-' + CONVERT(NVARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    
	
	-- Return the Error Message to the caller through the output parameter
	SET @out_vchMessage = @v_vchErrorMsg
	SET @v_nReturn = @v_nLogErrorNum
	
	-- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE 
	-- IT GETS ROLLED BACK HERE BECAUSE OF THE ERROR
	IF @v_nTranCount = 0 
		ROLLBACK TRANSACTION

ExitLabel:
    RETURN @v_nReturn
