
CREATE PROCEDURE [dbo].[usp_xml_import_item]
	(
		 @v_vchHostGroupID		NVARCHAR(36)
		,@out_vchCode           uddt_output_code   OUTPUT
		,@out_vchMsg            uddt_output_msg    OUTPUT
	)
	
AS
-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                         HighJump Software
--                         Minneapolis, Minnesota, USA
-- ********************************************************************************
-- 
--    PURPOSE:
--          The purpose of this stored procedure is to populate GHI Tables for 
--              Item Import
--
--    DESCRIPTION:
--	
--    INPUT:
--      Host Group ID
--
--    OUTPUT:
--        out_vchCode - Contains 'SUCCESS' or Error Code.
--        out_vchMsg - Contains the error message or informational log message.:
--      
--  TARGET: SQL Server 
--
-- *********************************************************************************	
DECLARE

----------------------------------------------------------------------------------------------------------------------------	
-- Procedure variables
----------------------------------------------------------------------------------------------------------------------------
		
	 @v_dtTranDateTime			DATETIME
	,@v_dtRecordCreateDate		DATETIME
	
		
----------------------------------------------------------------------------------------------------------------------------	
-- Local Variables
----------------------------------------------------------------------------------------------------------------------------
	,@c_vchObjName               uddt_obj_name	 	
	,@v_nSysErrorNum			INT
	,@v_vchMsg					NVARCHAR(4000)
    ,@v_vchCode					NVARCHAR(10)
	,@v_nRetryCount				INT
	,@v_nTranCount				INT	
	,@v_nXstate					INT		



SET NOCOUNT ON

----------------------------------------------------------------------------------------------------------------------------	
-- Set Constants
----------------------------------------------------------------------------------------------------------------------------
SET @c_vchObjName = N'usp_xml_import_item'	
SET @v_vchCode = N'SUCCESS'
SET @v_vchMsg  = N'NONE'
SET @v_nSysErrorNum = 0
SET @v_nTranCount = 0


----------------------------------------------------------------------------------------------------------------------------	
-- Insert GHI Records
----------------------------------------------------------------------------------------------------------------------------

---- Insert Item Master ------------------------------

SET @v_dtRecordCreateDate = GETDATE()	
SET @v_nRetryCount	= 3

INS_AL:
BEGIN TRY

	SET @v_nTranCount = @@TRANCOUNT
	
	IF @v_nTranCount = 0 
        BEGIN TRANSACTION 
    ELSE 
        SAVE TRANSACTION SAVEPOINT
		
    SET XACT_ABORT ON
	
		INSERT INTO t_al_host_item_master(
			 host_group_id
			,record_create_date
			,processing_code
			,item_number
			,display_item_number
			,wh_id
			,client_code
			,description
			,uom
			,inventory_type
			,shelf_life
			,alt_item_number
			,lot_control
			,reorder_point
			,reorder_qty
			,cycle_count_class
			,class_id
			,upc
			,unit_weight
			,unit_volume
			,tare_weight
			,haz_material
			,pick_put_id
			,compatibility_name
			,commodity_type_name
			,freight_class_code
			,gen_attribute_control1
			,gen_attribute_control2
			,gen_attribute_control3
			,gen_attribute_control4
			,gen_attribute_control5
			,gen_attribute_control6
			,gen_attribute_control7
			,gen_attribute_control8
			,gen_attribute_control9
			,gen_attribute_control10
			,gen_attribute_control11
			,created_date
			,updated_date
			,user_num1
			,user_num2
			,user_num3
			,user_num4
			)
		SELECT
			 @v_vchHostGroupID
			,@v_dtRecordCreateDate
			,iti.TransactionCode
			,itm.ItemNumber
			,itm.DisplayItemNumber
			,itm.WarehouseID
			,itm.ClientCode
			,iti.Description
			,iti.DefaultBaseUOM 
			,ISNULL(iti.InventoryType, 'FG')
			,ISNULL(iti.ShelfLife, 9999)
			,iti.AltItemNumber
			,ISNULL(iti.LotControl, 'N')
			,ISNULL(iti.ReorderPoint, '0')
			,ISNULL(iti.ReorderQty, '0')
			,iti.CYCClass
			,iti.ClassID
			,UPC
			,ISNULL(iti.UnitWeight, '0')
			,ISNULL(iti.UnitVolume, '0')
			,ISNULL(iti.TareWeight, '0')
			,iti.HazMatIndicator
			,ISNULL(iti.PickPutID, 'Default')
			,iti.CompatibilityName 
			,iti.CommodityTypeName 
			,iti.FreightClassNumber 
			,ISNULL(iti.Attribute1,'N')
			,ISNULL(iti.Attribute2,'N')
			,ISNULL(iti.Attribute3,'N')
			,ISNULL(iti.Attribute4,'N')
			,ISNULL(iti.Attribute5,'N')
			,ISNULL(iti.Attribute6,'N')
			,ISNULL(iti.Attribute7,'N')
			,ISNULL(iti.Attribute8,'N')
			,ISNULL(iti.Attribute9,'N')
			,ISNULL(iti.Attribute10,'N')
			,ISNULL(iti.Attribute11,'N')
			,'1/1/1900'
			,'1/1/1900'
			,0
			,0
			,0
			,0
		 FROM t_xml_imp_item_master itm WITH (NOLOCK)
		INNER JOIN t_xml_imp_item_info iti WITH (NOLOCK)
		   ON iti.hjs_parent_id = itm.hjs_node_id
		WHERE itm.hjs_parent_id = @v_vchHostGroupID
		ORDER BY itm.hjs_sequence    
		 
	 
------ Insert Item UOM  ------------------------------
		 
		 INSERT INTO t_al_host_item_uom(
			 host_item_master_id
			,host_group_id
			,record_create_date
			,processing_code
			,item_number
			,display_item_number
			,wh_id
			,client_code
			,uom
			,conversion_factor
			,units_per_layer
			,layers_per_uom
			,uom_weight
			,pickable
			,box_type
			,length
			,width
			,height
			,no_overhang_on_top
			,stack_code
			,batch
			,use_orientation_data
			,turnable
			,on_bottom_ok
			,on_side_ok
			,on_end_ok
			,bottom_only
			,top_only
			,max_in_layer
			,max_support_weight
			,stack_index
			,container_value
			,load_separately
			,nesting_height_increase
			,nested_volume
			,unit_volume
			,status
			,uom_prompt
			,default_receipt_uom
			,default_pick_uom
			,class_id
			,pick_put_id
			,std_hand_qty
			,min_hand_qty
			,max_hand_qty
			,default_pick_area
			,shippable_uom
		)  
		SELECT 
			 ISNULL(host_item_master_id, 0)
			,@v_vchHostGroupID
			,@v_dtRecordCreateDate
			,uom.TransactionCode
			,itm.ItemNumber
			,itm.DisplayItemNumber
			,itm.WarehouseID
			,itm.ClientCode
			,uom.UOM
			,ISNULL(uom.ConversionFactor, '0')
			,ISNULL(uom.UnitsPerLayer, '0') 
			,ISNULL(uom.LayersPerUOM, '0') 
			,ISNULL(uom.Weight, '1') 
			,ISNULL(uom.Pickable, 'Y')
			,ISNULL(uom.BoxType, '1') 
			,ISNULL(uom.Length, '1') 
			,ISNULL(uom.Width, '1') 
			,ISNULL(uom.Height, '1') 
			,ISNULL(uom.NoOverhangOnTop, '0') 
			,ISNULL(uom.StackCode, '-1') 
			,ISNULL(uom.Batch, 0) 
			,ISNULL(uom.UseOrientationData, 0) 
			,ISNULL(uom.Turnable, 0) 
			,ISNULL(OnBottomOK, 0) 
			,ISNULL(OnSideOK, 0) 
			,ISNULL(uom.OnEndOK, 0) 
			,ISNULL(uom.BottomOnly, 0) 
			,ISNULL(uom.TopOnly, 0) 
			,ISNULL(uom.MaxInLayer, 1) 
			,ISNULL(uom.MaxSupportWeight, '1') 
			,ISNULL(uom.StackIndex, '0') 
			,ISNULL(uom.ContainerValue, '0') 
			,ISNULL(uom.LoadSeparately, '0') 
			,ISNULL(uom.NestingHeightIncrease, '0') 
			,ISNULL(iti.NestedVolume, '0') 
			,ISNULL(iti.UnitVolume, '0') 
			,ISNULL(uom.Status, 'ACTIVE')
			,ISNULL(uom.UoMPrompt, 'None')
			,ISNULL(uom.DefaultReceiptUOM, 'NO')
			,ISNULL(uom.DefaultPickUOM, 'NO')
			,iti.ClassID
			,ISNULL(iti.PickPutID, 'Default')
			,ISNULL(uom.StdHandQty, '0') 
			,ISNULL(uom.MinHandQty, '0') 
			,ISNULL(uom.MaxHandQty, '0') 
			,uom.DefaultPickArea
			,ISNULL(uom.ShippableUOM, 'N')
		  FROM t_xml_imp_item_uom uom WITH (NOLOCK)
		 INNER JOIN t_xml_imp_item_uoms ums WITH (NOLOCK) 
		    ON ums.hjs_node_id = uom.hjs_parent_id
		 INNER JOIN t_xml_imp_item_master itm WITH (NOLOCK)
			ON itm.hjs_node_id = ums.hjs_parent_id
		 LEFT OUTER JOIN t_xml_imp_item_info iti WITH (NOLOCK)
			ON iti.hjs_parent_id = itm.hjs_node_id	
		 LEFT OUTER JOIN t_al_host_item_master ahm WITH (NOLOCK)
			ON ahm.host_group_id = itm.hjs_parent_id
		   AND ISNULL(ahm.item_number, '-1') = ISNULL(itm.ItemNumber, '-1')
		   AND ISNULL(ahm.display_item_number, '-1') = ISNULL(itm.DisplayItemNumber, '-1')
		   AND ISNULL(ahm.wh_id, '-1') = ISNULL(itm.WarehouseID, '-1')
		   AND ISNULL(ahm.client_code, '-1') = ISNULL(itm.ClientCode, '-1')	
		 WHERE itm.hjs_parent_id = @v_vchHostGroupID  	
		 ORDER BY itm.hjs_sequence, iti.hjs_sequence, uom.hjs_sequence

	COMMIT TRANSACTION
	
	SET XACT_ABORT OFF		
	
END TRY
 
BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
	SET @v_nTranCount = @@TRANCOUNT
	SET @v_nXstate = XACT_STATE() 
  
	IF @v_nXstate = -1 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount = 0 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount > 0 
        ROLLBACK TRANSACTION SAVEPOINT   


-- Check for Deadlock and Retry as long as the Retry Counter is greater than zero  
    IF (@v_nRetryCount > 0 AND @v_nSysErrorNum = 1205) 
	BEGIN
		SET @v_nRetryCount = @v_nRetryCount - 1
		SET XACT_ABORT OFF;	
		GOTO INS_AL
	END

	SET @v_vchCode = N'-20001'    
    SET @v_vchMsg = N'A SQL error occured while inserting t_xml_exp records for Item Import.'	
	SET @v_vchMsg = @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE()
	GOTO ERROR_HANDLER
END CATCH

GOTO EXIT_LABEL
	
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + N'Deadlock error: 40001 ' + @v_vchMsg
    ELSE    
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + @v_vchMsg 
		
    --Should only raise error in the parent sproc
    RAISERROR(@v_vchMsg, 11, 1)
    
    -- Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg
    
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

-- Always leave the stored procedure from here.
RETURN 
