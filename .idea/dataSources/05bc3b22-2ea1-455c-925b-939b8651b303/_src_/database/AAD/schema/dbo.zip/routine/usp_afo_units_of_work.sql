
CREATE PROCEDURE usp_afo_units_of_work
    @in_vchWaveID     AS NVARCHAR(60),
    @in_vchWhID       AS NVARCHAR(10),
    @out_vchMessage   AS NVARCHAR(500) OUTPUT

AS

  --declare variables
  DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nItemRowCount            INT,
    @v_nReturn                  INT,
    @v_nTranCount               INT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @e_InsPKDFailed             INT,
    @e_UOMSqlError              INT,           
       
    -- Local Variables
    @v_vchItem                  NVARCHAR(30)

	
    SET NOCOUNT ON	    
    
    SET @out_vchMessage = 'SUCCESS'
    SET @v_nReturn = 0
    
    -- Set Constants
    SET @c_nModuleNumber = 63     
    SET @c_nFileNumber = 9        -- This # must be unique per object.
    
    -- Log/Local Error Constants
    SET @e_GenSqlError  = 1
    SET @e_SprocError   = 2
    SET @e_InsPKDFailed = 3
    SET @e_UOMSqlError  = 4
	
    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN
	
    IF @v_nTranCount = 0
        BEGIN TRANSACTION
	
	
    
    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END

-- create temp table to act as data buffer for operation
CREATE TABLE #tmp_pick_detail (
	pick_id               INT IDENTITY (1, 1) NOT NULL ,
	order_number			NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
	line_number			NVARCHAR(5)   COLLATE DATABASE_DEFAULT NULL ,
	type				CHAR(2)      COLLATE DATABASE_DEFAULT NULL ,
	uom				NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
	work_q_id			NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
	work_type			NVARCHAR(2)   COLLATE DATABASE_DEFAULT NULL ,
	status				NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
	item_number			NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
	lot_number			NVARCHAR(15)  COLLATE DATABASE_DEFAULT NULL ,
	serial_number			NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
	unplanned_quantity		FLOAT  NULL  DEFAULT (0),
	planned_quantity		FLOAT  NULL  DEFAULT (0),
	picked_quantity			FLOAT  NULL  DEFAULT (0),
	staged_quantity			FLOAT  NULL  DEFAULT (0),
	loaded_quantity			FLOAT  NULL  DEFAULT (0),
	pick_location			NVARCHAR(50)  COLLATE DATABASE_DEFAULT NULL ,
	picking_flow			NVARCHAR(10) COLLATE DATABASE_DEFAULT NULL ,
	staging_location		NVARCHAR(50)  COLLATE DATABASE_DEFAULT NULL ,
	zone				NVARCHAR(20)  COLLATE DATABASE_DEFAULT NULL ,
	wave_id				NVARCHAR(20)  COLLATE DATABASE_DEFAULT NULL  DEFAULT ('0'),
	load_id				NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
	load_sequence			INT  NULL ,
	stop_id				NVARCHAR(20)  COLLATE DATABASE_DEFAULT NULL ,
	container_id			NVARCHAR(22)  COLLATE DATABASE_DEFAULT NULL ,
	pick_category			NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
	user_assigned			NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
	bulk_pick_flag			CHAR(1)       COLLATE DATABASE_DEFAULT NULL ,
	stacking_sequence		INT NULL ,
	pick_area			NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
	wh_id				NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
	cartonization_batch_id	NVARCHAR(60)  COLLATE DATABASE_DEFAULT NULL,
	manifest_batch_id		NVARCHAR(50)  COLLATE DATABASE_DEFAULT NULL,
	manifest_carrier_flag	        CHAR(1)       COLLATE DATABASE_DEFAULT NULL,
	stored_attribute_id		BIGINT		 NULL	
)

    -- Create entries for all unplanned HUD records into the PKD table.  Unplanned HUD records
    -- are identified by load detail lines where t_ta_load_detail_line.planned_qty <> SUM(t_pick_detail.planned_qty).
    -- The SUM(t_pick_detail.planned_qty) is derived from the view v_pkd_planned_qty
    INSERT INTO #tmp_pick_detail (
                order_number, line_number, type, uom, work_type, status, item_number, 
                lot_number, unplanned_quantity, planned_quantity, picked_quantity, 
                pick_location, picking_flow, zone, wave_id, load_id, load_sequence, 
                stop_id, pick_area, wh_id, manifest_carrier_flag,stored_attribute_id)
           SELECT wvd.order_number	AS order_number, 
                  wdl.line_number	AS line_number, 
                  'PP'				AS type, 
                  NULL				AS uom, 
                  NULL				AS work_type,
                  'UNPLANNED'		AS status,
                  wdl.item_number	AS item_number, 
                  wdl.lot_number	AS lot_number, 
                  (wdl.planned_qty - ISNULL(pkd_planned,0)) AS unplanned_quantity,
                  0					AS planned_quantity, 
                  0					AS picked_quantity,
                  NULL				AS pick_location, 
                  0					AS pick_flow, 
                  NULL				AS zone, 
                  wm.wave_id		AS wave_id,
                  orm.load_id,
                  0					AS load_sequence, 
                  0					AS stop_id, 
                  NULL				AS pick_area, 
                  wvd.wh_id			AS wh_id,
                  dbo.usf_manifest_carrier_flag ( @in_vchWhID, orm.order_number, '')
									AS manifest_carrier_flag,
				  ord.stored_attribute_id AS stored_attribute_id
           FROM 
	          t_wave_master wm 
           INNER JOIN t_afo_wave_detail wvd ON wm.wave_id = wvd.wave_id 
	          AND wm.wh_id = wvd.wh_id 
           INNER JOIN t_afo_wave_detail_line wdl 
              ON wvd.wave_detail_id = wdl.wave_detail_id 
	         AND wvd.wh_id = wdl.wh_id 
           INNER JOIN t_order_detail ord 
              ON wvd.order_number = ord.order_number
              AND wvd.wh_id = ord.wh_id
              AND ord.item_number = wdl.item_number
              AND ord.line_number = wdl.line_number
           INNER JOIN t_order orm
              ON ord.order_number = orm.order_number
             AND ord.wh_id = orm.wh_id
           LEFT OUTER JOIN v_afo_pkd_planned_qty pkd 
                 ON pkd.order_number = wvd.order_number
                AND pkd.wave_id = wvd.wave_id 
                AND pkd.item_number = wdl.item_number
                AND pkd.line_number = wdl.line_number
                AND pkd.wh_id = wvd.wh_id
	   WHERE  pkd.item_number is null --Notes below ((wdl.planned_qty > pkd.pkd_planned) OR (pkd.pkd_planned IS NULL))
	     AND (wm.wh_id = @in_vchWhID) 
	     AND (wm.wave_id = @in_vchWaveID)
    
    -- By adding item_number to v_afo_pkd_planned_qty view and including 
    -- WHERE pkd.item_number IS NULL, we eliminate processing both planned & unplanned
    -- order items that already exist in pkd.

    -- ERROR check the insert into statement's results.
    SELECT @v_nErrorNumber = @@ERROR, @v_nItemRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
    -- Check for Number of rows affected.
    IF @v_nItemRowCount = 0
    BEGIN
        SET @v_vchErrorMsg = 'No records to process for wave: ' +
            ISNULL(@in_vchWaveID,'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_InsPKDFailed
        GOTO ErrorHandler
    END

    -- Newly added Check
    -- Check if any of the order items is missing units of measure. If true, 
    -- write an exception into the exception log table
    SELECT @v_nRowCount= COUNT(tmp.item_number)
        FROM 
           #tmp_pick_detail tmp
        where wh_id = @in_vchWhID
          AND item_number NOT IN 
                     (SELECT item_number 
                        FROM t_item_uom NOLOCK
                       WHERE wh_id = @in_vchWhID)

    IF @v_nRowCount > 0 
        BEGIN
            BEGIN TRANSACTION
                    INSERT INTO t_exception_log ( tran_type, wh_id, description, exception_date, exception_time, quantity)
            	    VALUES ('001', @in_vchWhID, LTRIM(str(@v_nRowCount)) + ' Items in Wave: ' + LTRIM(STR(@in_vchWaveID)) + ' found with no ITU records' , GETDATE(), GETDATE(), 1);
            COMMIT TRAN
        END

    IF @v_nItemRowCount = @v_nRowCount
    BEGIN
        SET @v_vchErrorMsg = 'No UOM setup for items been released. Contact the Administrator!!'
        SET @v_nLogErrorNum = @e_UOMSqlError
        GOTO ErrorHandler
    END
    
    -- ERROR check the insert into statement's results.
    SELECT @v_nErrorNumber = @@ERROR
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    --  Call usp_afo_breakdown_unplanned to break all the unplanned records into planned
    --  records by uom.
    EXEC @v_nReturn = usp_breakdown_unplanned -- (Base)

	-- ERROR check the called sproc's results.
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END

    -- insert data back to t_pick_detail
    INSERT t_pick_detail ( 
        order_number, 
        line_number, 
        type, uom, 
        work_type, 
        status, 
        item_number, 
        lot_number,  
        unplanned_quantity, 
        planned_quantity, 
        pick_location, 
        picking_flow, 
        staging_location, 
        zone, 
        wave_id, 
        load_id, 
        load_sequence, 
        stop_id, 
        pick_area, 
        wh_id,
		stored_attribute_id)
    SELECT 
        order_number, 
        line_number, 
        type,
        uom, 
        work_type, 
        status, 
        item_number, 
        lot_number,  
        unplanned_quantity, 
        planned_quantity,  
        pick_location, 
        picking_flow, 
        staging_location, 
        zone, 
        wave_id, 
        load_id,
        load_sequence,
        stop_id,
        pick_area,
        wh_id,
		stored_attribute_id
    FROM #tmp_pick_detail

    --drop the temp table
    DROP TABLE #tmp_pick_detail

    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
    EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(NVARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(NVARCHAR(3),@c_nFileNumber) + '-' + CONVERT(NVARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    
	
	-- Return the Error Message to the caller through the output parameter
	SET @out_vchMessage = @v_vchErrorMsg
	SET @v_nReturn = @v_nLogErrorNum
	
	-- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE 
	-- IT GETS ROLLED BACK HERE BECAUSE OF THE ERROR
	IF @v_nTranCount = 0 
		ROLLBACK TRANSACTION

ExitLabel:
    RETURN @v_nReturn

