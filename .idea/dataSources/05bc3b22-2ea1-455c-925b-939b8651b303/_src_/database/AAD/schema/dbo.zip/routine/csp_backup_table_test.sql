

--created by leroy lee 2017.221 17:00
CREATE PROCEDURE [dbo].[csp_backup_table_test]
 
AS
--获取当前日期是否为第一天
DECLARE @FirstDay		date
DECLARE @Now			date
DECLARE @BEGIN_DATE		datetime
DECLARE @END_DATE		datetime
DECLARE @BUDAT_POINT	varchar(100)
DECLARE @MONTH_DAYS		INT
DECLARE @DELETE_COUNT	decimal

select @FirstDay = convert(date,dateadd(d,-day(getdate())+1,getdate()),120) 
select @MONTH_DAYS = day(dateadd(month,1,getdate()) - day(getdate()))
set @BUDAT_POINT = convert(varchar(100),@FirstDay,112)
set @Now = convert(date,getdate(),120)

print @FirstDay
print @Now


if @Now = '2017-02-22'
	begin
	 --清理回传接口表
		 --开始时间
		 select @BEGIN_DATE = getdate()

		 --备份到历史表中
		 insert into tbl_inf_exp_inoutbound_back
		 select top 1 * 
		 from tbl_inf_exp_inoutbound with(nolock)
		 where BUDAT < @BUDAT_POINT
 
		 --删除已备份的数据
		 delete tiei 
		 from tbl_inf_exp_inoutbound tiei 
		 inner join tbl_inf_exp_inoutbound_back tieib 
		 on tiei.EBELN = tieib.EBELN 
		 AND tiei.EBELP = tieib.EBELP 
		 AND tiei.MENGE = tieib.MENGE


		 --查询删除掉的条数
		 select @DELETE_COUNT = @@ROWCOUNT
		 
		 --结束时间
		 select @END_DATE = getdate()

		 --插入日志
		 insert into tbl_job_log 
		 values(@FirstDay,@MONTH_DAYS,'tbl_inf_exp_inoutbound',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)

	end


