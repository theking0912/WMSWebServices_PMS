
CREATE VIEW dbo.ea_v_RuntimeAlertDetails AS
SELECT
    ah.alert_event_id,
    ah.date_added,
    ah.alert_id,
    a.alert_name,
    a.alert_description,
    ah.context_description,
    a.suggested_resolution
FROM
    ea_t_alert_history ah,
    ea_t_alert a
WHERE
    a.alert_id = ah.alert_id
