CREATE PROCEDURE [dbo].[csp_Order_Allocation_B2B]    
     @wh_id				NVARCHAR(10)   
    ,@order_number	    NVARCHAR(30) 

AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY

		DECLARE @item_number			NVARCHAR(30)
		DECLARE @lot_number				NVARCHAR(30)
		DECLARE @line_number			NVARCHAR(5)
		DECLARE @planned_qty			float
		DECLARE @picked_qty				float
		DECLARE @leave_allocate_qty		float
		DECLARE @uom_qty				float
		DECLARE @alloc_qty				float
		DECLARE @allocated_qty			float
		DECLARE @pick_id				bigint
		DECLARE @seq_id					bigint
		DECLARE @case_flag				NVARCHAR(30)
		DECLARE @client_code			NVARCHAR(30)
		DECLARE @pick_put_id			NVARCHAR(30)
		DECLARE @location_id			NVARCHAR(30)
		DECLARE @zone					NVARCHAR(30)
		DECLARE @pick_seq				NVARCHAR(30)
		DECLARE @shipping_label			NVARCHAR(30)
		DECLARE @carrier				NVARCHAR(30)
		DECLARE @event_data				NVARCHAR(2000)
		DECLARE @result                 INT
		DECLARE @alloc_lot_number       NVARCHAR(30)
		DECLARE @re_release				NVARCHAR(30)
		DECLARE @is_rollback			NVARCHAR(30)

		set @re_release = 'N'
		
		if(not exists (select 1
		from t_client c,t_order o
		where c.client_code = o.client_code
		and c.wh_id = o.wh_id
		and o.order_number = @order_number
		and o.wh_id = @wh_id
		and c.client_type = 'B'))
		return;
		
		select @carrier = carrier_scac
		from t_order
		where wh_id = @wh_id
		and order_number = @order_number

		set @is_rollback = 'N'
		
		BEGIN TRANSACTION

		select @client_code = client_code
		from t_order
		where order_number = @order_number
		and wh_id = @wh_id

		set @pick_id = 0

		while(1=1)
		begin
			
			select top 1 @item_number = pkd.item_number
					,	@lot_number = pkd.lot_number
					,	@line_number = pkd.line_number
					,	@planned_qty = pkd.planned_quantity
					,	@picked_qty = pkd.picked_quantity
					,	@pick_id = pkd.pick_id
			from t_pick_detail pkd
			where pkd.order_number = @order_number
			and pkd.wh_id = @wh_id
			and pkd.pick_id > @pick_id
			order by pkd.pick_id

			if @@ROWCOUNT = 0 or @is_rollback = 'Y'
				break;

			-- for re-allocation clear allocated qty
			if exists (select 1 from tbl_allocation 
						WHERE  order_number = @order_number
						and item_number = @item_number
						and (@lot_number is null or lot_number = @lot_number)
						and line_number = @line_number
						and pick_id = @pick_id  
						and status = 'E')
			begin
				set @re_release = 'Y'
				delete from tbl_shipping_label
				where order_number = @order_number
				and wh_id = @wh_id
				and exists(select 1 
							from tbl_allocation a
							where tbl_shipping_label.ship_label_barcode = a.shipping_label
							and a.order_number = @order_number
							and a.wh_id = @wh_id
							and status = 'E')
				--select * from tbl_shipping_label
				select top 1 @shipping_label = shipping_label
				from tbl_allocation
				where order_number = @order_number
				and wh_id = @wh_id
				and (shipping_label is not null or shipping_label <> '')
			end

			DELETE FROM tbl_allocation 
			WHERE  order_number = @order_number
			and item_number = @item_number
			and (@lot_number is null or lot_number = @lot_number)
			and line_number = @line_number
			and pick_id = @pick_id  
			and status = 'E'
			and picked_qty = 0

			-- for re-allocation clear allocated qty
			update tbl_allocation
			set allocated_qty = picked_qty
			,	status = 'C'
			where order_number = @order_number
			and item_number = @item_number
			and (@lot_number is null or lot_number = @lot_number)
			and pick_id = @pick_id
			and status = 'E'
			and line_number = @line_number 

			select @allocated_qty = sum(allocated_qty - picked_qty)
			from tbl_allocation
			where order_number = @order_number
			and item_number = @item_number
			and (@lot_number is null or lot_number = @lot_number)
			and pick_id = @pick_id
			and line_number = @line_number 

			set @uom_qty = 9999999
			/*
			select @picked_qty = isnull(sum(picked_qty),0)
			from tbl_allocation
			where order_number = @order_number
			and item_number = @item_number
			and (@lot_number is null or lot_number = @lot_number)
			and line_number = @line_number*/
			
			set @leave_allocate_qty = @planned_qty - @picked_qty - isnull(@allocated_qty,0)

			if @leave_allocate_qty > 0
			begin
				-- clear allocated qty
				/*
				if @picked_qty > 0
				begin
					update tbl_allocation
					set allocated_qty = picked_qty
					where order_number = @order_number
					and item_number = @item_number
					and (@lot_number is null or lot_number = @lot_number)
					and line_number = @line_number 
				end*/

				while(1=1)
				begin
					select @uom_qty = max(itu.conversion_factor)
					from t_item_uom itu
					where wh_id = @wh_id
					and item_number = @item_number
					and conversion_factor < @uom_qty
					and conversion_factor <= @leave_allocate_qty

					select @pick_put_id = ppr.before
					from t_item_uom itu
						,t_pick_put_master ppm
						,t_pick_put_detail ppd
						,t_pick_put_rules ppr
					where itu.pick_put_id = ppm.pick_put_id
					and ppm.pick_put_id = ppd.pick_put_id
					and ppd.rule_id = ppr.rule_id
					and wh_id = @wh_id
					and item_number = @item_number
					and conversion_factor = @uom_qty

					if @@ROWCOUNT = 0
					break;

					while(1=1)
					begin
						if @leave_allocate_qty < @uom_qty or @leave_allocate_qty <= 0
						break;

						if(@uom_qty = 1)
						begin
							set @case_flag = 'N'
							set @alloc_qty = @leave_allocate_qty

						end
						else
						begin
							set @case_flag = 'Y'
							set @alloc_qty = @uom_qty
						end
						--print '@pick_put_id' + @pick_put_id
						--Exec getlocation
						EXEC @pick_put_id @wh_id,@item_number,@lot_number,@alloc_qty,@client_code,@case_flag,@location_id output,@alloc_qty output
						--print '@pick_put_id' + @location_id
						if @location_id is null or @alloc_qty = 0
						break;

						select top 1 @zone = zone,@pick_seq=pick_seq
						from t_zone_loca
						where location_id = @location_id
						
						set @leave_allocate_qty = @leave_allocate_qty - @alloc_qty

						SELECT TOP 1 @alloc_lot_number = lot_number
						FROM t_stored_item
						WHERE location_id = @location_id
						AND wh_id = @wh_id
						AND item_number = @item_number
						ORDER BY lot_number

						insert into tbl_allocation(
						wave_id,order_number,pick_id,item_number,lot_number,stored_attribute_id
						,location_id,hu_id,allocated_qty,picked_qty,status,released_date,ref_number
						,pick_wall_loc,pick_wall_slot,pick_conveyor_node,zone,wh_id,line_number,picking_flow,allo_type)
						select	 pkd.wave_id				as wave_id
								,@order_number				as order_number
								,pkd.pick_id				as pick_id
								,pkd.item_number			as item_number
								,@alloc_lot_number			as lot_number
								,pkd.stored_attribute_id	as stored_attribute_id
								,@location_id				as location_id
								,null						as hu_id
								,@alloc_qty					as allocated_qty
								,0							as picked_qty
								,'U'						as status
								,getdate()					as released_date
								,@order_number				as ref_number
								,null						as pick_wall_loc
								,null						as pick_wall_slot
								,null						as pick_conveyor_node
								,@zone						as zone
								,@wh_id						as wh_id
								,@line_number				as line_number
								,@pick_seq					as picking_flow
								,case when @case_flag = 'Y' then 'BC'
								      when @case_flag = 'N' then 'BU' end as allo_type
						from t_pick_detail pkd
						where pkd.pick_id = @pick_id

						set @seq_id = @@IDENTITY
						/*
						if @re_release = 'Y' 
						begin
							update tbl_allocation
							set shipping_label = @shipping_label
							where order_number = @order_number
							and wh_id = @wh_id
							and pick_id = @pick_id
							and seq_id = @seq_id
						end*/

						if @alloc_qty = @uom_qty AND @uom_qty > 1
												and exists(select 1 from t_zone_loca zl, t_zone z
															where zl.wh_id = z.wh_id
															and zl.zone = z.zone
															and z.case_flag = 'Y'
															and zl.location_id = @location_id)
							
						begin
 				     		--get shipping label
							exec csp_GetShipping_Label @wh_id, @carrier,@result output, @shipping_label output

							--print '@shipping_label' + @shipping_label + '@carrier' + @carrier
							if @shipping_label is not null
							begin
								insert into tbl_shipping_label
								(wh_id,ship_label_barcode,route,carrier,weight,status,order_number,weight_time,create_time,remark,pack_type)
								select @wh_id,@shipping_label,route,carrier_scac,0,'NEW',@order_number,null,getdate(),null,null
								from t_order
								where wh_id = @wh_id
								and order_number = @order_number

								insert into tbl_shipping_label_detail
								(wh_id,ship_label_barcode,item_number,lot_number,stored_attribute_id,quantity,create_time,remark,line_number)
								values(@wh_id,@shipping_label,@item_number,@lot_number,null,@alloc_qty,getdate(),null,@line_number)

								update tbl_allocation
								set shipping_label = @shipping_label
								where order_number = @order_number
								and wh_id = @wh_id
								and pick_id = @pick_id
								and seq_id = @seq_id

								if @re_release = 'Y'
								begin
									-- insert print_scheduler
									set @event_data = @shipping_label + '|' + @carrier + '|' + '1'

									insert into tbl_print_scheduler (print_type,print_station,wh_id,print_data,print_date,print_user
									)values('ShippingLabel',@client_code,@wh_id,@event_data,getdate(),'SP:B2B')
									
								end
								--set @event_data = 'wh_id|' + @wh_id + 'key|' + @shipping_label + 'qty|' + '1' + 'station|' + @client_code + 'print_type|SL' + 'carrier|' + @carrier + 'user|' + 'SP'
								--EXECUTE ADV.dbo.usp_AdvAddEvent '4','SEND PRINT',@event_data,50


							end
							else
							begin
								set @is_rollback = 'Y'
							end


						end


					end

				end

			end

		end

		if @is_rollback = 'Y'
		begin
			ROLLBACK;
		end
		else
		begin

			if exists (select 1 from tbl_allocation alloc
						where wh_id = @wh_id
						and order_number = @order_number
						and alloc.allocated_qty - alloc.picked_qty > 0)
			begin
				update t_order
				set status = 'RELEASED'
				where wh_id = @wh_id
				and order_number = @order_number

				update t_pick_detail
				set status = 'RELEASED'
				where wh_id = @wh_id
				and order_number = @order_number

			end
			else
			begin
				update t_order
				set status = 'WAVED'
				where wh_id = @wh_id
				and order_number = @order_number

				--update t_pick_detail
				--set status = 'NEW'
				--where wh_id = @wh_id
				--and order_number = @order_number
			end					

			--COMMIT
			DECLARE @sum_alloc_qty	        FLOAT
			DECLARE @sum_planned_qty        FLOAT

			select @sum_alloc_qty = isnull(sum(allocated_qty),0)
			from tbl_allocation
			where wh_id = @wh_id
			and order_number = @order_number

			select @sum_planned_qty = isnull(sum(pkd.planned_quantity),0)
			from t_pick_detail pkd
			where pkd.order_number = @order_number
			and pkd.wh_id = @wh_id

			IF @sum_alloc_qty = @sum_planned_qty
			COMMIT;

			IF @sum_alloc_qty <> @sum_planned_qty
			ROLLBACK;
		end
				
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        RETURN
    END CATCH
  
END
