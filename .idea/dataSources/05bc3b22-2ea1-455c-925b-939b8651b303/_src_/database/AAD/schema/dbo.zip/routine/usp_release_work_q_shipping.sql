
CREATE PROCEDURE usp_release_work_q_shipping

    @in_OrderNumber  		AS NVARCHAR(20) = NULL,
    @in_LoadNumber	        AS NVARCHAR(20) = NULL,
    @in_WaveNumber		AS NVARCHAR(20) = NULL,
    @in_ItemNumber		AS NVARCHAR(30) = NULL,
    @in_LotNumber		AS NVARCHAR(15) = NULL,
    @in_PickArea		As NVARCHAR(10) = 'ALL',
    @in_vchType                 AS NVARCHAR(2) = 'PP',
    @in_WHID			AS NVARCHAR(10) = '01',
    @in_nResultsFlag            AS INT = 0    -- 1 means return results;  0 means don't return results

AS

  --declare variables
  DECLARE
    @n_StartWKQ 		INT,
    @n_FinishWKQ 		INT,
    @n_Count 			INT,
    @n_Range			INT,
    @n_SQLCount         INT,
	@str_WorkType		NVARCHAR(10),
    @str_Query			NVARCHAR(2000),
    @str_WhereClause		NVARCHAR(1000),
    @str_GroupByClause		NVARCHAR(1000),
    @str_where_clause_addition  NVARCHAR(500),
    @str_ReleaseSprocName       NVARCHAR(100),

    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_vchOutMsg		NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @v_nTranCount		INT,

    -- Log Error numbers used for branching in the Error Handler.
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @e_MissingITMError          INT,
    @e_TControlError            INT,
    @e_BeforePickError		INT,
    @e_GetWKQRangeError		INT,
    @e_SetWKQTempError		INT,
    @e_SetWKQIDError		INT,
    @e_AddWKQError		INT

    SET NOCOUNT ON

    -- Retrieve Database Log Level from t_control.  If it doesn't exist, insert it.
    -- 0 = Off, 1 = On
    SELECT @v_nLogLevel = next_value FROM t_control WHERE control_type = 'DB OBJ LOG LEVEL'

    IF @@ROWCOUNT = 0
    BEGIN
      INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit)
        VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', '0', 'SHOW_VA', '1')
      SET @v_nLogLevel = 0
    END

    SET @v_nReturn = 0
    SET @n_Count = 0

    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 7        -- This # must be unique per object.

    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_MissingITMError = 3
    SET @e_TControlError = 4
    SET @e_BeforePickError = 5
    SET @e_GetWKQRangeError = 6
    SET @e_SetWKQTempError = 7
    SET @e_AddWKQError = 8

    -- Print a trace level log message.
    IF @v_nLogLevel >= 5
    	PRINT 'Paramters passed: Order Number: ' +  @in_OrderNumber  +
                                                 ' Load Number:' +  @in_LoadNumber +
                                                 ' Wave Number ' +  @in_WaveNumber	+
                                                 ' Pick Area ' +    @in_PickArea	+
                                                 ' Item Number ' +  @in_ItemNumber	+
                                                 ' Lot Number ' +   @in_LotNumber +                                                 ' Type ' +     @in_vchType +
                                                 ' Warehouse ID ' +    @in_WHID

    --  Check to see if there are any load work q to be created
    SELECT @n_Count = COUNT(*)
        FROM #tmp_pick_details_to_update pkd
        WHERE pkd.status = 'PRERLSE'
            AND pkd.load_id not in (SELECT pick_ref_number FROM t_work_q wkq
        			    WHERE pkd.load_id = wkq.pick_ref_number
            				AND pkd.wh_id = wkq.wh_id
            				AND wkq.work_type IN ('10', '11', '12'))

    SELECT @v_nErrorNumber = @@ERROR
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
    -- Check for Number of rows affected.
    IF @n_Count = 0
    BEGIN
		-- Print a trace level log message.
    	IF @v_nLogLevel >= 4
    		PRINT 'No records found for release for Load work Queues'

        -- Update the PKD's with PRERLSE status to RELEASE if a work q has been assigned
        UPDATE #tmp_pick_details_to_update --t_pick_detail
        SET status = 'RELEASED'
        WHERE status = 'PRERLSE'
            AND (work_q_id IS NOT NULL or work_type = '15')

        SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
        -- Check for any errors. If so, error number will not be equal to zero.
        IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
        GOTO ExitLabel
    END

    -- create temp table for holding pick details grouped by Load ID
    CREATE TABLE #t_work_d_work (
	   id              INT IDENTITY(1,1) NOT NULL,
	   load_id         NVARCHAR(30)      COLLATE DATABASE_DEFAULT NULL,
	   load_work_q_id  NVARCHAR(30)      COLLATE DATABASE_DEFAULT NULL,
	   audit_work_q_id NVARCHAR(30)      COLLATE DATABASE_DEFAULT NULL,
	   ship_work_q_id  NVARCHAR(20)      COLLATE DATABASE_DEFAULT NULL,
           wh_id           NVARCHAR(10)      COLLATE DATABASE_DEFAULT NULL
       )

    --  Create work queue numbers in the #t_work_q_work temp table
    --  for Loading, Audit, Shipping work queues.  Some work queues in the
    --  reserved range will not be used
    --  Insert a record for each load/warehosue into the temp table

    INSERT #t_work_d_work (load_id, wh_id)
	    SELECT pkd.load_id, pkd.wh_id
        FROM #tmp_pick_details_to_update pkd 
        WHERE pkd.status = 'PRERLSE'
            AND pkd.load_id not in (SELECT pick_ref_number FROM t_work_q wkq
        			    WHERE pkd.load_id = wkq.pick_ref_number
            				AND pkd.wh_id = wkq.wh_id
            				AND wkq.work_type IN ('10', '11', '12'))
       GROUP BY pkd.load_id, pkd.wh_id


    -- Count the number of record we need to create load, ship, etc.. requests for
    SELECT @n_Count  = COUNT (*)
    FROM #t_work_d_work

    -- Check for Errors
    SELECT @v_nErrorNumber = @@ERROR
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
    IF @n_Count = 0
    BEGIN
        -- Then all work requests are already generated so update PKD's and exit
        DROP TABLE #t_work_d_work

        -- Update the PKD's with PRERLSE status to RELEASE if a work q has been assigned
        UPDATE #tmp_pick_details_to_update --t_pick_detail
        SET status = 'RELEASED'
        WHERE status = 'PRERLSE'
            AND (work_q_id IS NOT NULL or work_type = '15')

        SELECT @v_nErrorNumber = @@ERROR
        -- Check for any errors. If so, error number will not be equal to zero.
        IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
        -- Exit
        GOTO ExitLabel
    END



    -- Get new range of values....need one per load id
    -- Number or loads * three (1 for load, 1 for load audit, and 1 for ship request)
    SET @n_Range = (@n_Count * 3)

    -- Increment the t_control WORK_Q_ID entry for the number of Work Q's needed
    BEGIN TRAN

    EXEC @v_nReturn = usp_get_next_value_range @in_vchType = 'WORK_Q_ID', @in_nIncrement = @n_Range ,
                      @out_nUIDFirst = @n_StartWKQ OUTPUT, @out_nUIDLast = 	@n_FinishWKQ OUTPUT ,
                      @out_nErrorNumber = @v_nErrorNumber OUTPUT, @out_vchLogMsg = @v_vchOutMsg OUTPUT

    IF @v_nReturn <> 0
    BEGIN
        ROLLBACK TRAN
        SET @v_vchErrorMsg = @v_vchOutMsg
        SET @v_nLogErrorNum = @e_GetWKQRangeError
	GOTO ErrorHandler
    END
    ELSE
    BEGIN
        COMMIT
    END

    -- DECREMENT THE START WORK Q
    SET @n_StartWKQ = @n_StartWKQ - 1


    -- Update the records with their work queue ids
    UPDATE #t_work_d_work
    SET load_work_q_id = @n_StartWKQ +  id,
        audit_work_q_id =  @n_StartWKQ + (@n_Count) + id,
        ship_work_q_id = @n_StartWKQ + (2 * @n_Count) + id
    FROM #t_work_d_work
    WHERE #t_work_d_work.id = #t_work_d_work.id


    -- Insert work queue entries for Loading
    INSERT t_work_q (work_q_id, pick_ref_number, pkd.work_type, priority, description, date_due, time_due, wh_id,
					work_status, workers_required, workers_assigned)
    SELECT wkd.load_work_q_id, load_id, '10' , MIN(wkt.default_priority), MIN(wkt.description), GETDATE(), GETDATE(), wkd.wh_id,
		 'U', 1 , 0
    FROM #t_work_d_work wkd, t_work_types wkt
    WHERE wkt.work_type = '10'
    GROUP BY wkd.load_work_q_id, load_id, wkd.wh_id

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
        -- Check for Number of rows affected.
    IF @v_nRowCount = 0
        BEGIN
            SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Loading. '
            SET @v_nLogErrorNum = @e_AddWKQError

            GOTO ErrorHandler
        END

    -- Insert work queues for Load Audit
    INSERT t_work_q (work_q_id, pick_ref_number, pkd.work_type, priority, description, date_due, time_due, wh_id,
					work_status, workers_required, workers_assigned)
    SELECT wkd.audit_work_q_id, load_id, '11' , MIN(wkt.default_priority), 
           MIN(wkt.description), GETDATE(), GETDATE(),
           wkd.wh_id, 'U', 1 , 0
    FROM #t_work_d_work wkd, t_work_types wkt
    WHERE wkt.work_type = '11'
    GROUP BY wkd.audit_work_q_id, load_id, wkd.wh_id


    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
        -- Check for Number of rows affected.
    IF @v_nRowCount = 0
    BEGIN
        SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Load Audit. '
        SET @v_nLogErrorNum = @e_AddWKQError
        GOTO ErrorHandler
    END

    -- Insert work queues for Shipping
    INSERT t_work_q (work_q_id, pick_ref_number, pkd.work_type, priority, description, date_due, time_due, wh_id,
					work_status, workers_required, workers_assigned)
    SELECT wkd.ship_work_q_id, load_id, '12' , MIN(wkt.default_priority), 
           MIN(wkt.description), GETDATE(), GETDATE(),
           wkd.wh_id, 'H', 1 , 0
    FROM #t_work_d_work wkd, t_work_types wkt
    WHERE wkt.work_type = '12'
    GROUP BY wkd.ship_work_q_id, load_id, wkd.wh_id


    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
    BEGIN
        SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Shipping. '
        SET @v_nLogErrorNum = @e_AddWKQError
        GOTO ErrorHandler
   END

    -- Insert dependencies
    INSERT t_work_q_dependency (parent_work_q_id, dependent_work_q_id, status, dependency_type, wh_id)
    SELECT DISTINCT audit_work_q_id , ship_work_q_id, 'ACTIVE' , 'FS' , twk.wh_id
    FROM #t_work_d_work twk, 
         #tmp_pick_details_to_update pkd, --t_pick_detail pkd, 
         t_order ord
    WHERE twk.load_id = pkd.load_id
        AND twk.wh_id = pkd.wh_id
	AND pkd.order_number = ord.order_number
        AND pkd.wh_id = ord.wh_id
        AND ord.partial_order_flag = 'N'

    UPDATE t_work_q 
    SET work_status = 'H'
    WHERE work_q_id in (SELECT dependent_work_q_id 
			FROM t_work_q_dependency
			WHERE dependency_type = 'FS')


    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT

    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


     -- Update the PKD's with PRERLSE status to RELEASE
    UPDATE #tmp_pick_details_to_update
    SET status = 'RELEASED'
    WHERE  #tmp_pick_details_to_update.status = 'PRERLSE'
            

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END

    -- Check for Number of rows affected.
--     IF @v_nRowCount = 0
--         BEGIN
--             SET @v_vchErrorMsg = 'Failed to update PKD status to RELEASED where status is PRERLSE. '
--             SET @v_nLogErrorNum = @e_AddWKQError
--             GOTO ErrorHandler
--         END

    -- Clean up temporary tables
    DROP TABLE #t_work_d_work

Results:
    -- Return message if called from WebWise

    IF @n_Count =  0
        BEGIN
            IF @in_nResultsFlag = 1
                    SELECT 'No Records to Release for Criteria Provided!' AS message
            GOTO ExitLabel
        END
    ELSE
        IF @in_nResultsFlag = 1
            SELECT 'Order Release Successful!' AS message

    GoTo ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)

    SET @v_nReturn = @v_nLogErrorNum

    IF @v_nTranCount > 0
        ROLLBACK TRANSACTION

ExitLabel:
    -- Always leave the stored procedure from here.
    RETURN @v_nReturn




