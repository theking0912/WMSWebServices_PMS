
CREATE PROCEDURE usp_arch_table_exists  @in_vchTable_Name     NVARCHAR(100),
                                        @in_vchHistDatabase   NVARCHAR(100) = 'AAD',
                                        @Result               NVARCHAR(3) OUTPUT
                                        
 AS   
BEGIN 
        DECLARE @vCount           INTEGER,      
                @vTableName       NVARCHAR(100),
                @vHistDatabase    NVARCHAR(100),
                @vLongStrDDL      NVARCHAR(4000),
                @vParamDefinition NVARCHAR(500)

            SET @vTableName    = LTRIM(RTRIM(@in_vchTable_Name))
            SET @vHistDatabase = LTRIM(RTRIM(@in_vchHistDatabase))



         SET @vLongStrDDL = 'SELECT @nQueryOutput = Count(*) '
                          + 'FROM ' + @vHistDatabase + '..' + 'sysobjects '
                          + 'WHERE name = ''' + @vTableName + ''''
                          + ' AND  xtype = ''U'''
         SET @vParamDefinition = '@nQueryOutput INT OUTPUT'
         EXECUTE sp_executesql @vLongStrDDL, @vParamDefinition, @nQueryOutput=@vCount OUTPUT;


   
    IF @vCount > 0 
      SET @Result = 'YES'
    ELSE
      SET @Result = 'NO'
   
      
ExitLabel:
 --   RETURN @Result

END

