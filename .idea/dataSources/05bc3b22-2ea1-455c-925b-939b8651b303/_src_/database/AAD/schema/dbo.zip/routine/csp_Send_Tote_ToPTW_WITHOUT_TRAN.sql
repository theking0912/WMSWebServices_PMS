


CREATE PROCEDURE [dbo].[csp_Send_Tote_ToPTW_WITHOUT_TRAN]    
     @wh_id				NVARCHAR(10),  
     @hu_id			    NVARCHAR(30)
as    
begin    
    -- set nocount on added to prevent extra result sets from    
    set nocount on;    

		DECLARE @seq_id NVARCHAR(36)

		--IF NOT EXISTS ( SELECT 1 
		--			FROM t_hu_master hum
		--			     inner join tbl_pick_wall pw on hum.wh_id = pw.wh_id 
		--							and hum.control_number = pw.wall_id
		--			WHERE hum.wh_id = @wh_id
		--			AND hum.hu_id = @hu_id)
		--	BEGIN
		--		RETURN
		--	END


		
		INSERT INTO tbl_inf_dps_lp
		([wave_id],[order_number],[hu_id],[pick_wall_slot],[item_number],[item_name]
           ,[meas],[picked_qty],[create_date],[inf_date],[status])
		SELECT (SELECT TOP 1 wave_id FROM t_afo_wave_detail WHERE wh_id = sto.wh_id AND order_number = pkd.order_number)
			,pkd.order_number
			,sto.hu_id
			,(SELECT TOP 1 slot FROM tbl_pick_wall_slot_detail WITH(NOLOCK) WHERE wh_id = sto.wh_id AND order_number = pkd.order_number AND wall_id = sto.shipment_number)
			,sto.item_number
			,MAX(itm.[description])
			,CASE  WHEN ISNULL(MAX(itm.pack_flag),'N') = 'Y' AND ISNULL(sto.stored_attribute_id,'') <> ''
				THEN (SELECT TOP 1 tiu.uom 
						FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
							INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
							ON tscd.attribute_id = tacd.attribute_id
							INNER JOIN t_item_uom tiu WITH(NOLOCK)
							ON tiu.uom_prompt = tscd.attribute_value
							WHERE tacd.attribute_collection_id = MAX(itm.attribute_collection_id)
								AND tscd.stored_attribute_id = sto.stored_attribute_id
								AND tiu.item_number = MAX(itm.item_number)
								AND tiu.wh_id = sto.wh_id)
				WHEN ISNULL(MAX(itm.ed_flag),'N') = 'Y'
								THEN (SELECT TOP 1 order_uom FROM t_order_detail od
										WHERE od.wh_id = sto.wh_id
										AND od.order_number = pkd.order_number
										AND od.item_number = sto.item_number)
				ELSE
					(SELECT TOP 1 tiu.uom 
							FROM t_item_uom tiu WITH(NOLOCK)
								WHERE wh_id = sto.wh_id
									AND item_number = sto.item_number
								ORDER BY conversion_factor ASC)
				END
			--,SUM(sto.actual_qty)
			,CASE  WHEN ISNULL(MAX(itm.pack_flag),'N') = 'Y' AND ISNULL(sto.stored_attribute_id,'') <> ''
				THEN SUM(sto.actual_qty) / (SELECT TOP 1 tiu.conversion_factor 
						FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
							INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
							ON tscd.attribute_id = tacd.attribute_id
							INNER JOIN t_item_uom tiu WITH(NOLOCK)
							ON tiu.uom_prompt = tscd.attribute_value
							WHERE tacd.attribute_collection_id = MAX(itm.attribute_collection_id)
								AND tscd.stored_attribute_id = sto.stored_attribute_id
								AND tiu.item_number = MAX(itm.item_number)
								AND tiu.wh_id = sto.wh_id)
				WHEN ISNULL(MAX(itm.ed_flag),'N') = 'Y'
						THEN  SUM(sto.actual_qty) / (SELECT TOP 1 tiu.conversion_factor FROM t_order_detail od
									INNER JOIN t_item_uom tiu WITH(NOLOCK)
									ON od.wh_id = tiu.wh_id
									AND od.item_number = tiu.item_number
									AND od.order_uom = tiu.uom
										WHERE od.wh_id = sto.wh_id
										AND od.order_number = pkd.order_number
										AND od.item_number = sto.item_number)
				ELSE
					 SUM(sto.actual_qty)
				END
			,GETDATE()
			,NULL
			,0
		FROM t_stored_item sto
			INNER JOIN t_item_master itm on sto.wh_id = itm.wh_id
										AND sto.item_number = itm.item_number
			INNER JOIN t_pick_detail pkd on pkd.pick_id = sto.[type]
		WHERE sto.wh_id = @wh_id
		AND  EXISTS(SELECT 1 FROM t_order WITH(NOLOCK) 
									INNER JOIN t_customer c WITH(NOLOCK)
									ON t_order.customer_id = c.customer_id 
										WHERE t_order.order_number = pkd.order_number
										AND t_order.wh_id = pkd.wh_id
										AND ISNULL(c.customer_type,'') <> 'SHWX-ND')	
		AND sto.hu_id = @hu_id
		GROUP BY sto.hu_id,sto.wh_id,sto.shipment_number,pkd.order_number,sto.item_number,sto.stored_attribute_id
		ORDER BY sto.hu_id,sto.wh_id,sto.shipment_number,pkd.order_number,sto.item_number,sto.stored_attribute_id

        return

end    
    

