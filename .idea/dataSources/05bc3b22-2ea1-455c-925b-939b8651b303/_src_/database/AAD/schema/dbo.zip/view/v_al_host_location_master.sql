
CREATE VIEW v_al_host_location_master AS
SELECT
host_location_id,
host_group_id,
record_create_date,
processing_code,
wh_id,
location_id,
description,
zone,
class,
picking_flow,
type,
capacity_volume,
length,
width,
height,
pick_area,
item_hu_indicator
  FROM t_al_host_location_master
