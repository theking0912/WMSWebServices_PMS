
CREATE VIEW v_po_master AS
SELECT p.po_number, (SELECT type FROM v_type WHERE type_id = p.type_id) AS type, p.vendor_code, p.create_date, p.wh_id, p.status
  FROM t_po_master p
