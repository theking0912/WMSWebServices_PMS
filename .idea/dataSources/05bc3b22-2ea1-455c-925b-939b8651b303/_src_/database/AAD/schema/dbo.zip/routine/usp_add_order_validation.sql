
CREATE PROCEDURE usp_add_order_validation
@in_vchOrderNumber    NVARCHAR(60),
@in_vchWarehouseId    NVARCHAR(20),
@in_vchWaveId         NVARCHAR(20),   
@out_vchMessage       NVARCHAR(200) OUTPUT, -- Contians "SUCCESS" or the message to be displayed.
@out_nAllow           INTEGER OUTPUT    -- 0 = Succes, 1 = warning, 2 = error

AS

DECLARE 
    @v_nErrorNumber		 INTEGER,
    @v_vchParam1         NVARCHAR(100),
    @v_vchLogMsg         NVARCHAR(250),

    @c_nModuleNumber     INTEGER,
    @c_nFileNumber       INTEGER,
    @v_nRaiseErrorNumber INTEGER,
    @v_vchSqlErrorNumber NVARCHAR(50),
    @v_nRowCount         INTEGER,
    @v_nTranCount        INTEGER,
    @e_GenSqlError       INTEGER

    SET @out_vchMessage = 'FAILURE'
    SET @out_nAllow = 2   -- eRROR

    SET NOCOUNT ON

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    -- See if any candidate lines left on the order
    SELECT @v_nRowCount = COUNT (*)
    FROM t_order_detail
    WHERE order_number = @in_vchOrderNumber
        AND wh_id = @in_vchWarehouseId
        AND afo_plan_qty > 0

    -- Check for error
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END
    
    IF @v_nRowCount > = 1 -- At least one line
        SET @out_vchMessage = 'SUCCESS'

    IF @v_nRowCount = 0 -- Qty/all lines have been moved possibly by another user
        SET @out_vchMessage = 'NO QTY'


    -- Add Additional Validation Rules


    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    Goto ExitLabel


ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
        SET @out_nAllow = 2 -- Error
    END
    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    -- Raiserror parameters: Error #, Severity(11=ADO requirement), State(1), Parameter(to be used in error)
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)        


ExitLabel:
    RETURN
