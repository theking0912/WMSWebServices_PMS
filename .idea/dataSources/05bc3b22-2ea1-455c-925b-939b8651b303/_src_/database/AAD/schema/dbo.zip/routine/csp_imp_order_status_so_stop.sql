CREATE PROCEDURE  csp_imp_order_status_so_stop
AS --
update t_control 
set c1='N' 
WHERE control_type  ='C_LOCK_SALE' AND UPPER(isnull(c1,'N'))<>'N'