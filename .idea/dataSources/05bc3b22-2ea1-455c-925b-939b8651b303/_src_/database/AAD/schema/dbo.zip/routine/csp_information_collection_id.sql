

CREATE PROCEDURE [dbo].[csp_information_collection_id]
   @in_vchCollectionName   NVARCHAR(30),
   @out_RowID              INT OUTPUT
AS
SET NOCOUNT ON

INSERT INTO tbl_information_collection_master( 
  information_collection_name
  , create_date
  , modified_date
) VALUES (
  @in_vchCollectionName
  , CONVERT(datetime, CONVERT(NVARCHAR, GETDATE(),101))
  , CONVERT(datetime, CONVERT(NVARCHAR, GETDATE(),101))
);

SET @out_RowID = SCOPE_IDENTITY();
ExitLabel:
    RETURN
