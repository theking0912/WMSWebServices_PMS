
CREATE PROCEDURE usp_afo_hold_wave
@in_vchWarehouseId    NVARCHAR(20),
@in_vchWaveId         NVARCHAR(60),
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contains "SUCCESS" or the message to be displayed.

AS
-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                            HighJump Software
--                        Minneapolis, Minnesota, USA
-- ********************************************************************************
--  The purpose of this stored procedure is to set the t_wave_master and
--  t_work_q status for the shipment to H for held. It also does validation to
--  make sure the shipment is "holdable" which means it is not currently being
--  picked and it has not been shipped.
--
--  Notes:
--
--  Input:
--      WaveId
--      LoadId
--
--  Output:
--	   @out_vchMessage -- SUCCESS or the error Message
--
--  Uses:
--	    Table(s) -
--        t_wave_master
--        t_work_q
--
--	    Sproc(S) -
--
--	    Trigger(s) -
--
--  Target:
--	    SQL Server
--
-- ********************************************************************************
DECLARE
    @v_nLogErrorNum       INTEGER,
    @v_vchErrorMsg        NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,

    @e_GenSqlError   	   INTEGER,
    @e_NotHoldable         INTEGER,
    @e_UpdLDMFailed        INTEGER,
    @e_DelWKQDepFailed     INTEGER,
    @e_DelWKQShipReqFailed INTEGER,
    @e_DelWKQPickReqFailed INTEGER,
    @e_DelPKDFailed        INTEGER,

    @c_chHoldStatus       CHAR(1),
    @v_vchOrderNumber     NVARCHAR(60),
    @v_nTranCount         INTEGER,
    @v_nValue             INTEGER,
    @vchOrderNum          NVARCHAR(60),
    @vchWHID              NVARCHAR(20),
    @v_nContAdvFlag       INTEGER,
    @v_nContManifestFlag  INTEGER


    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @c_chHoldStatus = 'H'

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 6

    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_NotHoldable = 2
    SET @e_UpdLDMFailed = 3
    SET @e_DelWKQDepFailed = 4
    SET @e_DelWKQShipReqFailed = 5
    SET @e_DelWKQPickReqFailed = 6
    SET @e_DelPKDFailed = 7

    -- Temp table used to hold items from t_pick_detail.
    -- Items will be updated with a location_id and
    -- picking flow based on any specific rules which are executed.
    --D-10333 - WB changed this to be a table variable and added container_id. 
    DECLARE @tbl_pick_details_to_update TABLE
        (
            wh_id                    NVARCHAR(10)       COLLATE DATABASE_DEFAULT NOT NULL,
            pick_id                  INTEGER                                     NOT NULL,
            wave_id                  NVARCHAR(20)       COLLATE DATABASE_DEFAULT     NULL,
            load_id                  NVARCHAR(30)       COLLATE DATABASE_DEFAULT     NULL,
            work_q_id                NVARCHAR(30)       COLLATE DATABASE_DEFAULT     NULL,
            container_id 			 NVARCHAR(22)	    COLLATE DATABASE_DEFAULT     NULL,
            cartonization_batch_id   NVARCHAR(60)       COLLATE DATABASE_DEFAULT     NULL
        )
 
    -- create local temp tables
    DECLARE @tbl_carton_batch TABLE
        (
            cartonization_batch_id   NVARCHAR(60)       COLLATE DATABASE_DEFAULT NOT NULL
        )


    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0
        BEGIN TRANSACTION


    -- Check to see if picking has begun for any of the orders on the wave
    -- to be put on hold.
    SELECT @v_nRowCount = COUNT (*)
    FROM t_pick_detail
    WHERE wh_id = @in_vchWarehouseId
        AND wave_id = @in_vchWaveId
        AND(
            ((picked_quantity > 0) 
	     OR (staged_quantity > 0) 
	     OR (loaded_quantity > 0))
         OR (user_assigned IS NOT NULL)
            )

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount > 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        END
        ELSE
        BEGIN
             SET @v_vchErrorMsg = 'Wave cannot be held.  Picking has started.'
             SET @v_nLogErrorNum = @e_NotHoldable
        END
    GOTO ErrorHandler
    END

    INSERT INTO @tbl_pick_details_to_update 
        (wh_id, pick_id, wave_id, load_id, work_q_id, container_id, cartonization_batch_id)
    SELECT wh_id, pick_id, wave_id, load_id, work_q_id, container_id, cartonization_batch_id 
    FROM t_pick_detail
    WHERE wh_id = @in_vchWarehouseId
        AND wave_id = @in_vchWaveId

    -- Check for errors
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        SET @v_vchErrorMsg = 'Error filling temp table! (INSERT INTO temp table)  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END


    -- Check to see if labels have been printed for any of the orders on the wave
    -- to be put on hold.
    SELECT @v_nRowCount = COUNT (*)
    FROM @tbl_pick_details_to_update pkd, t_label lbl
    WHERE pkd.pick_id = lbl.pick_id
        AND lbl.label_status in ( 'PRINTED' , 'REPRINTED' )
        AND pkd.wh_id = @in_vchWarehouseId
        AND pkd.wave_id = @in_vchWaveId

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount > 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        END
        ELSE
        BEGIN
             SET @v_vchErrorMsg = 'Wave cannot be held.  Picking has started (labels printed).'
             SET @v_nLogErrorNum = @e_NotHoldable
        END
    GOTO ErrorHandler
    END  

    -- check for if flagship is installed.  
    SELECT @v_nContManifestFlag = ISNULL(next_value, 0)
    FROM t_whse_control 
    WHERE control_type = 'MANIFEST_SYSTEM'
	AND   wh_id = @in_vchWarehouseId 

    --Moved this before the deletion of the container because info from the container needs to be used in the stored procedure.
    IF @v_nContManifestFlag = '1'
    BEGIN
        EXEC dbo.usp_alp_ship_void @in_vchWaveId
        SELECT @v_vchSqlErrorNumber = @@ERROR
        
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server error occured while executing usp_alp_ship_void!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
    END    

    -- Delete data for the wave in the pick container table
    DELETE t_pick_container
    FROM t_pick_container pct
    WHERE EXISTS (SELECT pkd.container_id FROM @tbl_pick_details_to_update pkd 
                      WHERE pkd.wh_id = pct.wh_id AND pkd.container_id = pct.container_id)
    
    -- Check for errors 
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        SET @v_vchErrorMsg = 'bbb SQL Server System error occured!  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    -- check for if CTA is installed.  If it is there is more data to clean up
    SELECT @v_nContAdvFlag = ISNULL(next_value, 0)
    FROM t_control 
    WHERE control_type = 'CONTAINER-OPTIMIZE'


    IF @v_nContAdvFlag = 1 -- CTA is being used
    BEGIN -- Begin Cartonization clean up
    
        -- Get all the containerization batch id's on the wave for lines sent to cartonization
        -- This determines whether we need to clean up data that was containerized
        INSERT INTO @tbl_carton_batch (cartonization_batch_id) 
            (SELECT cartonization_batch_id
            FROM @tbl_pick_details_to_update
            WHERE wh_id = @in_vchWarehouseId
                AND wave_id = @in_vchWaveId
                AND cartonization_batch_id IS NOT NULL) -- Was sent to cartonizaiton

        -- Checkk for errors
        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'temp fill SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
        -- Check for no rows
        IF @v_nRowCount = 0
        BEGIN
            -- Skip this portion of the code because no container clean-up is needed
            GOTO HoldWave
        END
        
        -- Delete the cartonization results data results data
        DELETE t_container_optimize_block
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM @tbl_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'wwwSQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


        DELETE t_container_optimize_status
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM @tbl_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


        DELETE t_container_optimize_xml
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM @tbl_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


        -- delete carton prep data
        DELETE t_pick_task_uom
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM @tbl_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
    END -- End Cartonization data cleanup.

HoldWave:
    -- Update t_wave_master to a status of held
    UPDATE t_wave_master
    SET status = @c_chHoldStatus
    WHERE wave_id = @in_vchWaveId
        AND wh_id = @in_vchWarehouseId

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        END
        ELSE
        BEGIN
             SET @v_vchErrorMsg = 'Falied to update t_wave_master record to status of H.'
             SET @v_nLogErrorNum = @e_UpdLDMFailed
        END
    GOTO ErrorHandler
    END

   

    -- Delete the pick details and any work requests related to the wave
    --First delete dependency records 
    --Dependecy records should only exist for the ship request
    DELETE t_work_q_dependency
    WHERE wh_id = @in_vchWarehouseId
        AND parent_work_q_id IN (SELECT wkq.work_q_id -- A work request that belongs to the wave
                                FROM t_work_q wkq, @tbl_pick_details_to_update pkd
                                WHERE wkq.wh_id = pkd.wh_id
                                   AND wkq.pick_ref_number = pkd.load_id
                                   AND wkq.wh_id = @in_vchWarehouseId
                                   AND pkd.wave_id =  @in_vchWaveId
                                )
        OR dependent_work_q_id IN (SELECT wkq.work_q_id  -- A work request that belongs to the wave
                               FROM t_work_q wkq, @tbl_pick_details_to_update pkd
                                WHERE wkq.wh_id = pkd.wh_id
                                   AND wkq.pick_ref_number = pkd.load_id
                                   AND wkq.wh_id = @in_vchWarehouseId
                                   AND pkd.wave_id =  @in_vchWaveId
                                )

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    
    -- Delete any related ship, load, or load_audit requests related to the wave
    DELETE t_work_q
    WHERE wh_id = @in_vchWarehouseId
        AND pick_ref_number IN (SELECT load_id
                                FROM @tbl_pick_details_to_update
                                WHERE wh_id = @in_vchWarehouseId
                                    AND wave_id = @in_vchWaveId)
        AND work_type IN ('10', '11', '12') 

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
 
 


   -- Delete the pick request work_q's
   DELETE t_work_q
   WHERE wh_id = @in_vchWarehouseId
       AND work_q_id IN (SELECT work_q_id
                         FROM @tbl_pick_details_to_update
                         WHERE wh_id = @in_vchWarehouseId
                             AND wave_id = @in_vchWaveId)

    SELECT @v_vchSqlErrorNumber = @@ERROR

        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


   -- delete the label records
   DELETE lbl
   FROM t_label lbl , @tbl_pick_details_to_update pkd  
    WHERE lbl.pick_id = pkd.pick_id
        AND pkd.wh_id = @in_vchWarehouseId
        AND pkd.wave_id = @in_vchWaveId

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END


   -- delete the pick detail records
   DELETE t_pick_detail
   WHERE wh_id = @in_vchWarehouseId
       AND wave_id = @in_vchWaveId

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        END
        ELSE
        BEGIN
             SET @v_vchErrorMsg = 'Falied to detlete record from the t_pick_detail table.'
             SET @v_nLogErrorNum = @e_DelPKDFailed
        END
    GOTO ErrorHandler
    END

-- START CSA ORDER STATUS HISTORY LOGIC
-- Add Code here to loop through all the orders on a wave and write an order status history record for CSA.
--
--     --If CSA is installed and the order history sproc exists then insert order status history records.
--     --First check to see if CSA is installed and the usp_ta_order_status_history sproc are installed.
--     SELECT @v_nValue = next_value FROM t_control WHERE control_type = 'CSA'
--     --If the sproc exists
--     IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('dbo.usp_ta_order_status_history'))
--     BEGIN
--     	--AND if CSA is installed
--         IF ISNULL(@v_nValue,0) = 1
-- 	BEGIN
-- 	    DECLARE curOrders INSENSITIVE CURSOR FOR
--         	SELECT order_number, wh_id
--             		FROM t_ta_load_detail
--             		WHERE load_id = @in_vchLoadId
--         		FOR READ ONLY
--         	OPEN curOrders
-- 
--     		FETCH NEXT FROM curOrders
--             		INTO @vchOrderNum, @vchWHID
-- 
--     		WHILE @@FETCH_STATUS = 0
--     		BEGIN
-- 
-- 			EXECUTE usp_ta_order_status_history @vchWHID, @vchOrderNum, 'RELEASED'
-- 
--  		FETCH NEXT FROM curOrders
--             		INTO @vchOrderNum, @vchWHID
--     		END
--     		CLOSE curOrders
--    	 	DEALLOCATE curOrders
-- 	END
--     END --Of inserting CSA order status history records.
-- 
-- END CSA ORDER STATUS HISTORY LOGIC

    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    --D-10333 - WB - Commented these two statements out because I changed the tables to be table variables.
    --DROP TABLE #tbl_pick_details_to_update
    --DROP TABLE #tbl_carton_batch
    GOTO ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
    EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

    IF @v_nTranCount = 0
    	ROLLBACK TRANSACTION

    --D-10333 - WB - Commented these two statements out because I changed the tables to be table variables.
    --DROP TABLE #tbl_pick_details_to_update
    --DROP TABLE #tbl_carton_batch
   
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(NVARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(NVARCHAR(3),@c_nFileNumber) + '-' + CONVERT(NVARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    
    
    SET @out_vchMessage = @v_vchErrorMsg

ExitLabel:
    RETURN
