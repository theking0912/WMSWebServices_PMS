
CREATE VIEW v_al_host_po_detail_comment 
AS
SELECT
	host_po_detail_comment_id,
	host_po_detail_id,
    host_group_id,
	record_create_date,
	processing_code,
	wh_id,
    client_code,
	po_number,
    display_po_number,
	line_number,
	schedule_number,
    item_number,
	comment_type,
	comment_date,
	comment_text,
	comment_sequence
FROM
    t_al_host_po_detail_comment    
