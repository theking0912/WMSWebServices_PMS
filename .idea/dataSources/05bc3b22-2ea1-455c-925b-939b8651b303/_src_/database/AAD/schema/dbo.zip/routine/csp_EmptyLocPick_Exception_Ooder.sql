



-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Return Receiving by LP   
--  
    
-- =======================================    

CREATE PROCEDURE [dbo].[csp_EmptyLocPick_Exception_Ooder]    
     @wh_id					NVARCHAR(10)  
	,@ref_number			Nvarchar(30)  
    ,@pick_loc				Nvarchar(30)  
	,@item_number			Nvarchar(30)
	,@user_id				nvarchar(30)
	,@pick_hu				NVARCHAR(30)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @order_number NVARCHAR(30)
		DECLARE @loop_order_number NVARCHAR(30)
		DECLARE @wave_id NVARCHAR(30)
		SET @order_number=''-------will  add  20160716
		BEGIN TRANSACTION

		UPDATE tbl_allocation
		SET status ='E'
		  --- ,user_assign = NULL   ---modify by will 20160616
		WHERE wh_id = @wh_id
		AND user_assign = @user_id
		AND status = 'A'
		AND (hu_id = @pick_hu OR ISNULL(hu_id,'-1') = ISNULL(@pick_hu,'-1'))
		--AND ref_number = @ref_number
		AND location_id = @pick_loc
		AND item_number = @item_number
		
		COMMIT	TRANSACTION

		/*SELECT TOP 1 @order_number = order_number,
			@wave_id=wave_id
		FROM tbl_allocation
		WHERE wh_id = @wh_id
		AND status ='E'
		--AND ref_number = @ref_number
		AND location_id = @pick_loc
		AND (hu_id = @pick_hu OR ISNULL(hu_id,'-1') = ISNULL(@pick_hu,'-1'))
		AND item_number = @item_number
		GROUP BY wave_id,order_number
		ORDER BY order_number*/   -------------modify by will 20160716

	---	WHILE(@@ROWCOUNT > 0)  --delete by will 
	     WHILE (1=1)
			BEGIN
	--SET @loop_order_number = @order_number  --  delete by will 20160716
	---------------------will  add 20160716 s----------------------------
	SELECT TOP 1 @order_number = order_number,
			@wave_id=wave_id
		FROM tbl_allocation
		WHERE wh_id = @wh_id
		AND status ='E'
		--AND ref_number = @ref_number
		AND location_id = @pick_loc
		AND (hu_id = @pick_hu OR ISNULL(hu_id,'-1') = ISNULL(@pick_hu,'-1'))
		AND item_number = @item_number
		AND order_number>@order_number
		GROUP BY wave_id,order_number
		ORDER BY order_number
		IF @@ROWCOUNT <=0
		break
	---------------------will  add 20160716 e----------------------------

				EXEC [dbo].[csp_ReRelease_Order] @wh_id,@wave_id,@order_number

				EXEC csp_Create_Exception_Pick_List_order @wh_id,@wave_id,@order_number,@item_number


			UPDATE pd
	SET pd.status = 'LOADED'
	FROM t_pick_detail pd
	LEFT JOIN tbl_allocation allo on pd.wh_id = allo.wh_id
						AND pd.pick_id = allo.pick_id 
	WHERE pd.wh_id=@wh_id 
		AND pd.wave_id = @wave_id
		AND pd.item_number = @item_number 
		AND pd.order_number=@order_number
		AND pd.type='PP'
		AND NOT EXISTS(select 1 from tbl_allocation al where pd.wh_id = al.wh_id
						AND pd.pick_id = al.pick_id 
						AND al.wh_id=@wh_id 
						AND al.wave_id = @wave_id
						AND al.item_number = @item_number	
						AND al.order_number=@order_number				
						AND al.status <> 'C'
						AND al.allo_type = 'O')
	IF @@ROWCOUNT >0
	BEGIN

	------------------------------will add 20160621 start----------------------------------
   INSERT INTO [dbo].[t_exception_log]
           ([tran_type]
           ,[description]
           ,[exception_date]
           ,[exception_time]
           ,[employee_id]
           ,[wh_id]
           ,[suggested_value]
           ,[entered_value]
           ,[location_id]
           ,[item_number]
           ,[lot_number]
           ,[quantity]
           ,[hu_id]
           ,[load_id]
           ,[control_number]
           ,[line_number]
           ,[tracking_number]
           ,[error_code]
           ,[error_message]
           ,[status]
           ,[uom])
    VALUES( '1026',
	       N'摘果F7报空后无库存系统默认进行0短拣',
		   GETDATE(),
		   GETDATE(),
		   @user_id,
		   @wh_id,
		   NULL,
		   NULL,
		   @pick_loc,
		   @item_number,
		   NULL,
		   0,
		   @pick_hu,
		   NULL,
		   @order_number,
		   NULL,
		   NULL,
		   '1026',
		   N'摘果F7报空后无库存系统默认进行0短拣',
		   NULL,
		   NULL)

		  END
	
------------------------------will add 20160621 end----------------------------------

	UPDATE od
	SET od.status = 'STAGED'
	FROM t_order od
	INNER JOIN t_pick_detail pk ON od.wh_id = pk.wh_id
		AND od.order_number = pk.order_number
	WHERE pk.wh_id = @wh_id
		AND pk.wave_id = @wave_id
		AND pk.type = 'PP'
		AND NOT EXISTS (
			SELECT 1
			FROM t_order_detail a
			LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
				AND a.line_number = b.line_number
				AND a.item_number = b.item_number
				AND a.wh_id = b.wh_id				
			WHERE isnull(b.status, '') NOT IN ('STAGED','LOADED')
				AND a.wh_id = @wh_id
				AND isnull(b.work_type, '') = ''
				AND a.wh_id = od.wh_id
				AND a.order_number = od.order_number
			)
		AND EXISTS (
			SELECT 1
			FROM t_order_detail a
			LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
				AND a.line_number = b.line_number
				AND a.item_number = b.item_number
				AND a.wh_id = b.wh_id				
			WHERE isnull(b.status, '') IN ('STAGED','LOADED')
				AND a.wh_id = @wh_id
				AND isnull(b.work_type, '') = ''
				AND a.wh_id = od.wh_id
				AND a.order_number = od.order_number
			)

	UPDATE od
	SET od.status = 'LOADED'
	FROM t_order od
	INNER JOIN t_pick_detail pk ON od.wh_id = pk.wh_id
		AND od.order_number = pk.order_number
	WHERE pk.wh_id = @wh_id
		AND pk.wave_id = @wave_id
		AND pk.type = 'PP'
		AND NOT EXISTS (
			SELECT 1
			FROM t_order_detail a
			LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
				AND a.line_number = b.line_number
				AND a.item_number = b.item_number
				AND a.wh_id = b.wh_id				
			WHERE isnull(b.status, '') NOT IN ('LOADED')
				AND a.wh_id = @wh_id
				AND isnull(b.work_type, '') = ''
				AND a.wh_id = od.wh_id
				AND a.order_number = od.order_number
			)
		AND EXISTS (
			SELECT 1
			FROM t_order_detail a
			LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
				AND a.line_number = b.line_number
				AND a.item_number = b.item_number
				AND a.wh_id = b.wh_id				
			WHERE isnull(b.status, '') IN ('LOADED')
				AND a.wh_id = @wh_id
				AND isnull(b.work_type, '') = ''
				AND a.wh_id = od.wh_id
				AND a.order_number = od.order_number
			)
			---------------delete by will  20160716 s-------------------
				/*SELECT TOP 1 @order_number = order_number,
					@wave_id=wave_id
				FROM tbl_allocation
				WHERE wh_id = @wh_id
				AND status ='E'
				--AND ref_number = @ref_number
				AND location_id = @pick_loc
				AND (hu_id = @pick_hu OR ISNULL(hu_id,'-1') = ISNULL(@pick_hu,'-1'))
				AND item_number = @item_number
				AND order_number > @loop_order_number
				GROUP BY wave_id,order_number
				ORDER BY order_number*/
			---------------delete by will  20160716 e-------------------
			END


	
		SET @passornot = 0
		SET @msg = ''
		
        RETURN

    END TRY

    BEGIN CATCH
		IF @@TRANCOUNT >0 
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END




