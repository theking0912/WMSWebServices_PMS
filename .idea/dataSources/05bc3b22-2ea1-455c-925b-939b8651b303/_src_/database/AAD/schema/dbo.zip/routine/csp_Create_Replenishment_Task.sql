

CREATE  PROCEDURE [dbo].[csp_Create_Replenishment_Task]
	@wh_id NVARCHAR(30), 
	@zone NVARCHAR(50) 
AS
BEGIN	
	DECLARE @item_number NVARCHAR(30) --物料号
	DECLARE @location_id NVARCHAR(30) --货位号
	DECLARE @rep_qty DECIMAL(30, 8) --需要补货数量
	DECLARE @full_case_qty DECIMAL(30, 8) --满箱值

	SET @item_number = ''
	SET @location_id = ''

	IF OBJECT_ID('#temp_rep_item') IS NOT NULL
		DROP TABLE #temp_rep_item

	CREATE TABLE #temp_rep_item (
		item_number NVARCHAR(30)
		,location_id NVARCHAR(30)
		,rep_qty DECIMAL(30, 8)
		,wh_id NVARCHAR(30)
		)

	--取出tbl_loc_item绑定C区需补货的商品  
	INSERT INTO #temp_rep_item (
		item_number
		,location_id
		,rep_qty
		,wh_id
		)
	SELECT li.item_number
		,li.location_id
		,li.max_qty-ISNULL(st.actual_qty,0)
		,li.wh_id
	FROM tbl_loc_item li
	INNER JOIN t_location loc ON loc.wh_id = li.wh_id
		AND loc.location_id = li.location_id
	INNER JOIN t_zone_loca zl ON loc.wh_id=zl.wh_id and loc.location_id=zl.location_id 
	LEFT JOIN (select wh_id,item_number,location_id,sum(actual_qty) as actual_qty 
				from t_stored_item where wh_id=@wh_id 
				group by wh_id,item_number,location_id
				) st ON li.wh_id=st.wh_id and li.location_id=st.location_id and li.item_number=st.item_number
	WHERE loc.type = 'C'
		AND zl.zone=@zone
		AND li.wh_id=@wh_id
		AND (ISNULL(st.actual_qty,0)<li.min_qty or (li.min_qty =0 and ISNULL(st.actual_qty,0)=0))
		AND li.max_qty - ISNULL(st.actual_qty, 0) > 0
		AND NOT EXISTS (
			SELECT 1
			FROM tbl_allocation
			WHERE status IN (
					'U'
					,'A'
					)
				AND item_number = li.item_number
				AND wh_id = @wh_id
			)
		AND NOT EXISTS (
			SELECT 1
			FROM t_work_q
			WHERE work_status IN (
					'U'
					,'A'
					)
				AND item_number = li.item_number
				AND wh_id = @wh_id
				AND work_type IN (
					'05'
					,'06'
					)
			)

	IF EXISTS(select 1 from #temp_rep_item)
	BEGIN
		WHILE (1 = 1)
		BEGIN
			--获取物料
			SELECT TOP 1 @item_number = item_number
			FROM #temp_rep_item
			WHERE item_number > @item_number
			AND wh_id = @wh_id 
			ORDER BY item_number

			IF @@ROWCOUNT = 0
				BREAK

			SET @location_id = ''

			WHILE (1 = 1)
			BEGIN
				--获取货位
				SELECT TOP 1 @location_id = location_id,@rep_qty=rep_qty
				FROM #temp_rep_item
				WHERE item_number = @item_number
				AND wh_id = @wh_id 
				AND location_id > @location_id
				ORDER BY location_id

				IF @@ROWCOUNT = 0
					BREAK

				--生成P到C的补货
				EXECUTE dbo.csp_Replenishment_Alloc @item_number 
						,@location_id
						,@rep_qty
						,@wh_id
			END		

			--如果绑定了B区，则生成B区的补货任务
			IF EXISTS(select 1 from tbl_loc_item li
				INNER JOIN t_location loc ON loc.wh_id = li.wh_id
					AND loc.location_id = li.location_id
				INNER JOIN t_zone_loca zl ON loc.wh_id=zl.wh_id and loc.location_id=zl.location_id 
				WHERE loc.type in ('B','Z')
					AND zl.zone=@zone
					AND li.wh_id=@wh_id
					AND li.item_number=@item_number)
			BEGIN
				EXEC csp_Create_Replenishment_Task_CB @item_number
						,@wh_id
			END
		END
	END
	
	SET @item_number = ''
	SET @location_id = ''

	DELETE FROM #temp_rep_item

	--取出tbl_loc_item 中只绑定B区和只绑定C区的临时表
	INSERT INTO #temp_rep_item (
		item_number
		,location_id
		,rep_qty
		,wh_id
		)
	SELECT li.item_number
		,li.location_id
		,li.max_qty-ISNULL(st.actual_qty,0)
		,li.wh_id
	FROM tbl_loc_item li
	INNER JOIN t_location loc ON li.wh_id = loc.wh_id
		AND li.location_id = loc.location_id
	INNER JOIN t_zone_loca zl ON loc.wh_id=zl.wh_id and loc.location_id=zl.location_id 
	--LEFT JOIN t_stored_item st ON li.wh_id=st.wh_id and li.location_id=st.location_id and li.item_number=st.item_number--delete by will 20160708
	------------------add by will s 20160708------------------------
	LEFT JOIN (select wh_id,item_number,location_id,sum(actual_qty) as actual_qty 
				from t_stored_item where wh_id=@wh_id 
				group by wh_id,item_number,location_id
				) st ON li.wh_id=st.wh_id and li.location_id=st.location_id and li.item_number=st.item_number
   ------------------add by will e 20160708------------------------
	WHERE loc.type in ('B','Z') 
		AND zl.zone=@zone
		AND li.wh_id=@wh_id
		AND (ISNULL(st.actual_qty,0)<li.min_qty or (li.min_qty =0 and ISNULL(st.actual_qty,0)=0))
		AND li.max_qty - ISNULL(st.actual_qty, 0) > 0
		AND NOT EXISTS (select 1 from tbl_loc_item li2
			INNER JOIN t_location loc2 ON li2.wh_id = loc2.wh_id
				AND li2.location_id = loc2.location_id 
				AND li2.item_number = li.item_number 
				AND loc2.type='C'
				AND li2.wh_id=@wh_id)
		AND NOT EXISTS (
			SELECT 1
			FROM tbl_allocation
			WHERE status IN (
					'U'
					,'A'
					)
				AND item_number = li.item_number
				AND wh_id = @wh_id
			)
		AND NOT EXISTS (
			SELECT 1
			FROM t_work_q
			WHERE work_status IN (
					'U'
					,'A'
					)
				AND item_number = li.item_number
				AND wh_id = @wh_id
				AND work_type IN (
					'05'
					,'06'
					)
			)		

	IF EXISTS(select 1 from #temp_rep_item)
	BEGIN
		WHILE (1 = 1)
		BEGIN
			--获取物料
			SELECT TOP 1 @item_number = item_number
			FROM #temp_rep_item
			WHERE item_number > @item_number
			AND wh_id = @wh_id 
			ORDER BY item_number

			IF @@ROWCOUNT = 0
				BREAK

			SELECT TOP 1 @full_case_qty = ISNULL(full_case_qty, 1)
			FROM dbo.t_item_master
			WHERE item_number = @item_number
				AND wh_id = @wh_id

			SET @location_id = ''

			WHILE (1 = 1)
			BEGIN
				--获取货位
				SELECT TOP 1 @location_id = location_id,@rep_qty=rep_qty
				FROM #temp_rep_item
				WHERE item_number = @item_number
				AND wh_id = @wh_id 
				AND location_id > @location_id
				ORDER BY location_id

				IF @@ROWCOUNT = 0
					BREAK

				--如果P区需要拆托，则整箱拣出，向下取整
				SET @rep_qty=ISNULL((FLOOR((@rep_qty / @full_case_qty)) * @full_case_qty), 0)

				--生成P到C的补货
				EXECUTE dbo.csp_Replenishment_Alloc_PB @item_number 
						,@location_id
						,@rep_qty
						,@wh_id
			END		
		END
	END
END


