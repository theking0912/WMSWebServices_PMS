


CREATE FUNCTION usf_arch_sequence_change
(
     @in_nSource         INT,
     @in_nDestination    INT,
     @in_nActualPosition INT
)
RETURNS INT
AS
BEGIN

DECLARE
    @v_nNewPosition INT  

   IF @in_nActualPosition = @in_nSource
        SET @v_nNewPosition = @in_nDestination

   ELSE IF (    @in_nSource         >  @in_nDestination 
            AND @in_nActualPosition >= @in_nDestination
            AND @in_nActualPosition <  @in_nSource)
        SET @v_nNewPosition = @in_nActualPosition + 1

   ELSE IF (    @in_nSource         <  @in_nDestination 
            AND @in_nActualPosition <= @in_nDestination
            AND @in_nActualPosition >  @in_nSource)
        SET @v_nNewPosition = @in_nActualPosition - 1

   ELSE SET @v_nNewPosition = @in_nActualPosition


RETURN @v_nNewPosition

END

