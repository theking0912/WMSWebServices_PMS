
CREATE PROCEDURE usp_execute_sql_statement 
				@SQLStatement NVARCHAR(2000),
				@OUTMSG       NVARCHAR(2000) OUTPUT,
			    @STATUS_VALID INT OUTPUT
AS

	--declare variables
	DECLARE @vErrorNumber INT,
            @vIndexSQL    INT,
            @vCharacter   NCHAR(1),
            @vSQL_Str     NVARCHAR(50),
            @vErrorMsg    NVARCHAR(2000)

		SET @vErrorNumber  = 0
        SET @vIndexSQL     = 1
        SET @vErrorMsg     = ''
        SET @OUTMSG        = ''
        SET @STATUS_VALID  = 0 

	--Validate Structure of the string "SQLStatement"
BEGIN TRANSACTION
    --get the first 6 characters and validated if it's a function SELECT
    SET @vSQL_Str = UPPER(RTRIM(LTRIM(@SQLStatement)))
	IF SUBSTRING(@vSQL_Str, 1, 6)  <> 'SELECT'
		BEGIN	
			SET @vErrorNumber = 10000
			GOTO ErrorHandler
		END
	ELSE
		BEGIN
            SET @vCharacter = ''
        	WHILE @vIndexSQL < = LEN(@vSQL_Str)
			BEGIN
				SET @vCharacter = SUBSTRING(@vSQL_Str,@vIndexSQL,1)
                IF (@vCharacter = '') OR (@vCharacter = 'G')
                	BEGIN
						IF (SUBSTRING(@vSQL_Str,@vIndexSQL+1,3) = 'GO ')
							OR (SUBSTRING(@vSQL_Str,@vIndexSQL,2) = 'GO')
								OR (SUBSTRING(@vSQL_Str,@vIndexSQL,3) = 'GO;')
                    		BEGIN
								SET @vErrorNumber = 10001
                    			SET @vErrorMsg = N'The Sql statement is incorect the characters '''+ SUBSTRING(@vSQL_Str,@vIndexSQL+1,3) + 
                                                  ''', is not valid. '''+ @SQLStatement + ''''
             					GOTO ErrorHandler
							END
                	END
                ELSE
                    IF @vCharacter = 'C'
                    	BEGIN
							IF (SUBSTRING(@vSQL_Str,@vIndexSQL,6) = 'COMMIT')
                        		BEGIN
									SET @vErrorNumber = 10001
                        			SET @vErrorMsg = N'The Sql statement is incorect the characters '''+ SUBSTRING(@vSQL_Str,@vIndexSQL,6) + 
                                                      ''', is not valid. '''+ @SQLStatement + ''''
                 					GOTO ErrorHandler
								END
                    	END
                ELSE
                    IF @vCharacter = 'B'
                    	BEGIN
							IF (SUBSTRING(@vSQL_Str,@vIndexSQL,17) = 'BEGIN TRANSACTION')
									OR (SUBSTRING(@vSQL_Str,@vIndexSQL,10) = 'BEGIN TRAN')
                        		BEGIN
									SET @vErrorNumber = 10001
                        			SET @vErrorMsg = N'The Sql statement is incorect the Instruction ''BEGIN TRANSACTION or BEGIN TRAN'', is not valid. '''+ @SQLStatement + ''''
                 					GOTO ErrorHandler
								END
                    	END
				ELSE
					IF @vCharacter = 'D'
                    	BEGIN
							IF (SUBSTRING(@vSQL_Str,@vIndexSQL,6) = 'DELETE')
                        		BEGIN
									SET @vErrorNumber = 10001
                        			SET @vErrorMsg = N'The Sql statement is incorect the characters '''+ SUBSTRING(@vSQL_Str,@vIndexSQL,6) + 
                                                      ''', is not valid. '''+ @SQLStatement + ''''
                 					GOTO ErrorHandler
								END
                    	END
                ELSE
                    IF @vCharacter = ';'
                    	BEGIN
							SET @vErrorNumber = 10001
                        	SET @vErrorMsg = N'The Sql statement is incorect the characters '';'', is not valid. '''+ @SQLStatement + ''''
                 			GOTO ErrorHandler
                    	END
             
				SET @vIndexSQL = @vIndexSQL + 1
			END			
            --Execute SQL Statement
            --EXEC(@SQLStatement)
		END
		--Valid if exists a error 
	IF @@ERROR = 0 
		BEGIN
            SET @STATUS_VALID = 0
        	SET @OUTMSG = N'The SQL Statement was validated successfully'
  			GOTO ExitLabel					
		END
	ELSE
		BEGIN
			SET @vErrorNumber = @@ERROR
			GOTO ErrorHandler
		END	
	
ErrorHandler:
	IF @vErrorNumber = 10000 --Error controled
		BEGIN
			SET @OUTMSG = N'The Sql statement is incorect because the function '''+SUBSTRING(LTRIM(@vSQL_Str), 1, 6) +
                         	   ''', is not valid should be a ''SELECT'', '''+ @SQLStatement + ''''
            SET @STATUS_VALID = 1
		END
	ELSE
		IF @vErrorNumber = 10001 --Error controled
			BEGIN
				SET @OUTMSG = @vErrorMsg
                SET @STATUS_VALID = 1
			END
		ELSE
			BEGIN
				SET @OUTMSG = N'An SQL Server Error has occurred, ['+ CONVERT(NVARCHAR(20),@@ERROR)+
	                               '] Incorrect syntax, '''+ @SQLStatement + ''''
				SET @STATUS_VALID = 1
			END
		
ExitLabel:
        ROLLBACK TRANSACTION
    	RETURN
