
CREATE PROCEDURE [dbo].[usp_xml_export_invoice]
	(
		 @v_vchHostGroupID		NVARCHAR(36)		
		,@out_vchCode           uddt_output_code   OUTPUT
		,@out_vchMsg            uddt_output_msg    OUTPUT
	)
	
AS

-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                            HighJump Software
--                        Minneapolis, Minnesota, USA
-- ********************************************************************************
-- PURPOSE:
--   	The purpose of this stored procedure is to populate records into XML Staging Tables 
--  	from AL Host tables for Invoice Export
--
--  NOTES:
--	
--  INPUT:
--      See parameter list.
--	
--  OUTPUT:
--	    Return Code
--
--  USES:
--	    Table(s) - 
--        t_xml_exp_export_ivc
--        t_xml_exp_ivc_master
--		  t_xml_exp_ivc_details
--		  t_xml_exp_ivc_detail
--		  
--
--  TARGET:
--	    SQL Server 
--
--
-- ********************************************************************************	
DECLARE

----------------------------------------------------------------------------------------------------------------------------	
-- Procedure variables
----------------------------------------------------------------------------------------------------------------------------
		
	@v_dtRecordCreateDate		DATETIME
	
		
----------------------------------------------------------------------------------------------------------------------------	
-- Local Variables
----------------------------------------------------------------------------------------------------------------------------
	,@c_vchObjName               uddt_obj_name			
	,@v_nSysErrorNum			INT
	,@v_vchMsg					NVARCHAR(4000)
    ,@v_vchCode					NVARCHAR(10)
    ,@v_nRetryCount				INT
	,@v_nTranCount				INT
	,@v_nXstate					INT		



SET NOCOUNT ON

----------------------------------------------------------------------------------------------------------------------------	
-- Set Constants
----------------------------------------------------------------------------------------------------------------------------

SET @c_vchObjName = N'usp_xml_export_invoice'
SET @v_vchCode = N'SUCCESS'
SET @v_vchMsg  = N'NONE'
SET @v_nSysErrorNum = 0
SET @v_nTranCount = 0


----------------------------------------------------------------------------------------------------------------------------	
-- Insert XML staging Records
----------------------------------------------------------------------------------------------------------------------------

SET @v_dtRecordCreateDate = GETDATE()	
SET @v_nRetryCount = 3


INS_AL:

BEGIN TRY

	SET @v_nTranCount = @@TRANCOUNT  
	
	IF @v_nTranCount = 0 
        BEGIN TRANSACTION 
    ELSE 
        SAVE TRANSACTION SAVEPOINT
		
    SET XACT_ABORT ON
	
	------------------------------------------------------------------------------------
	--		INSERT INTO t_xml_exp_export_ivc
	------------------------------------------------------------------------------------
		INSERT INTO t_xml_exp_export_ivc(
			 hjs_parent_id
			,hjs_node_id
			,hjs_sequence
			,hjs_error_number			
			)
		SELECT DISTINCT
			 @v_vchHostGroupID
			,@v_vchHostGroupID
			,0
			,0
		
	------------------------------------------------------------------------------------
	--		INSERT INTO t_xml_exp_ivc_master
	------------------------------------------------------------------------------------
		INSERT INTO t_xml_exp_ivc_master(
			 hjs_parent_id
			,hjs_node_id
			,hjs_sequence
			,hjs_error_number
			,OrderNumber
			,DisplayOrderNumber
			,ClientCode
			,WarehouseID
			,CarrierSCAC
			,LoadID
			,ProNumber
			,SealNumber
			,TotalWeight
			,TotalVolume
			,Status
			,SplitStatus
			,UserID
			)
		SELECT
			 @v_vchHostGroupID
			,NEWID()
			,0
			,0
			,tsm.order_number
			,tsm.display_order_number
			,tsm.client_code
			,tsm.wh_id
			,tsm.carrier_code
			,tsm.load_id
			,tsm.pro_number
			,tsm.seal_number
			,CONVERT(DECIMAL(8,2),tsm.total_weight)
			,CONVERT(DECIMAL(8,2),tsm.total_volume)
			,tsm.status
			,tsm.split_status
			,tsm.user_id			
		 FROM t_al_host_shipment_master tsm WITH (NOLOCK)
		WHERE tsm.host_group_id = @v_vchHostGroupID		
		
	------------------------------------------------------------------------------------
	--		INSERT INTO t_xml_exp_ivc_details
	------------------------------------------------------------------------------------
		INSERT INTO t_xml_exp_ivc_details(
			 hjs_parent_id
			,hjs_node_id
			,hjs_sequence
			,hjs_error_number
			)
		SELECT DISTINCT
			 txmlexp.hjs_node_id
			,NEWID()
			,0
			,0
		FROM t_al_host_shipment_master tsm WITH (NOLOCK)
		INNER JOIN t_xml_exp_ivc_master txmlexp ON txmlexp.OrderNumber = tsm.order_number
		WHERE tsm.host_group_id = @v_vchHostGroupID
				
	------------------------------------------------------------------------------------
	--		INSERT INTO t_xml_exp_ivc_detail
	------------------------------------------------------------------------------------
		 INSERT INTO t_xml_exp_ivc_detail(
			 hjs_parent_id
			,hjs_node_id
			,hjs_sequence
			,hjs_error_number			
			,LineNumber
			,ItemNumber
			,DisplayItemNumber
			,LotNumber
			,QuantityShipped
			,HUID
			,Tracking
			,UOM
			,Attribute1
			,Attribute2
			,Attribute3
			,Attribute4
			,Attribute5
			,Attribute6
			,Attribute7
			,Attribute8
			,Attribute9
			,Attribute10
			,Attribute11
			)
		SELECT DISTINCT
			 txmldet.hjs_node_id
			,NEWID()
			,0
			,0
			,tsd.line_number
		    ,tsd.item_number
		    ,tsd.display_item_number
		    ,tsd.lot_number
		    ,tsd.quantity_shipped
		    ,tsd.hu_id
		    ,tsd.tracking_number
		    ,tsd.uom
		    ,tsd.gen_attribute_value1
		    ,tsd.gen_attribute_value2
		    ,tsd.gen_attribute_value3
		    ,tsd.gen_attribute_value4
		    ,tsd.gen_attribute_value5
		    ,tsd.gen_attribute_value6
		    ,tsd.gen_attribute_value7
		    ,tsd.gen_attribute_value8
		    ,tsd.gen_attribute_value9
		    ,tsd.gen_attribute_value10
		    ,tsd.gen_attribute_value11
		FROM 
			t_al_host_shipment_detail tsd WITH (NOLOCK)
			INNER JOIN t_al_host_shipment_master tsm WITH (NOLOCK)
			   ON  tsm.shipment_id = tsd.shipment_id
			   AND tsm.wh_id = tsd.wh_id
			INNER JOIN t_xml_exp_ivc_master txmlexp ON txmlexp.OrderNumber = tsm.order_number
			INNER JOIN t_xml_exp_ivc_details txmldet ON txmldet.hjs_parent_id = txmlexp.hjs_node_id
		WHERE
			 tsm.host_group_id  = @v_vchHostGroupID

	COMMIT TRANSACTION
	
	SET XACT_ABORT OFF		
	
END TRY
 
BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
	SET @v_nTranCount = @@TRANCOUNT
	SET @v_nXstate = XACT_STATE() 
  
	IF @v_nXstate = -1 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount = 0 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount > 0 
        ROLLBACK TRANSACTION SAVEPOINT   


-- Check for Deadlock and Retry as long as the Retry Counter is greater than zero  
    IF (@v_nRetryCount > 0 AND @v_nSysErrorNum = 1205) 
	BEGIN
		SET @v_nRetryCount = @v_nRetryCount - 1
		SET XACT_ABORT OFF;	
		GOTO INS_AL
	END

	SET @v_vchCode = N'-20001'    
    SET @v_vchMsg = N'A SQL error occured while inserting t_xml_exp records for Invoice Export.'	
	SET @v_vchMsg = @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE()
	GOTO ERROR_HANDLER
END CATCH

GOTO EXIT_LABEL
	
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + N'Deadlock error: 40001 ' + @v_vchMsg
    ELSE    
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + @v_vchMsg 
		
    --Should only raise error in the parent sproc
    RAISERROR(@v_vchMsg, 11, 1)
    
    -- Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg
    
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

-- Always leave the stored procedure from here.
RETURN 
