
CREATE VIEW dbo.v_constant
AS
SELECT lookup_id as status_id, locale_id, source, sequence, text, description, lookup_type
    FROM t_lookup
    WHERE lookup_type = 'CONSTANT'

