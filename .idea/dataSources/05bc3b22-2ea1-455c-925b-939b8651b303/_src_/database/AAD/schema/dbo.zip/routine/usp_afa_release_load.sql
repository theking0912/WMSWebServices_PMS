
CREATE PROCEDURE usp_afa_release_load
@in_vchWarehouseId     NVARCHAR(20),    
@in_vchLoadId          NVARCHAR(60),
@in_vchPriority        NVARCHAR(10),
@in_nWorkersRequired   INTEGER,
@in_dtEarliestShipDate DATETIME,
@in_dtLatestShipDate   DATETIME,
@in_OverrideWorkType   NVARCHAR(2),
@out_vchMessage        NVARCHAR(500) OUTPUT -- Contians "SUCCESS" or the message to be displayed.

AS

DECLARE 
    @v_nErrorNumber       INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(500),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,
    @v_nReturn            INTEGER,
    @v_vchErrorMsg        NVARCHAR(500),
    @v_nSysErrorNum       INTEGER,

    @e_GenSqlError   	  INTEGER,
    @e_InvalidWorkType    INTEGER,
    @e_UpdLDMFailed       INTEGER,
    @e_InsWKQFailed       INTEGER,
    @e_UpdWKQFailed       INTEGER,
    @e_SprocError         INTEGER,
    @e_MissingUomData     INTEGER,

    @c_chReleaseStatus    CHAR(1),
    @c_chUnassigned       CHAR(1),
    @v_nLoopCount         INTEGER,
    @v_vchWhId            NVARCHAR(20),
    @v_vchNextWhId        NVARCHAR(20),

    @v_nContAdvFlag       INTEGER,
    @v_nTranCount         INTEGER,
    @v_vchDescription     NVARCHAR(100),
    @v_dtTimeDue          DATETIME,
    @v_dtDateDue          DATETIME,
    @v_vchWorkqId         NVARCHAR(60),
    @v_PKDStagingLoc      NVARCHAR(20),
    @v_vchStageLoc        NVARCHAR(50),
    @v_vchDoorLoc         NVARCHAR(50),
    @v_nValue             INTEGER,
    @v_vchOutMsg          NVARCHAR(500),
    @v_nLogErrorNum       INTEGER,
    @v_vchStartTran       INTEGER,

    @n_StartWKQ			  INTEGER,
    @n_FinishWKQ		  INTEGER,
	@v_dtLatestShipDate	  DATETIME


    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @c_chReleaseStatus = 'R'
    SET @c_chUnassigned = 'U'

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 7
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_UpdLDMFailed = 2
    SET @e_InvalidWorkType = 3
    SET @e_InsWKQFailed = 4
    SET @e_UpdWKQFailed = 5
    SET @e_SprocError = 6
    SET @e_MissingUomData = 7
    SET @v_vchStartTran = 0

	--Fix Defect D-08697
		--IF AFA is Installed and profile is 4 for "Wave then Load"
		--Then only create the WKQ's for load and shipments
		--PKDs and their WKQ are already created during wave release process.
		--This sproc is only called during load release part of "Wave then Load".
		--Rest of the functionality is left alone as this sproc is also used for "Load Only" when it generates picks too.

		IF (SELECT next_value
			FROM t_whse_control WITH (NOLOCK)
			WHERE wh_id = @in_vchWarehouseId
			  AND control_type = 'AFA_INSTALLED') = 4 

		BEGIN

			SET @v_vchStartTran = 1
			-- Get new range of values....need three per load id (1 for load, 1 for load audit and 1 for ship request)
			-- Increment the t_control WORK_Q_ID entry for the number of Work Q's needed
			BEGIN TRAN

				EXEC @v_nReturn = usp_get_next_value_range @in_vchType = 'WORK_Q_ID', @in_nIncrement = 3 ,
								  @out_nUIDFirst = @n_StartWKQ OUTPUT, @out_nUIDLast = 	@n_FinishWKQ OUTPUT ,
								  @out_nErrorNumber = @v_nLogErrorNum OUTPUT, @out_vchLogMsg = @v_vchOutMsg OUTPUT

				IF @v_nReturn <> 0
				BEGIN
					SET @v_vchErrorMsg = @v_vchOutMsg
					SET @v_nLogErrorNum = @e_SprocError
					GOTO ErrorHandler
				END
			COMMIT TRAN

			BEGIN TRAN

				-- Insert work queue entries for Loading
				INSERT t_work_q (work_q_id, pick_ref_number, pkd.work_type, priority, description, date_due, time_due, wh_id,
								work_status, workers_required, workers_assigned)
				SELECT @n_StartWKQ, @in_vchLoadId , MIN(wkt.work_type) , MIN(wkt.default_priority), MIN(wkt.description), GETDATE(), GETDATE(), @in_vchWarehouseId,
						@c_chUnassigned, 1 , 0
				FROM t_work_types wkt
				WHERE wkt.work_type = '10'
				  AND wkt.wh_id = @in_vchWarehouseId
				GROUP BY wkt.work_type, wkt.wh_id

				SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
				-- Check for any errors. If so, error number will not be equal to zero.
				IF @v_nErrorNumber <> 0
					BEGIN
						SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
							'the exact nature of the error.'
						SET @v_nLogErrorNum = @e_GenSqlError
						GOTO ErrorHandler
					END
				-- Check for Number of rows affected.
				IF @v_nRowCount = 0
					BEGIN
						SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Loading. '
						SET @v_nLogErrorNum = @e_GenSqlError

						GOTO ErrorHandler
					END

				-- Insert work queue entries for Load Audit
				INSERT t_work_q (work_q_id, pick_ref_number, pkd.work_type, priority, description, date_due, time_due, wh_id,
								work_status, workers_required, workers_assigned)
				SELECT @n_StartWKQ + 1, @in_vchLoadId , MIN(wkt.work_type) , MIN(wkt.default_priority), MIN(wkt.description), GETDATE(), GETDATE(), @in_vchWarehouseId,
						@c_chUnassigned, 1 , 0
				FROM t_work_types wkt
				WHERE wkt.work_type = '11'
				  AND wkt.wh_id = @in_vchWarehouseId
				GROUP BY wkt.work_type, wkt.wh_id

				SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
				-- Check for any errors. If so, error number will not be equal to zero.
				IF @v_nErrorNumber <> 0
					BEGIN
						SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
							'the exact nature of the error.'
						SET @v_nLogErrorNum = @e_GenSqlError
						GOTO ErrorHandler
					END
				-- Check for Number of rows affected.
				IF @v_nRowCount = 0
					BEGIN
						SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Load Audit. '
						SET @v_nLogErrorNum = @e_GenSqlError

						GOTO ErrorHandler
					END

				-- Insert work queue entries for Shipping
				INSERT t_work_q (work_q_id, pick_ref_number, pkd.work_type, priority, description, date_due, time_due, wh_id,
								work_status, workers_required, workers_assigned)
				SELECT @n_FinishWKQ, @in_vchLoadId , MIN(wkt.work_type) , MIN(wkt.default_priority), MIN(wkt.description), GETDATE(), GETDATE(), @in_vchWarehouseId,
						@c_chUnassigned, 1 , 0
				FROM t_work_types wkt
				WHERE wkt.work_type = '12'
				  AND wkt.wh_id = @in_vchWarehouseId
				GROUP BY wkt.work_type, wkt.wh_id

				SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
				-- Check for any errors. If so, error number will not be equal to zero.
				IF @v_nErrorNumber <> 0
					BEGIN
						SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
							'the exact nature of the error.'
						SET @v_nLogErrorNum = @e_GenSqlError
						GOTO ErrorHandler
					END
					-- Check for Number of rows affected.
				IF @v_nRowCount = 0
					BEGIN
						SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Shipping. '
						SET @v_nLogErrorNum = @e_GenSqlError

						GOTO ErrorHandler
					END

				-- Insert dependencies
				INSERT t_work_q_dependency (parent_work_q_id, dependent_work_q_id, status, dependency_type, wh_id)
				SELECT (@n_StartWKQ + 1), @n_FinishWKQ, 'ACTIVE' , 'FS' , @in_vchWarehouseId

				SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
				-- Check for any errors. If so, error number will not be equal to zero.
				IF @v_nErrorNumber <> 0
					BEGIN
						SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
							'the exact nature of the error.'
						SET @v_nLogErrorNum = @e_GenSqlError
						GOTO ErrorHandler
					END

				UPDATE t_work_q 
				SET work_status = 'H'
				WHERE work_q_id in (SELECT dependent_work_q_id 
						FROM t_work_q_dependency
						WHERE dependency_type = 'FS')

				SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
				-- Check for any errors. If so, error number will not be equal to zero.
				IF @v_nErrorNumber <> 0
					BEGIN
						SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
							'the exact nature of the error.'
						SET @v_nLogErrorNum = @e_GenSqlError
						GOTO ErrorHandler
					END

				-- Tie the waved released pick details to the load - currently splitting of order across load is not supported
				UPDATE t_pick_detail 
				   SET load_id = @in_vchLoadId
				  FROM t_pick_detail pkd INNER JOIN 
					   t_afa_load_detail ald
					on pkd.order_number = ald.order_number 
				   AND pkd.wh_id = ald.wh_id
				 WHERE ald.load_id = @in_vchLoadId
				   AND ald.wh_id = @in_vchWarehouseId

				SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
				-- Check for any errors. If so, error number will not be equal to zero.
				IF @v_nErrorNumber <> 0
					BEGIN
						SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
							'the exact nature of the error.'
						SET @v_nLogErrorNum = @e_GenSqlError
						GOTO ErrorHandler
					END

				-- Update load record with passed in values
				-- If LatestShipDate < EarliestShipDate, then write a NULL for LatestShipDate
				IF (@in_dtLatestShipDate < @in_dtEarliestShipDate)
					SET @v_dtLatestShipDate = NULL
				ELSE 
					SET @v_dtLatestShipDate = @in_dtLatestShipDate

				BEGIN
					UPDATE t_load_master
					SET status = @c_chReleaseStatus, 
					  earliest_ship_date = @in_dtEarliestShipDate,
					  latest_ship_date = @v_dtLatestShipDate
					WHERE wh_id = @in_vchWarehouseId
						AND load_id = @in_vchLoadId
				END

				SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
				IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
				BEGIN
					SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
							'the exact nature of the error.'
					SET @v_nLogErrorNum = @e_GenSqlError
					GOTO ErrorHandler	
				END

			COMMIT TRAN
			GOTO ExitLabel
		END
-- End --IF AFA is Installed and profile is 4 for "Wave then Load"

    	EXECUTE usp_afa_release_shipment 
    	@in_vchWarehouseId,    
		@in_vchLoadId,
		@in_vchPriority,
		@in_nWorkersRequired,
		@in_dtEarliestShipDate,
		@in_dtLatestShipDate,
		@v_vchErrorMsg OUTPUT
	
    	SELECT @v_nSysErrorNum = @@ERROR
    	IF @v_nSysErrorNum <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            	+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        	SET @v_nLogErrorNum = @e_GenSqlError
        	GOTO ErrorHandler
    	END
    	

    	IF @in_OverrideWorkType IS NOT NULL AND @in_OverrideWorkType <> '00'
    	BEGIN
    		EXECUTE usp_release_override_wk_type
			@in_OrderNumber =NULL,
			@in_LoadNumber = @in_vchLoadId, 
			@in_WaveNumber = NULL,
            @in_ItemNumber = NULL,
			@in_LotNumber = NULL,			
			@in_PickArea	= NULL,   
			@in_vchType = NULL, 
			@in_WHID = @in_vchWarehouseId,
			@in_OverrideWorkType = @in_OverrideWorkType,
			@in_nResultsFlag = 0
		
		SELECT @v_nSysErrorNum = @@ERROR
    		IF @v_nSysErrorNum <> 0
    		BEGIN
        		SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            		+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        		SET @v_nLogErrorNum = @e_GenSqlError
        		GOTO ErrorHandler
    		END
    	END 
    	
		GOTO ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        --EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(VARCHAR(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END
    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_vchStartTran = 1
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN
