

CREATE FUNCTION [dbo].[csf_get_convert_uom_desc]
(
    @in_item_number    NVARCHAR(30),
	@in_wh_id           NVARCHAR(50),
	@in_att		BIGINT
)
RETURNS NVARCHAR(100)
AS
BEGIN
    DECLARE @uom_desc NVARCHAR(50)
	DECLARE @pack_flag NVARCHAR(10)
	DECLARE @ship_uom NVARCHAR(50)

	SELECT @pack_flag =  pack_flag ,
	       @ship_uom=ship_uom
	  from dbo.t_item_master with(nolock)
	 WHERE item_number = @in_item_number 
	   AND wh_id =@in_wh_id
    
	IF  @in_att IS NOT NULL
	BEGIN

		SELECT  @uom_desc = td.uom_prompt
		from  t_item_uom td with(nolock)
		INNER JOIN t_sto_attrib_collection_detail te ON 
		   td.uom_prompt = te.attribute_value
		 where te.stored_attribute_id =@in_att
		  AND td.item_number = @in_item_number
		  AND td.wh_id = @in_wh_id

	END

	ELSE
	 BEGIN

	  IF  ISNULL(@pack_flag,N'N') =N'N' AND EXISTS( SELECT 1 FROM dbo.t_item_uom WHERE item_number=@in_item_number AND wh_id=@in_wh_id
	 AND uom=@ship_uom )
	  BEGIN
	    SELECT @uom_desc = uom_prompt
		  from dbo.t_item_uom with(nolock)
		 WHERE item_number = @in_item_number
		   AND wh_id = @in_wh_id
		   AND uom = @ship_uom
	  END 
     ELSE
	 BEGIN
	  SELECT @uom_desc =uom_prompt
	  FROM dbo.t_item_uom with(nolock)
	  WHERE item_number = @in_item_number
	  AND wh_id =@in_wh_id
	  AND conversion_factor =1
	  AND status = N'ACTIVE'

	 END


     END
	 
	
          
    RETURN @uom_desc

END

