-- =============================================
-- Author:		Laver
-- Create date: 2013-12-23
-- Description:	Cancel order by order_number,wh_id
-- =============================================
CREATE PROCEDURE [dbo].[csp_Cancel_Ord] 
	@In_Nvch_Wh_ID				AS	NVARCHAR(10),
	@In_Nvch_Ord_Number			AS	NVARCHAR(30),
	@Out_Nvch_Exe_Code			AS	NVARCHAR(3)	OUTPUT			-- Success:		000
																-- Shipping:	001
																-- Pick & Rls:	002
																-- Sp Error:	003
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Define local var
	DECLARE @Int_Rec_Cnt			AS	INT
	DECLARE @Nvch_Ord_Status		AS	NVARCHAR(20)
	DECLARE @Nvch_Sts_New			AS	NVARCHAR(3) = 'NEW'
	DECLARE @Nvch_Sts_Wave			AS	NVARCHAR(5) = 'WAVED'
	DECLARE @Nvch_Sts_Cancel		AS	NVARCHAR(9) = 'CANCELLED'
	DECLARE @Nvch_Sts_Pack			AS	NVARCHAR(6) = 'PACKED'
	DECLARE @Nvch_Sts_Load			AS	NVARCHAR(6) = 'LOADED'
	DECLARE @Nvch_Sts_Ship			AS	NVARCHAR(6) = 'SHIPPED'
	--select distinct status from t_order
	BEGIN TRY
		-- get the status of order
		SELECT @Nvch_Ord_Status = status 
		  FROM t_order 
		 WHERE wh_id = @In_Nvch_Wh_ID 
		   AND order_number = @In_Nvch_Ord_Number
		
		IF (ISNULL(@Nvch_Ord_Status,'') = '')
		BEGIN
			-- ORDER IS NOT EXISTS
			SET @Out_Nvch_Exe_Code = 004
			RETURN
		END

		BEGIN TRANSACTION
		
		-- status = new
		IF (@Nvch_Ord_Status = @Nvch_Sts_New)
		BEGIN
			-- Cancel Order
			UPDATE t_order
			   SET status = @Nvch_Sts_Cancel
			 WHERE wh_id = @In_Nvch_Wh_ID
			   AND order_number = @In_Nvch_Ord_Number

			SET @Out_Nvch_Exe_Code = '000'
		END
		ELSE IF (@Nvch_Ord_Status = @Nvch_Sts_Wave) -- order was waved
		BEGIN
			-- Cancel Order
			UPDATE t_order
			   SET status = @Nvch_Sts_Cancel
			 WHERE wh_id = @In_Nvch_Wh_ID
			   AND order_number = @In_Nvch_Ord_Number

			DELETE FROM t_afo_wave_detail_line
				WHERE wave_detail_id = (SELECT wave_detail_id 
										  FROM t_afo_wave_detail 
										 WHERE wh_id = @In_Nvch_Wh_ID
										   AND order_number = @In_Nvch_Ord_Number)

			DELETE FROM t_afo_wave_detail
				  WHERE wh_id = @In_Nvch_Wh_ID
					AND order_number = @In_Nvch_Ord_Number

			SET @Out_Nvch_Exe_Code = '000'
		END
		ELSE IF (@Nvch_Ord_Status in ('PACKED','LOADED','SHIPPED')) -- order is already shipping
		BEGIN
			SET @Out_Nvch_Exe_Code = '001'
		END
		ELSE	-- PICK OR RELEASE
		BEGIN
		--print @Nvch_Ord_Status + @Nvch_Sts_Pack + @Nvch_Sts_Load + @Nvch_Sts_Ship
			UPDATE t_order
			   SET cancel_flag = '1'
		     WHERE wh_id = @In_Nvch_Wh_ID
			   AND order_number = @In_Nvch_Ord_Number

			SET @Out_Nvch_Exe_Code = '002'
		END
		
		COMMIT

		RETURN
	END TRY

	BEGIN CATCH
		ROLLBACK
		SET @Out_Nvch_Exe_Code = '003'
		RETURN
	END CATCH
END
