





-- =======================================    
-- Author: will    
-- Create Date:03172016   
-- Description: update short status   
--  
    
-- =======================================    

CREATE PROCEDURE [dbo].[csp_short_pick_status_old]    
     @wh_id					NVARCHAR(10)  
	,@location_id           Nvarchar(30) 
	,@hu_id					Nvarchar(30)
    ,@pick_id               Nvarchar(30)
	,@passornot				nvarchar(1) output
	--,@ABC    Nvarchar(30)output
AS    
    
    -- SET NOCOUNT ON added to prevent extra result sets from      
BEGIN
    DECLARE @item_number  Nvarchar(30)
	DECLARE @wave_id      Nvarchar(30)
	DECLARE @order_number Nvarchar(30)
	DECLARE @qty          FLOAT

	SET @wave_id=''
	SET @item_number=''
	SET @passornot=1

	-----------------------找出波次--------------------
	--20160507 Updated by ty start
    --select @wave_id =wave_id ,@order_number=order_number from tbl_pick_list 
    --where wh_id=@wh_id and seq_id =cast(cast (@pick_id as decimal(9,2)) as int)
	
	select top 1 @wave_id =pkd.wave_id 
			,@order_number=pkd.order_number
	from t_stored_item sto
		 inner join t_pick_detail pkd on sto.wh_id = pkd.wh_id and sto.type = pkd.pick_id
	WHERE sto.wh_id = @wh_id
	and sto.hu_id = @hu_id
	--20160507 Updated by ty end
WHILE (1=1)
  BEGIN
 select top 1 @item_number=item.item_number from t_stored_item item
 where --item.hu_id=@hu_id
    isnull(item.hu_id,'')=isnull(@hu_id,'')    ------ Modified by Trevor on 20150412
    and item.location_id =@location_id  and item.wh_id=@wh_id 
 and item.item_number >@item_number order by item.item_number

  --IF(@item_number='')
  if @@ROWCOUNT =0
   break
	   
--select @qty=sum (isnull(actual_qty,0)) from t_stored_item where hu_id=@hu_id and wh_id=@wh_id and item_number=@item_number
select @qty=sum (isnull(actual_qty,0)) from t_stored_item where isnull(hu_id,'')=isnull(@hu_id,'') and wh_id=@wh_id and item_number=@item_number 
------ Modified by Trevor on 20150412

	 if exists (select 1 from tbl_allocation allo where allo.wave_id =@wave_id
	                                               and  allo.item_number =@item_number
												   and  allo.order_number=@order_number
												   and  allo.wh_id=@wh_id
												   and  allo.status<>'C'
												   and  allo.allo_type='O')
	     begin

				UPDATE t_pick_detail   SET loaded_quantity =loaded_quantity+@qty
				where order_number=@order_number and wh_id=@wh_id and item_number =@item_number 

		 end

		 else
		    begin

			UPDATE t_pick_detail  SET loaded_quantity =loaded_quantity+@qty ,status='LOADED' 
			where order_number=@order_number and wh_id=@wh_id and item_number =@item_number 

       -- IF NOT EXISTS (select 1 from tbl_allocation where wave_id=@wave_id and order_number =@order_number and status<>'C' and  allo_type='O') --del by tony 20160325
          IF NOT EXISTS (select 1 from tbl_allocation where wave_id=@wave_id and order_number =@order_number and status<>'C' and wh_id = @wh_id)  --add by tony 20160325
           BEGIN   
			  
			   --UPDATE t_order
      --         SET status = 'LOADED'
      --          WHERE EXISTS (SELECT 1 
      --                          FROM t_stored_item sto
      --                          inner join t_pick_detail pkd on sto.type = pkd.pick_id
      --                          WHERE sto.hu_id = @hu_id
      --                            AND sto.wh_id = @wh_id
      --                            AND pkd.wh_id = t_order.wh_id
      --                            and pkd.order_number = t_order.order_number)  
      --            and exists( select 1 from t_pick_detail pkd
      --                         where pkd.wh_id = t_order.wh_id
      --                         and pkd.order_number = t_order.order_number
      --                         -- and pkd.planned_quantity >pkd.loaded_quantity
      --                         and pkd.type = 'PP')
      --           and wh_id =  @wh_id
               If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') NOT IN('STAGED','LOADED') and a.order_number= @order_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
			      AND EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') ='STAGED' and a.order_number= @order_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
				  UPDATE t_order SET status = 'STAGED' where order_number= @order_number and wh_id=@wh_id
			    ELSE
				  BEGIN 
				    If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'')<>'LOADED' and a.order_number= @order_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
			        UPDATE t_order SET status = 'LOADED' where order_number= @order_number and wh_id=@wh_id
			      end
			   --------------- modified by Trevor on 20160326


	  --UPDATE t_order SET status = 'LOADED' where wh_id=@wh_id and order_number =@order_number 

		    END
			end
        
  END
END
  
  
    









