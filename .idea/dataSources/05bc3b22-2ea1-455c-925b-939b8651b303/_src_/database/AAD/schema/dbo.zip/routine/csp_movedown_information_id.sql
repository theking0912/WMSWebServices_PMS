

CREATE PROCEDURE [dbo].[csp_movedown_information_id]
   @in_Information_Collection_ID INT
 , @in_Information_ID  INT
AS
DECLARE 
   @n_Seq     INT
 , @n_SeqMax  INT
 , @n_SeqDown INT
 , @n_InforID  INT

SET NOCOUNT ON

SELECT @n_SeqMax = COALESCE(MAX(sequence_id), 0) 
FROM tbl_information_collection_detail
WHERE 
     information_collection_id = @in_Information_Collection_ID

SELECT @n_Seq = Coalesce(sequence_id,0)
FROM tbl_information_collection_detail
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @in_Information_ID

IF @n_Seq = @n_SeqMax GOTO ExitLabel;

SET @n_SeqDown = @n_Seq+1

SELECT @n_InforID = information_id
FROM tbl_information_collection_detail
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND sequence_id = @n_SeqDown

UPDATE tbl_information_collection_detail 
  SET sequence_id = @n_SeqDown
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @in_Information_ID

UPDATE tbl_information_collection_detail 
  SET sequence_id = @n_Seq
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @n_InforID

ExitLabel:
    RETURN
