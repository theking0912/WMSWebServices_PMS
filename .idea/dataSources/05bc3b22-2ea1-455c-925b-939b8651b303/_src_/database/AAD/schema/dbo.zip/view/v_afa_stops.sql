
CREATE VIEW dbo.v_afa_stops
AS
SELECT
    s.wh_id,
    s.load_id,
    s.stop_id,
    s.stop_sequence,
    s.earliest_delivery_date,
    s.latest_delivery_date,
    s.actual_delivery_date,
    s.ship_to_name,
    s.ship_to_addr1,
    s.ship_to_addr2,
    s.ship_to_addr3,
    s.ship_to_city,
    s.ship_to_state,
    s.ship_to_zip,
    s.ship_to_phone,
    s.ship_to_country_code,
    s.ship_to_country_name,
    CASE
        WHEN
            UPPER(
                RTRIM(ISNULL(s.ship_to_name, '')) +
                RTRIM(ISNULL(s.ship_to_addr1, '')) +
                RTRIM(ISNULL(s.ship_to_addr2, '')) +
                RTRIM(ISNULL(s.ship_to_addr3, '')) +
                RTRIM(ISNULL(s.ship_to_city, '')) +
                RTRIM(ISNULL(s.ship_to_state, '')) +
                RTRIM(ISNULL(s.ship_to_zip, ''))
            )
            =
            UPPER(
                RTRIM(ISNULL(s.delivery_name, '')) +
                RTRIM(ISNULL(s.delivery_addr1, '')) +
                RTRIM(ISNULL(s.delivery_addr2, '')) +
                RTRIM(ISNULL(s.delivery_addr3, '')) +
                RTRIM(ISNULL(s.delivery_city, '')) +
                RTRIM(ISNULL(s.delivery_state, '')) +
                RTRIM(ISNULL(s.delivery_zip, ''))
            )
        THEN 'N'
        ELSE 'Y'
    END
        AS pool_point_delivery,
    s.delivery_name,
    s.delivery_addr1,
    s.delivery_addr2,
    s.delivery_addr3,
    s.delivery_city,
    s.delivery_state,
    s.delivery_zip,
    s.delivery_phone,
    s.delivery_country_code,
    s.delivery_country_name,
    s.special_instructions,
    s.received_by,
    s.tracking_request_pending,
    s.tracking_request_date,
    s.tracking_response_date,
    s.tracking_updated_by,
    s.pod_request_pending,
    s.pod_request_date,
    s.pod_response_date,
    s.pod_updated_by,
    s.pod_attachment_mime_type,
    s.pod_attachment_filename,
    s.pod_attachment,
    vline.num_lines,
    vagg.num_orders,
    vagg.num_items,
    vagg.total_weight,
    vagg.total_cube,
    vagg.num_pallets,
    vagg.haz_material
FROM
    t_stop s
INNER JOIN
    v_afa_stop_line_count vline
    ON
        s.stop_id = vline.stop_id
INNER JOIN
    v_afa_stop_aggregates vagg
    ON
        s.stop_id = vagg.stop_id

