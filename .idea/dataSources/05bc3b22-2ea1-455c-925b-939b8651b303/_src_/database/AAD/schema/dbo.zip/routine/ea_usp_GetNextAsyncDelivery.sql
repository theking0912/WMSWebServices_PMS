
CREATE PROCEDURE dbo.ea_usp_GetNextAsyncDelivery
    @in_nMaxRetries     INTEGER,
    @out_vchEventId     VARCHAR(36) OUTPUT,
    @out_nRetryCount    INTEGER     OUTPUT
AS
DECLARE
    @v_nEventId BIGINT

    -- The following is necessary when using ADO Recordsets
    SET NOCOUNT ON

    -- within a transaction, get the next event ID
    BEGIN TRAN

        SELECT TOP 1 @v_nEventId = event_id, @out_nRetryCount = retry_count
          FROM ea_t_async_work_queue
          WITH (UPDLOCK)
         WHERE retry_count < @in_nMaxRetries
           AND date_added <= GETDATE()
           AND date_started IS NULL
           AND status IN ('NEW', 'RETRY')
           AND event_class IN ('Email', 'File', 'HTTP', 'FTP', 'Voice', 'APager')
      ORDER BY priority, date_added

    IF @@ROWCOUNT = 1
    BEGIN
        -- update the record so it doesn't get selected again
        UPDATE ea_t_async_work_queue
           SET date_started = GETDATE()
         WHERE event_id = @v_nEventId
        SET @out_vchEventId = CONVERT(VARCHAR(36), @v_nEventId)
    END

    -- and release our lock on the table by committing the transaction
    COMMIT TRAN
