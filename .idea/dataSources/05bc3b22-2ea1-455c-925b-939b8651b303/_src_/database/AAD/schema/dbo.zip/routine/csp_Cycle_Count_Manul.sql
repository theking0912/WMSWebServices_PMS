




-- ======================================    
-- Author: JERRY.Ming   
-- Create Date: 09.2014   
-- Description: Insert Cycle Count Manul
--  
-- =======================================    
CREATE PROCEDURE [dbo].[csp_Cycle_Count_Manul] @wh_id NVARCHAR(10)
	,@location_id NVARCHAR(50)
	,@item_number NVARCHAR(30)
	,@type BIGINT
	,@hu_id NVARCHAR(22)
	,@lot_number NVARCHAR(15)
	,@stored_attribute_id NVARCHAR(15)
	--,@actual_qty            nvarchar(30)
	,@actual_qty FLOAT
	,@user_id NVARCHAR(30)
	--,@in_dtExpirationDate   DATE
	,@in_dtExpirationDate NVARCHAR(30)
	,@conversion_factor NVARCHAR(30)
	--,@stored_qty			nvarchar(30)
	,@stored_qty FLOAT
	,@new_flag NVARCHAR(1)
	--,@vendor_code           NVARCHAR(10)----------------------will  add
	,@passornot NVARCHAR(2) OUTPUT --0 pass|1 fail
	,@msg NVARCHAR(200) OUTPUT
AS
DECLARE @inv_qty INT
	,@discrepancy_flag NVARCHAR(1)
	,--0 same|1 diffient
	@sysdate DATETIME
	,@local_id NVARCHAR(50)
	,@SQL1 NVARCHAR(1000)
	,@SQL2 NVARCHAR(1000)
	,@work_q_id NVARCHAR(30)
	,@v_nReturn INT
	,@v_nErrorNumber INT
	,@v_vchErrorMsg NVARCHAR(1000)
	,@expiration_date DATE
	,@shelf_life INT
	,@v_expir_date DATE
	,@v_count INT
	,@v_hu_flag NVARCHAR(2)
	,@expire_control_flag NVARCHAR(2)
	,@aa NVARCHAR(10)
	,@loc_type NVARCHAR(10)
	,@flag NVARCHAR(2) --E

--@passornot				nvarchar(2),
--@msg					nvarchar(200)
SET @discrepancy_flag = N'0'
SET @sysdate = getdate()
SET @local_id = @location_id
SET @passornot = 0
SET @inv_qty = 0
SET @flag = 0 --E

--SET @lot_number=@lot_number+@vendor_code-------------------will   add
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from    
	SET NOCOUNT ON;
	SET ANSI_NULLS OFF

	---initial log by E---
	INSERT INTO [dbo].[tbl_cyclecount_history_log]
				   ([wh_id]
				   ,[work_q_id]
				   ,[location_id]
				   ,[sys_hu_id]
				   ,[sys_item_number]
				   ,[sys_lot_number]
				   ,[sys_stored_attribute_id]
				   ,[sys_qty]
				   ,[count_qty]
				   ,[discrepancy_type]
				   ,[counted_date]
				   ,[counted_by]
				   ,[expiration_date] 
				   ,[flag])
			 VALUES
				   (@wh_id
				   ,@work_q_id
				   ,@location_id
				   ,@hu_id
				   ,@item_number
				   ,@lot_number
				   ,@stored_attribute_id
				   ,@inv_qty
				   ,@actual_qty+@inv_qty
				   ,@discrepancy_flag
				   ,@sysdate
				   ,@user_id
				   ,@in_dtExpirationDate
				   ,@flag
				   )
				   
	BEGIN TRY
		SELECT @location_id = location_id
			,@v_hu_flag = item_hu_indicator
			,@loc_type = type
		FROM dbo.t_location
		WHERE location_id = @location_id
			AND wh_id = @wh_id

		SELECT @v_count = @@ROWCOUNT

---update flag = 1
		update tbl_cyclecount_history_log set flag = '1' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '0'

		IF ISNULL(@v_count, 0) = 0
		BEGIN
			SET @msg = '货位不存在'

			RAISERROR (
					@msg
					,11
					,1
					)
		END

---update flag = 2
		update tbl_cyclecount_history_log set flag = '2' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '1'

		--IF @loc_type NOT IN('I','M') 
		--BEGIN
		-- SET @msg ='货位不是存储货位'
		-- RAISERROR(@msg,11,1)
		--	END
		IF CAST(@actual_qty * @conversion_factor AS INT) <> @actual_qty * @conversion_factor
		BEGIN
			SET @msg = '盘点数量不能为小数'

			RAISERROR (
					@msg
					,11
					,1
					)
		END

---update flag = 3
		update tbl_cyclecount_history_log set flag = '3' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '2'

		IF ISNULL(@v_hu_flag, '') = 'H'
			AND ISNULL(@hu_id, '') = ''
		BEGIN
			SET @msg = '托盘管理的货位，托盘不能为空'

			RAISERROR (
					@msg
					,11
					,1
					)
		END

---update flag = 4
		update tbl_cyclecount_history_log set flag = '4' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '3'

		IF EXISTS (
				SELECT 1
				FROM dbo.t_hu_master
				WHERE location_id <> @location_id
					AND hu_id = @hu_id
				)
			and @hu_id <> ''
		BEGIN
			SET @msg = '该托盘被其他货位占用'

			RAISERROR (
					@msg
					,11
					,1
					)
		END

---update flag = 5
		update tbl_cyclecount_history_log set flag = '5' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '4'

		IF EXISTS (
				SELECT 1
				FROM dbo.tbl_cyclecount_history
				WHERE location_id <> @location_id
					AND sys_hu_id = @hu_id
					AND ISNULL(close_sign, 'N') = 'N'
				)
		BEGIN
			SET @msg = '该托盘在盘点任务中被其他货位使用'

			RAISERROR (
					@msg
					,11
					,1
					)
		END

---update flag = 6
		update tbl_cyclecount_history_log set flag = '6' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '5'

		--gaoym 限制托盘编号
		IF isnull(@v_hu_flag, '') = 'H'
			AND @hu_id IS NOT NULL
		BEGIN
			EXEC @aa = fn_Check_ToteAndPlateNo 'LP'
				,@hu_id

			IF @aa <> '0'
			BEGIN
				SET @msg = '托盘编号错误'

				RAISERROR (
						@msg
						,11
						,1
						)
			END
		END

---update flag = 7
		update tbl_cyclecount_history_log set flag = '7' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '6'

		--end
		IF ISNULL(@v_hu_flag, '') <> 'H'
			AND ISNULL(@hu_id, '') <> ''
		BEGIN
			SET @msg = '非托盘管理的货位，不能有托盘'

			RAISERROR (
					@msg
					,11
					,1
					)
		END

---update flag=1 failed 
		update tbl_cyclecount_history_log set flag = '1' 
		where location_id = @location_id 
		   and sys_item_number = @item_number
		   and sys_lot_number = @lot_number
		   and flag = '0'


		IF ISNULL(@stored_qty, 0) <> ISNULL(@actual_qty, 0)
		BEGIN
			IF @new_flag = 'Y'
			BEGIN
				SELECT @shelf_life = shelf_life
					,@expire_control_flag = expiration_date_control
				FROM t_item_master
				WHERE wh_id = @wh_id
					AND item_number = @item_number

				IF @expire_control_flag = 'Y'
				BEGIN
					IF (
							@in_dtExpirationDate IS NULL
							OR @in_dtExpirationDate > GETDATE()
							)
					BEGIN
						SET @msg = '生产日期错误'

						RAISERROR (
								@msg
								,11
								,1
								)
					END

					SELECT @v_expir_date = convert(DATE, @in_dtExpirationDate)

					--select @v_expir_date= @in_dtExpirationDate
					SET @lot_number = convert(NVARCHAR(20), @v_expir_date, 112)
					--  set @lot_number=@lot_number+@vendor_code-------------------will   add
					SET @expiration_date = DATEADD(DAY, @shelf_life, @v_expir_date)
				END
				ELSE
				BEGIN
					SET @expiration_date = NULL
					SET @lot_number = NULL
				END
			END
			ELSE
			BEGIN
				SET @expiration_date = @in_dtExpirationDate
			END

			--SET @inv_qty = (convert(float,@actual_qty)-convert(float,@stored_qty))*convert(float,@conversion_factor)
			SET @inv_qty = (@actual_qty - @stored_qty) * @conversion_factor

			IF @stored_attribute_id = ''
			BEGIN
				SET @stored_attribute_id = NULL
			END

			IF @hu_id = ''
			BEGIN
				SET @hu_id = NULL
			END

			IF @lot_number = ''
			BEGIN
				SET @lot_number = NULL
			END

			--Generate the work_q_id
			EXECUTE @v_nReturn = usp_get_next_value 'WORK_Q_ID'
				,@work_q_id OUTPUT
				,@v_nErrorNumber OUTPUT
				,@v_vchErrorMsg OUTPUT


			--Generate the dismatch count
			EXECUTE @v_nReturn = csp_Cycle_Count_Insert @wh_id
				,@location_id
				,@item_number
				,@type
				,@hu_id
				,@lot_number
				,@stored_attribute_id
				,@inv_qty
				,@work_q_id
				,@user_id
				,@expiration_date
				--,@vendor_code 
				,@passornot
				,@msg

			SET @msg = '保存成功'

		END
		ELSE
			SET @msg = 'NO Quantity Change'
	END TRY

	BEGIN CATCH
		SET NOCOUNT OFF
		SET @passornot = 1

		RETURN
	END CATCH
END




