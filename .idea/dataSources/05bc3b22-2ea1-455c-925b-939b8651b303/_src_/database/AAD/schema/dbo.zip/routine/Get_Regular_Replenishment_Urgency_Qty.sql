




-- =======================================    
-- Author: will.xu
-- Create Date: 02 15 2016    

--  
    
-- =======================================    


    
CREATE   PROCEDURE [dbo].[Get_Regular_Replenishment_Urgency_Qty]    
     @wh_id					NVARCHAR(10)
	,@inputqty              INT      -----输入数量
	,@sort_location			NVARCHAR(30) ----补货库位
	,@item_number			NVARCHAR(30)  ------补货商品	
	,@qty					INT         -------补货数量
	,@work_q_id             INT
	,@outqty                INT             output
	,@passornot				NVARCHAR(1)		output
AS    
set @passornot=0
IF (@inputqty=@qty)
begin
set @outqty=0
UPDATE t_work_q 
SET work_status = (CASE WHEN  qty =@inputqty THEN 'C' ELSE work_status END)
WHERE wh_id=@wh_id 
and item_number =@item_number
and location_id =@sort_location 
and work_q_id = @work_q_id
and work_status='A'
and work_type = '06' 
if(@@ROWCOUNT <=0)
begin
set @passornot=1
end
end
else 
begin
   set @outqty=@inputqty
end



