






-- =======================================    
-- Author: will.xu
-- Create Date: 02 19 2016       
-- =======================================    
    
CREATE PROCEDURE [dbo].[Get Stored Attribute ID_NBO]    

	 @current_qty_per_case            NVARCHAR(30)
	,@BOXNext_value				INT		output
AS   
BEGIN 
if not exists (select 1 from t_attribute_values where attribute_value = @current_qty_per_case)
			begin
				insert into  t_sto_attrib_collection_master( attribute_collection_id, detail_checksum, create_date)
				values(1,'375474944',GETDATE())
			    
				select @BOXNext_value=max(stored_attribute_id) from t_sto_attrib_collection_master
				
				insert into t_attribute_type( attribute_type, description, import_validation, lookup_validation, create_date, modified_date, prompt_validation, allow_mix)
				values(@BOXNext_value, null, 'N', 'N', GETDATE(), GETDATE(), 'D', 'Y')	
				
				select @BOXNext_value = max(attribute_id) from t_attribute_type
				
				insert into t_attribute_values (attribute_id, attribute_value) 
				values(@BOXNext_value,@current_qty_per_case)
				
			end
			else
			begin
			select top 1 @BOXNext_value = attribute_id from t_attribute_values 
			where attribute_value = @current_qty_per_case
			end

END

    










