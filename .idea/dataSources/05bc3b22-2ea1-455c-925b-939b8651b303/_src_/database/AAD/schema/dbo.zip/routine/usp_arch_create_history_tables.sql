
CREATE PROCEDURE usp_arch_create_history_tables
    
AS
DECLARE 
      @vHTable                 NVARCHAR(100),
      @vSchema                 NVARCHAR(15),
      @vHTabPrefix             NVARCHAR(10),
      @vHTabSuffix             NVARCHAR(10),
      @vLongStrDDL             NVARCHAR(4000),
      @vTableColumns           NVARCHAR(4000),
      @vSeq                    INTEGER,
      @Number_Failed           INTEGER,
      @Number_Processed        INTEGER,

      --Error treatment variables
      @v_vchParam1             NVARCHAR(100),
      @v_nRaiseErrorNumber     INTEGER,
      @v_nError                INTEGER,
      @vSQLErr                 NVARCHAR(400),


      --Variables to interact with table t_arch_backup_control
      @bc_id                   INTEGER,
      @bc_backup_control_id    INTEGER,
      @bc_table_name           NVARCHAR(100),
      @bc_control_type         NVARCHAR(2),
      @bc_where_clause         NVARCHAR (2000),
      @bc_last_processed_date  DATETIME ,
      @bc_status               NCHAR(1),
      @bc_hist_table_prefix    NVARCHAR (10),
      @bc_hist_table_suffix    NVARCHAR (10),
      @bc_table_schema         NVARCHAR(15),
      @bc_elapsed_time         NVARCHAR(26),
      @bc_last_exec_message    NVARCHAR(400),
      @bc_exec_frequency       INTEGER,
      @bc_stored_procedure     NVARCHAR(100),
      @bc_hist_database        NVARCHAR(10)
     
BEGIN 

       IF NOT EXISTS(SELECT * FROM t_arch_backup_control WHERE control_type = 'CT')
          BEGIN
            SELECT '0 Archiving tasks were processed. 0 failed.' as out_vchMessage
            GOTO ExitLabel
          END
       SET @Number_Processed = 0
 
           DECLARE cur_bc_tab CURSOR FOR 
            SELECT id,
                   backup_control_id,
                   table_name,
                   control_type,
                   where_clause,
                   last_processed_date,
                   status,
                   hist_table_prefix,
                   hist_table_suffix,
                   table_schema,
                   elapsed_time,
                   last_exec_message,
                   exec_frequency,
                   stored_procedure,
                   hist_database
              FROM t_arch_backup_control
             WHERE control_type = 'CT'
             ORDER BY id


          OPEN cur_bc_tab


          FETCH NEXT FROM cur_bc_tab 
          INTO @bc_id,
               @bc_backup_control_id,
               @bc_table_name,
               @bc_control_type,
               @bc_where_clause,
               @bc_last_processed_date,
               @bc_status,
               @bc_hist_table_prefix,
               @bc_hist_table_suffix,
               @bc_table_schema,
               @bc_elapsed_time,
               @bc_last_exec_message,
               @bc_exec_frequency,
               @bc_stored_procedure,
               @bc_hist_database


          WHILE @@FETCH_STATUS = 0
             BEGIN

               SET @Number_Processed = @Number_Processed + 1

               EXEC usp_arch_process_ctype_ct @bc_table_name, @bc_id
               
               -- Get the next column.
               FETCH NEXT FROM cur_bc_tab 
               INTO @bc_id,
                    @bc_backup_control_id,
                    @bc_table_name,
                    @bc_control_type,
                    @bc_where_clause,
                    @bc_last_processed_date,
                    @bc_status,
                    @bc_hist_table_prefix,
                    @bc_hist_table_suffix,
                    @bc_table_schema,
                    @bc_elapsed_time,
                    @bc_last_exec_message,
                    @bc_exec_frequency,
                    @bc_stored_procedure,
                    @bc_hist_database
           END

 
      CLOSE cur_bc_tab
      DEALLOCATE cur_bc_tab

      SELECT @Number_Failed = COUNT(*) 
      FROM t_arch_backup_control 
      WHERE control_type = 'CT' AND status = 'F'

      SELECT CONVERT(VARCHAR(10),@Number_Processed) + 
             ' Archiving tasks were processed.' + 
             CONVERT(VARCHAR(10),@Number_Failed) + ' failed.' as out_vchMessage 


GOTO ExitLabel

ErrorHandler:



ExitLabel:
--RETURN
END 

