

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Create_Print_Task] 
	-- Add the parameters for the stored procedure here
	@in_wh_id				AS	NVARCHAR(20),
	@in_station				AS	NVARCHAR(30),
	@in_print_type			AS	NVARCHAR(30),
	@in_key1				AS	NVARCHAR(30),
	@in_key2				AS	NVARCHAR(30),
	@in_key3				AS	NVARCHAR(30),
	@in_user				AS	NVARCHAR(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--copies
	DECLARE		@print_data		NVARCHAR(100) = '1|'

	SET @print_data = @print_data + @in_wh_id

	IF	ISNULL(@in_key1,'') <> ''
	BEGIN
		SET @print_data = @print_data + '|' + @in_key1
	END

	IF	ISNULL(@in_key2,'') <> ''
	BEGIN
		SET @print_data = @print_data + '|' + @in_key2
	END

	IF	ISNULL(@in_key3,'') <> ''
	BEGIN
		SET @print_data = @print_data + '|' + @in_key3
	END

	 

    INSERT INTO [dbo].[tbl_print_scheduler]
           ([print_type]
           ,[print_station]
           ,[wh_id]
           ,[print_data]
           ,[print_date]
           ,[print_user]
           ,[print_status]
           ,[carrier_code])
     VALUES
           (@in_print_type
           ,@in_station
           ,@in_wh_id
           ,@print_data
           ,GETDATE()
           ,@in_user
           ,'U'
           ,@in_print_type)
END

