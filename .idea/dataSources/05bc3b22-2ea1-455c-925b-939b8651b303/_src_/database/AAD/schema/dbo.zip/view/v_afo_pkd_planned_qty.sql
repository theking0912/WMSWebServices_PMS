
CREATE VIEW v_afo_pkd_planned_qty
AS
SELECT SUM(planned_quantity) AS pkd_planned, order_number, line_number, wave_id, wh_id, item_number
	FROM t_pick_detail 
	GROUP BY wh_id, order_number, wave_id, line_number, item_number


