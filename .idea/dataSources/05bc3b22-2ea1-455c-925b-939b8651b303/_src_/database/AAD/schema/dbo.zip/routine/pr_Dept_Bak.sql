





CREATE procedure [dbo].[pr_Dept_Bak]
@date_end varchar(100)

as

begin

---这里可以增加对数据表的查询条件或更多的数据处理；

---将结果放入一个新的数据表，然后将这个新表导出EXCEL文件；

declare @file_path varchar(200);--导出EXCEl文件的路径；

declare @file_name varchar(200);--导出EXCEl的文件名；

declare @exec_sql  varchar(8000);--SQL语句；

---分开定义是为了以后修改路径或文件名更方便。

set @file_path = 'D:\Dept_Bak\'

set @file_name = 't_lookup' + REPLACE(CONVERT(CHAR(19), GETDATE(), 120), ':', '') +'.xls'


set @exec_sql = 'SELECT o.wh_id, 
wa.wave_id, 
list.list_number, 
ord.earliest_ship_date, 
o.order_number, 
ISNULL(dbo.csf_get_lookup( ''t_pick_detail'',''STATUS'', ''2052'', pd.status ),''新建'') as order_status,
lk1.description as description1, 
ISNULL(cus.short_name,cus.customer_name) AS customer_name, 
o.line_number ,
o.cancel_flag, 
o.item_number , 
im.description , 
ta.lot_number, 
o.qty,
(ISNULL(ta.allocated_qty,pd.planned_quantity) / ( SELECT conversion_factor FROM dbo.t_item_uom with(nolock) WHERE uom = o.order_uom AND item_number = o.item_number ) ) AS order_alloqty ,
(ISNULL( ta.picked_qty,pd.picked_quantity) / ( SELECT  conversion_factor
FROM dbo.t_item_uom  with(nolock)
WHERE uom = o.order_uom
AND item_number = o.item_number
) ) AS order_pick ,
( isnull( ta.allocated_qty - ta.picked_qty,pd.planned_quantity-pd.picked_quantity )
/ ( SELECT    conversion_factor
FROM      dbo.t_item_uom with(nolock)
WHERE     uom = o.order_uom
AND item_number = o.item_number
) ) AS order_unpick ,
( SELECT    uom + ''-'' + uom_prompt
FROM      dbo.t_item_uom with(nolock)
WHERE     uom = o.order_uom
AND item_number = o.item_number
) AS order_uom ,
lk.description AS task_status ,
ta.zone ,
ta.location_id ,
ISNULL(ta.allocated_qty,pd.planned_quantity ) as allocated_qty,
ISNULL(ta.picked_qty,pd.picked_quantity) as picked_qty,
ISNULL(ta.allocated_qty - ta.picked_qty,pd.planned_quantity -pd.picked_quantity) AS unpicked_qty ,
( SELECT  top 1   uom + ''-'' + uom_prompt
FROM dbo.t_item_uom with(nolock)
WHERE conversion_factor = ''1''
AND item_number = o.item_number) AS UOM ,
ta.ref_number ,
ta.pick_wall_loc ,
ta.pick_wall_slot ,
ta.user_assign 
FROM t_order_detail_back_for_qc o WITH(NOLOCK) INNER JOIN
( dbo.t_order ord WITH(NOLOCK) left join t_lookup  lk1 on lk1.source = ''t_order''  AND lk1.lookup_type  = ''TYPE'' AND lk1.locale_id  = ''2052'' and lk1.lookup_id = ord.type_id)
ON o.order_number = ord.order_number AND o.wh_id = ord.wh_id
LEFT OUTER JOIN ( tbl_allocation_back_for_qc ta with(nolock)
INNER JOIN dbo.tbl_pick_list list with(nolock) ON ta.seq_id = list.seq_id
LEFT JOIN t_lookup lk 
ON lk.source = ''tbl_allocation''
AND lk.lookup_type = ''STATUS''
AND lk.text = ta.status
AND lk.locale_id = N''2052''
) ON ta.order_number = o.order_number
AND o.item_number = ta.item_number 
AND ta.line_number = o.line_number
LEFT OUTER JOIN dbo.t_pick_detail_back_for_qc  pd with(nolock)
ON o.order_number = pd.order_number
AND o.line_number = pd.line_number
AND o.item_number = pd.item_number
AND pd.type = ''PP''
LEFT OUTER JOIN dbo.t_afo_wave_detail wa with(nolock)
ON o.order_number = wa.order_number
and o.wh_id = wa.wh_id 
LEFT OUTER JOIN dbo.t_customer cus with(nolock)
ON ord.customer_id = cus.customer_id
and cus.wh_id = o.wh_id,    
t_item_master im with(nolock)
WHERE   o.wh_id = im.wh_id
AND o.item_number = im.item_number
--AND im.item_number = pd.item_number
AND o.item_number LIKE N''%%%''
AND im.description LIKE N''%%%''
AND o.wh_id LIKE N''HDLSH''
AND o.order_number LIKE ''%''
AND lk1.description LIKE ''%''		
AND ISNULL(wa.wave_id,'''') LIKE N''%''
AND  ISNULL(wa.wave_id,'''') like ''%''
AND ord.earliest_ship_date <= CAST(''' + @date_end + ''' AS DATE)
   AND (ISNULL(ta.status, '''') LIKE ''%'')
   AND (CASE
         WHEN ISNULL(pd.status, ''N'') LIKE ''SHIPPED'' THEN
          ''Y''
         ELSE
          ''N''
       END LIKE ''%'')
   AND (ISNULL(ta.zone, '''') LIKE ''%%'')
   AND (ISNULL(ta.lot_number, '''') LIKE ''%'')
 ORDER BY o.wh_id, o.order_number, o.line_number'---数据表使用的完整路径；

set  @exec_sql = ' bcp "'+@exec_sql+'" queryout "'+@file_path+''+@file_name+'" -c -T -U "sa" -P "HJSPASS#1" -d"AAD"';

----U "sa" -P "SQLpassword" 这是数据库的sa账号和密码；

exec master..xp_cmdshell @exec_sql

end





