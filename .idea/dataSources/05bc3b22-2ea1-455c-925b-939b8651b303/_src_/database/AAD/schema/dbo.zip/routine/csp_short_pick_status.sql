

-- =======================================    
-- Author: will    
-- Create Date:03172016   
-- Description: update short status   
--  
-- =======================================    
CREATE PROCEDURE [dbo].[csp_short_pick_status] @wh_id NVARCHAR(10)
	,@location_id NVARCHAR(30)
	,@hu_id NVARCHAR(30)
	,@pick_id NVARCHAR(30)
	,@passornot NVARCHAR(1) OUTPUT
AS   
BEGIN
	DECLARE @order_number NVARCHAR(30)
	SET @passornot = 1

	SET @order_number=''

	UPDATE t_pick_detail
	SET loaded_quantity = staged_quantity
		,status='LOADED'
	WHERE EXISTS (
			SELECT 1
			FROM t_stored_item
			WHERE t_stored_item.type = t_pick_detail.pick_id
				AND t_stored_item.wh_id = t_pick_detail.wh_id
				AND t_stored_item.hu_id = @hu_id
				AND t_stored_item.wh_id = @wh_id
			)
		AND status in ('PICKED','LOADED')  

-------------ADD BY WILL   20160706 S------------
		UPDATE t_pick_detail
	SET loaded_quantity = staged_quantity
	WHERE EXISTS (
			SELECT 1
			FROM t_stored_item
			WHERE t_stored_item.type = t_pick_detail.pick_id
				AND t_stored_item.wh_id = t_pick_detail.wh_id
				AND t_stored_item.hu_id = @hu_id
				AND t_stored_item.wh_id = @wh_id
			) 
      AND status ='RELEASED'
 -------------ADD BY WILL   20160706 N------------
		

	WHILE (1 = 1)
	BEGIN
		SELECT TOP 1 @order_number = pkd.order_number
		FROM t_stored_item sto
		INNER JOIN t_pick_detail pkd ON sto.wh_id = pkd.wh_id
			AND sto.type = pkd.pick_id
		WHERE sto.wh_id = @wh_id
			AND sto.hu_id = @hu_id
			AND pkd.order_number > @order_number
		ORDER BY pkd.order_number

		IF @@ROWCOUNT = 0
			BREAK

		IF NOT EXISTS (
				SELECT 1
				FROM t_order_detail a
				LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
					AND a.wh_id = b.wh_id
					AND a.line_number = b.line_number
					AND a.item_number = b.item_number
				WHERE isnull(b.status, '') not in ('STAGED','LOADED')
					AND a.order_number = @order_number
					AND a.wh_id = @wh_id
					AND isnull(b.work_type, '') = ''
				)
		BEGIN
			IF NOT EXISTS (
					SELECT 1
					FROM t_order_detail a
					LEFT JOIN t_pick_detail b ON a.order_number = b.order_number
						AND a.wh_id = b.wh_id
						AND a.line_number = b.line_number
						AND a.item_number = b.item_number
					WHERE isnull(b.status, '') not in ('LOADED')
						AND a.order_number = @order_number
						AND a.wh_id = @wh_id
						AND isnull(b.work_type, '') = ''
					)
			BEGIN
				UPDATE t_order
				SET status = 'LOADED'
				WHERE order_number = @order_number
					AND wh_id = @wh_id
			END
			ELSE
			BEGIN
				UPDATE t_order
				SET status = 'STAGED'
				WHERE order_number = @order_number
					AND wh_id = @wh_id
			END
		END
	END
END

