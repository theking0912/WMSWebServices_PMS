



-- =============================================
-- Author:		will
-- Create date: 2016-3-02 11:04:34
-- Description:判断紧急补货的拣货库位的type（PCB）
-- =============================================



CREATE PROCEDURE [dbo].[csp_check_urgency_location_B] 

   @wh_id         NVARCHAR(50)
  ,@zone          NVARCHAR(50)
  ,@item_number   NVARCHAR(50)
 -- ,@pick_location NVARCHAR(50) 
  --,@put_location  NVARCHAR(50) 
  ,@flag          INT     OUTPUT

AS
BEGIN
DECLARE @pick_loc_type   NVARCHAR(50)
DECLARE @put_loc_type   NVARCHAR(50)
DECLARE @i       INT
DECLARE @j       INT
set @pick_loc_type=''
set @put_loc_type=''
set @i=0
set @j=0
set @flag=0

--select @pick_loc_type =type from t_location where wh_id=@wh_id and location_id=@pick_location
--select @put_loc_type =type from t_location where wh_id=@wh_id and location_id=@pick_location

---------------------------------------------------判断P区---------------------------------------
--if((@pick_loc_type='P' OR @pick_loc_type='L' OR @pick_loc_type='H') AND @put_loc_type='C')
--begin
      select @i=COUNT(1) FROM t_work_q tq INNER JOIN tbl_allocation allo 
	  ON tq.wh_id=allo.wh_id
	  AND tq.item_number=allo.item_number
	  AND allo.pick_id=tq.pick_ref_number
	  INNER JOIN t_location loc
	  ON loc.wh_id=tq.wh_id AND loc.location_id =tq.location_id
	  INNER JOIN tbl_loc_item li ON li.wh_id =tq.wh_id 
	  AND li.item_number =tq.item_number 
	  AND li.location_id =tq.location_id
	  WHERE tq.work_type='06' AND tq.work_status='A' AND tq.wh_id=@wh_id AND tq.item_number=@item_number
	  AND allo.allo_type='R2' AND allo.status='A' AND allo.zone=@zone AND loc.type IN ('B','Z')
   
      if (@i>0)
	  begin
	      set @flag=1  ----------------商品绑定BC区且B区存在补货任务
	  end


--end




END





