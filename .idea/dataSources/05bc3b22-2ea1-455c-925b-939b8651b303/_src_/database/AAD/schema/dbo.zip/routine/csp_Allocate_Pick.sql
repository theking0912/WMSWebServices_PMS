


-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Return Receiving by LP   
--      
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Allocate_Pick]    
     @wh_id					NVARCHAR(10)  
    ,@pick_loc				NVARCHAR(30)  
	,@hu_id					NVARCHAR(30)
	,@item_number			NVARCHAR(30)
	,@lot_number			NVARCHAR(30)
	,@stored_attribute_id	NVARCHAR(30)
	,@qty					FLOAT
	,@put_loc				NVARCHAR(30)
	,@put_hu_id				NVARCHAR(30)			
	,@user_id				NVARCHAR(30)
	,@tran_type				NVARCHAR(20)
	,@tran_description		NVARCHAR(50)
	,@damage_flag			NVARCHAR(1)
	,@passornot				NVARCHAR(1)		OUTPUT
	,@msg					NVARCHAR(200)	OUTPUT
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @pick_id		bigint
		DECLARE @allocated_qty	float
		DECLARE @picked_qty		float
		DECLARE @seq_id			bigint
		DECLARE @remove_qty		float
		DECLARE @order_number	nvarchar(30)
		DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
		DECLARE @ref_number		nvarchar(30)
		DECLARE @shiping_label	nvarchar(30)
		-- Trim string 
		SET @put_hu_id = RTRIM(LTRIM(@put_hu_id))

		SET @remove_qty = @qty * -1
		BEGIN TRANSACTION
		--Get allocation information
		WHILE (@qty > 0)
			BEGIN
				SELECT top 1 @pick_id = pick_id
						,@allocated_qty = allocated_qty - picked_qty
						,@seq_id = seq_id
						,@order_number = order_number
						,@ref_number = ref_number
						,@shiping_label = shipping_label
				FROM tbl_allocation
				WHERE user_assign = @user_id
				and wh_id = @wh_id
				and location_id = @pick_loc
				and item_number = @item_number
				and  allocated_qty - picked_qty > 0
				order by pick_id
		
				IF @@ROWCOUNT = 0
					BEGIN
						BREAK
					END
				--check the multi-wall sku into 1 location Start
				IF EXISTS (SELECT 1 FROM t_hu_master
							WHERE wh_id = @wh_id
							AND hu_id = @put_hu_id)
					BEGIN
						IF EXISTS(SELECT 1 FROM t_hu_master
									WHERE wh_id = @wh_id
									AND hu_id = @put_hu_id
									AND control_number <> @ref_number)
							BEGIN
								SET @passornot = 1
								SET @msg = 'System Error:Invalid Slot'
								ROLLBACK
								RETURN 
							END
					END
				--check the multi-wall sku into 1 location End
			

				IF @qty <= @allocated_qty
					BEGIN
						SET @picked_qty= @qty
						SET @qty = 0
					END
				ELSE
					BEGIN
						SET @picked_qty= @allocated_qty
						SET @qty = @qty - @allocated_qty
					END

				--Updated t_pick_detail
				UPDATE t_pick_detail
				SET status = (CASE WHEN  picked_quantity + @picked_qty = planned_quantity
									THEN 'PICKED'
								ELSE status END)
					,picked_quantity = picked_quantity + @picked_qty
				WHERE pick_id = @pick_id

				--Update allocation information
				UPDATE tbl_allocation
				SET status = (CASE WHEN  picked_qty + @picked_qty = allocated_qty
									THEN 'C'
								ELSE 'U' END)
					,picked_qty = picked_qty + @picked_qty
				WHERE seq_id = @seq_id
				--update shipping label status = picked
				--IF ISNULL(@shiping_label,'') <> ''
				--	BEGIN
				--		UPDATE tbl_shipping_label
				--		SET status ='PICKED'
				--		WHERE wh_id = @wh_id
				--		and ship_label_barcode = @shiping_label
				--		and not exists ( select 1 from t_pick_detail pkd
				--						WHERE pkd.wh_id = @wh_id
				--						and pkd.order_number = tbl_shipping_label.order_number
				--						and pkd.planned_quantity > pkd.picked_quantity)
					--END
				--update t_order status
				UPDATE t_order
				SET status ='PICKED'
				   ,date_picked = getdate()
				WHERE wh_id = @wh_id
				and order_number = @order_number
				and not exists ( select 1 from t_pick_detail pkd
								 where pkd.wh_id = t_order.wh_id
								 and pkd.order_number = t_order.order_number
								 and pkd.planned_quantity <> pkd.picked_quantity
								 )
				--Move the stock to fork
				EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @put_loc,
						@in_nType = @pick_id,
						@in_vchHUID = @put_hu_id,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @stored_attribute_id,
						@in_fQty = @picked_qty,
						@in_dtFifoDate = NULL,
						@in_dtExpirationDate = NULL,
						@in_vchHUType = N'SO',
						@in_vchShipmentNumber =@ref_number,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT


				--Create tran log
				--Insert t_tran_log_holding
				INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
					,wh_id_2,location_id_2,hu_id_2
					,generic_attribute_1,
					generic_attribute_2,
					generic_attribute_3,
					generic_attribute_4,
					generic_attribute_5,
					generic_attribute_6,
					generic_attribute_7,
					generic_attribute_8,
					generic_attribute_9,
					generic_attribute_10,
					generic_attribute_11)
				VALUES
					(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@pick_id
					,@wh_id,@pick_loc,@hu_id,@item_number,@lot_number,@picked_qty
					,@wh_id,@put_loc,@put_hu_id
					,(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_1),    
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_2), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_3), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_4), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_5), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_6), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_7), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_8), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_9), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_10), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_11)
					)

			END
		--

		--Remove the stock from pick location
		EXEC	[dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @wh_id,
				@in_vchItemNumber = @item_number,
				@in_vchLocationID = @pick_loc,
				@in_nType =0,
				@in_vchHUID = @hu_id,
				@in_vchLotNumber =@lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @remove_qty,
				@in_dtFifoDate = NULL,
				@in_dtExpirationDate = NULL,
				@in_vchHUType = N'IV',
				@in_vchShipmentNumber =NULL,
				@in_damage_flag = @damage_flag,
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT
			
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    



