
CREATE PROCEDURE [dbo].[csp_generate_replen]
@in_vchWhID                NVARCHAR(10),
@in_vchWaveID              NVARCHAR(30),
@in_vchItem                NVARCHAR(30),
@in_vchStoredAttributeID   BIGINT = NULL,
@in_vchUoM                 NVARCHAR(10) = 'EA',
@in_vchReplenLoc           NVARCHAR(30),
@in_vchType                NVARCHAR(10),
@in_fqty                   FLOAT
AS

DECLARE
-- Error handling and logging variables.
@c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
@c_nFileNumber              INT, -- The # that uniquely tags this object.
@c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
@v_nErrorCode               INT, -- The # that uniquely tags the error message.
@v_nLogLevel                INT, -- Holds log level (1-5).
@v_vchErrorMsg              NVARCHAR(500),
@v_nSysErrorNum             INT,
@v_nSqlRowCount             INT,
@v_nReturn                  INT,
@v_nCount                   INT,
@v_nTranCount               INT,

-- Local Variables
@v_vchWkqID                 NVARCHAR(30),
@v_vchPriority              NVARCHAR(3),
@v_vchWkqPriority           NVARCHAR(3),
@v_vchCalcFlag              NVARCHAR(3),
@v_nQty                     INTEGER,
@v_nMaxQty                  INTEGER,
@v_chWorkType               NVARCHAR(2),
@v_vchOrderNum              NVARCHAR(50),
@v_vchLineNumber            NVARCHAR(5),
@v_nOrderNumLength          INTEGER

-- Set Constants
SET @c_nModuleNumber = 60     -- Always #60 for WA.
SET @c_nFileNumber = 1        -- This # must be unique per object.
SET @c_vchObjName = 'csp_generate_replen'

-- Set the Work Type based on the type passed in.
IF @in_vchType IN ('MINMAX','71')
    SET @v_chWorkType = '71'
ELSE IF @in_vchType IN ('TOPOFF','72')
   SET @v_chWorkType = '72'
ELSE IF @in_vchType IN ('WAVEOFF','73')
   SET @v_chWorkType = '73'
ELSE
BEGIN
    SET @v_nErrorCode = -20001;
    SET @v_vchErrorMsg = 'Attempting to create a replenishment for an invalid work type.'
    GOTO ERROR_HANDLER
END

SET NOCOUNT ON

-- Grab the database object log level.
EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
IF @v_nReturn <> 0 -- A zero means success.
BEGIN
    SET @v_nErrorCode = -20002;
    SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
    	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
    GOTO ERROR_HANDLER
END

-----------------------------------------------------------------------------------
--                            Verify the ITM
-----------------------------------------------------------------------------------
SELECT
    @v_nCount = COUNT(*)
FROM
    t_item_master
WHERE
    item_number = @in_vchItem
    AND wh_id = @in_vchWhID

SELECT @v_nSysErrorNum = @@ERROR, @v_nSqlRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_nErrorCode = -20003;
    SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    GOTO ERROR_HANDLER
END
IF @v_nCount = 0
BEGIN
    SET @v_nErrorCode = -20004;
    SET @v_vchErrorMsg = 'Attempting to create a replenishment for an ' +
        ' invalid item [' + ISNULL(@in_vchItem,'(NULL)') + '].'
    GOTO ERROR_HANDLER
END

-----------------------------------------------------------------------------------
--                            Verify the ITU
-----------------------------------------------------------------------------------
SELECT
    @v_nCount = COUNT(*)
FROM
    t_item_uom
WHERE
    item_number = @in_vchItem
    AND uom = @in_vchUoM
    AND wh_id = @in_vchWhID

SELECT @v_nSysErrorNum = @@ERROR, @v_nSqlRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_nErrorCode = -20005;
    SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    GOTO ERROR_HANDLER
END
IF @v_nCount = 0
BEGIN
    SET @v_nErrorCode = -20006;    
    SET @v_vchErrorMsg = 'Attempting to create a replenishment for an ' +
        'invalid unit of measure [' + ISNULL(@in_vchUoM,'(NULL)') + '].'
    GOTO ERROR_HANDLER
END

-----------------------------------------------------------------------------------
--                            Verify the LOC
-----------------------------------------------------------------------------------
SELECT
    @v_nCount = COUNT(*)
  FROM
    t_location
 WHERE
    location_id = @in_vchReplenLoc
    AND wh_id = @in_vchWhID

SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_nErrorCode = -20007;
    SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    GOTO ERROR_HANDLER
END
IF @v_nCount = 0
BEGIN
    SET @v_nErrorCode = -20008;
    SET @v_vchErrorMsg = 'Attempting to create a replenishment for an ' +
        ' invalid location [' + ISNULL(@in_vchReplenLoc,'(NULL)') + '].'
    GOTO ERROR_HANDLER
END


    SELECT
        @v_nCount = COUNT(*)
    FROM
        t_pick_detail WITH(NOLOCK)
    WHERE
        wh_id = @in_vchWhID
		AND wave_id = @in_vchWaveID
        AND item_number = @in_vchItem
        AND (stored_attribute_id = @in_vchStoredAttributeID OR @in_vchStoredAttributeID IS NULL)
        AND staging_location = @in_vchReplenLoc

    SELECT @v_nSysErrorNum = @@ERROR, @v_nSqlRowCount = @@ROWCOUNT
    IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_nErrorCode = -20013;
        SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        GOTO ERROR_HANDLER
    END

    -- If PKD already exists, no more work to be done.  This task just hasn't released yet.
    IF @v_nCount > 0
	BEGIN
        GOTO EXIT_LABEL
	END
-----------------------------------------------------------------------------------
--                     Insert into the PKD Table
-----------------------------------------------------------------------------------

-- Build order number to satisfy existing Picking functionality.
-- Include picking flow to be used on out sort.
BEGIN TRAN 
SELECT
    @v_vchOrderNum = 'R-' + @in_vchWaveID + '-' + @in_vchReplenLoc,
    @v_nOrderNumLength = LEN('R-' + @in_vchWaveID + '-' + @in_vchReplenLoc)
FROM
    t_location
WHERE
    location_id = @in_vchReplenLoc
	AND wh_id = @in_vchWhID

SELECT @v_nSysErrorNum = @@ERROR, @v_nSqlRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_nErrorCode = -20017;
    SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    GOTO ERROR_HANDLER
END

-- In case the resulting order # exceeds the t_pick_detail.order_number length allowed.
IF @v_nOrderNumLength > 30
BEGIN
    SET @v_nErrorCode = -20018;
    SET @v_vchErrorMsg = 'The resulting order number [' + @v_vchOrderNum
                     + '] is too long to fit into PKD.order_number.'
    GOTO ERROR_HANDLER
END

-- Build order line
SELECT  @v_vchLineNumber = ISNULL(MAX(line_number), 0) + 1
FROM    dbo.t_pick_detail
WHERE   wh_id = @in_vchWhID
        AND wave_id = @in_vchWaveID
        AND order_number = @v_vchOrderNum

-- Create the PKD record
INSERT INTO t_pick_detail
    (
	wave_id,
    order_number,
    line_number,
    type,
    work_type,
    status,
    item_number,
    uom,
    planned_quantity,
    staging_location,
    wh_id,
    pick_area,
    stored_attribute_id
    )
VALUES
    (
	@in_vchWaveID,
    @v_vchOrderNum,
    @v_vchLineNumber,
    'RP',
    @v_chWorkType,
    'CREATED',
    @in_vchItem,
    @in_vchUoM,
    @in_fqty,
    @in_vchReplenLoc,
    @in_vchWhID,
    'ALL',
    @in_vchStoredAttributeID
    )

SELECT @v_nSysErrorNum = @@ERROR, @v_nSqlRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_nErrorCode = -20019;
    SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    GOTO ERROR_HANDLER
END
IF @v_nSqlRowCount = 0
BEGIN
    SET @v_nErrorCode = -20020;
    SET @v_vchErrorMsg = 'Failed to insert t_pick_detail record for work type [' + @v_chWorkType
        + '] Replenishments. '
    GOTO ERROR_HANDLER
END

COMMIT TRAN
GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling Code
-----------------------------------------------------------------------------------
ERROR_HANDLER:

    SET @v_vchErrorMsg = @c_vchObjName + ': ' + CONVERT(VARCHAR(10), @v_nErrorCode) + ' ' + @v_vchErrorMsg
                          + ' SQL Error = ' + CONVERT(VARCHAR(30), ISNULL(@v_nSysErrorNum,0)) + '.'

    RAISERROR(@v_vchErrorMsg, 11, 1)

	IF @@TRANCOUNT > 0   
	BEGIN
		ROLLBACK TRANSACTION
	END
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:
RETURN

