
CREATE TRIGGER dbo.tr_attribute_action_update ON dbo.t_attribute_action FOR UPDATE  AS 
BEGIN

DECLARE	@strErrorMessage		NVARCHAR(200),
        @nErrorNumber			integer,
	@nLogLevel			tinyint,
        @strObjName			NVARCHAR(30),

	@count				integer,
	@rows				integer

  -- Set constant values.
  SET @strObjName = 'tr_attribute_action_update'

  SET NOCOUNT ON

  -- Grab the Database Log Level from t_control.  If it doesn't exist, insert it.
  -- 0 = Off, 1 = On
  SELECT @nLogLevel = next_value FROM t_control WHERE control_type = 'DB OBJ LOG LEVEL'

  IF @@ROWCOUNT = 0
    BEGIN
      INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit)
        VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', '0', 'SHOW_VA', '1')
      SET @nLogLevel = 0
    END

  -- Do not allow changing of the primary key.
  IF UPDATE (attribute_id) OR UPDATE (attribute_behavior_id) OR UPDATE (process_before)
     OR UPDATE (process_after) OR UPDATE (process_during)
    BEGIN
    	UPDATE     [t_attribute_action]
    	SET        modified_date = CONVERT(datetime, CONVERT(NVARCHAR(30), GetDate(), 101))
    	FROM       inserted i 
        INNER JOIN [t_attribute_action] taa ON i.attribute_action_id = taa.attribute_action_id 
    END

END
