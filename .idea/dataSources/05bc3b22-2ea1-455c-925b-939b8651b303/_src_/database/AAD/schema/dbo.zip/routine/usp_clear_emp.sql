
CREATE PROCEDURE usp_clear_emp
@in_strWhID NVARCHAR(10),
@in_strEmpID NVARCHAR(10)

AS
DECLARE
    @strErrorMessage		NVARCHAR(200),
    @nErrorNumber		int,
    @nLogLevel			tinyint,
    @strObjName			NVARCHAR(30),
    @v_vchSqlErrorNumber	int,
    @c_vnReturnUpdate	int,
    @v_nRowCount                int,
    @c_vnServerError            int,
    @c_nModuleNumber            int, 
    @c_nFileNumber              int 

  SET NOCOUNT ON

  -- Grab the database object log level.
  EXECUTE usp_db_obj_log_level @nLogLevel OUTPUT

  -- Set constant values.
  SET @strObjName = 'usp_clear_emp'
  SET @c_vnServerError = 1
  SET @c_vnReturnUpdate = 2
  SET @c_nModuleNumber =60           
  SET @c_nFileNumber  =99   

  -- Initialize the EMP.sp_return storage field.
  UPDATE t_employee
    SET sp_return = NULL
    WHERE id = @in_strEmpID
      AND wh_id = @in_strWhID

  -- Be sure a row was updated/found.
   SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount =@@ROWCOUNT
   IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount =0
    BEGIN
      IF @v_vchSqlErrorNumber <> 0
        SET @nErrorNumber = @c_vnServerError
      ELSE SET @nErrorNumber = @c_vnReturnUpdate
      GOTO ErrorHandler
    END

  
--    PRINT @strObjName + ': The sp_return field was cleared for employee id : ' + @in_strEmpID
--    + ' in warehouse : ' + @in_strWhID + '.'
 
  GOTO ExitLabel

ErrorHandler:
  SET @strErrorMessage =
    CASE
      -- SQL Server error:
      WHEN @nErrorNumber = @c_vnServerError THEN
        @strObjName + ': A SQL Server error ' + CONVERT(varchar(30),@@ERROR) + ' occured.  Check Sytem Status ' +
        ' Console, DATA, sproc syntax, etc.'
      -- Internal errors:
      WHEN @nErrorNumber = @c_vnReturnUpdate THEN
        @strObjName + ': t_employee.sp_return update failed for employee ' + @in_strEmpID + '.'
    END
  
 -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @nErrorNumber, @nLogLevel, @strErrorMessage, 1
  -- This is the application's way of knowing there was an error in this sproc.  Be sure the app
  -- looks at this field immediately after running the sproc.
  UPDATE t_employee SET sp_return = 'PROC ERROR' WHERE id = @in_strEmpID AND wh_id = @in_strWhID

  RAISERROR (@strErrorMessage, 1, 1)

ExitLabel:
  RETURN
