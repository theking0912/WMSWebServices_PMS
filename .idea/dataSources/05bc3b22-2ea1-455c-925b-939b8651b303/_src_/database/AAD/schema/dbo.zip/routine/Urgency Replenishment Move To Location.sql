








-- =======================================    
-- Author: will.xu
-- Create Date: 02 18 2016    
-- Description: 紧急补货（放下）
--  
    
-- =======================================    
CREATE PROCEDURE [dbo].[Urgency Replenishment Move To Location]    
     @wh_id					NVARCHAR(10)
    ,@fork_id				NVARCHAR(30)  
	--,@wave_id				NVARCHAR(30)
	,@sort_location			NVARCHAR(30)
	,@item_number			NVARCHAR(30)	
	,@lot_number			NVARCHAR(30)
	,@qty					INT
	,@user_id				NVARCHAR(30)
	,@passornot				NVARCHAR(1)		output
	,@msg					NVARCHAR(200)	output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @fifo_date			NVARCHAR(30)
		DECLARE @expiration_date	NVARCHAR(30)
		DECLARE @attribute_id		NVARCHAR(30)
		DECLARE @wave_id			NVARCHAR(30)  
		DECLARE @remove_qty			INT
	    DECLARE @damage_flag      NVARCHAR(1)   ---------------正常和货损
		DECLARE	@out_vchCode		uddt_output_code,
				@out_vchMsg			uddt_output_msg

		BEGIN TRANSACTION
		
		SET @remove_qty = -@qty
		set @wave_id =null   ----will add  
		set @passornot = 0
		SET @damage_flag='N'
		SELECT @fifo_date = fifo_date
			  ,@expiration_date = expiration_date
			  ,@attribute_id =stored_attribute_id
			  FROM t_stored_item
			 WHERE wh_id = @wh_id
			   AND item_number = @item_number
			   AND (lot_number = @lot_number OR @lot_number IS NULL OR @lot_number ='') 
			   AND location_id = @fork_id  AND damage_flag=@damage_flag
			   --AND hu_id = @wave_id
			   
			--Remove the stock from fork ID
			--EXEC	[dbo].[usp_inventory_adjust]
			--		@in_vchWhID = @wh_id,
			--		@in_vchItemNumber = @item_number,
			--		@in_vchLocationID = @fork_id,
			--		@in_nType = 0,
			--		@in_vchHUID = @wave_id,
			--		@in_vchLotNumber =@lot_number,
			--		@in_nStoredAttributeID = @attribute_id,
			--		@in_fQty = @remove_qty,
			--		@in_dtFifoDate = @fifo_date,
			--		@in_dtExpirationDate = @expiration_date,
			--		@in_vchHUType = N'SO',
			--		@in_vchShipmentNumber = @wave_id,
			--		@out_vchCode = @out_vchCode OUTPUT,
			--		@out_vchMsg = @out_vchMsg OUTPUT



			
				EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @fork_id,
						@in_nType = 0,
						@in_vchHUID = @wave_id,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @attribute_id,
						@in_fQty = @remove_qty,
						----@in_dtFifoDate = NULL,@FifoDate
						@in_dtFifoDate =@fifo_date,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = N'SO',
						@in_vchShipmentNumber =@wave_id,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT





			IF @out_vchCode <> N'SUCCESS'
			BEGIN
				SET @passornot = 1
				SET @msg = @out_vchMsg
			END

			-- Add the stock to sorting Location
			--EXEC	[dbo].[usp_inventory_adjust]
			--		@in_vchWhID = @wh_id,
			--		@in_vchItemNumber = @item_number,
			--		@in_vchLocationID = @sort_location,
			--		@in_nType = 0,
			--		@in_vchHUID = NULL,
			--		@in_vchLotNumber =@lot_number,
			--		@in_nStoredAttributeID = @attribute_id,
			--		@in_fQty = @qty,
			--		@in_dtFifoDate = @fifo_date,
			--		@in_dtExpirationDate = @expiration_date,
			--		@in_vchHUType = N'SO',
			--		@in_vchShipmentNumber = NULL,
			--		@out_vchCode = @out_vchCode OUTPUT,
			--		@out_vchMsg = @out_vchMsg OUTPUT


					EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @sort_location,
						@in_nType = 0,
						@in_vchHUID = NULL,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @attribute_id,
						@in_fQty = @qty,
						----@in_dtFifoDate = NULL,@FifoDate
						@in_dtFifoDate =@fifo_date,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = N'SO',
						@in_vchShipmentNumber =NULL,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT




			IF @out_vchCode <> N'SUCCESS'
			BEGIN
				SET @passornot = 1
				SET @msg = @out_vchMsg
			END

		--IF NOT EXISTS (SELECT hu_id
		--					 FROM dbo.t_stored_item
		--				    WHERE wh_id = @wh_id
		--					  AND location_id = @fork_id) 
		--	BEGIN 
		--		DELETE 
		--		  FROM dbo.t_hu_master
		--		 WHERE wh_id = @wh_id
		--		   AND hu_id = @wave_id
		--	END
			
		--Create tran log
		--Insert t_tran_log_holding
		INSERT INTO dbo.t_tran_log_holding
                       (tran_type
                       ,description
                       ,start_tran_date
                       ,start_tran_time
                       ,end_tran_date
                       ,end_tran_time
                       ,employee_id
                       ,control_number
                       ,control_number_2
                       ,wh_id
                       ,location_id
                       ,hu_id
                       ,item_number
                       ,lot_number
                       ,tran_qty
                       ,wh_id_2
                       ,location_id_2
                       ,hu_id_2
                       ,generic_attribute_1
                       ,generic_attribute_2
                       ,generic_attribute_3
                       ,generic_attribute_4
                       ,generic_attribute_5
                       ,generic_attribute_6
                       ,generic_attribute_7
                       ,generic_attribute_8
                       ,generic_attribute_9
                       ,generic_attribute_10
                       ,generic_attribute_11)
				 VALUES
					  ('993'
					   ,N'紧急补货（放下）'
					   ,GETDATE()
                       ,GETDATE()
                       ,GETDATE()
                       ,GETDATE()
                       ,@user_id
                       --,@wave_id
                       ,NULL
					   ,NULL
                       ,@wh_id
                       ,@fork_id
                       ,NULL
                       ,@item_number
                       ,@lot_number
                       ,@qty
                       ,@wh_id
                       ,@sort_location
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL
                       ,NULL)
UPDATE t_work_q 
SET work_status = (CASE WHEN  qty =@qty THEN 'C' ELSE work_status END)
WHERE wh_id=@wh_id and item_number =@item_number
and lot_number =@lot_number and location_id =@sort_location and work_status='A'
and work_type = '06'  and qty =@qty

if @@ROWCOUNT<=0
 begin
  SET @passornot = 1
 end
		
		--IF NOT EXISTS (SELECT 1
		--				 FROM dbo.tbl_allocation
		--				WHERE wh_id = @wh_id
		--			      AND wave_id = @wave_id
		--			      AND allo_type = 'RP1'
		--			      AND status IN('A','U') )
		--	BEGIN 
		--		UPDATE dbo.t_wave_master
		--		   SET is_tr_completed = 'Y'
		--		 WHERE wh_id = @wh_id
		--		   AND wave_id = @wave_id
		--	END
			
		SET @passornot = 0
		SET @msg = ''
		IF @passornot = 0
		COMMIT	TRANSACTION
		ELSE
		ROLLBACK TRANSACTION
        RETURN

		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    









