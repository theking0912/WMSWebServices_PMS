



-- =============================================
-- Author:		K1
-- Create date: 2016-03-19
-- Description:	
-- =============================================

CREATE PROCEDURE [dbo].[csp_Web_Rep]
    @in_wh_id					NVARCHAR(10) ,
 --   @in_pick_loc_id				NVARCHAR(30) ,
	--@in_dest_loc_id				NVARCHAR(30) ,
    @in_item_number				NVARCHAR(20) ,
	--@in_allo_id					BIGINT,
	--@in_work_q_id				BIGINT,
	--@in_lot_number				NVARCHAR(30) ,
	--@in_sto_attribute_id		NVARCHAR(30) ,
	@in_pick_qty				FLOAT,
	--@in_pick_hu_id				NVARCHAR(30) ,
	@in_user_id					NVARCHAR(30) ,
	@in_pick_id					BIGINT		 ,
    @out_passornot				NVARCHAR(1)		OUTPUT  ,--0:Pass 1: Fail   
    @out_msg					NVARCHAR(200)	OUTPUT
AS
    BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
        SET NOCOUNT ON;
		DECLARE @remove_qty				FLOAT
		DECLARE @order_number			NVARCHAR(30)
		DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
		DECLARE @type					NVARCHAR(2) = 'SO'
		DECLARE @pick_type				BIGINT
		DECLARE @expiration_date		DATETIME
		DECLARE @damage_flag			NVARCHAR(1)
		DECLARE @Rec_Cnt			AS	INT
		DECLARE @tran_type			AS	NVARCHAR(10) = '922'
		DECLARE @tran_description	AS	NVARCHAR(50) = 'WEB 紧急补货（拣起）'

		DECLARE @tran1_type			AS	NVARCHAR(10) = '923'
		DECLARE @tran1_description	AS	NVARCHAR(50) = 'WEB 紧急补货（放下）'

		DECLARE @bln_tran			AS	NVARCHAR(1) = 0
        SET @out_passornot = 0



		DECLARE @pick_loc_id			NVARCHAR(30)
		DECLARE @dest_loc_id				NVARCHAR(30)  
		DECLARE @allo_id					BIGINT
		DECLARE @work_q_id				BIGINT
		DECLARE @lot_number				NVARCHAR(30)
		DECLARE @sto_attribute_id			NVARCHAR(30) 
		DECLARE @pick_hu_id				NVARCHAR(30)
		DECLARE @pick_qty					FLOAT
		DECLARE @put_qty					FLOAT

/****** Added by Trevor on 20160419 started ******/
		DECLARE @pick_loc_id_x			NVARCHAR(30)
		DECLARE @dest_loc_id_x				NVARCHAR(30)  

		if exists (select 1 from tbl_allocation
		            where wh_id=@in_wh_id and item_number=@in_item_number and pick_id =@in_pick_id and status not in ('U','C') and allo_type='R2')
		   or exists (select 1 from t_work_q
		              where wh_id=@in_wh_id and item_number=@in_item_number and pick_ref_number =@in_pick_id and work_status not in ('U','C') and work_type='06')
		begin
		    select top 1 @pick_loc_id_x=location_id from tbl_allocation
			 where wh_id=@in_wh_id and item_number=@in_item_number and pick_id =@in_pick_id and status not in ('U','C') and allo_type='R2'
			select top 1 @dest_loc_id_x=location_id from t_work_q
			 where wh_id=@in_wh_id and item_number=@in_item_number and pick_ref_number =@in_pick_id and work_status not in ('U','C') and work_type='06'
		    
			SET @out_msg = N'商品'+@in_item_number+N'在库位'+@pick_loc_id_x+N'或在库位'+@dest_loc_id_x++N'有紧急补货正在进行中'
            SET @out_passornot = 1
		  return
		end
/****** Added by Trevor on 20160419 ended ******/

        BEGIN TRY
			
			--IF @in_sto_attribute_id = ''
			--BEGIN
			--	SET @in_sto_attribute_id = NULL
			--END
			
			--IF @in_lot_number = ''
			--BEGIN
			--	SET @in_lot_number = NULL
			--END

			--IF @in_pick_hu_id = ''
			--BEGIN
			--	SET @in_pick_hu_id = NULL
			--END
			BEGIN TRANSACTION

			WHILE (1=1)
			BEGIN
				SELECT TOP 1 @dest_loc_id = location_id 
							,@sto_attribute_id = stored_attribute_id
							,@lot_number = lot_number
							,@put_qty = qty
							,@work_q_id = work_q_id
					FROM t_work_q
					WHERE pick_ref_number = @in_pick_id
						AND wh_id = @in_wh_id
						AND work_status <> 'C'
						AND work_type = '06'
					ORDER BY work_q_id

				IF @@ROWCOUNT = 0
				BEGIN
					BREAK
				END

				IF ISNULL(@lot_number,'') <> ''
				BEGIN
					SET @expiration_date = DATEADD(DAY
											,(SELECT ISNULL(shelf_life,0)
												 FROM t_item_master
												WHERE item_number = @in_item_number
													AND wh_id = @in_wh_id)
											,CONVERT(datetime,left(@lot_number,8))
											)

				END

				EXEC	[dbo].[csp_Inventory_Adjust]
							@in_vchWhID = @in_wh_id,
							@in_vchItemNumber = @in_item_number,
							@in_vchLocationID = @dest_loc_id,
							@in_nType = 0,
							@in_vchHUID = NULL,
							@in_vchLotNumber =@lot_number,
							@in_nStoredAttributeID = @sto_attribute_id,
							@in_fQty = @put_qty,
							@in_dtFifoDate = NULL,
							@in_dtExpirationDate = @expiration_date,
							@in_vchHUType = 'IV',
							@in_vchShipmentNumber = NULL,
							@in_damage_flag = 'N',
							@out_vchCode = @out_vchCode OUTPUT,
							@out_vchMsg = @out_vchMsg OUTPUT
				
				UPDATE t_work_q
					SET work_status  = 'C'
				WHERE work_q_id = @work_q_id
					AND wh_id = @in_wh_id
					AND work_status <> 'C'

				--Create tran log
					--Insert t_tran_log_holding
					INSERT INTO t_tran_log_holding
						([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
						,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
						,wh_id_2,location_id_2,hu_id_2
						,generic_attribute_1,
						generic_attribute_2,
						generic_attribute_3,
						generic_attribute_4,
						generic_attribute_5,
						generic_attribute_6,
						generic_attribute_7,
						generic_attribute_8,
						generic_attribute_9,
						generic_attribute_10,
						generic_attribute_11)
					VALUES
						(@tran1_type,@tran1_description,getdate(),getdate(),getdate(),getdate(),@in_user_id,@order_number,@in_pick_id
						,@in_wh_id,NULL,NULL,@in_item_number,@lot_number,@put_qty
						,@in_wh_id,@dest_loc_id,''
						,(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_1),    
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_2), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_3), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_4), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_5), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_6), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_7), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_8), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_9), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_10), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_11)
						)

			END

			WHILE (1=1)
			BEGIN
				SELECT TOP 1 @sto_attribute_id = stored_attribute_id
							,@lot_number = lot_number
							,@pick_loc_id = location_id
							,@pick_hu_id = hu_id
							,@pick_qty = allocated_qty - picked_qty
							,@expiration_date = expiration_date
							,@damage_flag = damage_flag
							,@allo_id = seq_id
						from tbl_allocation allo
						where allo.allo_type = 'R2'
						and allo.status <> 'C'
						and allo.pick_id = @in_pick_id
						ORDER BY seq_id 

				IF @@ROWCOUNT = 0
				BEGIN
					break
				END
			

					SELECT @expiration_date = expiration_date
						,@damage_flag = damage_flag
					FROM t_stored_item sto 
					WHERE sto.wh_id = @in_wh_id
						AND item_number = @in_item_number
						AND ISNULL(hu_id,'') = ISNULL(@pick_hu_id,'')
						AND location_id = @pick_loc_id
						AND ISNULL(lot_number,'') = ISNULL(@lot_number,'')
						AND ISNULL(stored_attribute_id,'') = ISNULL(@sto_attribute_id,'')
						AND status = 'A'
						AND actual_qty >= @pick_qty
		 
					IF @@ROWCOUNT = 0
					BEGIN
						RAISERROR ('拣货数量超出实际数量',  -- Message text.
							   16, -- Severity.
							   1     -- State.
							   );
					END										 
				 
					 
					 SET @bln_tran = '1'
					--Update allocation information
					UPDATE tbl_allocation
					SET status = (CASE WHEN  picked_qty + @pick_qty = allocated_qty
										THEN 'C'
									ELSE 'U' END)
						,picked_qty = picked_qty + @pick_qty
					WHERE seq_id = @allo_id
				
				
					--SELECT TOP 1 @work_q_id = work_q_id
					--			,@dest_loc_id = location_id
					--	FROM t_work_q
					--	WHERE work_type = '06'
					--		AND work_status <> 'C'
					--		AND pick_ref_number = @in_pick_id
					--		AND item_number = @in_item_number
					--		AND ISNULL(lot_number,'') = ISNULL(@lot_number,'')
					--		AND ISNULL(stored_attribute_id,'') = ISNULL(@sto_attribute_id,'')
					--		AND wh_id = @in_wh_id

					--UPDATE t_work_q
					--	SET work_status = (CASE WHEN NOT EXISTS(SELECT 1
					--											FROM tbl_allocation
					--											WHERE pick_id = @in_pick_id
					--											AND allo_type = 'R2'
					--											AND wh_id = @in_wh_id
					--											AND item_number = @in_item_number														
					--											AND ISNULL(lot_number,'') = ISNULL(@lot_number,'')
					--											AND ISNULL(stored_attribute_id,'') = ISNULL(@sto_attribute_id,'')
					--											AND status <> 'C')
					--								THEN 'C'
					--							ELSE 'U' END)
					--		WHERE work_q_id = @work_q_id

						set @type = 'IV'
						SET @pick_type = 0
				 
				 
					--Move the stock to fork
					--EXEC	[dbo].[csp_Inventory_Adjust]
					--		@in_vchWhID = @in_wh_id,
					--		@in_vchItemNumber = @in_item_number,
					--		@in_vchLocationID = @dest_loc_id,
					--		@in_nType = @pick_type,
					--		@in_vchHUID = NULL,
					--		@in_vchLotNumber =@lot_number,
					--		@in_nStoredAttributeID = @sto_attribute_id,
					--		@in_fQty = @in_pick_qty,
					--		@in_dtFifoDate = NULL,
					--		@in_dtExpirationDate = @expiration_date,
					--		@in_vchHUType = @type,
					--		@in_vchShipmentNumber = NULL,
					--		@in_damage_flag = @damage_flag,
					--		@out_vchCode = @out_vchCode OUTPUT,
					--		@out_vchMsg = @out_vchMsg OUTPUT
	 
					

						--Insert t_tran_log_holding
					INSERT INTO t_tran_log_holding
						([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
						,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
						,wh_id_2,location_id_2,hu_id_2
						,generic_attribute_1,
						generic_attribute_2,
						generic_attribute_3,
						generic_attribute_4,
						generic_attribute_5,
						generic_attribute_6,
						generic_attribute_7,
						generic_attribute_8,
						generic_attribute_9,
						generic_attribute_10,
						generic_attribute_11)
					VALUES
						(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@in_user_id,@order_number,@in_pick_id
						,@in_wh_id,@pick_loc_id,@pick_hu_id,@in_item_number,@lot_number,@in_pick_qty
						,@in_wh_id,'',''
						,(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_1),    
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_2), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_3), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_4), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_5), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_6), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_7), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_8), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_9), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_10), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @sto_attribute_id
    					AND a.attribute_id = alm.generic_attribute_11)
						)


						SET @remove_qty = @pick_qty * -1
						--Remove the stock from pick location
						EXEC	[dbo].[csp_Inventory_Adjust]
								@in_vchWhID = @in_wh_id,
								@in_vchItemNumber = @in_item_number,
								@in_vchLocationID = @pick_loc_id,
								@in_nType =0,
								@in_vchHUID = @pick_hu_id,
								@in_vchLotNumber =@lot_number,
								@in_nStoredAttributeID = @sto_attribute_id,
								@in_fQty = @remove_qty,
								@in_dtFifoDate = NULL,
								@in_dtExpirationDate = @expiration_date,
								@in_vchHUType = N'IV',
								@in_vchShipmentNumber =NULL,
								@in_damage_flag = @damage_flag,
								@out_vchCode = @out_vchCode OUTPUT,
								@out_vchMsg = @out_vchMsg OUTPUT				
			END
			
			--CREATE SN Interface
            SET @out_passornot = 0
            SET @out_msg = ''
            COMMIT		
            RETURN
        END TRY
        BEGIN CATCH
			IF @bln_tran = '1'
			BEGIN
            ROLLBACK
			END			
            SET @out_msg = ERROR_MESSAGE()
            SET @out_passornot = 1

			RAISERROR (@out_msg,  -- Message text.
						   16, -- Severity.
						   2     -- State.
						   );

            RETURN
        END CATCH

    END




