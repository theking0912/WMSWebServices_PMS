
-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Yard Receipt    
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Yard_Receipt]    
     @wh_id				NVARCHAR(10)    
    ,@shipment_number   NVARCHAR(30)    
	,@truck_number		nvarchar(30)
    ,@package_number	NVARCHAR(30) 
	,@passornot			nvarchar(1) output
	,@msg				nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY

		BEGIN TRANSACTION
			--Check the format is correct or not
			IF SUBSTRING(@package_number,1,1) <> '4' OR ISNUMERIC(@package_number) != 1 OR LEN(@package_number)>6
				BEGIN
					ROLLBACK;
					SET @passornot = 2
					SET @msg = 'Invalid Format';
					return;
				END
			--Check the package has been scanned or not
			IF EXISTS(SELECT 1 FROM [tbl_rcpt_ship_package]
					   WHERE wh_id = @wh_id
					   and [package_number] = @package_number)
				BEGIN
					ROLLBACK;
					SET @passornot = 3
					SET @msg = 'Package Scanned';
					return;
				END

			--bind the package to shipment
			INSERT INTO [dbo].[tbl_rcpt_ship_package]
			([wh_id],[shipment_number],[trailer_number],[package_number],[status],[remark])
			VALUES
			 (@wh_id,@shipment_number,@truck_number,@package_number,'N','')

			 SET @passornot = 0
			 SET @msg = ''
		COMMIT		
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END

