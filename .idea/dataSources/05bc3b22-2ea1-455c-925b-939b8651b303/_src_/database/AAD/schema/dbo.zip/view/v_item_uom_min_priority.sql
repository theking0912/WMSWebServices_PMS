
CREATE VIEW dbo.v_item_uom_min_priority AS
SELECT
    u.*
FROM
    t_item_uom u,
    (
    SELECT
        item_number,
        wh_id,
        uom,
        MIN(priority) min_priority
    FROM
        t_item_uom
    GROUP BY
        item_number,
        wh_id,
        uom
    ) u_min
WHERE
    u.item_number = u_min.item_number AND
    u.wh_id = u_min.wh_id AND
    u.uom = u_min.uom AND
    u.priority = u_min.min_priority
