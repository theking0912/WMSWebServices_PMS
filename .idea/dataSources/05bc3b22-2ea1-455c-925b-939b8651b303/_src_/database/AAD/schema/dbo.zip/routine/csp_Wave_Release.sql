CREATE PROCEDURE [dbo].[csp_Wave_Release]
    @wh_id NVARCHAR(10) ,
    @wave_id NVARCHAR(30)
AS
    BEGIN    
	   

    -- SET NOCOUNT ON added to prevent extra result sets from    
        SET NOCOUNT ON;    
	--SET STATISTICS IO ON;
	--SET STATISTICS TIME ON ;

        BEGIN TRY
            DECLARE @wave_type NVARCHAR(20)
            DECLARE @status NVARCHAR(20)
			DECLARE @n_cnt  INT
            SELECT  @wave_type = wave_type ,
                    @status = status
            FROM    t_wave_master WITH(NOLOCK)
            WHERE   wh_id = @wh_id
                    AND wave_id = @wave_id

            IF ( @status = 'H' )
            BEGIN
                UPDATE  tbl_allocation
                SET     status = 'U'
                WHERE   wh_id = @wh_id
                        AND wave_id = @wave_id
                        AND status = 'H'

                UPDATE  t_wave_master
                SET     status = 'R'
                WHERE   wh_id = @wh_id
                        AND wave_id = @wave_id
                        AND status = 'H'
            END

            EXEC csp_Wave_Release_Alloc @wh_id, @wave_id


			/*需要进行打包的商品，直接在打包台分配任务，打包台库存不够分配，则分配负库存，再从存储货位进行补货打包台*/
            --SELECT  @n_cnt = COUNT(1)
            --FROM    tbl_allocation allo ,
            --        t_item_master itm
            --WHERE   allo.wh_id = itm.wh_id
            --        AND allo.item_number = itm.item_number
            --        AND allo.allocated_qty < 0
            --        AND itm.pack_flag = 'Y'
            --        AND allo.wh_id = @wh_id
            --        AND allo.wave_id = @wave_id
            --IF @n_cnt > 0
            --    BEGIN
            --        EXEC csp_create_wave_replens @wh_id, @wave_id 
            --    END 
            RETURN

        END TRY

        BEGIN CATCH
            RETURN
        END CATCH
  
    END
