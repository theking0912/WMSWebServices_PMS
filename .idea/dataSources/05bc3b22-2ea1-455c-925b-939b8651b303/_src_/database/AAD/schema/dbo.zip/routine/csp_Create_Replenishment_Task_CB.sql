
CREATE PROCEDURE [dbo].[csp_Create_Replenishment_Task_CB]
	@item_number NVARCHAR(50),
	@wh_id       NVARCHAR(50)
AS
BEGIN    
	SET NOCOUNT ON;

	DECLARE @location_id NVARCHAR(30) --货位号
	DECLARE @rep_qty DECIMAL(30, 8) --需要补货数量
	DECLARE @full_case_qty DECIMAL(30, 8) --满箱值

	SET @location_id = ''

	IF OBJECT_ID('#temp_rep_item_CB') IS NOT NULL
		DROP TABLE #temp_rep_item_CB

	CREATE TABLE #temp_rep_item_CB (
		item_number NVARCHAR(30)
		,location_id NVARCHAR(30)
		,rep_qty DECIMAL(30, 8)
		,wh_id NVARCHAR(30)
		)

	--取出tbl_loc_item绑定C区需补货的商品  
	INSERT INTO #temp_rep_item_CB (
		item_number
		,location_id
		,rep_qty
		,wh_id
		)
	SELECT li.item_number
		,li.location_id
		,li.max_qty-ISNULL(st.actual_qty,0)
		,li.wh_id
	FROM tbl_loc_item li
	INNER JOIN t_location loc ON loc.wh_id = li.wh_id
		AND loc.location_id = li.location_id
	INNER JOIN t_zone_loca zl ON loc.wh_id=zl.wh_id and loc.location_id=zl.location_id 
	LEFT JOIN (select wh_id,item_number,location_id,sum(actual_qty) as actual_qty 
				from t_stored_item where wh_id=@wh_id 
				group by wh_id,item_number,location_id
				) st ON li.wh_id=st.wh_id and li.location_id=st.location_id and li.item_number=st.item_number
	WHERE loc.type in ('B','Z')
		AND li.wh_id=@wh_id
		AND li.item_number=@item_number
		AND (ISNULL(st.actual_qty,0)<li.min_qty or (li.min_qty =0 and ISNULL(st.actual_qty,0)=0))
		AND li.max_qty - ISNULL(st.actual_qty, 0) > 0

	IF EXISTS(select 1 from #temp_rep_item_CB)
	BEGIN
		SELECT TOP 1 @full_case_qty = ISNULL(full_case_qty, 1)
		FROM dbo.t_item_master
		WHERE item_number = @item_number
			AND wh_id = @wh_id
		
		WHILE (1 = 1)
		BEGIN
			--获取货位
			SELECT TOP 1 @location_id = location_id,@rep_qty=rep_qty
			FROM #temp_rep_item_CB
			WHERE item_number = @item_number
			AND wh_id = @wh_id 
			AND location_id > @location_id
			ORDER BY location_id

			IF @@ROWCOUNT = 0
				BREAK

			--C补到B，需要拣整箱，向下取整
			SET @rep_qty=ISNULL((FLOOR((@rep_qty / @full_case_qty)) * @full_case_qty), 0)

			EXECUTE dbo.csp_Replenishment_Alloc_CB @item_number 
					,@location_id
					,@rep_qty
					,@wh_id
		END
	END
END

