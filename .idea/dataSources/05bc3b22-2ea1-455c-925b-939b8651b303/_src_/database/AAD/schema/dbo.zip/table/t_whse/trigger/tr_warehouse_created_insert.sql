
CREATE TRIGGER dbo.tr_warehouse_created_insert ON dbo.t_whse FOR INSERT AS 
BEGIN

DECLARE	
    -- Error handling variables
    @c_vchObjName               NVARCHAR(30),  -- The name that uniquely tags this object.
    @v_nSysErrorNum             INTEGER,
    @v_nRowCount                INTEGER,
    @v_vchCode                  NVARCHAR(30),
    @v_vchMsg                   NVARCHAR(1000)    

    -- Set Constants
    SET @c_vchObjName = 'tr_warehouse_created_insert'

    SET NOCOUNT ON
  
    -- Insert client record.
	INSERT INTO t_client (wh_id, client_code, name, addr1, addr2, addr3,
		city, state, zip, country_code, country_name, phone, email,
		contact, fax)
    SELECT
        wh_id, wh_id, ISNULL(name, wh_id), addr1, addr2, addr3, city, state, zip,
		country_code, country_name, phone, NULL, NULL, fax
    FROM
        inserted   
	      
	SELECT @v_nSysErrorNum = @@ERROR
	IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchCode = '-20001'
		SET @v_vchMsg = 'An error occured in trigger tr_warehouse_created_insert while ' +
				'attempting to insert client record.'
		GOTO ERROR_HANDLER
	END

GOTO EXIT_LABEL
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:

    SET @v_vchMsg = @c_vchObjName + ': [' + @v_vchCode + '] ' + @v_vchMsg
                          + ' SQL Error = ' + CONVERT(VARCHAR(30), ISNULL(@v_nSysErrorNum,0)) + '.'

    RAISERROR(@v_vchMsg, 11, 1)

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:
    RETURN
END

