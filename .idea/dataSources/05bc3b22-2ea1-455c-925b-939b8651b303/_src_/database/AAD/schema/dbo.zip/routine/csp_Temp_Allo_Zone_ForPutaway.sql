


-- Procedure
-- Procedure
-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Allocation Zone for put
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Allo_Zone_ForPutaway]    
     @wh_id				NVARCHAR(10)    
    ,@hu_id			    NVARCHAR(30)  
	,@caseflag			NVARCHAR(10) --Y: CASE, N:UNIT
	,@passornot			NVARCHAR(1) output
	,@msg				NVARCHAR(200) output
	,@dest_loc			NVARCHAR(30) = NULL
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY

		BEGIN TRANSACTION
		DECLARE @suggest_zone	NVARCHAR(30)
		DECLARE @usage			float
		DECLARE @zone_type		NVARCHAR(30)
		DECLARE @client_code	NVARCHAR(30)
		DECLARE @location_id	NVARCHAR(30)
		DECLARE @conveyor_loop  NVARCHAR(30)
		DECLARE @node			NVARCHAR(30)
		DECLARE @conveyor_flag	NVARCHAR(10)

		DECLARE @vip_flag		NVARCHAR(10)
		
		--Get zone type and qc location
		SELECT @zone_type = subtype
			,@location_id = location_id
		FROM t_hu_master 
		WHERE wh_id = @wh_id
		AND hu_id = @hu_id

		SELECT top 1 @client_code = itm.client_code
					FROM t_stored_item sto
						inner join t_item_master itm on sto.wh_id = itm.wh_id
													and sto.item_number = itm.item_number
					WHERE sto.wh_id = @wh_id
					AND sto.hu_id = @hu_id

		select @vip_flag = vip_flag
		from t_client a
		where a.wh_id = @wh_id
		and a.client_code = @client_code

		--Get loop
		SELECT @conveyor_loop = conveyor_loop,
			   @conveyor_flag = conveyor
		FROM tbl_qc_station_loca
		where wh_id = @wh_id
		and qc_location = @location_id
		--test
		--INSERT INTO tbl_debug_loc_test
		--(in_end_loc, get_end_loc)
		--VALUES
		--(@location_id,@hu_id)
		--
		--Get Conveyor sign
		IF ISNULL(@dest_loc,'') <> ''
			BEGIN
				SELECT @conveyor_flag = c3
				FROM t_location
				where wh_id = @wh_id
				and location_id = @dest_loc
			END

		IF ISNULL(@conveyor_flag,'') = ''
			BEGIN
				SET @conveyor_flag = 'N' 
			END
                            
		--SET @conveyor_flag = 'Y' 
		--Get Zone for conveyor
		IF @conveyor_flag = 'Y' 
			BEGIN
			IF @zone_type = 'BV' OR @zone_type = 'CV' or @vip_flag = 'V'
				BEGIN
					SELECT top 1 @client_code = itm.client_code
					FROM t_stored_item sto
						inner join t_item_master itm on sto.wh_id = itm.wh_id
													and sto.item_number = itm.item_number
					WHERE sto.wh_id = @wh_id
					AND sto.hu_id = @hu_id

					SELECT TOP 1 @suggest_zone = z.zone
								--,@usage = isnull(zuq.emp_qty,0)/ztq.loc_qty
								,@usage = cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float)
								,@node = gn.node
					FROM t_zone z
						inner join tbl_zone_rcpt_node zrn on z.wh_id = zrn.wh_id and zrn.zone = z.zone
						INNER JOIN tbl_gwy_node gn ON gn.wh_id = zrn.wh_id AND gn.node = zrn.node
						inner join tbl_client_zone cz on z.wh_id = cz.wh_id
												and z.zone = cz.zone
						inner join ( select zla.wh_id,zla.zone,count(loc.location_id) as loc_qty,
										sum(case loc.status when 'E' then 1 else 0 end) as emp_qty
										from t_location loc
										inner join t_zone_loca zla on loc.wh_id = zla.wh_id and loc.location_id = zla.location_id
										inner join t_zone z on zla.wh_id = z.wh_id
																and zla.zone = z.zone
									WHERE zla.wh_id = @wh_id
									AND z.zone_type = @zone_type
									and isnull(z.vip_flag,'S') = 'V'
									--and loc.status = 'E'
									group by zla.wh_id,zla.zone) zuq 
									on z.wh_id = zuq.wh_id and z.zone = zuq.zone
					WHERE z.wh_id = @wh_id
					AND z.zone_type = @zone_type
					and cz.client_code = @client_code
					and isnull(z.case_flag,'N') = @caseflag
					and isnull(z.vip_flag,'S') = 'V'
					and ISNULL(z.status,'A') = 'A'
					--and gn.[loop] = @conveyor_loop
					order by (case when gn.[loop] = @conveyor_loop then 0 else 1 end),cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float) desc, z.zone
				END
			ELSE
				BEGIN
					SELECT TOP 1 @suggest_zone = z.zone
								--,@usage = isnull(zuq.emp_qty,0)/ztq.loc_qty
								,@usage = cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float)
								,@node = gn.node
					FROM t_zone z
						inner join tbl_zone_rcpt_node zrn on z.wh_id = zrn.wh_id and zrn.zone = z.zone
						INNER JOIN tbl_gwy_node gn ON gn.wh_id = zrn.wh_id AND gn.node = zrn.node
						inner join ( select zla.wh_id,zla.zone,count(loc.location_id) as loc_qty,
										sum(case loc.status when 'E' then 1 else 0 end) as emp_qty
										from t_location loc
										inner join t_zone_loca zla on loc.wh_id = zla.wh_id and loc.location_id = zla.location_id
										inner join t_zone z on zla.wh_id = z.wh_id
																and zla.zone = z.zone
									WHERE zla.wh_id = @wh_id
									AND z.zone_type = @zone_type
									and isnull(z.vip_flag,'S') = 'S'
									--and loc.status = 'E'
									group by zla.wh_id,zla.zone) zuq 
									on z.wh_id = zuq.wh_id and z.zone = zuq.zone
					WHERE z.wh_id = @wh_id
					AND z.zone_type = @zone_type
					and isnull(z.case_flag,'N')  = @caseflag
					and ISNULL(z.status,'A') = 'A'
					and isnull(z.vip_flag,'S') = 'S'
					--and gn.[loop] = @conveyor_loop
					order by (case when gn.[loop] = @conveyor_loop then 0 else 1 end),cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float) desc, z.zone
				END
			END

		--Get Zone for non-conveyor
		IF @conveyor_flag = 'N' or @suggest_zone is null
			BEGIN
				IF @zone_type = 'BV' OR @zone_type = 'CV' or @vip_flag = 'V'
					BEGIN
						SELECT top 1 @client_code = itm.client_code
						FROM t_stored_item sto
							inner join t_item_master itm on sto.wh_id = itm.wh_id
														and sto.item_number = itm.item_number
						WHERE sto.wh_id = @wh_id
						AND sto.hu_id = @hu_id

						SELECT TOP 1 @suggest_zone = z.zone
									,@usage = cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float)
						FROM t_zone z
							inner join tbl_client_zone cz on z.wh_id = cz.wh_id
													and z.zone = cz.zone
							inner join ( select zla.wh_id,zla.zone,count(loc.location_id) as loc_qty,
										sum(case loc.status when 'E' then 1 else 0 end) as emp_qty
										from t_location loc
										inner join t_zone_loca zla on loc.wh_id = zla.wh_id and loc.location_id = zla.location_id
										inner join t_zone z on zla.wh_id = z.wh_id
																and zla.zone = z.zone
									WHERE zla.wh_id = @wh_id
									AND z.zone_type = @zone_type
									and isnull(z.vip_flag,'S') = 'V'
									--and loc.status = 'E'
									group by zla.wh_id,zla.zone) zuq 
									on z.wh_id = zuq.wh_id and z.zone = zuq.zone
						WHERE z.wh_id = @wh_id
						AND z.zone_type = @zone_type
						and cz.client_code = @client_code
						and isnull(z.case_flag,'N') = @caseflag
						and isnull(z.vip_flag,'S') = 'V'
						and ISNULL(z.status,'A') = 'A'
						order by cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float) desc, z.zone
					END
				ELSE
					BEGIN
						SELECT TOP 1 @suggest_zone = z.zone
									,@usage = cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float)
						FROM t_zone z
							inner join ( select zla.wh_id,zla.zone,count(loc.location_id) as loc_qty,
										sum(case loc.status when 'E' then 1 else 0 end) as emp_qty
										from t_location loc
										inner join t_zone_loca zla on loc.wh_id = zla.wh_id and loc.location_id = zla.location_id
										inner join t_zone z on zla.wh_id = z.wh_id
																and zla.zone = z.zone
									WHERE zla.wh_id = @wh_id
									AND z.zone_type = @zone_type
									and isnull(z.vip_flag,'S') = 'S'
									--and loc.status = 'E'
									group by zla.wh_id,zla.zone) zuq 
									on z.wh_id = zuq.wh_id and z.zone = zuq.zone
						WHERE z.wh_id = @wh_id
						AND z.zone_type = @zone_type
						and isnull(z.case_flag,'N')  = @caseflag
						and isnull(z.vip_flag,'S') = 'S'
						and ISNULL(z.status,'A') = 'A'
						order by cast(isnull(zuq.emp_qty,0) as float)/cast(zuq.loc_qty as float) desc, z.zone
					END
			END

	    IF @suggest_zone IS NULL OR @suggest_zone = ''
		BEGIN
			SET @passornot = 1
			SET @msg = 'Cannot find the zone.'
			rollback
			RETURN
		END
		ELSE
		BEGIN
			--Update t_hu_master
			UPDATE t_hu_master
			SET zone = @suggest_zone
				,reserved_for = @node
			WHERE wh_id = @wh_id
			AND hu_id = @hu_id

			SET @passornot = 0
			SET @msg = @node
			COMMIT		
			RETURN
		END

    END TRY

    BEGIN CATCH
        ROLLBACK
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END



