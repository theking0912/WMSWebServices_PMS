-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create  PROCEDURE [dbo].[csp_Move_Stock_For_Dps_bak] 
	-- Add the parameters for the stored procedure here
	@dpsPickId					AS  BIGINT,
	@in_wh_id					AS	NVARCHAR(30),
	@in_order_number			AS	NVARCHAR(30),
	@in_hu_id					AS	NVARCHAR(30),
	@in_put_location			AS	NVARCHAR(30),
	@in_item_number				AS	NVARCHAR(30),
	@in_uom						AS	NVARCHAR(20),
	@in_qty						AS	FLOAT,
	@out_msg					AS	NVARCHAR(200),
	@out_passornot				AS	INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @pick_id				BIGINT
	DECLARE @lot_number				NVARCHAR(30)
	DECLARE @stored_attribute_id	NVARCHAR(30)
	DECLARE @expiration_date		DATETIME
	DECLARE @type					BIGINT
	DECLARE @source_location		BIGINT
	DECLARE @picked_qty				FLOAT
	DECLARE @remove__qty			FLOAT
	DECLARE @damage_flag			NVARCHAR(1)
	DECLARE @put_hu_id				NVARCHAR(30)

	DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg

	BEGIN TRY

		BEGIN TRANSACTION

		SELECT @lot_number = lot_number,
			   @stored_attribute_id = stored_attribute_id,
			   @expiration_date = expiration_date,
			   @type = type,
			   @source_location = location_id,
			   @damage_flag = damage_flag
			FROM t_stored_item 
			WHERE wh_id = @in_wh_id
			 AND hu_id = @in_hu_id
			 AND type <> 0

		SELECT @picked_qty = conversion_factor * @in_qty
				FROM t_item_uom WITH(NOLOCK)
			WHERE wh_id = @in_wh_id
				AND item_number = @in_item_number
				AND uom = @in_uom
	

		UPDATE t_pick_detail
				SET loaded_quantity = loaded_quantity + @picked_qty
					,status = CASE WHEN planned_quantity = loaded_quantity + @picked_qty THEN 'LOADED'
								ELSE status END
					WHERE pick_id = @type

		SET @put_hu_id = @in_order_number + '-' + @in_put_location
	
		--Move the stock to fork
		EXEC [dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @in_wh_id,
				@in_vchItemNumber = @in_item_number,
				@in_vchLocationID = @in_put_location,
				@in_nType = @type,
				@in_vchHUID = @put_hu_id,
				@in_vchLotNumber = @lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @picked_qty,
				@in_dtFifoDate = NULL,
				@in_dtExpirationDate = @expiration_date,
				@in_vchHUType = 'SO',
				@in_vchShipmentNumber = @in_order_number,
				@in_damage_flag = @damage_flag,
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT

		SET @remove__qty = @picked_qty * -1

		--ReMove the stock to fork
		EXEC [dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @in_wh_id,
				@in_vchItemNumber = @in_item_number,
				@in_vchLocationID = @source_location,
				@in_nType = @type,
				@in_vchHUID = @in_hu_id,
				@in_vchLotNumber = @lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @remove__qty,
				@in_dtFifoDate = NULL,
				@in_dtExpirationDate = @expiration_date,
				@in_vchHUType = 'SO',
				@in_vchShipmentNumber = NULL,
				@in_damage_flag = @damage_flag,
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT

		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],location_id,[location_id_2],[hu_id],[item_number],[lot_number],[tran_qty])
			values('201','Move(Pick)',getdate(),getdate(),getdate(),getdate(),'PTW',@in_order_number,null,
			@in_wh_id,@source_location,null,@in_hu_id,@in_item_number,@lot_number,@picked_qty)

		INSERT INTO t_tran_log_holding
		([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
		,[wh_id],location_id,[location_id_2],[hu_id],[item_number],[lot_number],[tran_qty])
		values('202','Move(Put)',getdate(),getdate(),getdate(),getdate(),'PTW',@in_order_number,null,
		@in_wh_id,@in_put_location,NULL,@put_hu_id,@in_item_number,@lot_number,@picked_qty)
		 if not exists(select 1 from work_pointer where PointerName='DpsPick')
			insert work_pointer(PointerName) select 'DpsPick'
			update work_pointer set PointerId=@dpsPickId where PointerName='DpsPick' and PointerId<@dpsPickId
		COMMIT
		SET @out_passornot = 0
		RETURN
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION
		END
		SET @out_passornot = 1
		SET @out_msg = ERROR_MESSAGE()
		RETURN
	END CATCH
END
