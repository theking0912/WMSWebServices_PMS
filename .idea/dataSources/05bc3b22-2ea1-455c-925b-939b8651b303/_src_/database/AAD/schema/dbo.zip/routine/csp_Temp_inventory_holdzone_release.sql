


CREATE PROCEDURE [dbo].[csp_inventory_holdzone_release]
    @in_vchWhID                  NVARCHAR(10),
    @in_vchItemNumber            NVARCHAR(30),
    @in_vchLocationID            NVARCHAR(50),
    @in_nType                    BIGINT,
    @in_vchHUID                  NVARCHAR(22),
    @in_vchLotNumber             NVARCHAR(15),
    @in_nStoredAttributeID       BIGINT,
    @in_vchStatus                NCHAR(1) = N'A',
    @in_vchReasonCode			 NVARCHAR(10),					
    @in_vchEmpID				 NVARCHAR(255),
    @out_vchCode                 uddt_output_code   OUTPUT,
    @out_vchMsg                  uddt_output_msg    OUTPUT
 
AS

-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                            HighJump Software
--                        Minneapolis, Minnesota, USA
-- ********************************************************************************
-- 
--    PURPOSE:
--          The purpose of this stored procedure is to adjust inventory.
--
--    INPUT:
--
--    OUTPUT:
--        out_vchCode - Contains 'SUCCESS' or Error Code.
--        out_vchMsg - Contains the error message or informational log message.
--      
--  TARGET: SQL Server
--
-- *********************************************************************************
DECLARE
    -- Error handling variables
    @c_vchObjName                   uddt_obj_name,  -- The name that uniquely tags this object.
    @v_vchCode                      uddt_output_code,
    @v_vchMsg                       uddt_output_msg,
    @v_nSysErrorNum                 INT,

    -- Local Variables
    @v_nRowCount 					INT,
    @v_nHoldCount					INT,
	@v_dDateCreated					DATETIME

    -- Set Constants
    SET @c_vchObjName = N'usp_inventory_holdzone_release'   
    SET @v_vchCode = N'SUCCESS'
    SET @v_vchMsg  = N'NONE'
    SET @v_nSysErrorNum = 0
	SET @v_dDateCreated = GETDATE()
        
    SET NOCOUNT ON
	
-----------------------------------------------------------------------------------
--                  Get HLD Record Count
-----------------------------------------------------------------------------------  

SELECT @v_nHoldCount = ISNULL(COUNT(1), 0)
  FROM t_holds
 WHERE wh_id       = @in_vchWhID
   AND item_number = @in_vchItemNumber
   AND location_id = @in_vchLocationID
   AND type        = @in_nType
   AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'') = ISNULL(@in_vchHUID,'')))
   AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'') = ISNULL(@in_vchLotNumber,'')))
   AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'') = ISNULL(@in_nStoredAttributeID,'')))    
   AND reason_id = @in_vchReasonCode	


-----------------------------------------------------------------------------------
--                  If it is a Hold request and there are already records
--					for the quantam of inventory - no inventory updates required
-----------------------------------------------------------------------------------     
IF (@v_nHoldCount > 0 AND @in_vchStatus = N'H') BEGIN
	GOTO EXIT_LABEL
END	
ELSE IF (@v_nHoldCount > 0 AND @in_vchStatus = N'A') BEGIN
-----------------------------------------------------------------------------------
--                  Update Inventory and Delete HLD record
--					only if the request is a Release
-----------------------------------------------------------------------------------  
BEGIN TRY	

	DELETE FROM t_holds
	 WHERE wh_id       = @in_vchWhID
	   AND item_number = @in_vchItemNumber
	   AND location_id = @in_vchLocationID
	   AND type        = @in_nType
	   AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'') = ISNULL(@in_vchHUID,'')))
	   AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'') = ISNULL(@in_vchLotNumber,'')))
	   AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'') = ISNULL(@in_nStoredAttributeID,'')))    
	   AND reason_id = @in_vchReasonCode		
END TRY	   
   
BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
    SET @v_vchCode = N'-20001'
    SET @v_vchMsg = N'A SQL error occured while attempting to delete HLD records.'
    GOTO ERROR_HANDLER
END CATCH

-----------------------------------------------------------------------------------
--                  If no HLD record exists for the quantum of Inventory
--					Update Inventory status or else skip updating status
-----------------------------------------------------------------------------------  
	IF EXISTS(
		SELECT 1
		  FROM t_holds
		 WHERE wh_id       = @in_vchWhID
		   AND item_number = @in_vchItemNumber
		   AND location_id = @in_vchLocationID
		   AND type        = @in_nType
		   AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'') = ISNULL(@in_vchHUID,'')))
		   AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'') = ISNULL(@in_vchLotNumber,'')))
		   AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'') = ISNULL(@in_nStoredAttributeID,'')))
		) BEGIN
		
		GOTO EXIT_LABEL
	END 
		
	GOTO UPDATE_INVENTORY
	
END

-----------------------------------------------------------------------------------
--                  Insert HLD Record if there are no records 
-- 					            for the reason code
-----------------------------------------------------------------------------------  
IF @in_vchStatus ='H' BEGIN
	BEGIN TRY	

		INSERT INTO t_holds
			(item_number, wh_id, lot_number, stored_attribute_id, hu_id, reason_id, date_created, employee_id, type, location_id)
		SELECT
			@in_vchItemNumber, @in_vchWhID, @in_vchLotNumber, @in_nStoredAttributeID, @in_vchHUID, @in_vchReasonCode, @v_dDateCreated, @in_vchEmpID, @in_nType, @in_vchLocationID
			
	END TRY

	BEGIN CATCH    
		SET @v_nSysErrorNum = ERROR_NUMBER()
		SET @v_vchCode = N'-20002'
		SET @v_vchMsg = N'A SQL error occured while attempting to insert HLD records.'
		GOTO ERROR_HANDLER
	END CATCH
END


-----------------------------------------------------------------------------------
--                  Update STO Record
-----------------------------------------------------------------------------------  

UPDATE_INVENTORY:
BEGIN TRY
    UPDATE t_stored_item
        SET unavailable_qty = CASE WHEN @in_vchStatus = N'H' THEN actual_qty ELSE 0 END
          ,status          = @in_vchStatus
    WHERE wh_id          = @in_vchWhID
        AND item_number = @in_vchItemNumber
        AND location_id = @in_vchLocationID
        AND type        = @in_nType
        AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'') = ISNULL(@in_vchHUID,'')))
        AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'') = ISNULL(@in_vchLotNumber,'')))
        AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'') = ISNULL(@in_nStoredAttributeID,'')))    
        AND status     <> @in_vchStatus
       
    SET @v_nRowCount = @@ROWCOUNT
END TRY

BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
    SET @v_vchCode = N'-20003'
    SET @v_vchMsg = N'A SQL error occured while attempting to update STO records.'
    GOTO ERROR_HANDLER
END CATCH

-----------------------------------------------------------------------------------
--                  Update HUM Record
-----------------------------------------------------------------------------------  
IF @v_nRowCount > 0 AND @in_vchLocationID IS NOT NULL 
BEGIN
    IF @in_vchStatus = N'H' AND EXISTS (SELECT N'TRUE' 
                                    FROM t_stored_item
                                   WHERE wh_id = @in_vchWhID
                                     AND location_id = @in_vchLocationID
                                     AND status <> N'H')
    SET @in_vchStatus = N'A'

    BEGIN TRY
        UPDATE t_location 
            SET status = @in_vchStatus
        WHERE wh_id = @in_vchWhID
            AND location_id = @in_vchLocationID
            AND status <> @in_vchStatus       
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
        SET @v_vchCode = N'-20004'
        SET @v_vchMsg = N'A SQL error occured while attempting to update STO records.'
        GOTO ERROR_HANDLER
    END CATCH


	
    BEGIN TRY
        UPDATE t_zone 
            SET status = @in_vchStatus
        WHERE wh_id = @in_vchWhID
            AND zone in (select zone from t_zone_loca where location_id= @in_vchLocationID)
            AND (status <> @in_vchStatus or status is null)
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
        SET @v_vchCode = N'-20004'
        SET @v_vchMsg = N'A SQL error occured while attempting to update STO records.'
        GOTO ERROR_HANDLER
    END CATCH
END

GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + N'Deadlock error: 40001 ' 
                    + @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE() + N'.'
    ELSE    
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + @v_vchMsg
                    + N' SQL Error = ' + ERROR_MESSAGE() + N'.'

    RAISERROR(@v_vchMsg, 11, 1)
   
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

	-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

    -- Always leave the stored procedure from here.
    RETURN


