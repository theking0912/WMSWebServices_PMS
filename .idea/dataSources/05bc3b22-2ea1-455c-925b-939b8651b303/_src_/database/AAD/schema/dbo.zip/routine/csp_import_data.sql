-- ======================================= 
--
-- Description: 

--January 2015 ADD by Jerry
-- =======================================


CREATE PROCEDURE [dbo].[csp_import_data]
@in_number           NVARCHAR(100),
@in_vchWhID              NVARCHAR(10),
@out_vchMsg             NVARCHAR(200) OUTPUT
AS

DECLARE

    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER,
	@v_nSequence            INTEGER,

	@v_vchPoType            NVARCHAR(10),
	@v_vchItemNumber        NVARCHAR(30),
	@n_vchDescription       NVARCHAR(60),
	@n_vchUom               NVARCHAR(10),
	@in_fQty                FLOAT,  
	@v_LineNumber           INTEGER,
	@v_vchClientCode        NVARCHAR(30),
	@v_vchPo                NVARCHAR(30),
	@v_customer				NVARCHAR(50),
	@v_customer_id			INT ,
	@v_vendor_id				NVARCHAR(50),
	@v_vendor				NVARCHAR(50),
	@v_cnt					INT,
	@v_cnt1					INT ,
	@client_code			NVARCHAR(50),
	@uom					NVARCHAR(50)

    SET @v_vchPoType = 'OMO'
	SET @v_nSequence = 0
	SET @client_code = @in_vchWhID

    SET NOCOUNT ON

	BEGIN TRANSACTION

	IF @in_number = N'主档导入'
    --WHILE ( 1 = 1 )
        BEGIN
		   
    --        SELECT TOP 1 @in_number= item_number
		  --    FROM    tbl_imp_item_master WITH ( NOLOCK )
			 --GROUP BY item_number
			 --ORDER BY item_number
				 
    --        SELECT  @v_nRowCount = @@ROWCOUNT
    --        IF @v_nRowCount = 0
    --            BEGIN
    --              BREAK
    --            END
	      
		  UPDATE tbl_imp_item_master
			SET youxq = RTRIM(LTRIM(youxq)),
			discount_flag = RTRIM(LTRIM(discount_flag)),
			expiration_date_control = RTRIM(LTRIM(expiration_date_control)),
			information_collection_id = RTRIM(LTRIM(information_collection_id)),
			stock_flag = RTRIM(LTRIM(stock_flag)),
			pick_type = RTRIM(LTRIM(pick_type)),
			pack_flag = RTRIM(LTRIM(pack_flag)),
			ed_flag =RTRIM(LTRIM(ed_flag)),
			tihi_level =RTRIM(LTRIM(tihi_level)),
			tihi_qty = RTRIM(LTRIM(tihi_qty)),
			zone_group =RTRIM(LTRIM(zone_group))

		  UPDATE t_item_master 
            SET shelf_life=t2.youxq,
				discount_flag = t2.discount_flag,
				expiration_date_control=t2.expiration_date_control,
				stock_flag = t2.stock_flag,
				pick_type = t2.pick_type,
				pack_flag = t2.pack_flag,
				ed_flag = t2.ed_flag,
				new_flag = 'N',
				pack_pos =  t2.pack_pos,
				storage_type = t2.zone_group,
				information_collection_id = CASE WHEN t2.information_collection_id ='A' THEN 30 
											WHEN t2.information_collection_id ='C'THEN 32 
											WHEN t2.information_collection_id ='AC' THEN 33 
											ELSE NULL END
	 
			FROM  tbl_imp_item_master as t2
		   WHERE t_item_master.item_number = t2.item_number
		     AND t_item_master.wh_id = t2.wh_id
			 AND t_item_master.client_code = t2.client_code

        END 

	IF @in_number = N'代收代发主档导入'
	  BEGIN
	    UPDATE tbl_imp_item_master_3pl
			SET youxq = RTRIM(LTRIM(youxq)),
			discount_flag = RTRIM(LTRIM(discount_flag)),
			expiration_date_control = RTRIM(LTRIM(expiration_date_control)),
			information_collection_id = RTRIM(LTRIM(information_collection_id)),
			stock_flag = RTRIM(LTRIM(stock_flag)),
			pick_type = RTRIM(LTRIM(pick_type)),
			pack_flag = RTRIM(LTRIM(pack_flag)),
			ed_flag =RTRIM(LTRIM(ed_flag)),
			tihi_level =RTRIM(LTRIM(tihi_level)),
			tihi_qty = RTRIM(LTRIM(tihi_qty)),
			zone_group =RTRIM(LTRIM(zone_group))

	    WHILE ( 1 = 1 )
        BEGIN
		   
            SELECT TOP 1 @in_number= item_number
		      FROM    tbl_imp_item_master_3pl WITH ( NOLOCK )
			 GROUP BY item_number
			 ORDER BY item_number

		    SELECT  @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0
                BEGIN
                  BREAK
                END

			IF EXISTS(SELECT 1 FROM dbo.t_item_master WHERE item_number = @in_number AND wh_id =@in_vchWhID)
			BEGIN
			  UPDATE t_item_master 
				SET shelf_life=t2.youxq,
					discount_flag = t2.discount_flag,
					expiration_date_control=t2.expiration_date_control,
					stock_flag = t2.stock_flag,
					pick_type = t2.pick_type,
					pack_flag = t2.pack_flag,
					ed_flag = t2.ed_flag,
					new_flag = 'N',
					pack_pos =  t2.pack_pos,
					storage_type = t2.zone_group,
					information_collection_id = CASE WHEN t2.information_collection_id ='A' THEN 30 
												WHEN t2.information_collection_id ='C'THEN 32 
												WHEN t2.information_collection_id ='AC' THEN 33 
												ELSE NULL END
	 
				FROM  tbl_imp_item_master_3pl as t2
			   WHERE  t_item_master.item_number = t2.item_number
				 AND  t_item_master.wh_id = t2.wh_id
				 AND  t_item_master.client_code = t2.client_code
				 AND  t_item_master.item_number = @in_number
				 AND  t_item_master.wh_id =@in_vchWhID

			END
			ELSE
            BEGIN
              INSERT INTO dbo.t_item_master
                      ( item_number ,
                        description ,
                        uom ,
                        inventory_type ,
                        shelf_life ,
                        price ,
                        std_hand_qty ,
                        inspection_code ,
                        serialized ,
                        lot_control ,
                        wh_id ,
                        reorder_point ,
                        reorder_qty ,
                        last_count_date ,
                        comment_flag ,
                        ver_flag ,
                        unit_weight ,
                        tare_weight ,
                        unit_volume ,
                        nested_volume ,
                        pick_put_id ,
                        length ,
                        width ,
                        height ,
                        sample_rate ,
                        expiration_date_control ,
                        attribute_collection_id ,
                        display_item_number ,
                        client_code ,
                        storage_type ,
                        discount_flag ,
                        pick_type ,
                        stock_flag ,
                        pack_flag ,
                        ed_flag ,
                        new_flag ,
                        information_collection_id ,
                        nostock_flag ,
                        item_status ,
                        pack_pos ,
                        barcode_start ,
                        barcode_length ,
                        barcode_rate ,
                        barcode_weight_length
                      )
              SELECT item_number ,
					 descripiton,
					 uom,
					 N'FG',
					 youxq,
					 0,
					 0,
					 N'N',
					 N'N',
					 N'N',
					 wh_id,
					 0,
					 0,
					 GETDATE(),
					 N'N',
					 N'N',
					 0,
					 0,
					 0,
					 0,
					 N'Default',
					 0,
					 0,
					 0,
					 0,
					 expiration_date_control,
					 NULL,
					 item_number,
					 client_code,
					 zone_group,
					 discount_flag,
					 pick_type,
					 stock_flag,
					 pack_flag,
					 ed_flag,
					 'N',
					 information_collection_id,
					 'T',
					 N'ACTIVE',
					 pack_pos,
					 barcode_start,
					 barcode_length,
					 barcode_rate,
					 barcode_weight_length
				from tbl_imp_item_master_3pl
			   WHERE item_number = @in_number
			     AND wh_id = @in_vchWhID

			  
			END

			DELETE FROM tbl_imp_item_master_3pl WHERE item_number =@in_number AND wh_id =@in_vchWhID
		END

	  END

	IF @in_number=N'代收代发商品单位导入'
	  BEGIN
	     WHILE ( 1 = 1 )
		 BEGIN
		   SELECT TOP 1 @in_number= item_number,@uom = uom
		      FROM    tbl_imp_item_uom WITH ( NOLOCK )
			 GROUP BY item_number,uom
			 ORDER BY item_number,uom

		    SELECT  @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0
                BEGIN
                  BREAK
                END

		   IF NOT EXISTS(SELECT 1 FROM t_item_uom WHERE item_number = @in_number AND uom =@uom AND wh_id =@in_vchWhID)
		   AND EXISTS(SELECT 1 FROM dbo.t_item_master WHERE item_number = @in_number AND wh_id =@in_vchWhID
		   AND new_flag = 'N')
		   BEGIN
		     INSERT INTO dbo.t_item_uom
		             ( item_number ,
		               wh_id ,
		               uom ,
		               conversion_factor ,
		               package_weight ,
		               units_per_layer ,
		               layers_per_uom ,
		               uom_weight ,
		               pickable ,
		               box_type ,
		               length ,
		               width ,
		               height ,
		               no_overhang_on_top ,
		               stack_code ,
		               batch ,
		               use_orientation_data ,
		               turnable ,
		               on_bottom_ok ,
		               on_side_ok ,
		               on_end_ok ,
		               bottom_only ,
		               top_only ,
		               max_in_layer ,
		               max_support_weight ,
		               stack_index ,
		               container_value ,
		               load_separately ,
		               nesting_height_increase ,
		               nested_volume ,
		               unit_volume ,
		               pattern ,
		               priority ,
		               status ,
		               uom_prompt ,
		               default_receipt_uom ,
		               default_pick_uom ,
		               class_id ,
		               pick_put_id ,
		               conveyable ,
		               std_hand_qty ,
		               min_hand_qty ,
		               max_hand_qty ,
		               default_pick_area ,
		               pick_location ,
		               display_config ,
		               vas_profile ,
		               cartonization_flag ,
		               gtin ,
		               shippable_uom ,
		               units_per_grab
		             )
				SELECT item_number,
					   wh_id,
					   uom,
					   conversion_factor,
					   0,
					   units_per_layer,
					   layers_per_uom,
					   0,
					   N'Y',
					   1,
					   1,
					   1,
					   1,
					   0,
					   -1,
					   0,
					   0,
					   1,
					   0,
					   0,
					   0,
					   0,
					   0,
					   1,
					   1,
					   0,
					   0,
					   0,
					   0,
					   0,
					   0,
					   N'STANDARD',
					   1,
					   N'ACTIVE',
					   uom_prompt,
					   N'NO',
					   N'NO',
					   NULL,
					   CASE WHEN (SELECT expiration_date_control FROM dbo.t_item_master WHERE item_number =@in_number
					   AND wh_id = @in_vchWhID) = N'Y' THEN N'Default' ELSE 'FIFO'END,
					   N'YES',
					   0,
					   0,
					   0,
					   NULL,
					   NULL,
					   CASE WHEN units_per_layer IS NOT NULL THEN 'YES' ELSE 'NO' END,
					   NULL,
					   N'NO',
					   NULL,
					   N'N',
					   0
				  FROM tbl_imp_item_uom 
				 WHERE item_number = @in_number AND wh_id = @in_vchWhID

		   END

		 END

	  END







		IF @out_vchMsg IS NULL 
			BEGIN
				--SET @out_vchMsg = '数据插入成功'

				COMMIT TRANSACTION
			END
		ELSE
		  BEGIN
		   
			 GOTO ErrorHandler
		  END

ErrorHandler:
    RAISERROR(@out_vchMsg,0,0)
    IF @@TRANCOUNT > 0   
	BEGIN
		ROLLBACK TRANSACTION
	END
