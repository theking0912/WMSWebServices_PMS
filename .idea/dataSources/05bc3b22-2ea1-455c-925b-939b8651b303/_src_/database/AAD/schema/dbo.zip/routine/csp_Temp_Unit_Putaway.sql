-- =======================================    
-- Author: Tony.chen    
-- Create Date: 11 Nov 2013    
-- Description: Get return slot for receipt
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Unit_Putaway]    
     @wh_id					NVARCHAR(10)    
    ,@item_number			NVARCHAR(30)  
	,@lot_number			NVARCHAR(30)
	,@stored_attribute_id	NVARCHAR(30)
	,@qty					float
	,@source_hu_id			NVARCHAR(30)
	,@source_location		NVARCHAR(30)
	,@dest_hu_id			NVARCHAR(30)
	,@start_loc				NVARCHAR(30)
	,@end_loc				nvarchar(30)
	,@user_id				nvarchar(30)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    
	
	BEGIN TRY
		BEGIN TRANSACTION
		--Cancel the stock from the source LP
		UPDATE t_stored_item
		SET actual_qty = actual_qty - @qty
		WHERE wh_id = @wh_id
		and location_id = @source_location
		and hu_id = @source_hu_id
		and item_number = @item_number
		and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
		and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))

		/*
		  INSERT INTO t_hu_master(wh_id, hu_id, location_id, type, status, control_number)
                    VALUES (@in_vchWhID, @in_vchHUID, @in_vchLocationID, @in_vchHUType, 'A', @in_vchShipmentNumber) */

		--add the stock for destincation location
		IF EXISTS ( SELECT 1 FROM t_stored_item
					WHERE wh_id = @wh_id
					and location_id = @source_location
					and (hu_id = @dest_hu_id  or @dest_hu_id is null)
					and item_number = @item_number
					and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
					and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null)))
			BEGIN
				UPDATE t_stored_item
				SET actual_qty = actual_qty + @qty
				WHERE wh_id = @wh_id
				and location_id = @start_loc
				and (hu_id = @dest_hu_id  or @dest_hu_id is null)
				and item_number = @item_number
				and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
				and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
			END
		ELSE
			BEGIN
				 INSERT INTO t_stored_item(
					wh_id, item_number, location_id, type, hu_id, lot_number, stored_attribute_id, 
					actual_qty, unavailable_qty, status, fifo_date, expiration_date, sequence,
					shipment_number)
				VALUES(
					@wh_id, @item_number, @start_loc, 0, @dest_hu_id, 
					@lot_number, @stored_attribute_id, @qty, 0, N'A', getdate(), GETDATE(), 0,
					NULL)  
			END

		--delete t_stored_item whose actual_qty = 0
		DELETE FROM t_stored_item
		WHERE wh_id = @wh_id
		and location_id = @source_location
		and hu_id = @source_hu_id
		and item_number = @item_number
		and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
		and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
		AND actual_qty = 0
		
		--delete t_hu_master which no stock
		DELETE FROM t_hu_master
		WHERE  wh_id = @wh_id
		and hu_id = @source_hu_id
		and not exists ( select 1 from t_stored_item sto
						WHERE sto.wh_id = @wh_id
						and sto.hu_id = t_hu_master.hu_id)

		--insert into t_tran_log
			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty],wh_id_2,location_id_2,hu_id_2
				,generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11)
			VALUES
				('125','Return Receipt',getdate(),getdate(),getdate(),getdate(),@user_id,'',''
				,@wh_id,@source_location,@source_hu_id,@item_number,@lot_number,@qty,@wh_id,@start_loc,@dest_hu_id
				,(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
				)




		COMMIT
		SET @passornot = 0
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END
