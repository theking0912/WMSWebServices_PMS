
CREATE VIEW v_al_host_order_detail_comment AS
SELECT
host_order_detail_comment_id,
host_group_id,
record_create_date,
processing_code,
wh_id,
order_number,
comment_type,
line_number,
item_number,
comment_sequence,
comment_date,
comment_text
  FROM t_al_host_order_detail_comment
