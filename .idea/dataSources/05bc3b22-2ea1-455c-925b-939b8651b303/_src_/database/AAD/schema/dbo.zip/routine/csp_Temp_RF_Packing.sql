CREATE PROCEDURE [dbo].[csp_RF_Packing]    
     @wh_id				NVARCHAR(10),  
     @fork_location		NVARCHAR(30),
	 @dest_location     NVARCHAR(30),
	 @conveyor		    NVARCHAR(10),
	 @user_id           NVARCHAR(10),   
	 @passornot			INT output,			--0:PASS, 1: FAIL
	 @msg				NVARCHAR(200) output
as    
begin    
    -- set nocount on added to prevent extra result sets from    
    set nocount on;    

	begin try
		begin transaction
		SET @passornot = 0
		SET @msg = ''
		declare @order_number nvarchar(20)
		declare @node nvarchar(30)
		declare @route nvarchar(30)
		declare @event_data   nvarchar(max)
		declare @event_data1  nvarchar(max)
		declare @dept  nvarchar(11)
		declare @carrier  nvarchar(30)
		declare @dest_staging_loc nvarchar(30)
		declare @hu_count int
		declare @loc_type nvarchar(30)
		declare @hu_type nvarchar(10)
		declare @pkd_status nvarchar(20)
		declare @shipping_label nvarchar(30)
		declare @rec_count	INT
		
		SELECT TOP 1 @shipping_label = hu_id
		FROM t_hu_master
		WHERE wh_id = @wh_id
		AND location_id = @fork_location
		order by hu_id

		WHILE (@@ROWCOUNT > 0)
			BEGIN
				SELECT @order_number = order_number,@carrier=carrier ,@route = [route]
				FROM tbl_shipping_label sl 
				WHERE wh_id = @wh_id
				AND   ship_label_barcode = @shipping_label

				IF  @conveyor='Y'
					BEGIN
						SELECT TOP 1  @node = snr.node, @hu_count = isnull(hu_count,0)
						FROM tbl_ship_node_route snr
								LEFT JOIN ( SELECT wh_id,location_id,count(hu_id) hu_count FROM t_hu_master
											WHERE wh_id = @wh_id
											GROUP BY wh_id,location_id
											) hum ON snr.wh_id = hum.wh_id
													AND snr.node = hum.location_id
						WHERE snr.carrier = @carrier
						and snr.[route] = @route
						and snr.wh_id = @wh_id
						ORDER BY isnull(hu_count,0) 

						SET @dest_staging_loc = @node
					END
				ELSE
					BEGIN
						SET @dest_staging_loc = @dest_location
					END

				SELECT @loc_type = type
				FROM t_location 
				WHERE wh_id = @wh_id
				AND location_id = @dest_staging_loc

				IF @loc_type = 'D'
					BEGIN
						SET @hu_type = 'LO'
						SET @pkd_status ='LOADED'
					END
				ELSE
					BEGIN
						SET @hu_type = 'SO'
						SET @pkd_status ='PACKED'
					END

				--Move
				UPDATE t_hu_master 
				SET location_id = @dest_staging_loc
					,load_id = @shipping_label
					,type =@hu_type
					,control_number = @order_number
					,reserved_for = @node
				WHERE wh_id = @wh_id
				AND hu_id = @shipping_label

				UPDATE t_stored_item
				SET location_id = @dest_staging_loc
				WHERE wh_id = @wh_id
				AND hu_id = @shipping_label

				--Update pkd
				UPDATE t_pick_detail
				SET packed_quantity = packed_quantity + (SELECT SUM(sto.actual_qty)
																FROM t_stored_item sto
																WHERE sto.wh_id = @wh_id
																AND sto.hu_id = @shipping_label
																and sto.type = t_pick_detail.pick_id)
					,loaded_quantity = loaded_quantity + (case @pkd_status when 'LOADED' THEN  (SELECT SUM(sto.actual_qty)
																FROM t_stored_item sto
																WHERE sto.wh_id = @wh_id
																AND sto.hu_id = @shipping_label
																and sto.type = t_pick_detail.pick_id)
																ELSE 0 END)
				WHERE wh_id = @wh_id
				AND order_number = @order_number
				AND EXISTS ( SELECT 1 FROM t_stored_item sto
							WHERE sto.wh_id = @wh_id
							AND sto.hu_id = @shipping_label
							and sto.type = t_pick_detail.pick_id)

				UPDATE t_pick_detail
				SET status =  case when planned_quantity = loaded_quantity then 'LOADED'
								   when planned_quantity = packed_quantity then 'PACKED'
								   ELSE status end
				WHERE wh_id = @wh_id
				AND order_number = @order_number
				AND EXISTS ( SELECT 1 FROM t_stored_item sto
							WHERE sto.wh_id = @wh_id
							AND sto.hu_id = @shipping_label
							and sto.type = t_pick_detail.pick_id)
				--
				update tbl_shipping_label set pack_type = 'H', status =@pkd_status
				where wh_id = @wh_id
				 and  ship_label_barcode = @shipping_label

				 -- update status of t_order 
				 IF @pkd_status = 'LOADED'
					BEGIN
						update t_order set status = 'LOADED' 
						where not exists (select 1 from t_pick_detail pkd
											where pkd.wh_id = t_order.wh_id
											and   pkd.order_number = t_order.order_number
											and   pkd.planned_quantity <> pkd.loaded_quantity)	
						AND wh_id = @wh_id
						and order_number = @order_number
					END
				ELSE
					BEGIN
						update t_order set status =@pkd_status 
						where not exists (select 1 from t_pick_detail pkd
											where pkd.wh_id = t_order.wh_id
											and   pkd.order_number = t_order.order_number
											and   pkd.planned_quantity <> pkd.packed_quantity)	
						AND wh_id = @wh_id
						and order_number = @order_number
					END
				--Insert into t_tran_log	
				INSERT INTO t_tran_log_holding
							([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
							,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
							,wh_id_2,location_id_2,hu_id_2
							,generic_attribute_1,
							generic_attribute_2,
							generic_attribute_3,
							generic_attribute_4,
							generic_attribute_5,
							generic_attribute_6,
							generic_attribute_7,
							generic_attribute_8,
							generic_attribute_9,
							generic_attribute_10,
							generic_attribute_11)
				SELECT '315','Packing',GETDATE(),GETDATE(),GETDATE(),GETDATE(),@user_id,@order_number,@shipping_label
					  ,@wh_id,@fork_location,sto.hu_id,sto.item_number,sto.lot_number, sto.actual_qty
					  ,@wh_id,@dest_staging_loc,@shipping_label,
					  (SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_1),    
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_2), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_3), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_4), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_5), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_6), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_7), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_8), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_9), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_10), 
    						(SELECT a.attribute_value 
    						FROM t_sto_attrib_collection_detail a,
								t_attribute_legacy_map alm
    						WHERE a.stored_attribute_id = sto.stored_attribute_id
    						AND a.attribute_id = alm.generic_attribute_11)
				FROM t_stored_item sto
				WHERE EXISTS ( SELECT 1 FROM t_pick_detail pkd
												WHERE pkd.wh_id = @wh_id
												AND pkd.order_number = @order_number
												AND pkd.pick_id = sto.[type])
				AND sto.wh_id = @wh_id
				AND sto.hu_id = @shipping_label
		
				IF @loc_type ='D' 
					BEGIN
					--Insert into t_tran_log	
					INSERT INTO t_tran_log_holding
								([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
								,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
								,wh_id_2,location_id_2,hu_id_2
								,generic_attribute_1,
								generic_attribute_2,
								generic_attribute_3,
								generic_attribute_4,
								generic_attribute_5,
								generic_attribute_6,
								generic_attribute_7,
								generic_attribute_8,
								generic_attribute_9,
								generic_attribute_10,
								generic_attribute_11)
					SELECT '322','Loading(Put)',GETDATE(),GETDATE(),GETDATE(),GETDATE(),@user_id,@order_number,@shipping_label
						  ,@wh_id,@fork_location,sto.hu_id,sto.item_number,sto.lot_number, sto.actual_qty
						  ,@wh_id,@dest_staging_loc,@shipping_label,
						  (SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_1),    
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_2), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_3), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_4), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_5), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_6), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_7), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_8), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_9), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_10), 
    							(SELECT a.attribute_value 
    							FROM t_sto_attrib_collection_detail a,
									t_attribute_legacy_map alm
    							WHERE a.stored_attribute_id = sto.stored_attribute_id
    							AND a.attribute_id = alm.generic_attribute_11)
					FROM t_stored_item sto
					WHERE EXISTS ( SELECT 1 FROM t_pick_detail pkd
									WHERE pkd.wh_id = @wh_id
									AND pkd.order_number = @order_number
									AND pkd.pick_id = sto.[type])
					AND sto.wh_id = @wh_id
					AND sto.hu_id = @shipping_label
				END

				if @conveyor='Y'
				begin
					--set @event_data = 'TRAN|CREA|'+@shipping_label+'|'+@node;
					--exec [ADV].[dbo].[usp_AdvAddEvent] 4,'SEND SORKET',@event_data,50

					SELECT @rec_count = COUNT(1)
						FROM tbl_out_socket_task
						WHERE lc_id = @shipping_label 
						AND status <> 'COMP'
						AND mode = 'CREA'
						AND msg_type = 'TRAN'
			
					if @rec_count = 0
					begin
						insert tbl_out_socket_msg_queue
							(type,mode,lc_id,node,create_date)
						values('TRAN','CREA',@shipping_label,@node,getdate())
					end
					else
					begin
						-- cancel the exists task
						insert tbl_out_socket_msg_queue
							(type,mode,lc_id,node,create_date)
						values('TRAN','CANC',@shipping_label,@node,getdate())

						-- create new task
						insert tbl_out_socket_msg_queue
							(type,mode,lc_id,node,create_date)
						values('TRAN','CREA',@shipping_label,@node,getdate())
					end
				end

				SELECT TOP 1 @shipping_label = hu_id
				FROM t_hu_master
				WHERE wh_id = @wh_id
				AND location_id = @fork_location
				order by hu_id
			END
		
		commit		
        return

    end try

    begin catch
        rollback
		SET @msg = ERROR_MESSAGE()
		   SET @passornot = 1
        return
    end catch  
end
