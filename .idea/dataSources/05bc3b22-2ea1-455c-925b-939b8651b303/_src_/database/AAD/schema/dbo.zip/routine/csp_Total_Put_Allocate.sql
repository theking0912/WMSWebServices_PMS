





-- =======================================    
-- Author: Bruce.yuan   
-- Create Date: 20160607
-- Description: Upd allocation qty
--  

-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Total_Put_Allocate]    
     @wh_id					NVARCHAR(10) 
	,@fork_id               Nvarchar(30)  
	,@hu_id                 NVARCHAR(30)
	,@Dest_loc              nvarchar(30)	
	,@Dest_HUID				nvarchar(30)	
	,@user_id				nvarchar(30)
	,@tran_type				nvarchar(20)
	,@tran_description		nvarchar(50)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @pick_id		     bigint
		DECLARE @order_number        NVARCHAR(30)
		DECLARE @item_number         NVARCHAR(30)
		DECLARE @lot_number          NVARCHAR(15)
		DECLARE @stored_attribute_id NVARCHAR(30)
		DECLARE @seq_id			     bigint
		DECLARE @id                  bigint
		DECLARE @location_id         nvarchar(30)
		DECLARE @actual_qty          float
		DECLARE @need_qty            float
		DECLARE @remove_qty		     float
		DECLARE @sorted_qty          float
		DECLARE @FifoDate            DATETIME
		DECLARE @expiration_date     DATETIME
		DECLARE	@out_vchCode         uddt_output_code
		DECLARE @out_vchMsg          uddt_output_msg
		DECLARE @type			     NVARCHAR(2)
		DECLARE @zone			     NVARCHAR(30)
		DECLARE @shipping_label      NVARCHAR(30)
		DECLARE @damage_flag		 NVARCHAR(1)
		DECLARE @subtype             NVARCHAR(10)
		--SET @remove_qty = @qty * -1	
		set @type = 'SO'

		CREATE TABLE #tmp_stored
		(
		  id                    INT IDENTITY(1,1) NOT NULL,
		  wh_id                 NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
		  item_number			NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
		  actual_qty            FLOAT  NULL  DEFAULT (0),
		  location_id           NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
		  lot_number            NVARCHAR(15)  COLLATE DATABASE_DEFAULT NULL ,
		  fifo_date             datetime,
		  expiration_date       datetime,
		  type                  bigint null,
		  hu_id                 nvarchar(30)      COLLATE DATABASE_DEFAULT NULL ,
		  stored_attribute_id   bigint null,
		  damage_flag           NVARCHAR(1)       COLLATE DATABASE_DEFAULT NULL ,
		  shipment_number       NVARCHAR(30)      COLLATE DATABASE_DEFAULT NULL ,
		)

		INSERT INTO #tmp_stored(wh_id,item_number,actual_qty,location_id,lot_number,fifo_date,expiration_date,hu_id,type,stored_attribute_id,damage_flag,shipment_number)
		SELECT wh_id,item_number,actual_qty,location_id,lot_number,fifo_date,expiration_date,hu_id,type,stored_attribute_id,damage_flag,shipment_number
		FROM t_stored_item WITH(NOLOCK)
		WHERE wh_id = @wh_id
		AND location_id = @fork_id
		AND hu_id = @hu_id
		ORDER BY wh_id,item_number


		BEGIN TRANSACTION
		--Get allocation information
		SET @id = 0
		WHILE(1=1)
		BEGIN
		   SELECT TOP 1 @id = id
		         ,@item_number = item_number
		         ,@actual_qty = actual_qty
				 ,@lot_number = lot_number
				 ,@FifoDate = fifo_date
				 ,@expiration_date = expiration_date
				 ,@type = type
				 ,@stored_attribute_id = stored_attribute_id
				 ,@damage_flag = damage_flag
				 ,@shipping_label = shipment_number
		   FROM #tmp_stored
		   WHERE wh_id = @wh_id
		   AND location_id = @fork_id
		   AND hu_id = @hu_id
		   AND id > @id
		   ORDER BY id

		   IF (@@ROWCOUNT = 0)
		   BEGIN
			  break
		   END

		   SELECT @subtype = subtype,
		          @zone = zone 
		   FROM t_hu_master 
		   WHERE wh_id = @wh_id 
		   AND hu_id = @hu_id

           SET @seq_id = 0
		   WHILE(1=1)
		   BEGIN
		       SELECT TOP 1 @order_number = allo.order_number
			          ,@pick_id = allo.pick_id
					  ,@seq_id = allo.seq_id
					  ,@sorted_qty = ISNULL(allo.picked_qty,0) - ISNULL(allo.sorted_qty,0)
			     FROM tbl_allocation allo,tbl_pick_list plt
				WHERE allo.wh_id = plt.wh_id
				  AND allo.seq_id = plt.seq_id
				  AND allo.user_assign = @user_id
				 --- AND (allo.user_assign = @user_id OR ISNULL(allo.user_assign,'')='')----MODIFY BY WILL 20160616
				  AND allo.wh_id = @wh_id
				  AND plt.shipping_label = @shipping_label
				  AND allo.item_number = @item_number
				  AND allo.lot_number = @lot_number
				  AND allo.status in ('A','C')
				  AND allo.allo_type = 'O'
				  AND ISNULL(allo.picked_qty,0) - ISNULL(allo.sorted_qty,0) > 0
				  AND allo.seq_id > @seq_id
				  ORDER BY allo.seq_id

				  IF (@@ROWCOUNT = 0 OR @actual_qty <= 0) 
				  BEGIN
				     BREAK
				  END

				  IF @sorted_qty <= @actual_qty
				  BEGIN
				    SET @need_qty = @sorted_qty
					SET @actual_qty = @actual_qty - @sorted_qty
				  END
				  ELSE
				  BEGIN
				  	SET @need_qty = @actual_qty
					SET @actual_qty = 0
				  END

                  SET @remove_qty = @need_qty * -1
				  --Remove the stock from fork
				  EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @fork_id,
						@in_nType = @type,
						@in_vchHUID = @hu_id,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @stored_attribute_id,
						@in_fQty = @remove_qty,
						@in_dtFifoDate =@FifoDate,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = N'SO',
						@in_vchShipmentNumber = @shipping_label,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT

               
				--Move the stock to Desc Location
				EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @Dest_loc,
						@in_nType = @pick_id,
						@in_vchHUID = @Dest_HUID,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @stored_attribute_id,
						@in_fQty = @need_qty,
						@in_dtFifoDate =@FifoDate,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = 'SO',
						@in_vchShipmentNumber =@order_number,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT


				--Create tran log
				--Insert t_tran_log_holding
				INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
					,wh_id_2,location_id_2,hu_id_2
					,generic_attribute_1,
					generic_attribute_2,
					generic_attribute_3,
					generic_attribute_4,
					generic_attribute_5,
					generic_attribute_6,
					generic_attribute_7,
					generic_attribute_8,
					generic_attribute_9,
					generic_attribute_10,
					generic_attribute_11)
				VALUES
					(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@user_id,@shipping_label,@pick_id
					,@wh_id,@fork_id,@hu_id,@item_number,@lot_number,@need_qty
					,@wh_id,@Dest_loc,@Dest_HUID
					,(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_1),    
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_2), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_3), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_4), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_5), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_6), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_7), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_8), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_9), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_10), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_11)
					)



					UPDATE tbl_allocation
					   SET sorted_qty = isnull(sorted_qty,0)+ @need_qty
					 WHERE wh_id = @wh_id 
					   AND seq_id = @seq_id
		   END


		   UPDATE t_hu_master 
		      SET control_number = @order_number
			    , subtype = @subtype
				, zone = @zone
		    WHERE wh_id = @wh_id
			  AND hu_id = @hu_id
		END
		
			
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN


    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    









