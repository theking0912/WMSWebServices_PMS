CREATE TRIGGER dbo.tr_item_master_insert ON dbo.t_item_master FOR INSERT AS 
BEGIN

DECLARE	
    -- Error handling variables
    @c_vchObjName               NVARCHAR(30),  -- The name that uniquely tags this object.
    @v_nSysErrorNum             INTEGER,
    @v_nRowCount                INTEGER,
    @v_vchCode                  NVARCHAR(30),
    @v_vchMsg                   NVARCHAR(1000),    

    -- Local Variables
    @v_vchClientCode            NVARCHAR(30),
    @v_vchDisplayItemNumber     NVARCHAR(30)

    -- Set Constants
    SET @c_vchObjName = 'tr_item_master_insert'

    SET NOCOUNT ON
  
    -- Get the new values.
    SELECT
        @v_vchClientCode = client_code,
        @v_vchDisplayItemNumber = display_item_number
    FROM
        inserted

    --Update item master
    IF @v_vchClientCode IS NULL OR @v_vchDisplayItemNumber IS NULL 
	BEGIN
		UPDATE itm
		     SET itm.client_code = ISNULL(itm.client_code, itm.wh_id),
			     itm.display_item_number = ISNULL(itm.display_item_number, itm.item_number) 
		FROM t_item_master itm
		INNER JOIN inserted ins
			ON itm.item_number = ins.item_number
		    AND itm.wh_id = ins.wh_id
	      
		 SELECT @v_nSysErrorNum = @@ERROR
		 IF @v_nSysErrorNum <> 0
		 BEGIN
			 SET @v_vchCode = '-20001'
			 SET @v_vchMsg = 'An error occured in trigger tr_item_master_insert while ' +
							'attempting update.'
			 GOTO ERROR_HANDLER
		 END
     END

GOTO EXIT_LABEL
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:

    SET @v_vchMsg = @c_vchObjName + ': [' + @v_vchCode + '] ' + @v_vchMsg
                          + ' SQL Error = ' + CONVERT(VARCHAR(30), ISNULL(@v_nSysErrorNum,0)) + '.'

    RAISERROR(@v_vchMsg, 11, 1)

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:
    RETURN
END
