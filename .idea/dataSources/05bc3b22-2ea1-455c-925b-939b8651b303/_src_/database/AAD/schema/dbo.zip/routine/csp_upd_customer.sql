-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE csp_upd_customer
	-- Add the parameters for the stored procedure here 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @c1		AS	NVARCHAR(40) = ''
	DECLARE @c2		AS	NVARCHAR(40)

	WHILE(1=1)
	BEGIN
		
	
		-- Insert statements for procedure here
		SELECT TOP 1 @c1=C1,@c2=C2
		FROM customer
		WHERE C1 > @c1
		 ORDER BY C1

		 IF @@rowcount = 0
		 BEGIN
			break;
		 END

		 UPDATE t_customer set short_name  = @c2
		 WHERE customer_code = @c1
	 END
END
