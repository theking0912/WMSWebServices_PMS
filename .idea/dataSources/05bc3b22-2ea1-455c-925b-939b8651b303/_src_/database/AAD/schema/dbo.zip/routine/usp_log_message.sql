 
CREATE PROCEDURE usp_log_message
    @in_nModule        INT,
    @in_nFileNum       INT,
    @in_nErrorNum      INT, 
    @in_nLogLevel      INT,
    @in_vchErrorMsg    NVARCHAR(MAX),
    @out_nObject       INT OUTPUT
AS
DECLARE
    -- Error handling and logging variables.    
    @v_vchCode     			 uddt_output_code,
    @v_nErrorNumber          INT,  
   	@v_vchMsg		   		 uddt_output_msg,
	--Local variable and constant
    @c_vchObjName 			 NVARCHAR(20),
	@v_vchLogMsg			 NVARCHAR(MAX)
    -- Log error constant	
	SET @c_vchObjName = N'usp_log_message'
	--log message	
	SET @v_vchLogMsg = 'Log Send: ' +
		CASE WHEN @in_nModule IS NOT NULL THEN '[Module ' + CAST(@in_nModule AS NVARCHAR(10)) + ']' ELSE '' END +
		CASE WHEN @in_nFileNum IS NOT NULL THEN ' [Object ' + CAST(@in_nFileNum AS NVARCHAR(38)) + ']' ELSE '' END +
		CASE WHEN @in_nErrorNum IS NOT NULL THEN ' [Error Number '+ CAST(@in_nErrorNum AS NVARCHAR(10)) + ']. ' ELSE '' END +	
		@in_vchErrorMsg
		
    SET NOCOUNT ON 
   
    BEGIN  TRY-- Write error to log   
		INSERT INTO t_logsend (
			log_datetime,			      
			log_level,
			log_message
		)
		VALUES (
			GETDATE(),					
			ISNULL(@in_nLogLevel, 3),
			@v_vchLogMsg
		)        
    END TRY	
	
	BEGIN CATCH 
		SET @v_vchCode = '-20004'
		SET @v_nErrorNumber = ERROR_NUMBER() 
		SET @v_vchMsg = N'An insert failed on table t_logsend.'
		SET @v_vchMsg = @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE()
		GOTO ERROR_HANDLER
	END CATCH 
	
    GOTO EXIT_LABEL

ERROR_HANDLER:
    IF @v_nErrorNumber = 1205 --Deadlock error
      SET @v_vchMsg = N'Procedure: '+ @c_vchObjName + N': '+ @v_vchCode + N': '+ N'Deadlock error: 40001 '+ @v_vchMsg	   
    ELSE          
	  SET @v_vchMsg = N'Procedure: '+ @c_vchObjName + N': '+ @v_vchCode + N': '+ N': '+ @v_vchMsg
	
     RAISERROR(@v_vchMsg, 11, 1)
	
    GOTO EXIT_LABEL

EXIT_LABEL:
    RETURN
