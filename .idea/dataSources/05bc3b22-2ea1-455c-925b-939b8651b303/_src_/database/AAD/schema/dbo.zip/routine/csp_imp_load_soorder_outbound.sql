

CREATE  PROCEDURE [dbo].[csp_imp_load_soorder_outbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id varchar(100),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG varchar(100)
AS
BEGIN
		/*
		//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //VBAK-VBELN	订单号
        //VBAK-AUART	订单类型
        //VBAK-KUNNR	客户编码
        //VBAK-AUDAT	订单日期
        //VBEP-EDATU    计划行日期
        //VBAK-VKORG	销售组织
        //VBAP-CMPRE	含税单价
        //VBAP-KZWI1	总金额

        //ZFLAG	        出入库标识
        //VBAP-POSNR	行号
        //VBAP-MATNR	物料号
        //VBAP-KWMENG	订单数量
        //VBAP-VRKME	订单单位
        //KONV-NETPR	净价
        //VBAP-KPEIN	价格单位
        //VBAP-WERKS	发货工厂
        //VBAP-UEBTO	过量交货
        //VBAP-UNTTO	交货不足
        //ABGRU         删除标注
		
		*/
		declare @ZPOSITION varchar(100)
        declare @VBELN varchar(100)
        declare @AUART varchar(100)
	 
        declare @KUNNR varchar(100)
		declare @KUNNR1 varchar(100)
        declare @AUDAT varchar(100)
		declare @EDATU varchar(100)

		declare @VKORG varchar(100)
		declare @CMPRE varchar(100)
		declare @KZWI1 varchar(100)
       
        declare @POSNR varchar(100)
        declare @MATNR varchar(100)
        declare @KWMENG varchar(100)
        declare @VRKME varchar(100)
        declare @NETPR varchar(100)
        declare @KPEIN varchar(100)
        declare @WERKS varchar(100)
        declare @UEBTO varchar(100)
        declare @UNTTO varchar(100)
        declare @ABGRU varchar(100)

		declare @order_typeid int
		declare @order_type varchar(100)
		declare @cancel_flag varchar(100)
		declare @customer_id int
		declare @customer_id2 int
		declare @customer_name varchar(100)
		declare @customer_name2 varchar(100)
	  	/*if exists(select top 1 * from t_order  WITH(NOLOCK) where order_number=@order_no  and status<>'NEW')
		begin
		   insert into #returnresult values(-101,'Fail','订单号['+@order_no+']订单状态已经变化，不能修改.4')
		   return
		end*/
		
	    select top 1    @ZPOSITION = ZPOSITION
						,@VBELN = VBELN
						,@AUART = AUART
						,@EDATU= isnull(EDATU,'')  
						,@VKORG=isnull(VKORG,'')
						,@CMPRE=isnull(CMPRE,'0')
						,@KZWI1=isnull(KZWI1,'0')
						,@KUNNR = KUNNR
						,@KUNNR1 = KUNNR1
						,@AUDAT = AUDAT
						,@ZFLAG = ZFLAG
						,@POSNR = POSNR
						,@MATNR = MATNR
						,@KWMENG= KWMENG
						,@VRKME = VRKME
						,@NETPR = NETPR 
						,@KPEIN = KPEIN
						,@WERKS = WERKS
						,@UEBTO = UEBTO
						,@UNTTO = UNTTO
						,@ABGRU = ABGRU
		  from  tbl_inf_imp_soorder   WITH(NOLOCK) 
		  where DATA_ID=@DataID and PROCESS_STATUS=@process_status 
		         and VBELN=@order_no and POSNR=@line_no  and ZFLAG=@ZFLAG 

		  if  (@EDATU='' or @EDATU='00000000') set @EDATU=null
           
		  if @EDATU=null
		  BEGIN
				if exists(select  top 1 order_number from t_order_detail with(nolock)
						where order_number=@order_no  and date_expected >'1901-01-0100:00:00' and wh_id=@wh_id )
				BEGIN
					select @EDATU=CONVERT(VARCHAR(10),MIN(date_expected),112)  
					from t_order_detail with(nolock)
					where order_number=@order_no  and date_expected >'1901-01-0100:00:00' 
					and wh_id=@wh_id 
                END
		  end 	    

		 select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype   WITH(NOLOCK) 
		 where sap_ordertype=@AUART   and flag_inoutbound=@ZFLAG 
	      
	     if (@ABGRU='X') 
		 begin
		      set @cancel_flag='Y'
		 end
		 else 
		      set @cancel_flag='N'

		select top 1 @customer_id=isnull(customer_id,0),
					 @customer_name=customer_name 
		from t_customer   WITH(NOLOCK) 
		where rtrim(customer_code)=@KUNNR 
		and wh_id=@wh_id 

		IF (@KUNNR1<>'')
		BEGIN
			select top 1 @customer_id2=isnull(customer_id,0), @customer_name2=customer_name  
			from t_customer   WITH(NOLOCK) 
			where rtrim(customer_code)=@KUNNR1 
			and wh_id=@wh_id 
		END
		ELSE SET @customer_id2=NULL


		if  (@KUNNR='300243')
		begin
			set  @order_typeid=5265
			set  @order_type='AO'  --员工申购
		end
 
		if (@customer_id=null or @customer_id=0)
		begin
			insert into #returnresult values(-201,N'fail',N'WMS中找不到对应的客户信息')
			return 
		end
 
 
    if not exists(select top 1 order_number from t_order  WITH(NOLOCK) where order_number=@order_no)
	    insert into t_order(  wh_id
							  ,order_number
							  ,type_id
							  ,order_type
							  ,display_order_number
							  ,order_date
							  ,customer_id
							  ,customer_name
							  ,client_code
							  ,status
							  ,lock_flag
							  ,sap_ordertype
							  ,earliest_ship_date
							  ,sold_to_id
							  ,sales_group
							  )
					values (     @wh_id
					            ,@order_no
					            ,@order_typeid
								,@order_type
								,@order_no
								,cast(@AUDAT as date)
								,@customer_id2
								,@customer_name2
								,@client_code
								,'NEW'
								,'N'
								,@AUART
								,CAST(@EDATU as date)
								,@customer_id
								,@VKORG
					         )
	 else
		   update t_order 
		   set       order_date=cast(@AUDAT as date)
					 ,customer_id=@customer_id2
					 ,customer_name=rtrim(@customer_name2)
					,client_code=@client_code
					,earliest_ship_date =CAST(@EDATU as date) 
					,sap_ordertype=@AUART
					,sold_to_id=@customer_id
					,sales_group=@VKORG
				 
		   from  t_order 
		   where  order_number=@order_no 
		   and wh_id=@wh_id 
		
 
		   
	   declare @stored_attribute_id bigint
	   declare @uom nvarchar(30)
	   set @uom=@VRKME
	  if exists( select top 1 item_number  from t_item_master  WITH(NOLOCK) WHERE item_number=@WERKS+'-'+@MATNR  and wh_id=@wh_id and pack_flag='Y')
	  begin
			SELECT @stored_attribute_id=CONVERT(INT,tscd.stored_attribute_id)
			FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
			INNER JOIN 
			(SELECT TOP 1 tacd.attribute_id,tiu.uom_prompt, tacd.attribute_collection_id FROM t_item_master tim WITH(NOLOCK) 
			INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK) 
			ON tim.attribute_collection_id = tacd.attribute_collection_id
			INNER JOIN t_item_uom tiu WITH(NOLOCK)
			ON tim.wh_id = tiu.wh_id
			AND tim.item_number = tiu.item_number
			WHERE tim.item_number = @WERKS+'-'+@MATNR
			AND tim.wh_id = @wh_id
			AND tiu.uom = @uom) a
			ON tscd.attribute_id = a.attribute_id
			AND tscd.attribute_value = a.uom_prompt
			 INNER JOIN t_sto_attrib_collection_master tscm
       on tscd.stored_attribute_id=tscm.stored_attribute_id and tscm.attribute_collection_id=a.attribute_collection_id
     end
	 
	declare @storage_location1 nvarchar(30),@storage_location2 nvarchar(30)
	select  @storage_location2=@WERKS, @storage_location1=''
 
	if not exists(select top 1 order_number from t_order_detail  WITH(NOLOCK) where  order_number=@order_no and line_number=@line_no and wh_id=@wh_id )
	BEGIN
			
		IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
		WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
		BEGIN
			insert into #returnresult values(-202,N'fail',N'订单已经加入波次，不允许新增行明细') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
			return 
		END
		ELSE
		BEGIN
			insert into  t_order_detail([wh_id]
								  ,[order_number]
								  ,[line_number]
								  ,[item_number]
								  ,[qty]
								  ,[order_uom]
								  ,stored_attribute_id
								  ,[storage_location]
								  ,[price]
								  ,[price_uom]
								  ,factory
								  ,[cancel_flag]
								  ,date_expected
								  ,price_tax
								  ,sum_price_tax)
							  values(@wh_id,
							         @order_no,
							         @line_no,
									 @WERKS+'-'+@MATNR,
									 cast(@KWMENG as float),
									 @VRKME,
									 @stored_attribute_id,
									 @WERKS,--
									 @NETPR,
									 @KPEIN,
									 @WERKS,
									 @cancel_flag,
									 CAST(@EDATU as date),
									 CAST(@CMPRE as float),
									 CAST(@KZWI1 as float)
									 ) 
			END	
		END			 
		else 
		BEGIN
			IF @cancel_flag = 'Y'
			BEGIN
				update t_order_detail
				set  cancel_flag=@cancel_flag
				where  order_number=@order_no and line_number=@line_no
			END
			ELSE
			BEGIN
				IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
				WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
				BEGIN
					insert into #returnresult values(-202,N'fail',N'已加入波次，未打删除标记，不允许修改') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
					return 
				END
				ELSE
				BEGIN
					update t_order_detail
					set  [wh_id]=@wh_id
						,[item_number]=@WERKS+'-'+@MATNR
						,[qty]=@KWMENG
						,[order_uom]=@VRKME
						,stored_attribute_id=@stored_attribute_id
						,[storage_location]= @WERKS
						,[price]=@NETPR
						,[price_uom]=@KPEIN
						,factory=@WERKS
						,[cancel_flag]=@cancel_flag
						,date_expected=CAST(@EDATU as date)
						,price_tax=CAST(@CMPRE as float)
						,sum_price_tax=CAST(@KZWI1 as float)
					where  order_number=@order_no and line_number=@line_no 
					and wh_id=@wh_id 
				END
			END
		END	
		
      insert into #returnresult values(1,N'OK',N'SO Outbound成功.')
END


