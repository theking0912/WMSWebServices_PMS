-- ======================================    
-- Author: JERRY.Ming   
-- Create Date: 09.2014   
-- Description: Insert asn
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_add_po_toasn]    
     @wh_id				    NVARCHAR(10)   
	,@user_id               NVARCHAR(30)
	,@shipment_number		NVARCHAR(50)
	,@status				NVARCHAR(10)
	,@comments				NVARCHAR(100)
	,@po_number				nvarchar(50)
	,@locale_id				NVARCHAR(50)
	,@item_number			NVARCHAR(50)
    ,@line_number			NVARCHAR(50)
--	,@qty					FLOAT
    ,@msg					nvarchar(1000) output

AS    
 DECLARE      
    @inv_qty               INT,
	@discrepancy_flag      NVARCHAR(1), --0 same|1 diffient
	@sysdate               DATETIME,
	@local_id              NVARCHAR(50),
	@SQL1                  NVARCHAR(1000),
	@SQL2                  NVARCHAR(1000),
	@work_q_id             NVARCHAR(30),
	@v_nReturn			   INT,
	@v_nErrorNumber		   INT,
	@v_vchErrorMsg		   NVARCHAR(1000),
	@expiration_date       DATE,
	@shelf_life			   int,
	@v_expir_date		   date,
	@v_ncount				int,
	@po_type			   nvarchar(20)
    ,@date_shipped			DATE
	,@date_expected			Date
	,@out_vchMsg			NVARCHAR(50)
	--@passornot				nvarchar(2),
	--@msg					nvarchar(200)


	SET @discrepancy_flag = N'0'   
	SET @sysdate =getdate()
	SET @inv_qty = 0

BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    
	begin TRANSACTION
	BEGIN TRY
	  
	  select @v_ncount=count(*) 
	  from t_rcpt_ship where wh_id=@wh_id and shipment_number=@shipment_number 

	  select @po_type = type_id,
			 @date_shipped = create_date ,
			 @date_expected= create_date
	   from t_po_master where po_number=@po_number and wh_id=@wh_id
 
	  
	  if @wh_id is null 	
	    begin
		  set @msg='仓库不能为空'
		  RAISERROR(@msg, 11, 1)
		end		
		
	  if @shipment_number is null 	
	    begin
		  set @msg='运单号不能为空'
		  RAISERROR(@msg, 11, 1)
		end		
	  
	  if @status is null 	
	    begin
		  set @msg='status 不能为空'
		  RAISERROR(@msg, 11, 1)
		end	
	  
	  if @po_number is null 	
	    begin
		  set @msg='shipment_type 不能为空'
		  RAISERROR(@msg, 11, 1)
		end	
	  	
				  		
	  IF @msg is null and @v_ncount=0 
	  begin
	    
	    INSERT INTO t_rcpt_ship
					(
					wh_id,
					shipment_number,
					carrier_id,
					trailer_number,
					date_shipped,
					date_expected,
					date_received,
					date_posting,
					status,
					comments,
					shipment_type,
					create_by,
					create_date
					)

					VALUES(
					@wh_id,
					@shipment_number,
					(select top 1 carrier_id from t_carrier),
					'NO.',
					@date_shipped			
					,@date_expected			
					,GETDATE()	
					,GETDATE()			
					,@status				
					,@comments				
					,@po_type			
				    ,@user_id
					,getdate()
					)
				--	INSERT INTO t_aaa values('1',10,1000)
				--select * from t_aaa
	   
	  end

	  select @v_ncount=count(*) 
	  from t_rcpt_ship_po_detail where wh_id=@wh_id and shipment_number=@shipment_number
			AND item_number = @item_number
		
		if @v_ncount > 0	
	    begin
		  set @msg= '(' + @item_number + ')在一张预到货通知单下存在多行'
		  RAISERROR(@msg, 11, 1)
		end	

	  EXECUTE csp_rcpt_ship_add_item
		@item_number,
		@line_number,
		--@qty,
		@shipment_number,
		@po_number,
		@wh_id,
		@locale_id,
		@out_vchMsg OUTPUT
       

	   SET @msg= @msg + @out_vchMsg

	   IF @msg IS not NULL 
	     
	     BEGIN
		   ROLLBACK TRANSACTION
		   RAISERROR(@msg, 11, 1)
		 END
	   commit
	   RETURN
    END TRY

    BEGIN CATCH
	    ROLLBACK TRANSACTION
        SET NOCOUNT OFF
        SET @msg = ERROR_MESSAGE()+@msg
		RAISERROR (@msg, -- Message text.
                11,
                1)
        RETURN
    END CATCH
  
END
