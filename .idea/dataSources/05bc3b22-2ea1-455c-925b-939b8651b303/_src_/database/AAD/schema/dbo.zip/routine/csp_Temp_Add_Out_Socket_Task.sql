-- Procedure
-- =============================================
-- Author:		Laver.Hu
-- Create date: 2013-11-25
-- Description:	add outbound socket task (CREATE,CANCEL)
-- =============================================
CREATE PROCEDURE [dbo].[csp_Add_Out_Socket_Task] 
	-- Add the parameters for the stored procedure here
	@In_Msg_Type		AS	NVARCHAR(4), 
	@In_Mode			AS	NVARCHAR(4),  
	@In_Lc_ID			AS	NVARCHAR(20), 
	@In_Node			AS	NVARCHAR(8),
	@In_Outbound_Msg	AS	NVARCHAR(2000),    
	@In_WMS_SeqNo		AS	NVARCHAR(12),
	@Out_ERR_Msg		AS	NVARCHAR(250)	OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE		@WMS_SEQ_NO		NVARCHAR(12)
	
	BEGIN TRY		
	
		BEGIN TRANSACTION
	
		IF  @In_Mode = 'CANC'
		BEGIN
			UPDATE tbl_out_socket_task
				SET status = 'ACKN',
					response = 'Y',
					response_date = GETDATE(),
					complete_date = GETDATE()
				WHERE lc_id = @In_Lc_ID
				AND msg_type = 'TRAN'
				AND mode = 'CANC'
				AND status = 'TRAN'
		END

		-- get a new socket msg's SeqNo
		--EXEC csp_Get_New_Socket_SeqNo @WMS_SEQ_NO OUTPUT
		SET @WMS_SEQ_NO = @In_WMS_SeqNo

		-- Insert a tran record
		INSERT INTO tbl_out_socket_task
					([msg_type]
					,[mode]
					,[wms_seq]
					,[tgw_seq]
					,[lc_id]
					,[node]
					,[response]
					,[status]
					,[recount]
					,[socket_msg]
					,[create_date]					
					,[response_date]
					,[complete_date])
				VALUES
					(@In_Msg_Type
					,@In_Mode
					,@WMS_SEQ_NO
					,NULL
					,@In_Lc_ID
					,@In_Node
					,'N'
					,'TRAN'
					,0
					,@In_Outbound_Msg
					,GETDATE()
					,NULL
					,NULL)		



		COMMIT

		RETURN
	END TRY

    BEGIN CATCH
        ROLLBACK
        SET @Out_ERR_Msg = ERROR_MESSAGE()
		RAISERROR(@Out_ERR_Msg, 11, 1)
        RETURN
    END CATCH
END
