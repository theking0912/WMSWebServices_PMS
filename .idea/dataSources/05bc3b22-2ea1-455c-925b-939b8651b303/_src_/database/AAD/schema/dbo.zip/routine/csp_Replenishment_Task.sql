
-- =============================================
-- Author:		Lij
-- Create date: 2016-1-15 14:43:56
-- Description:	生成补货任务
-- =============================================
CREATE PROCEDURE [dbo].[csp_Replenishment_Task] 
	-- Add the parameters for the stored procedure here
	@item_number nvarchar(500),
	@zone_type NVARCHAR(50)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRANSACTION;
	--如果临时表不为空则删除
	IF OBJECT_ID('#tmp_location') IS NOT NULL
	DROP TABLE #tmp_location;

	DECLARE @i INT --循环变量
	SET @i = 1;
	DECLARE @row_count INT --总行数
	DECLARE @location_id NVARCHAR(100) --货位号
	DECLARE @stored_qty DECIMAL(30, 8)  --当前库存数量
	DECLARE @xy_replenishment_qty DECIMAL(30, 8)  --需要补货数量
	DECLARE @j_qty DECIMAL(30, 8)  --一件数量
	DECLARE @replenishment_qty DECIMAL(30, 8) --补货数量
	--DECLARE @zone_type NVARCHAR(50) --货位区域；P->C->B

	BEGIN TRY
		--创建临时表，用于保存货位和自增长Id
		CREATE TABLE #tmp_location (Id INT IDENTITY(1, 1), location_id NVARCHAR(100) COLLATE database_default NULL);
		--为临时表赋值
		INSERT INTO #tmp_location SELECT tl.location_id FROM dbo.tbl_loc_item AS tl
		LEFT OUTER JOIN dbo.t_location loc ON loc.location_id = tl.location_id AND loc.wh_id = tl.wh_id
		WHERE item_number = @item_number AND loc.type = SUBSTRING(@zone_type,1,1);

		--获取货位号
        --SELECT  @location_id = location_id
        --FROM    #tmp_location
        --WHERE   Id = @i;
		--获取当前货位库存数量
        SELECT  @stored_qty = ISNULL(SUM(ISNULL(actual_qty, 0)), 0)
        FROM    dbo.t_stored_item ts INNER JOIN #tmp_location tml
		ON tml.location_id = ts.location_id
        WHERE   item_number = @item_number
                --AND ISNULL(shipment_number, '') = ''
                AND ISNULL(actual_qty, 0) >= 0;
		--获取需要补货数量
        SELECT  @xy_replenishment_qty = ISNULL(( SUM(max_qty) - @stored_qty ),
                                                0)
        FROM    dbo.tbl_loc_item tl INNER JOIN #tmp_location tml
		ON tml.location_id = tl.location_id
        WHERE   item_number = @item_number;
		--获取一件中的数量
		
        SELECT  @j_qty = ISNULL(full_case_qty, 0)
        FROM    dbo.t_item_master
        WHERE   item_number = @item_number;
		IF @zone_type = 'B'
		BEGIN
		    --获取向下取整后的补货数量（零散）
			SELECT  @replenishment_qty = ISNULL(( FLOOR(( @xy_replenishment_qty
                                                        / @j_qty ))  * @j_qty),
                                            0);
		END
		ELSE
		BEGIN
		    --获取向下取整后的补货数量（整箱）
			--SELECT  @replenishment_qty = ISNULL(( FLOOR(( @xy_replenishment_qty
   --                                                     / @j_qty ))),
   --                                         0);

			SELECT  @replenishment_qty = ISNULL(( FLOOR(( @xy_replenishment_qty
                                                        / @j_qty ))* @j_qty),
                                            0);
		END
		
		--判断
        IF NOT EXISTS ( SELECT  1
                        FROM    tbl_allocation
                        WHERE   status IN ( 'U', 'A' )
                                AND item_number = @item_number )
            AND NOT EXISTS ( SELECT 1
                                FROM   t_work_q
                                WHERE  work_status IN ( 'U', 'A' )
                                    AND item_number = @item_number
                                    AND work_type IN ( '05', '06' ) )
            BEGIN
                EXECUTE dbo.csp_Replenishment_Task_Gener @item_number = @item_number, -- nvarchar(50)
                    @zone_type = @zone_type, -- nvarchar(50)
                    @replenishment_qty = @replenishment_qty -- float
			  
            END;


		--获取数据总行数
		--SELECT @row_count = COUNT(*) FROM #tmp_location;
		--开始循环
		--WHILE @i <= @row_count
		--BEGIN
		--	--获取货位号
		--	SELECT @location_id = location_id FROM #tmp_location WHERE Id = @i;
		--    --获取当前货位库存数量
		--	SELECT @stored_qty = ISNULL(SUM(actual_qty), 0) FROM dbo.t_stored_item 
		--	WHERE location_id = @location_id AND item_number = @item_number 
		--	AND ISNULL(shipment_number, '') = '' AND actual_qty >= 0;
		--	--获取需要补货数量
		--	SELECT @xy_replenishment_qty = ISNULL((max_qty - @stored_qty), 0) FROM dbo.tbl_loc_item 
		--	WHERE item_number = @item_number AND location_id = @location_id;
		--	--获取一件中的数量
		--	SELECT @j_qty = ISNULL(full_case_qty, 0) FROM dbo.t_item_master WHERE item_number = @item_number;
		--	--获取向下取整后的补货数量（零散）
		--	SELECT @replenishment_qty = ISNULL((FLOOR((@xy_replenishment_qty * @j_qty) / @j_qty)) ,0);
		--	--判断
		--	IF NOT Exists(select 1 from tbl_allocation where status in ('U','A') and item_number = @item_number) and NOT EXISTS(select 1 from t_work_q where work_status in ('U','A') and item_number = @item_number and work_type in ('05','06'))
		--	BEGIN
		--	  EXECUTE dbo.csp_Replenishment_Task_Gener @item_number = @item_number, -- nvarchar(50)
		--	      @zone_type = @zone_type, -- nvarchar(50)
		--	      @replenishment_qty = @replenishment_qty; -- float
			  
		--	END

		--	SET @i = @i + 1;
		--END
		COMMIT;
    END TRY

	BEGIN CATCH
		ROLLBACK;
	END CATCH
END

