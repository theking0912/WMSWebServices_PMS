
CREATE PROCEDURE usp_afa_remove_order_data
@in_vchOrderNumber    NVARCHAR(60),
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchLoadId         NVARCHAR(60),
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contians "SUCCESS" or the message to be displayed.


AS

DECLARE 
    @v_nErrorNumber	  INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,

    @v_vchHuId            NVARCHAR(50),
    @v_chStatus           CHAR(1), 

    @e_GenSqlError   	  INTEGER,
    @e_DelLDFailed        INTEGER,
    @e_LoadMustBeHeld     INTEGER,
    @e_UpdOrderDetailFailed INTEGER,
    @e_DelLDLFailed	  INTEGER,
    @v_nAFACtl            INTEGER,

    @v_nTranCount         INTEGER


    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'

    SET @e_GenSqlError = 1
    SET @e_DelLDFailed = 2
    SET @e_LoadMustBeHeld = 3
    SET @e_UpdOrderDetailFailed = 4
    SET @e_DelLDLFailed = 5
    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 1

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN


    SELECT @v_nAFACtl = next_value
      FROM t_whse_control
     WHERE control_type = 'AFA_INSTALLED'
       AND wh_id = @in_vchWarehouseId


    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    -- Verify the load is on hold before manipulating data.
    SELECT @v_nRowCount = COUNT (*)
    FROM t_work_q
    WHERE wh_id = @in_vchWarehouseId                         
        AND work_q_id IN (SELECT work_q_id 
                         FROM t_pick_detail
                         WHERE wh_id = @in_vchWarehouseId
                             AND load_id = @in_vchLoadId)
        AND work_status <> 'H' 

    IF @v_nRowCount > 0 -- The the load is not on hold
    BEGIN
        SET @v_nErrorNumber = @e_LoadMustBeHeld
        GOTO ErrorHandler
    END
 
    -- Update t_order_detail to relfelct the quantitites are available again
    -- Update all lines on the load/order because this is only called when we move the entire order
    UPDATE ord
    SET ord.tran_plan_qty = ISNULL(tran_plan_qty, 0) + ldl.planned_qty,
        ord.afo_plan_qty  = CASE WHEN (ISNULL(@v_nAFACtl,0) =  2 AND afo_plan_qty = tran_plan_qty) 
                                 THEN ISNULL(tran_plan_qty, 0) + ldl.planned_qty
                                 ELSE ord.afo_plan_qty
                            END
    FROM t_afa_load_detail ld, t_afa_load_detail_line ldl, t_order_detail ord
    WHERE ld.load_id = @in_vchLoadId
        AND ld.order_number = @in_vchOrderNumber
        AND ld.wh_id = @in_vchWarehouseId
        AND ld.load_detail_id = ldl.load_detail_id
        AND ld.wh_id = ldl.wh_id
        AND ldl.line_number = ord.line_number
        AND ld.order_number = ord.order_number

   
    --Make sure the update was successful       
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_UpdOrderDetailFailed
        GOTO ErrorHandler                                
    END


    
    -- Remove any lines on the order/load
    DELETE t_afa_load_detail_line
    WHERE wh_id = @in_vchWarehouseId
        AND load_detail_id IN (SELECT load_detail_id
                               FROM t_afa_load_detail
                               WHERE order_number = @in_vchOrderNumber
                               AND load_id = @in_vchLoadId
                               AND wh_id = @in_vchWarehouseId)


    --Make sure the lines were removed     
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_DelLDLFailed
        GOTO ErrorHandler                                
    END

    DELETE t_afa_load_detail
    WHERE wh_id = @in_vchWarehouseId
        AND order_number = @in_vchOrderNumber
        AND load_id = @in_vchLoadId
   
    SELECT @v_vchSqlErrorNumber = @@ERROR  
    -- Check for errors
    
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler			
    END

    --Delete the Stop Records
    DELETE FROM t_stop 
    WHERE load_id = @in_vchLoadId 
      AND wh_id = @in_vchWarehouseId
      AND stop_id NOT IN (SELECT DISTINCT stop_id from t_afa_load_detail)

   --Make sure the delete worked.
   SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
   IF @v_vchSqlErrorNumber <> 0 
   BEGIN
       SET @v_nErrorNumber = @e_GenSqlError
       GOTO ErrorHandler                                
   END

    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_UpdOrderDetailFailed
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Error occurred updating afo_plan_qty in the t_order_detail table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_order_detail'
    END
    IF @v_nErrorNumber = @e_DelLDLFailed
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Error occurred deleting a record from the t_afa_load_detail_line table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afa_load_detail_line'
    END
    IF @v_nErrorNumber = @e_DelLDFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'Unable to delete t_afa_load_detail record for order ' + 
            @in_vchOrderNumber + ' on Load ' + ISNULL(@in_vchLoadId, '(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50004 -- Delete Failed
    END
    IF @v_nErrorNumber = @e_LoadMustBeHeld
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Load must be put on hold before removing items.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_work_q'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
        -- Reset message after logged to return to optimizer
        SET @v_vchLogMsg = 'NOT ON HOLD'
    END

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN
