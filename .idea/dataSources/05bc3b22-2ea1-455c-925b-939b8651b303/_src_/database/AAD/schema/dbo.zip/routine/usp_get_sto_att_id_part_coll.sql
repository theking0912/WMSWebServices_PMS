
CREATE PROCEDURE [dbo].[usp_get_sto_att_id_part_coll]

@in_vchIdentifier VARCHAR(36), -- Necesary user entered identitifier
@in_vchItemNumber NVARCHAR(30),
@in_vchWhId NVARCHAR(10),
@out_vchErrMsg VARCHAR(100) OUTPUT,

@out_nStoAttId BIGINT OUTPUT -- Stored Attribute ID to be returned

AS

DECLARE 
    @v_nCollId INT,
    @v_nStoAttributeId BIGINT

DECLARE -- checksum variables
    @v_vchAuxStr NVARCHAR(3000),
    @v_vchQryStr NVARCHAR(4000),
    @v_vchParamStr NVARCHAR(1000),
    @v_nOutchk int
    
DECLARE
-- Error handling and logging variables.

    @c_nModuleNumber INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum INT, -- The # that uniquely tags the error message.
    @v_vchErrorMsg NVARCHAR(500),

    @v_nLogLevel INT, -- Holds log level (1-5).

    @v_nReturn INT,
    @e_SprocError INT,

-- Local variables	
    @v_nOrigNoCountState INT

SET NOCOUNT ON

-- -----------------------------------------------------
BEGIN -- MAIN PROCEDURE
SET @out_vchErrMsg = ''

-- Creates a temporary table for use in comparing certain combination of attributes
CREATE TABLE #temp_att_values (att_id int NOT NULL, att_value varchar(250) COLLATE DATABASE_DEFAULT NOT NULL)

-- Validates if the values entered for the table: "t_user_entered_attributes" are NULL
IF EXISTS 
    (SELECT attribute_id
    , attribute_value 
    FROM t_user_entered_attributes 
    WHERE identifier = @in_vchIdentifier
    AND attribute_id IS NOT NULL 
    AND attribute_value IS NULL)
    
    BEGIN -- IF EXISTS VALIDATE ...
    
        SET @out_vchErrMsg = 'Null Attribute Value Found'
        RETURN(0)

    END -- IF EXISTS VALIDATE 

-- Gets all the attributes from table: t_user_entered_attributes and inserts them directly in the temporary table: #temp_att_values
INSERT INTO #temp_att_values(att_id, att_value)
SELECT attribute_id
, attribute_value
FROM t_user_entered_attributes
WHERE identifier = @in_vchIdentifier

SELECT @v_nCollId = attribute_collection_id
FROM t_item_master
WHERE item_number = @in_vchItemNumber
AND wh_id = @in_vchWhId

-- The attribute values which have an exception_control set to 'F' are retrieved
IF NOT EXISTS (
                 SELECT *
                 FROM t_attribute_exception_control
                 , #temp_att_values tav
                 WHERE item_number = @in_vchItemNumber
                 AND wh_id = @in_vchWhId
                 AND attribute_id = tav.att_id
                 AND attribute_control in ('I','O','T')
              )

        BEGIN -- IF EXISTS

        -- *******************************************************************************
        -- **** calculating checksum of the attribute values ordered by attribute_id *****
        -- *******************************************************************************

        SET @v_vchAuxStr = N''

        SELECT @v_vchAuxStr = @v_vchAuxStr + '''' + att_value + ''','
        FROM #temp_att_values tav
        WHERE att_value IS NOT NULL 
        AND att_id is NOT NULL
        ORDER BY att_id ASC

        SELECT @v_vchAuxStr = SUBSTRING(@v_vchAuxStr,1,LEN(@v_vchAuxStr)-1)
        SELECT @v_vchQryStr = N'select @chksum = checksum('+@v_vchAuxStr+')'
        SELECT @v_vchParamStr = N'@chksum int OUTPUT'

        EXECUTE sp_executesql @v_vchQryStr, @v_vchParamStr,  @chksum = @v_nOutchk OUTPUT

        -- *******************************************************************************
        -- ****************** end of checksum calculation ********************************
        -- *******************************************************************************

        -- This query retrieves the Stored Attribute ID and places in the variable v_nStoAttribute_Id
        -- when it finds the values are found in "t_sto_attrib_collection_detail"
        -- and "t_attribute_collection_detail" tables respectively

        SELECT @v_nStoAttributeId = t2.stored_attribute_id 
        FROM
          (SELECT 
             (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 1) as attrib_val1
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 2) as attrib_val2
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 3) as attrib_val3
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 4) as attrib_val4
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 5) as attrib_val5
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 6) as attrib_val6
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 7) as attrib_val7
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 8) as attrib_val8
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 9) as attrib_val9
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 10) as attrib_val10
             , (SELECT tt.att_value
               FROM #temp_att_values tt
               , t_attribute_collection_detail tacd
               WHERE tacd.attribute_collection_id = @v_nCollId
               AND tacd.attribute_id = tt.att_id
               AND tacd.sequence_id = 11) as attrib_val11
             ) t1

          , (SELECT 
               tsacm.stored_attribute_id
               , tsacm.attribute_collection_id
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 1) as val1
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 2) as val2
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 3) as val3
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 4) as val4
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 5) as val5
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 6) as val6
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 7) as val7
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 8) as val8
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 9) as val9
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd 
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 10) as val10
               , (SELECT attribute_value
                 FROM t_sto_attrib_collection_detail tsacd
                 , t_attribute_collection_detail tacd
                 WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                 AND tsacd.attribute_id = tacd.attribute_id
                 AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                 AND tacd.sequence_id = 11) as val11
               FROM t_sto_attrib_collection_master tsacm
               WHERE attribute_collection_id = @v_nCollId
               AND detail_checksum = @v_nOutchk
             ) t2

        WHERE ISNULL(t1.attrib_val1,'') = ISNULL(t2.val1,'')
        AND ISNULL(t1.attrib_val2,'') = ISNULL(t2.val2,'')
        AND ISNULL(t1.attrib_val3,'') = ISNULL(t2.val3,'')
        AND ISNULL(t1.attrib_val4,'') = ISNULL(t2.val4,'')
        AND ISNULL(t1.attrib_val5,'') = ISNULL(t2.val5,'')
        AND ISNULL(t1.attrib_val6,'') = ISNULL(t2.val6,'')
        AND ISNULL(t1.attrib_val7,'') = ISNULL(t2.val7,'')
        AND ISNULL(t1.attrib_val8,'') = ISNULL(t2.val8,'')
        AND ISNULL(t1.attrib_val9,'') = ISNULL(t2.val9,'')
        AND ISNULL(t1.attrib_val10,'') = ISNULL(t2.val10,'')
        AND ISNULL(t1.attrib_val11,'') = ISNULL(t2.val11,'')

        IF @v_nStoAttributeId IS NULL -- Create a stored_attribute_collection
            
        BEGIN

                INSERT INTO t_sto_attrib_collection_master (attribute_collection_id, detail_checksum)
                VALUES (@v_nCollId, @v_nOutchk)

                SELECT @v_nStoAttributeId = SCOPE_IDENTITY()

                INSERT INTO t_sto_attrib_collection_detail
                SELECT @v_nStoAttributeId, att_id, att_value
                FROM #temp_att_values
                WHERE att_id IS NOT NULL
                AND att_value IS NOT NULL

        END

        -- Once a stored attribute id is found it is returned
        SELECT @out_nStoAttId = @v_nStoAttributeId
        GOTO EXIT_LABEL

    END -- IF EXISTS
    
  
    -----------------------------------------------------------------------------------
    --                            Error Handling Code
    -----------------------------------------------------------------------------------
    ERROR_HANDLER:
    
    -- Roll back transaction if some error occurred    
        IF @@TRANCOUNT > 0
           ROLLBACK TRANSACTION
    
        -- Reset NOCOUNT
        IF @v_nOrigNoCountState = 0
           SET NOCOUNT OFF
    
    GOTO EXIT_LABEL

    -----------------------------------------------------------------------------------
    --                            Exit the Process
    -----------------------------------------------------------------------------------

    EXIT_LABEL:
    IF @@TRANCOUNT > 0
        COMMIT TRANSACTION

    -- Reset NOCOUNT
    IF @v_nOrigNoCountState = 0
        SET NOCOUNT OFF

    RETURN

END -- MAIN PROCEDURE ...

-- -----------------------------------------------------

SET QUOTED_IDENTIFIER OFF
