



-- =======================================    
-- Author: will 
-- Create Date: 2016-01-20  
-- Description: Short Pick zero  
--  
    
-- =======================================    

create PROCEDURE [dbo].[csp_zero_quantity_sort_short_pick_old]    
     @wh_id					NVARCHAR(10)  
    ,@pick_loc				Nvarchar(30)  
	,@item_number			Nvarchar(30)
	,@pick_key				NVARCHAR(30)
	,@hu_id					nvarchar(30) = NULL	--20160423 Added by TY	
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    
	DECLARE @wave_id         NVARCHAR(30)
	DECLARE @order_number    NVARCHAR(30)

		select @wave_id=wave_id  from tbl_pick_list where wh_id=@wh_id and shipping_label =@pick_key 

		select @order_number=order_number from tbl_allocation where wave_id=@wave_id and location_id=@pick_loc
		                                                      and wh_id=@wh_id and item_number=@item_number 

			UPDATE tbl_allocation SET status = 'C' WHERE wave_id=@wave_id and wh_id=@wh_id and location_id=@pick_loc
			                                        and item_number=@item_number 
													 and isnull(hu_id,'0') = isnull(@hu_id,'0') --20160423 Added by TY	

		if not exists (select 1 from tbl_allocation where wave_id=@wave_id and wh_id=@wh_id
		and item_number=@item_number and status <>'C' and  allo_type='S')
		  begin
		     UPDATE t_pick_detail SET status = 'STAGED' 
		     where order_number=@order_number and wh_id=@wh_id and item_number =@item_number

			 --IF NOT EXISTS (select 1 from tbl_allocation where
		  --   wave_id=@wave_id and order_number =@order_number and status<>'C' and  allo_type='S')

		  		  -- IF NOT EXISTS (select 1 from tbl_allocation where
		      --           -- wave_id=@wave_id and order_number =@order_number and status<>'C' and  allo_type='S')
						  --wave_id=@wave_id and order_number =@order_number and status<>'C' and  wh_id =@wh_id )
		   IF NOT EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') not in ('STAGED','LOADED') and  a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
		      and EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') in ('STAGED') and a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
			------- Modified by Trevor on 20150407
			begin

			   UPDATE t_order SET status = 'STAGED' where wh_id=@wh_id and order_number=@order_number

              end
		  end

		 

  
END    
    








