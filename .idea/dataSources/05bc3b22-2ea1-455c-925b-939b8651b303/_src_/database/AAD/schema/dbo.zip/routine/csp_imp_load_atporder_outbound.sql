


 
 --=======================================     
-- 存储过程名: csp_imp_load_atporder_outbound   
-- 描述：预留单接口出库业务处理  
-- =======================================   

CREATE PROCEDURE [dbo].[csp_imp_load_atporder_outbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id varchar(100),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG varchar(100)
AS
BEGIN
		/*//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //RKPF-RSNUM	预留编号
        //RKPF-RSDAT	创建日期
        //ZBSART        订单类型(固定：RSV)
        //ZFLAG	        出入库标识
        //RESB-RSPOS	行号
        //RESB-MATNR	物料
        //RESB-BDMNG	数量
        //MEINS            单位
        //RESB-WERKS	工厂
		*/

		declare @ZPOSITION varchar(100)
        declare @RSNUM varchar(100)
        declare @RSDAT varchar(100)
		declare @ZBSART varchar(100)
       
        declare @RSPOS varchar(100)
        declare @MATNR varchar(100)
        declare @BDMNG varchar(100)
		declare @MEINS varchar(100)
        declare @WERKS varchar(100)
        declare @LGORT varchar(100) 
		declare @XLOEK  varchar(100) 
		declare @order_typeid int
		declare @order_type varchar(100)
		declare @cancel_flag varchar(100)

		select top 1       @ZPOSITION=ZPOSITION,
							@RSNUM  =RSNUM,
							@RSDAT  =RSDAT,
							@ZBSART =ZBSART,
							@ZFLAG  =ZFLAG,

							@RSPOS  =RSPOS,
							@MATNR  =MATNR,
							@BDMNG  =BDMNG,
							@MEINS  =MEINS,
							@WERKS  =WERKS,
							@LGORT  =LGORT,
							@XLOEK=  XLOEK
		from  tbl_inf_imp_atporder   WITH(NOLOCK)
		where   DATA_ID=@DataID and PROCESS_STATUS=@process_status  
		       and RSNUM=@order_no  and RSPOS=@line_no and ZFLAG=@ZFLAG
	 
 
		 select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype   WITH(NOLOCK)
		 where sap_ordertype=@ZBSART  and flag_inoutbound=@ZFLAG
		  
		--删除标志
		 if (@XLOEK='X') 
			set @cancel_flag='Y' 
		else 
			set @cancel_flag='N'
    									
	if not exists(select top 1 order_number from t_order WITH(NOLOCK) where order_number=@order_no  )
	    insert into t_order(  wh_id
							  ,order_number
							  ,type_id
							  ,order_type
							  ,display_order_number
							  ,order_date
							  ,client_code
							  ,status
							  ,lock_flag
							  ,sap_ordertype
							  ,	earliest_ship_date
							  )
					values (     @wh_id
					            ,@order_no
					            ,@order_typeid
								,@order_type
								,@order_no
								,cast(@RSDAT as date)
								,@client_code
								,'NEW'
								,'N'
								,@ZBSART
								,cast(@RSDAT as date)
					         )
	 else
		   update t_order 
		   set      type_id=@order_typeid
				    ,order_type =@order_type
		            ,order_date=cast(@RSDAT as date)
					,client_code=@client_code
					,earliest_ship_date=cast(@RSDAT as date)
		   from  t_order 
		   where  order_number=@order_no  

		declare @uom varchar(100)
		
		SET @uom=@MEINS
		--if (isull(@uom,'')='') select top 1 @uom=uom from t_item_master  where item_number=@MATNR
		declare @stored_attribute_id bigint
		if exists( select top 1 item_number from t_item_master WITH(NOLOCK) where item_number=@WERKS+'-'+@MATNR  and wh_id=@wh_id and pack_flag='Y')
		begin
					SELECT @stored_attribute_id=CONVERT(INT,tscd.stored_attribute_id)
					FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
					INNER JOIN 
					(SELECT TOP 1 tacd.attribute_id,tiu.uom_prompt, tacd.attribute_collection_id  FROM t_item_master tim WITH(NOLOCK) 
					INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK) 
					ON tim.attribute_collection_id = tacd.attribute_collection_id
					INNER JOIN t_item_uom tiu WITH(NOLOCK)
					ON tim.wh_id = tiu.wh_id
					AND tim.item_number = tiu.item_number
					WHERE tim.item_number = @WERKS+'-'+@MATNR
					AND tim.wh_id = @wh_id
					AND tiu.uom = @uom) a
					ON tscd.attribute_id = a.attribute_id
					AND tscd.attribute_value = a.uom_prompt
					 INNER JOIN t_sto_attrib_collection_master tscm
       on tscd.stored_attribute_id=tscm.stored_attribute_id and tscm.attribute_collection_id=a.attribute_collection_id
		END

		declare @storage_location1 nvarchar(30),@storage_location2 nvarchar(30)
		select  @storage_location2=isnull(@WERKS,''), @storage_location1=isnull(@LGORT,'')

		if (@XLOEK='X') 
				set @cancel_flag='Y'
		 else
				set @cancel_flag='N'

		if not exists(select top 1  *  from t_order_detail WITH(NOLOCK) where  order_number=@order_no and line_number=@line_no)
		BEGIN
			
			IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
			WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
			BEGIN
				insert into #returnresult values(-202,N'fail',N'订单已经加入波次，不允许新增行明细') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
				return 
			END
			ELSE
			BEGIN
				insert into  t_order_detail( wh_id 
								, order_number 
								, line_number 
								, item_number 
								, qty 
								, order_uom 
								,stored_attribute_id
								, storage_location 
								,factory
								, cancel_flag
								,date_expected )
							values(@wh_id,
									@order_no,
									@line_no,
									@WERKS+'-'+@MATNR,
									cast(@BDMNG as float),
									@uom,
									@stored_attribute_id,
									@storage_location1,--
									@storage_location2,
									@cancel_flag,
									cast(@RSDAT as date)
									)
			END
		END
		else				
		BEGIN
			IF @cancel_flag = 'Y'
			BEGIN
				update t_order_detail
				set  cancel_flag=@cancel_flag
				where  order_number=@order_no and line_number=@line_no
			END
			ELSE
			BEGIN
				IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
				WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
				BEGIN
					insert into #returnresult values(-202,N'fail',N'已加入波次，未打删除标记，不允许修改') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
					return 
				END
				ELSE
				BEGIN
					update t_order_detail
					set   wh_id =@wh_id
						, item_number =@WERKS+'-'+@MATNR
						, qty =cast(@BDMNG as float)
						, order_uom =@uom
						, stored_attribute_id=@stored_attribute_id
						, storage_location= @storage_location1
						, factory=@storage_location2
						, cancel_flag=@cancel_flag
						,date_expected=cast(@RSDAT as date)
					where  order_number=@order_no and line_number=@line_no
				END
			END
		END		

     insert into #returnresult values(1,N'OK',N'ATP OutBound成功.')
END






