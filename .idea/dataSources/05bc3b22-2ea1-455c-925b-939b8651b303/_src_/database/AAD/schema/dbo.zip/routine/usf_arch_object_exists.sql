
CREATE FUNCTION usf_arch_object_exists (@in_vchObject_Name  NVARCHAR(100), 
                                  @in_vchObject_Type  NVARCHAR(30), 
                                  @in_vchTable_Name NVARCHAR(100)
                                  )  
RETURNS NVARCHAR(3)
 AS   
BEGIN 
        DECLARE @Result         NVARCHAR(3),
                @vCount         INTEGER,      
                @vObjectName    NVARCHAR(100),       
                @vObjectType    NVARCHAR(30),
                @vTableName     NVARCHAR(100)


            SET @vObjectName = LTRIM(RTRIM(@in_vchObject_Name))
            SET @vObjectType = LTRIM(RTRIM(@in_vchObject_Type))
            SET @vTableName = LTRIM(RTRIM(@in_vchTable_Name))


    IF @vObjectType = 'TABLE'
      BEGIN
            SELECT @vCount = COUNT(*)
              FROM sysobjects
             WHERE name = @vObjectName
               AND xtype = 'U'
      END 
    ELSE IF @vObjectType = 'COLUMN'
      BEGIN
            SELECT @vCount = COUNT(*)
              FROM syscolumns
             WHERE name = @vObjectName
               AND id = (SELECT id 
                           FROM sysobjects
                          WHERE name = @vTableName)
      END
    ELSE IF @vObjectType = 'CONSTRAINT'
      BEGIN
            SELECT @vCount = COUNT(*)
              FROM sysobjects
             WHERE name = @vObjectName
               AND xtype = 'C'
      END
    ELSE IF @vObjectType = 'FOREIGNKEYS'
      BEGIN
            SELECT @vCount = COUNT(*) 
              FROM sysforeignkeys 
             WHERE rkeyid = (SELECT id 
                               FROM sysobjects 
                              WHERE name = @vTableName)
      END
    ELSE
      BEGIN
            SELECT @vCount = COUNT(*)
              FROM sysobjects
             WHERE name = @vObjectName
      END

   
    IF @vCount > 0 
      SET @Result = 'YES'
    ELSE
      SET @Result = 'NO'
   
      
ExitLabel:
    RETURN @Result

END

