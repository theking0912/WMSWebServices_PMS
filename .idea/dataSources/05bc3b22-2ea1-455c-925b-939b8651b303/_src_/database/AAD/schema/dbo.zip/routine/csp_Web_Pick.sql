


-- =============================================
-- Author:		K1
-- Create date: 2016-03-18
-- Description:	
-- =============================================

CREATE PROCEDURE [dbo].[csp_Web_Pick]
    @in_wh_id					NVARCHAR(10) ,
    @in_pick_loc_id				NVARCHAR(30) ,
    @in_item_number				NVARCHAR(20) ,
	@in_allo_id					BIGINT,
	@in_pick_qty				FLOAT,
	@in_dest_hu_id				NVARCHAR(30),
	@in_user_id					NVARCHAR(30),
    @out_passornot				NVARCHAR(1)		OUTPUT  ,--0:Pass 1: Fail   
    @out_msg					NVARCHAR(200)	OUTPUT
AS
    BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
        SET NOCOUNT ON;
		DECLARE @pick_id				BIGINT
		DECLARE @allocated_qty			FLOAT
		DECLARE @picked_qty				FLOAT
		DECLARE @seq_id					BIGINT
		DECLARE @remove_qty				FLOAT
		DECLARE @order_number			NVARCHAR(30)
		DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
		DECLARE @ref_number				NVARCHAR(30)
		DECLARE @shiping_label			NVARCHAR(30)
		DECLARE @zone					NVARCHAR(30)
		DECLARE @zone_group				NVARCHAR(10)
		DECLARE @type					NVARCHAR(2) = 'SO'
		DECLARE @pick_type				BIGINT
		DECLARE @stored_attribute_id	Nvarchar(30)
		DECLARE @hu_id					NVARCHAR(30)
		DECLARE @lot_number				NVARCHAR(30)
		DECLARE @expiration_date		DATETIME
		DECLARE @damage_flag			NVARCHAR(1)
		DECLARE @Rec_Cnt			AS	INT
		DECLARE @tran_type			AS	NVARCHAR(10) = '921'
		DECLARE @tran_description	AS	NVARCHAR(50) = 'WEB 拣货'
		DECLARE @allo_type			AS	NVARCHAR(10)
		DECLARE	@staging_loc_type	AS	NVARCHAR(2)
		DECLARE	@dest_stagin_loc	AS	NVARCHAR(30)
		DECLARE @bln_tran			AS	NVARCHAR(1) = 0
		DECLARE	@customer_code	AS	NVARCHAR(30) 
		DECLARE	@wave_id	AS	NVARCHAR(30) 
		declare @errmsg nvarchar(200)

		SET LOCK_TIMEOUT 18000
		
        SET @out_passornot = 0

/****** Added by Trevor on 20160419 started ******/
		DECLARE @pick_loc_id_x			NVARCHAR(30) 

		if exists (select 1 from tbl_allocation
		            where wh_id=@in_wh_id and item_number=@in_item_number and location_id =@in_pick_loc_id and status not in ('U','C') and allo_type not in ('R1','R2'))
		begin
			SET @out_msg = N'商品'+@in_item_number+N'在库位'+@in_pick_loc_id+N'有拣货正在进行中'
            SET @out_passornot = 1
		  return
		end
/****** Added by Trevor on 20160419 ended ******/

        BEGIN TRY
			SELECT @Rec_Cnt = COUNT(1) FROM t_work_q
				WHERE wh_id = @in_wh_id
					AND item_number = @in_item_number
					AND location_id = @in_pick_loc_id
					AND work_status <> 'C'
					AND work_type = '06'

			IF @Rec_Cnt > 0
			BEGIN
				--RAISERROR ('商品在当前货位上有补货任务未完成',  -- Message text.
				SET @errmsg = '商品('+@in_item_number + ') 在当前货位(' + @in_pick_loc_id + ')上有补货任务未完成'
				RAISERROR (@errmsg,  -- Message text.
						   16, -- Severity.
						   1     -- State.
						   );

				--SET @out_msg = '商品在当前货位上有补货任务未完成'
				SET @out_passornot = 1
				RETURN
			END
			
			
			--供应链支持0短拣，Updated by George on 20160820
			IF (@in_pick_qty >= 0)
			BEGIN
				--print @in_wh_id
				--print @in_pick_loc_id
				--print @in_item_number
				--print @picked_qty
				--print @in_allo_id 

				SELECT top 1 @pick_id = alo.pick_id
						,@allocated_qty = alo.allocated_qty - alo.picked_qty
						,@seq_id = alo.seq_id
						,@order_number = alo.order_number
						,@ref_number = alo.ref_number
						,@hu_id = alo.hu_id
						,@lot_number = alo.lot_number
						,@stored_attribute_id = alo.stored_attribute_id
						,@expiration_date = alo.expiration_date
						,@damage_flag = alo.damage_flag
						,@allo_type = alo.allo_type
				FROM tbl_allocation alo 
				WHERE alo.seq_id = @in_allo_id
				AND alo.status = 'U'		
				and  (alo.allocated_qty - alo.picked_qty >= @in_pick_qty)
				AND (EXISTS(SELECT 1 FROM t_stored_item
									WHERE wh_id = @in_wh_id
										AND location_id = @in_pick_loc_id
										AND item_number = @in_item_number
										AND ISNULL(hu_id,'') = ISNULL(alo.hu_id,'')
										AND actual_qty >= @in_pick_qty))
				order by alo.pick_id
		 
				IF @@ROWCOUNT = 0
					BEGIN
						SET @errmsg = '商品('+@in_item_number + ') 在当前货位(' + @in_pick_loc_id + ')上没有合适的任务' 
						--RAISERROR ('没有合适的任务',  -- Message text.
						RAISERROR (@errmsg,  -- Message text.
						   16, -- Severity.
						   1     -- State.
						   );						    
					END 
				
				SELECT @Rec_Cnt = COUNT(1)
						 FROM t_stored_item
									WHERE wh_id = @in_wh_id
										AND location_id = @in_pick_loc_id
										AND item_number = @in_item_number
										AND ISNULL(hu_id,'') = ISNULL(@hu_id,'')
										AND actual_qty >= @in_pick_qty
										AND ISNULL(lot_number,'') = ISNULL(@lot_number,'')
										AND ISNULL(stored_attribute_id,'') = ISNULL(@stored_attribute_id,'')
										AND status = 'A'
				

				IF @Rec_Cnt = 0
				BEGIN
					SET @errmsg = '商品('+@in_item_number + ') 在当前货位(' + @in_pick_loc_id + ')上拣货数量超出实际数量' 
					--RAISERROR ('拣货数量超出实际数量',  -- Message text.
					RAISERROR (@errmsg,  -- Message text.
						   16, -- Severity.
						   1     -- State.
						   );

				--SET @out_msg = '商品在当前货位上有补货任务未完成'
				SET @out_passornot = 1
				RETURN
				END

				IF @in_pick_qty <= @allocated_qty
					BEGIN
						SET @picked_qty= @in_pick_qty
						
						SET @allocated_qty = @allocated_qty - @in_pick_qty
					END
				ELSE
					BEGIN
						SET @picked_qty= @allocated_qty
						SET @allocated_qty = 0
					END

				BEGIN TRANSACTION
	 
				--Updated t_pick_detail
				--UPDATE t_pick_detail
				--SET status = (CASE WHEN  picked_quantity + @picked_qty = planned_quantity
				--					THEN 'PICKED'
				--				ELSE status END)
				--	,picked_quantity = picked_quantity + @picked_qty
				--WHERE pick_id = @pick_id
				
				 
				--Update allocation information
				--UPDATE tbl_allocation
				--SET status = (CASE WHEN  picked_qty + @picked_qty = allocated_qty
				--					THEN 'C'
				--				ELSE 'U' END)
				--	,picked_qty = picked_qty + @picked_qty
				--WHERE seq_id = @seq_id
				UPDATE tbl_allocation
				SET status = 'C'
					,picked_qty = picked_qty + @picked_qty					
				WHERE seq_id = @seq_id
				
/*********  Updated by Trevor on 20160402 - stated  ******/
				--IF @allo_type = 'S'
				--BEGIN
				--	UPDATE t_pick_detail
				--	SET status = 'STAGED'
				--		,picked_quantity = picked_quantity + @picked_qty
				--		,staged_quantity = staged_quantity + @picked_qty
				--	WHERE pick_id = @pick_id

				--	UPDATE t_order
				--	SET status ='STAGED'
				--	   ,date_picked = getdate()
				--	WHERE wh_id = @in_wh_id
				--	and order_number = @order_number
				--	and not exists ( select 1 from t_pick_detail pkd
				--					 where pkd.wh_id = t_order.wh_id
				--					 and pkd.order_number = t_order.order_number
				--					 and pkd.planned_quantity <> pkd.staged_quantity
				--					 and pkd.type = 'PP'
				--					 )
				--END
				--ELSE
				--BEGIN
				--	UPDATE t_pick_detail
				--	SET status = 'LOADED'
				--		,picked_quantity = picked_quantity + @picked_qty
				--		,staged_quantity = staged_quantity + @picked_qty
				--		,loaded_quantity = loaded_quantity + @picked_qty
				--	WHERE pick_id = @pick_id

				--	UPDATE t_order
				--	SET status ='LOADED'
				--	   ,date_picked = getdate()
				--	WHERE wh_id = @in_wh_id
				--	and order_number = @order_number
				--	and not exists ( select 1 from t_pick_detail pkd
				--					 where pkd.wh_id = t_order.wh_id
				--					 and pkd.order_number = t_order.order_number
				--					 and pkd.planned_quantity <> pkd.loaded_quantity
				--					 and pkd.type = 'PP'
				--					 )

				--END

					UPDATE t_pick_detail
					SET status = 'LOADED'
						,picked_quantity = picked_quantity + @picked_qty
						,staged_quantity = staged_quantity + @picked_qty
						,loaded_quantity = loaded_quantity + @picked_qty
					WHERE pick_id = @pick_id
					
					begin
                      If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                           left join t_pick_detail b
									     on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                          where isnull(b.status,'')<>'LOADED' and a.order_number= @order_number and a.wh_id=@in_wh_id
									    and isnull(b.work_type,'')='')
			          UPDATE t_order SET status = 'LOADED'
					                 ,date_picked = getdate()
					 where order_number= @order_number and wh_id=@in_wh_id
					end

/*********  Updated by Trevor on 20160402 - ended  ******/

				--UPDATE t_order
				--SET status ='LOADED'
				--   ,date_picked = getdate()
				--WHERE wh_id = @in_wh_id
				--and order_number = @order_number

				--UPDATE t_order
				--SET status ='PICKED'
				--   ,date_picked = getdate()
				--WHERE wh_id = @in_wh_id
				--and order_number = @order_number
				--and not exists ( select 1 from t_pick_detail pkd
				--				 where pkd.wh_id = t_order.wh_id
				--				 and pkd.order_number = t_order.order_number
				--				 and pkd.planned_quantity <> pkd.picked_quantity
				--				 and pkd.type = 'PP'
				--				 )

				set @type = 'SO'
				SET @pick_type = @pick_id
				 

				-- calculate zone
				SET @zone_group = dbo.fn_Get_StorageType_ByItem(@in_wh_id,@in_item_number,CASE ISNULL(@damage_flag,'N') WHEN 'Y' THEN 'D' ELSE 'N' END)
				SELECT TOP 1 @zone = zone 
					FROM t_zone 
				WHERE zone_type = CASE ISNULL(@damage_flag,'N') WHEN 'Y' THEN 'D' ELSE 'N' END 
				AND wh_id = @in_wh_id
				AND zone_group = @zone_group

				IF @allo_type = 'S'
				BEGIN
					SET @staging_loc_type = 'X'
				END

				IF @allo_type = 'O'
				BEGIN
					SET @staging_loc_type = 'D'
				END 
				
				SELECT @dest_stagin_loc =  location_id  
				FROM tbl_zone_staging 
				WHERE zone = @zone
				AND type = @staging_loc_type
				AND wh_id = @in_wh_id
				 
				--Move the stock to fork
				EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @in_wh_id,
						@in_vchItemNumber = @in_item_number,
						@in_vchLocationID = @dest_stagin_loc,
						@in_nType = @pick_type,
						@in_vchHUID = @in_dest_hu_id,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @stored_attribute_id,
						@in_fQty = @picked_qty,
						@in_dtFifoDate = NULL,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = @type,
						@in_vchShipmentNumber =@ref_number,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT

				UPDATE t_hu_master SET zone = @zone ,subtype =  CASE ISNULL(@damage_flag,'N') WHEN 'Y' THEN 'D' ELSE 'N' END + @zone_group
				WHERE wh_id = @in_wh_id AND hu_id = @in_dest_hu_id
				 
				--Create tran log
				--Insert t_tran_log_holding
				INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
					,wh_id_2,location_id_2,hu_id_2
					,generic_attribute_1,
					generic_attribute_2,
					generic_attribute_3,
					generic_attribute_4,
					generic_attribute_5,
					generic_attribute_6,
					generic_attribute_7,
					generic_attribute_8,
					generic_attribute_9,
					generic_attribute_10,
					generic_attribute_11)
				VALUES
					(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@in_user_id,@order_number,@pick_id
					,@in_wh_id,@in_pick_loc_id,@hu_id,@in_item_number,@lot_number,@picked_qty
					,@in_wh_id,@dest_stagin_loc,@in_dest_hu_id
					,(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_1),    
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_2), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_3), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_4), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_5), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_6), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_7), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_8), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_9), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_10), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_11)
					)

					SET @remove_qty = @picked_qty * -1
					--Remove the stock from pick location
					EXEC	[dbo].[csp_Inventory_Adjust]
							@in_vchWhID = @in_wh_id,
							@in_vchItemNumber = @in_item_number,
							@in_vchLocationID = @in_pick_loc_id,
							@in_nType =0,
							@in_vchHUID = @hu_id,
							@in_vchLotNumber =@lot_number,
							@in_nStoredAttributeID = @stored_attribute_id,
							@in_fQty = @remove_qty,
							@in_dtFifoDate = NULL,
							@in_dtExpirationDate = @expiration_date,
							@in_vchHUType = N'IV',
							@in_vchShipmentNumber =NULL,
							@in_damage_flag = @damage_flag,
							@out_vchCode = @out_vchCode OUTPUT,
							@out_vchMsg = @out_vchMsg OUTPUT
 
					--供应链0短拣不需要重新生成拣货任务，Deleted by George on 20160820
					--IF @allocated_qty > 0
					--BEGIN
					--	-- short pick
					--	EXEC [dbo].[csp_EmptyLocPick_Exception]    
					--		 @in_wh_id 
					--		,@ref_number 
					--		,@in_pick_loc_id 
					--		,@in_item_number 
					--		,@in_user_id 
					--		,@hu_id 
					--		,@out_passornot output
					--		,@out_msg output
					--END
			END
			--供应链0短拣不需要重新生成拣货任务，Deleted by George on 20160820
			--ELSE 
			--BEGIN
			--	-- short pick
			--	EXEC [dbo].[csp_EmptyLocPick_Exception]    
			--		 @in_wh_id 
			--		,@ref_number 
			--		,@in_pick_loc_id 
			--		,@in_item_number 
			--		,@in_user_id 
			--		,@hu_id 
			--		,@out_passornot output
			--		,@out_msg output
			--END
			
			--供应链没有播种墙，Deleted by George on 20160820
			--如果分配了播种墙，则释放播种墙
			--IF Exists(select 1 from tbl_allocation 
			--		where wh_id=@in_wh_id 
			--			and seq_id=@in_allo_id 
			--			and status='C' 
			--			and allo_type ='S'
			--			and isnull(pick_wall_slot,'')<>'')
			--BEGIN
			--	delete sl from tbl_pick_wall_slot_detail sl
			--	where sl.wh_id = @in_wh_id 
			--		and Exists(select 1 from tbl_allocation al 
			--			where sl.wh_id=al.wh_id 
			--				and sl.slot=al.pick_wall_slot 
			--				and sl.wall_id=al.ref_number 
			--				and sl.order_number=al.order_number 
			--				and al.seq_id=@in_allo_id)

			--	update lp set status=1 
			--	from tbl_inf_dps_lp lp 
			--	inner join tbl_allocation al 
			--		on lp.wave_id=al.wave_id 
			--		and lp.order_number=al.order_number 
			--		and lp.item_number=al.item_number 
			--		and lp.pick_wall_slot=al.pick_wall_slot 
			--	where al.wh_id=@in_wh_id 
			--		and seq_id=@in_allo_id 
			--		and lp.status=0
				
			--	update tbl_allocation 
			--		set ref_number=''
			--			,pick_wall_loc=''
			--			,pick_wall_slot='' 
			--	where seq_id=@seq_id 
			--		and wh_id=@in_wh_id 

			--	select top 1 @customer_code=cs.customer_code,@wave_id=al.wave_id from tbl_allocation al 			
			--	inner join t_order od on al.wh_id=od.wh_id and al.order_number=od.order_number 
			--	inner join t_customer cs on od.wh_id=cs.wh_id and od.customer_id=cs.customer_id 
			--	where al.wh_id=@in_wh_id 
			--		and al.seq_id=@in_allo_id 

			--	If Not Exists(select 1 from tbl_pick_wall_slot_detail sl 
			--				inner join t_order od on sl.wh_id=od.wh_id and sl.order_number=od.order_number 
			--				inner join t_afo_wave_detail wd on od.wh_id=wd.wh_id and od.order_number=wd.order_number 
			--				inner join t_customer cs on od.wh_id=cs.wh_id and od.customer_id=cs.customer_id 
			--				where sl.wh_id=@in_wh_id 
			--					and cs.customer_code=@customer_code 
			--					and wd.wave_id=@wave_id)
			--	BEGIN
			--		update tbl_pick_wall_slot 
			--			set status='U'
			--			,customer_code=NULL
			--			,wave_id=NULL
			--		where wh_id=@in_wh_id
			--			and wave_id=@wave_id 
			--			and customer_code=@customer_code
			--	END
			--END
		
			--IF @out_passornot = 1
			--BEGIN
			--	RAISERROR (@out_msg,  -- Message text.
			--			   16, -- Severity.
			--			   1     -- State.
			--			   );
			--END
			
			--CREATE SN Interface
            SET @out_passornot = 0
            SET @out_msg = ''

			IF @@TRANCOUNT > 0
				COMMIT		
            RETURN
        END TRY
        BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
	
            SET @out_msg = ERROR_MESSAGE()
            SET @out_passornot = 1

			RAISERROR (@out_msg,  -- Message text.
						   16, -- Severity.
						   1     -- State.
						   );

            RETURN
        END CATCH

    END



