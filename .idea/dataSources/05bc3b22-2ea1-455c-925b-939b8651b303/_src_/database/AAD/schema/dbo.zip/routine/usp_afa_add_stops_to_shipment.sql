
CREATE PROCEDURE usp_afa_add_stops_to_shipment
@in_vchWarehouseId        NVARCHAR(20),
@in_vchLoadId             NVARCHAR(60),
@out_vchMessage           NVARCHAR(200) OUTPUT -- Contains "SUCCESS" or the message to be displayed.

AS
DECLARE
    @v_nErrorNumber       INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,
    @v_nReturn            INTEGER,
    @v_vchErrorMsg        NVARCHAR(200),

    @e_GenSqlError        INTEGER,
    @e_SprocError         INTEGER,
    @e_InsStopFailed      INTEGER,
    @e_UpdateStopFailed   INTEGER,
    @e_UpdateLDFailed     INTEGER,

    @v_nTranCount         INTEGER,
    @v_nSequence          INTEGER,
    @v_nValue             INTEGER,
    @v_chStatus           CHAR(1),
    @v_nLastStopId        INTEGER, 
    @v_nStopId            INTEGER

    SET NOCOUNT ON

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 4
    SET @out_vchMessage = 'SUCCESS'

    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_InsStopFailed = 3
    SET @e_UpdateStopFailed = 4
    SET @e_UpdateLDFailed = 5


    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN
    IF @v_nTranCount = 0
        BEGIN TRANSACTION


    -- Create Stops
    INSERT INTO t_stop (load_id, wh_id, ship_to_name, ship_to_addr1, ship_to_addr2, ship_to_addr3, ship_to_city,
       ship_to_state, ship_to_zip, ship_to_country_code, delivery_name, delivery_addr1, delivery_addr2, delivery_addr3, delivery_city,
       delivery_state, delivery_zip, delivery_country_code)
       SELECT distinct @in_vchLoadId,  @in_vchWarehouseId, o.ship_to_name, o.ship_to_addr1, o.ship_to_addr2, o.ship_to_addr3,
        o.ship_to_city, o.ship_to_state, o.ship_to_zip, o.ship_to_country_code, o.ship_to_name, o.ship_to_addr1, o.ship_to_addr2, o.ship_to_addr3,
        o.ship_to_city, o.ship_to_state, o.ship_to_zip, o.ship_to_country_code
       FROM t_order o, t_afa_load_detail ld
       WHERE o.order_number = ld.order_number 
	  and ld.wh_id = @in_vchWarehouseId
           and ld.load_id = @in_vchLoadId 
	   and not exists (	select * 
				from t_stop ts 
				where ts.load_id = @in_vchLoadId 
				and ts.wh_id = @in_vchWarehouseId
				and ((ts.ship_to_country_code = o.ship_to_country_code) OR ((ts.ship_to_country_code IS NULL) AND (o.ship_to_country_code IS NULL))) 
				and ((ts.ship_to_addr1 = o.ship_to_addr1) OR ((ts.ship_to_addr1 IS NULL) AND (o.ship_to_addr1 IS NULL)))
				and ((ts.ship_to_addr2 = o.ship_to_addr2) OR ((ts.ship_to_addr2 IS NULL) AND (o.ship_to_addr2 IS NULL)))
				and ((ts.ship_to_addr3 = o.ship_to_addr3) OR ((ts.ship_to_addr3 IS NULL) AND (o.ship_to_addr3 IS NULL)))
				and ((ts.ship_to_city = o.ship_to_city) OR ((ts.ship_to_city IS NULL) AND (o.ship_to_city IS NULL)))
				and ((ts.ship_to_state = o.ship_to_state) OR ((ts.ship_to_state IS NULL) AND (o.ship_to_state IS NULL)))
				and ((ts.ship_to_zip = o.ship_to_zip) OR ((ts.ship_to_zip IS NULL) AND (o.ship_to_zip IS NULL)))
				and ((ts.delivery_country_code = o.ship_to_country_code) OR ((ts.delivery_country_code IS NULL) AND (o.ship_to_country_code IS NULL)))
				and ((ts.delivery_addr1 = o.ship_to_addr1) OR ((ts.delivery_addr1 IS NULL) AND (o.ship_to_addr1 IS NULL)))
				and ((ts.delivery_addr2 = o.ship_to_addr2) OR ((ts.delivery_addr2 IS NULL) AND (o.ship_to_addr2 IS NULL)))
				and ((ts.delivery_addr3 = o.ship_to_addr3) OR ((ts.delivery_addr3 IS NULL) AND (o.ship_to_addr3 IS NULL)))
				and ((ts.delivery_city = o.ship_to_city) OR ((ts.delivery_city IS NULL) AND (o.ship_to_city IS NULL)))
				and ((ts.delivery_state = o.ship_to_state) OR ((ts.delivery_state IS NULL) AND (o.ship_to_state IS NULL)))
				and ((ts.delivery_zip = o.ship_to_zip) OR ((ts.delivery_zip IS NULL) AND (o.ship_to_zip IS NULL))) ) 

    -- Check for errors
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN    
      SET @v_nErrorNumber = @e_InsStopFailed
      GOTO ErrorHandler
    END

    -- Update stop sequences on t_stop table
    UPDATE t_stop set stop_sequence = (SELECT count(*) from t_stop ts2 where
      ts2.stop_id <= ts1.stop_id and ts2.load_id = @in_vchLoadId and ts2.wh_id = @in_vchWarehouseId)
    FROM t_stop ts1
    WHERE ts1.load_id = @in_vchLoadId and ts1.wh_id = @in_vchWarehouseId and stop_sequence is null

    -- Check for errors
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
      SET @v_nErrorNumber = @e_UpdateStopFailed
      GOTO ErrorHandler
    END
    
    UPDATE t_afa_load_detail set stop_id = 
    (SELECT distinct s.stop_id FROM t_afa_load_detail ld, t_order o, t_stop s
    WHERE t_afa_load_detail.load_detail_id = ld.load_detail_id and 
	ld.wh_id = o.wh_id and ld.order_number = o.order_number and 
        ld.load_id = s.load_id and ld.wh_id = s.wh_id and
	((o.ship_to_name = s.ship_to_name) or ((o.ship_to_name is null) and (s.ship_to_name is null))) and
	((o.ship_to_addr1 = s.ship_to_addr1) or ((o.ship_to_addr1 is null) and (s.ship_to_addr1 is null))) and   
	((o.ship_to_addr2 = s.ship_to_addr2) or ((o.ship_to_addr2 is null) and (s.ship_to_addr2 is null))) and   
	((o.ship_to_addr3 = s.ship_to_addr3) or ((o.ship_to_addr3 is null) and (s.ship_to_addr3 is null))) and   
	((o.ship_to_city = s.ship_to_city) or ((o.ship_to_city is null) and (s.ship_to_city is null))) and   
        ((o.ship_to_state = s.ship_to_state) or ((o.ship_to_state is null) and (s.ship_to_state is null))) and   
        ((o.ship_to_zip = s.ship_to_zip) or ((o.ship_to_zip is null) and (s.ship_to_zip is null))) and   
        ld.load_id = @in_vchLoadId and ld.wh_id = @in_vchWarehouseId)
   WHERE stop_id is null and load_id = @in_vchLoadId and wh_id = @in_vchWarehouseId 
   
      -- Check for errors
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END


    SELECT @v_nStopId = stop_id FROM t_afa_load_detail WHERE bill_number is null
    

    UPDATE t_afa_load_detail set bill_number =
           (SELECT min(ld.load_detail_id) 
            FROM t_afa_load_detail ld
            WHERE ld.load_id = @in_vchLoadId AND 
                  ld.wh_id = @in_vchWarehouseId AND 
                  ld.stop_id = @v_nStopId) 
    WHERE bill_number is null AND 
          load_id = @in_vchLoadId AND 
          wh_id = @in_vchWarehouseId 

    -- Check for errors
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END

    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE

    IF @v_nTranCount = 0
        COMMIT TRANSACTION


    GoTo ExitLabel

 

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    ELSE IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
            ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
       EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(varchar(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END
    ELSE IF @v_nErrorNumber = @e_InsStopFailed
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Error occurred inserting a record in to the t_stop table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_stop'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_UpdateStopFailed
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Error occurred updating a record in the t_stop table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_stop'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_UpdateLDFailed
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Error occurred updating a record in the t_afa_load_detail table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afa_load_detail'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END

    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    -- Raiserror parameters: Error #, Severity(11=ADO requirement), State(1), Parameter(to be used in error)
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)


ExitLabel:
    RETURN

