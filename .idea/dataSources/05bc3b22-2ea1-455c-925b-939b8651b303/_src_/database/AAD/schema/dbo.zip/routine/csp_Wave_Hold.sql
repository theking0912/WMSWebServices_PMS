CREATE PROCEDURE [dbo].[csp_Wave_Hold]
    @wh_id NVARCHAR(10) ,
    @wave_id NVARCHAR(30)
AS
    BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
        SET NOCOUNT ON;    

        BEGIN TRY
            DECLARE @wave_type NVARCHAR(20)

            UPDATE  tbl_allocation
            SET     status = 'H'
            WHERE   wh_id = @wh_id
                    AND wave_id = @wave_id
                    AND allocated_qty > picked_qty

            IF EXISTS ( SELECT  1
                        FROM    tbl_allocation allo
                        WHERE   wh_id = @wh_id
                                AND wave_id = @wave_id
                                AND allocated_qty > picked_qty
                                AND status = 'H' )
                BEGIN
                    --UPDATE  t_pick_detail
                    --SET     status = 'H'
                    --WHERE   wh_id = @wh_id
                    --        AND wave_id = @wave_id
			
                    UPDATE  t_wave_master
                    SET     status = 'H'
                    WHERE   wh_id = @wh_id
                            AND wave_id = @wave_id
                END
            ELSE
                IF NOT EXISTS ( SELECT  1
                                FROM    tbl_allocation allo
                                WHERE   wh_id = @wh_id
                                        AND wave_id = @wave_id )
                    BEGIN
                        --UPDATE  t_pick_detail
                        --SET     status = 'H'
                        --WHERE   wh_id = @wh_id
                        --        AND wave_id = @wave_id
			
                        UPDATE  t_wave_master
                        SET     status = 'H'
                        WHERE   wh_id = @wh_id
                                AND wave_id = @wave_id
                    END

            RETURN

        END TRY

        BEGIN CATCH
            RETURN
        END CATCH
  
    END
