
CREATE PROCEDURE usp_arch_process_ctype_ct
      @in_vTable     NVARCHAR(100),
      @in_vID        INTEGER
    
AS
DECLARE 
-- Error handling and logging variables.
   @c_nModuleNumber         INT, -- The # that uniquely tags the WA collection of objects.
   @c_nFileNumber           INT, -- The # that uniquely tags this object.
   @c_vchObjName            NVARCHAR(30), -- The name that uniquely tags this object.
   @v_nLogErrorNum          INT, -- The # that uniquely tags the error message.
   @v_nLogLevel             INT, -- Holds log level (1-5).
   @v_vchErrorMsg           NVARCHAR(500),
   @v_nSysErrorNum          INT,
   @v_nSysRowCount          INT,
   @v_nReturn               INT,

-- Log Error numbers used for branching in the Error Handler.
   @e_GenSqlError           INT,
   @e_SprocError            INT,
   @e_InvalidType           INT,

-- Local Variables
   @vHTable		    NVARCHAR(100),
   @vLongStrDDL		    NVARCHAR(4000),
   @VCname        	    INT,
   @vSchema		    NVARCHAR(15),
   @vHTabPrefix             NVARCHAR(10),
   @vHTabSuffix             NVARCHAR(10),
   @vTableColumns           NVARCHAR(4000),
   @vExistTable             NVARCHAR(3),
   @ValidChars              NVARCHAR(3),
   @vSeq                    INTEGER,

   --Variables to interact with table t_arch_backup_control
   @bc_backup_control_id    INTEGER,
   @bc_table_name           NVARCHAR(100),
   @bc_control_type         NVARCHAR(2),
   @bc_where_clause         NVARCHAR (2000),
   @bc_last_processed_date  DATETIME ,
   @bc_status               NCHAR(1),
   @bc_hist_table_prefix    NVARCHAR (10),
   @bc_hist_table_suffix    NVARCHAR (10),
   @bc_table_schema         NVARCHAR(15),
   @bc_elapsed_time         NVARCHAR(26),
   @bc_last_exec_message    NVARCHAR(400),
   @bc_exec_frequency       INTEGER,
   @bc_stored_procedure     NVARCHAR(100),
   @bc_hist_database        NVARCHAR(10)

BEGIN 
-- Set constant values.
   SET @c_nModuleNumber = 60     -- Always #60 for WA.
   SET @c_nFileNumber = 1        -- This # must be unique per object
   SET @c_vchObjName = 'usp_arch_process_ctype_ct'
   SET @e_GenSqlError = 1
   SET @e_SprocError = 2
   SET @e_InvalidType = 3

   SET @v_nSysErrorNum = 0
   SET @v_nLogErrorNum = 0
   SET @v_vchErrorMsg = ''

   SET NOCOUNT ON
 
   SELECT 
         @bc_backup_control_id = backup_control_id,
         @bc_table_name = table_name,
         @bc_control_type = control_type,
         @bc_where_clause = where_clause,
         @bc_last_processed_date = last_processed_date,
         @bc_status = status,
         @bc_hist_table_prefix = hist_table_prefix,
         @bc_hist_table_suffix = hist_table_suffix,
         @bc_table_schema = table_schema,
         @bc_elapsed_time = elapsed_time,
         @bc_last_exec_message = last_exec_message,
         @bc_exec_frequency = exec_frequency,
         @bc_stored_procedure = stored_procedure,
         @bc_hist_database = hist_database
    FROM t_arch_backup_control 
    WHERE id = @in_vID

   SELECT @v_nSysErrorNum = @@ERROR
   IF @v_nSysErrorNum <> 0
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Error retrieving record from t_arch_backup_control.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END

   SET @vExistTable = dbo.usf_arch_object_exists(@bc_table_name,'TABLE',@bc_table_name)

   IF @vExistTable = 'NO'
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Error table ' + @bc_table_name + ' does not exist.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END
   

   --Get Table columns
   SET @vTableColumns = dbo.usf_arch_get_table_columns(@bc_table_name)

   SELECT @v_nSysErrorNum = @@ERROR
   IF @v_nSysErrorNum <> 0
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Error when executing usf_arch_get_table_columns'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END

   SET @ValidChars = dbo.usf_arch_valid_table_chars(@bc_hist_table_prefix, 'PREFIX')
   IF @ValidChars = 'NO'
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Prefix can not start with a number and can only contain letters, numbers and underscores.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END

   SET @ValidChars = dbo.usf_arch_valid_table_chars(@bc_hist_table_suffix, 'SUFFIX')
   IF @ValidChars = 'NO'
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Prefix and Suffix can only contain letters, numbers and underscores.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END

   --Set Vars
   SET @vHTable = LTRIM(RTRIM(ISNULL(@bc_hist_table_prefix,'')))
                + LTRIM(RTRIM(@bc_table_name))
                + LTRIM(RTRIM(ISNULL(@bc_hist_table_suffix,'')))

	IF @bc_hist_database IS NULL OR @bc_hist_database = ''
      BEGIN
        SET @bc_hist_database = 'AAD'
      END


   
   EXECUTE dbo.usp_arch_table_exists @vHTable, @bc_hist_database, @vExistTable OUTPUT

   IF @vExistTable = 'YES'
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Error table ' + @vHTable + ' already exists.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END


    SET @vHTable = @bc_hist_database + '..' + @vHTable    
   --Get Next value to generate primary key 
   BEGIN TRANSACTION
      SELECT @vSeq = next_value
       FROM t_sca_control
       WHERE control_type = 'ARCH_HIST_PK_VAL'
     
      IF @@ROWCOUNT < 1
         BEGIN
            INSERT INTO t_sca_control VALUES ('ARCH_HIST_PK_VAL','PK Hist Tables',1,'SHOW_VA','0',NULL,NULL,NULL)
            SELECT @vSeq = 1
         END 
      ELSE
         BEGIN       
            UPDATE t_sca_control
               SET next_value = next_value + 1
             WHERE control_type = 'ARCH_HIST_PK_VAL'
         END
   COMMIT TRANSACTION
      
          
   --Build DDL statement
   SET @vLongStrDDL = 'CREATE TABLE '
                     + @vHTable
                     + ' ('
                     + @vTableColumns
                     + ', DATE_TIME_H DATETIME DEFAULT GETDATE()'
                     + ', ID_H INT IDENTITY'
                     + ', CONSTRAINT '
                     + 'PK_'
                     + CAST(@vSeq AS NVARCHAR(10))
                     + '_ID_H'
                     + ' PRIMARY KEY(ID_H))'


   -- Create the History Table   
   EXEC(@vLongStrDDL)

   SELECT @v_nSysErrorNum = @@ERROR
   IF @v_nSysErrorNum <> 0
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Error when Executing the DDL statement to create the History table. DDL Statement: '
                           + @vLongStrDDL + ' .'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END


   INSERT INTO t_arch_created_hist_table     
              (table_name, 
               table_schema, 
               hist_table_name, 
               hist_table_prefix,
               hist_table_suffix, 
               hist_database, 
               date_time)
       VALUES (@bc_table_name,
               @bc_table_schema,
               LTRIM(RTRIM(ISNULL(@bc_hist_table_prefix,''))) 
             + LTRIM(RTRIM(@bc_table_name))
             + LTRIM(RTRIM(ISNULL(@bc_hist_table_suffix,''))),
               @bc_hist_table_prefix,
               @bc_hist_table_suffix,
               @bc_hist_database,
               GETDATE())

   SELECT @v_nSysErrorNum = @@ERROR
   IF @v_nSysErrorNum <> 0
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Error during insertion in table t_arch_created_hist_table'
                           + @vLongStrDDL + ' .'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END

 
   DELETE t_arch_backup_control WHERE id = @in_vID

   SELECT @v_nSysErrorNum = @@ERROR
   IF @v_nSysErrorNum <> 0
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ':Error during deletion of table t_arch_backup_control'
                           + @vLongStrDDL + ' .'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
      END


GOTO EXIT_LABEL

ERROR_HANDLER:

   UPDATE t_arch_backup_control
     SET last_exec_message = @v_vchErrorMsg + '. Error Number: ' + CAST(@v_nSysErrorNum AS NVARCHAR(10)),
         status = 'F'
   WHERE id = @in_vID

EXIT_LABEL:

END 

