
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Get_Next_Pick_Dock] 
	-- Add the parameters for the stored procedure here
	@In_Nvch_Zone						AS	NVARCHAR(10),
	@In_Nvch_Current_Loc				AS	NVARCHAR(30),
	@In_Nvch_Wh_ID						AS	NVARCHAR(10),
	@In_Nvch_Ref_Number					AS	NVARCHAR(30),
	@In_Nvch_User_Id					AS	NVARCHAR(30),	
	@In_Nvch_Pick_Item_Number			AS	NVARCHAR(30),
	@Out_Nvch_Next_Loc					AS	NVARCHAR(30)		OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE		@Loc_Header_String		AS	NVARCHAR(10)
	DECLARE		@Dock_No				AS	INT
	DECLARE		@Next_Dock_No			AS	INT
	DECLARE		@Last_Dock_No			AS	INT
	DECLARE		@Last_Loc				AS	NVARCHAR(30)
	

	SELECT  TOP 1 @Out_Nvch_Next_Loc = zl.location_id FROM t_zone_loca zl
		INNER JOIN t_location l
		ON l.location_id = zl.location_id
		AND l.wh_id = zl.wh_id
	WHERE zl.zone = @In_Nvch_Zone
		AND l.type <> 'F'
		AND zl.wh_id = @In_Nvch_Wh_ID
		AND CONVERT(NVARCHAR,CONVERT(INT,SUBSTRING(zl.location_id,3,2))) > CONVERT(NVARCHAR,CONVERT(INT,SUBSTRING(@In_Nvch_Current_Loc,3,2)))
		ORDER BY pick_seq ASC

	IF @@ROWCOUNT = 0
	BEGIN
		SELECT TOP 1 @Out_Nvch_Next_Loc = zl.location_id FROM t_zone_loca zl
				INNER JOIN t_location l
				ON l.location_id = zl.location_id
				AND l.wh_id = zl.wh_id
			WHERE  zl.zone = @In_Nvch_Zone 
				AND l.type <> 'F'
				AND zl.wh_id = @In_Nvch_Wh_ID
				ORDER BY pick_seq ASC
	END

	UPDATE tbl_allocation
		SET user_assign = NULL
			,status ='U'
		WHERE wh_id = @In_Nvch_Wh_ID
		and status = 'A'
		AND zone = @In_Nvch_Zone
		AND ref_number = @In_Nvch_Ref_Number
		AND allo_type in ('CU','BU')
		AND location_id = @In_Nvch_Current_Loc
		AND item_number = @In_Nvch_Pick_Item_Number
		AND user_assign = @In_Nvch_User_Id

	RETURN 1
 --   --SELECT SUBSTRING('2-01-11-01-01-1',1,2) + RIGHT('00' + CONVERT(NVARCHAR,CONVERT(INT,SUBSTRING('2-01-11-01-01-1',3,2)) + 1),2)
	---- for example : 01
	--SET @Dock_No = CONVERT(NVARCHAR,CONVERT(INT,SUBSTRING(@In_Nvch_Current_Loc,3,2)))
	
	---- get the last dock no 
	--SELECT TOP 1 @Last_Loc = location_id FROM t_zone_loca WHERE zone = @In_Nvch_Zone AND wh_id = @In_Nvch_Wh_ID ORDER BY pick_seq DESC

	--IF ISNULL(@Last_Loc,'') = ''
	--BEGIN
	--	SET @Out_Nvch_Next_Loc = @In_Nvch_Current_Loc

	--	UPDATE tbl_allocation
	--		SET user_assign = NULL
	--			,status ='U'
	--		WHERE wh_id = @In_Nvch_Wh_ID
	--		and status = 'A'
	--		AND zone = @In_Nvch_Zone
	--		AND ref_number = @In_Nvch_Ref_Number
	--		AND allo_type in ('CU','BU')
	--		AND location_id = @In_Nvch_Current_Loc
	--		AND item_number = @In_Nvch_Pick_Item_Number
	--		AND user_assign = @In_Nvch_User_Id
	--	RETURN 1
	--END
	--ELSE
	--BEGIN
	--	SET @Last_Dock_No = CONVERT(NVARCHAR,CONVERT(INT,SUBSTRING(@Last_Loc,3,2)))
	--	SET @Out_Nvch_Next_Loc = @Last_Loc
	--END
	
	--SET @Next_Dock_No = @Dock_No
	--WHILE(1=1)
	--BEGIN
	--	IF @Next_Dock_No >= @Last_Dock_No 
	--	BEGIN
	--		-- get the first location 
	--		SELECT TOP 1 @Out_Nvch_Next_Loc = zl.location_id FROM t_zone_loca zl
	--			INNER JOIN t_location l
	--			ON l.location_id = zl.location_id
	--			AND l.wh_id = zl.wh_id
	--		WHERE zl.zone = @In_Nvch_Zone 
	--		    AND zl.wh_id = @In_Nvch_Wh_ID
	--			AND l.type <> 'F'

	--		UPDATE tbl_allocation
	--			SET user_assign = NULL
	--				,status ='U'
	--			WHERE wh_id = @In_Nvch_Wh_ID
	--			and status = 'A'
	--			AND zone = @In_Nvch_Zone
	--			AND ref_number = @In_Nvch_Ref_Number
	--			AND allo_type in ('CU','BU')
	--			AND location_id = @In_Nvch_Current_Loc
	--			AND item_number = @In_Nvch_Pick_Item_Number
	--			AND user_assign = @In_Nvch_User_Id
	--		RETURN 1
	--	END
	--	ELSE
	--	BEGIN
	--		SET @Next_Dock_No = @Next_Dock_No + 1		
		
	--		SET @Loc_Header_String = SUBSTRING(@In_Nvch_Current_Loc,1,2) + RIGHT('00' + CONVERT(NVARCHAR,@Next_Dock_No),2)
		
	--		SELECT TOP 1 @Out_Nvch_Next_Loc = zl.location_id FROM t_zone_loca zl
	--			INNER JOIN t_location l
	--			ON l.location_id = zl.location_id
	--			AND l.wh_id = zl.wh_id
	--		WHERE zl.location_id LIKE  + @Loc_Header_String + '%' 
	--			AND  zl.zone = @In_Nvch_Zone 
	--			AND l.type <> 'F'
	--			AND zl.wh_id = @In_Nvch_Wh_ID
	--			ORDER BY pick_seq ASC
		  

	--		IF @@ROWCOUNT > 0 
	--		BEGIN				
	--			UPDATE tbl_allocation
	--			SET user_assign = NULL
	--				,status ='U'
	--			WHERE wh_id = @In_Nvch_Wh_ID
	--			and status = 'A'
	--			AND zone = @In_Nvch_Zone
	--			AND ref_number = @In_Nvch_Ref_Number
	--			AND allo_type in ('CU','BU')
	--			AND location_id = @In_Nvch_Current_Loc
	--			AND item_number = @In_Nvch_Pick_Item_Number
	--			AND user_assign = @In_Nvch_User_Id
	--			RETURN 1
	--		END
	--	END	
	--END
END

