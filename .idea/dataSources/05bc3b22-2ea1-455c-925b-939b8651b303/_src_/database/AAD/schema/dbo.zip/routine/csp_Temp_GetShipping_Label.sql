CREATE PROCEDURE  [dbo].[csp_GetShipping_Label]   
	@wh_id				nvarchar(20),
	@carrier_code		nvarchar(20),
	@Out_Result         int OUTPUT,
	@out_ShippingLabel	NVARCHAR(200) OUTPUT
AS

BEGIN TRY

	select top 1 @out_ShippingLabel=shipping_label
	from tbl_carrier_shipping_label
	where carrier_code = @carrier_code
	and status = '0'
	order by shipping_label asc

	update tbl_carrier_shipping_label
	set status = '2' -- using
	where  carrier_code = @carrier_code
	and shipping_label = @out_ShippingLabel

	RETURN
END TRY

BEGIN CATCH
    set @Out_Result=-1;
    SET @out_ShippingLabel = ''
    RETURN
END CATCH
