
CREATE PROCEDURE [dbo].[csp_Release_Ord_By_Slot_Test]
	@in_order_number			AS	NVARCHAR(30),
	@in_slot					AS	NVARCHAR(30),
	@in_wh_id                   AS	NVARCHAR(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET XACT_ABORT ON 
	BEGIN TRY

	--	BEGIN TRANSACTION
    -- Insert statements for procedure here
	
			
	--WHILE (1 = 1)
	BEGIN
		SELECT TOP 1 @in_order_number = order_number 
			FROM tbl_pick_wall_slot_detail
			WHERE slot = @in_slot
			AND wh_id =@in_wh_id
			AND order_number = @in_order_number
			ORDER BY order_number ASC
			
		--IF @@ROWCOUNT = 0
		--BEGIN
		--	BREAK
		--END 		
			
	

	END
	
	---- update order status
	--UPDATE t_order
	--	SET status = 'LOADED'
	--	WHERE wh_id = @in_wh_id
	--	AND order_number = @in_order_number
	--	AND EXISTS(SELECT 1 FROM t_pick_detail
	--					WHERE wh_id = @in_wh_id
	--						AND order_number = @in_order_number
	--						AND planned_quantity = loaded_quantity)

	-- update order status
	UPDATE t_order
		SET status = 'LOADED'
		WHERE wh_id =@in_wh_id
		AND order_number = @in_order_number
		AND NOT EXISTS(SELECT 1 FROM t_pick_detail
						WHERE wh_id =  @in_wh_id
							AND order_number = @in_order_number
							AND status <> 'LOADED')

	IF NOT EXISTS(SELECT 1 FROM t_stored_item 
			INNER JOIN tbl_allocation 
			ON t_stored_item.item_number = tbl_allocation.item_number
				AND t_stored_item.wh_id = tbl_allocation.wh_id
				 AND t_stored_item.type = tbl_allocation.pick_id 
				  WHERE tbl_allocation.order_number = @in_order_number
					AND SUBSTRING(t_stored_item.location_id,1,3) <> 'PTL' 
					AND allo_type='S')
		AND NOT EXISTS(SELECT 1 FROM tbl_allocation WHERE order_number = @in_order_number
								AND status NOT IN ('C','E'))
	BEGIN
			-- release the slot
			DELETE FROM tbl_pick_wall_slot_detail
					WHERE wh_id = @in_wh_id
					AND	order_number = @in_order_number
					AND slot = @in_slot
	END

	
	
	UPDATE tbl_pick_wall_slot
		SET status = 'U',
			ship_label_barcode = '',
			order_number = '',
			customer_code = NULL,
			wave_id = NULL
		WHERE wh_id = @in_wh_id
		AND slot = @in_slot
		AND NOT EXISTS( SELECT 1 FROM tbl_pick_wall_slot_detail
							WHERE wh_id = @in_wh_id
								AND slot = @in_slot)

	  
	--COMMIT
	RETURN

	END TRY
	BEGIN CATCH
		ROLLBACK
		-- sp error
		 
		RETURN
	END CATCH
END
