-- Batch submitted through debugger: SQLQuery10.sql|7|0|C:\Users\DEV01\AppData\Local\Temp\3\~vs6F3E.sql

CREATE PROCEDURE [dbo].[csp_Inventory_Adjust_Attribute]
    @in_vchWhID                NVARCHAR(10),
    @in_vchItemNumber          NVARCHAR(30),
    @in_vchLocationID          NVARCHAR(50),
    @in_nType                  BIGINT, 
    @in_vchHUID                NVARCHAR(22),
    @in_vchLotNumber           NVARCHAR(15),
    @in_nStoredAttributeID     BIGINT, 
    @in_fQty                   FLOAT,
    @in_dtFifoDate             DATETIME,
    @in_dtExpirationDate       DATETIME,
    @in_vchHUType              NVARCHAR(10),
    @in_vchShipmentNumber      NVARCHAR(30),
	@in_damage_flag			   NVARCHAR(1),
    @out_vchCode               uddt_output_code   OUTPUT,
    @out_vchMsg                uddt_output_msg    OUTPUT

AS

-- ********************************************************************************
--                             Copyright ⌐ 2013.
--                           All Rights Reserved.
--                            HighJump Software
--                        Minneapolis, Minnesota, USA
-- ********************************************************************************
-- 
--    PURPOSE:
--          The purpose of this stored procedure is to adjust inventory.
--
--    INPUT:
--
--    OUTPUT:
--        out_vchCode - Contains 'SUCCESS' or Error Code.
--        out_vchMsg - Contains the error message or informational log message.:
--      
--  TARGET: SQL Server 2005
--
-- *********************************************************************************
DECLARE
    -- Error handling variables
    @c_vchObjName                   uddt_obj_name,  -- The name that uniquely tags this object.
    @v_vchCode                      uddt_output_code,
    @v_vchMsg                       uddt_output_msg,
    @v_nSysErrorNum                 INT,

    -- Local Variables
    @v_nExists                      BIT,
    @v_nRowCount                    INT,
    @v_fActualQty                   FLOAT,
    @v_fUnavailableQty              FLOAT, 
    @v_nSequence                    INT,
	@v_expire_control				NVARCHAR(4),
	@v_lot_control					NVARCHAR(4),
	@v_nExpire_days					INT
    -- Set Constants
    SET @c_vchObjName = N'csp_Inventory_Adjust'   
    SET @v_vchCode = N'SUCCESS'
    SET @v_vchMsg  = N'NONE'
    SET @v_nSysErrorNum = 0
    SET @v_nSequence = 0

	SELECT @v_lot_control=lot_control,@v_expire_control=expiration_date_control,@v_nExpire_days=shelf_life
	  FROM t_item_master
	where item_number=@in_vchItemNumber
	  and wh_id=@in_vchWhID


	-- Handle NULLS and Implicit NULLS (01/01/1900)
	SET @in_dtFifoDate = CASE WHEN @in_dtFifoDate IS NULL OR @in_dtFifoDate = '01/01/1900' THEN GETDATE() ELSE @in_dtFifoDate END
	SET @in_dtExpirationDate = CASE @in_dtExpirationDate WHEN '01/01/1900' THEN NULL ELSE @in_dtExpirationDate END 
    --IF  @in_dtExpirationDate IS NOT NULL AND @in_dtExpirationDate <> '01/01/1900' AND @in_vchLotNumber IS NULL
	
    SET NOCOUNT ON

-----------------------------------------------------------------------------------
--                  Update STO Record
-----------------------------------------------------------------------------------  
BEGIN TRY  
    UPDATE t_stored_item
       SET @v_fActualQty  = actual_qty = actual_qty + @in_fQty
	  ,unavailable_qty = CASE WHEN status = N'H' THEN actual_qty + @in_fQty  ELSE unavailable_qty END 	  
          ,fifo_date       = CASE WHEN fifo_date < @in_dtFifoDate THEN fifo_date ELSE @in_dtFifoDate END
          --,expiration_date = CASE WHEN @in_dtExpirationDate IS NULL THEN expiration_date ELSE @in_dtExpirationDate END
          ,sequence        = @v_nSequence
     WHERE wh_id       = @in_vchWhID
       AND item_number = @in_vchItemNumber
       AND location_id = @in_vchLocationID
       AND type        = @in_nType
       AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'-1') = ISNULL(@in_vchHUID,'-1')))
       AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'-1') = ISNULL(@in_vchLotNumber,'-1')))
	   AND ((expiration_date = @in_dtExpirationDate) OR (ISNULL(expiration_date,'1900-01-01 00:00:00') = ISNULL(@in_dtExpirationDate,'1900-01-01 00:00:00')))
       AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'-1') = ISNULL(@in_nStoredAttributeID,'-1')))
	   AND ((damage_flag = @in_damage_flag) OR (ISNULL(damage_flag,'Y') = ISNULL(@in_damage_flag,'Y')))
       
       SET @v_nRowCount = @@ROWCOUNT
	   
	
END TRY

BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
    SET @v_vchCode = N'-20001'
    SET @v_vchMsg = N'A SQL error occured while attempting to update STO records.'
    GOTO ERROR_HANDLER
END CATCH



IF @v_nRowCount > 0 SET @v_nExists = 1 ELSE SET @v_nExists = 0

IF @v_nExists = 0 
BEGIN --1
    IF @in_vchHUID IS NOT NULL 
    BEGIN--2
        -----------------------------------------------------------------------------------
        --                  Update HUM Record
        ----------------------------------------------------------------------------------- 
        BEGIN TRY
            UPDATE t_hu_master 
                SET location_id = @in_vchLocationID, type = @in_vchHUType
            WHERE wh_id = @in_vchWhID
                AND hu_id = @in_vchHUID
                
            SET @v_nRowCount = @@ROWCOUNT
			
        END TRY

        BEGIN CATCH    
            SET @v_nSysErrorNum = ERROR_NUMBER()
            SET @v_vchCode = N'-20002'
            SET @v_vchMsg = N'A SQL error occured while attempting to update HUM record.'
            GOTO ERROR_HANDLER
        END CATCH
 
        IF @v_nRowCount <= 0 
        BEGIN--3 
            -----------------------------------------------------------------------------------
            --                  Insert HUM Record
            -----------------------------------------------------------------------------------        
            BEGIN TRY                
                INSERT INTO t_hu_master(wh_id, hu_id, location_id, type, status, control_number)
                    VALUES (@in_vchWhID, @in_vchHUID, @in_vchLocationID, @in_vchHUType, 'A', @in_vchShipmentNumber)

				 --UPDATE t_location SET hu_count = hu_count + 1
					--WHERE  wh_id = @in_vchWhID
					--AND location_id = @in_vchLocationID 
					--AND type IN ('I','M')
            END TRY
    
            BEGIN CATCH    
                SET @v_nSysErrorNum = ERROR_NUMBER()
                SET @v_vchCode = N'-20003'
                SET @v_vchMsg = N'A SQL error occured while attempting to insert HUM record.'
                GOTO ERROR_HANDLER
            END CATCH               
        END--3           
    END--2        
    -----------------------------------------------------------------------------------
    --                 Create STO Record
    ----------------------------------------------------------------------------------- 
    BEGIN TRY 
	    --IF @v_lot_control <>'F' SET @in_vchLotNumber = CONVERT(NVARCHAR,@in_dtExpirationDate,112)

	    --IF @v_expire_control='Y'  SET @in_dtExpirationDate=@in_dtExpirationDate+@v_nExpire_days
		
		
        INSERT INTO t_stored_item(
            wh_id, item_number, location_id, type, hu_id, lot_number, stored_attribute_id, 
            actual_qty, unavailable_qty, status, fifo_date, expiration_date, sequence,
            shipment_number,damage_flag)
        VALUES(
            @in_vchWhID, @in_vchItemNumber, @in_vchLocationID, @in_nType, @in_vchHUID, 
            @in_vchLotNumber, @in_nStoredAttributeID, @in_fQty, 0, N'A', @in_dtFifoDate, 
            @in_dtExpirationDate, @v_nSequence,
            @in_vchShipmentNumber,@in_damage_flag)  
			
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
        SET @v_vchCode = N'-20004'
        SET @v_vchMsg = N'A SQL error occured while attempting to update STO record : '+ ERROR_MESSAGE()
        GOTO ERROR_HANDLER
    END CATCH 
END--1

-----------------------------------------------------------------------------------
--                Delete STO Record
----------------------------------------------------------------------------------- 
IF @v_nExists = 1 AND @v_fActualQty = 0 
BEGIN--1
    BEGIN TRY
        DELETE t_stored_item
            WHERE wh_id       = @in_vchWhID
                AND item_number = @in_vchItemNumber
                AND location_id = @in_vchLocationID
                AND type        = @in_nType
                AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'-1') = ISNULL(@in_vchHUID,'-1')))
               AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'-1') = ISNULL(@in_vchLotNumber,'-1')))
	   AND ((expiration_date = @in_dtExpirationDate) OR (ISNULL(expiration_date,'1900-01-01 00:00:00') = ISNULL(@in_dtExpirationDate,'1900-01-01 00:00:00')))
       AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'-1') = ISNULL(@in_nStoredAttributeID,'-1')))
	   AND ((damage_flag = @in_damage_flag) OR (ISNULL(damage_flag,'Y') = ISNULL(@in_damage_flag,'Y')))
                AND actual_qty = 0
               -- AND unavailable_qty = 0
      
	 -- UPDATE t_location SET hu_count = hu_count - 1
		--WHERE (hu_count - 1) >= 0
		--AND wh_id = @in_vchWhID
		--AND location_id = @in_vchLocationID 
		--AND type IN ('I','M')
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
        SET @v_vchCode = N'-20005'
        SET @v_vchMsg = N'A SQL error occured while attempting to delete STO record.'
        GOTO ERROR_HANDLER
    END CATCH    

    -----------------------------------------------------------------------------------
    --                 Delete HUM Record
    ----------------------------------------------------------------------------------- 
    IF @in_vchHUID IS NOT NULL 
    BEGIN--2   
        IF NOT EXISTS (SELECT N'TRUE'
                         FROM t_stored_item
                        WHERE wh_id = @in_vchWhID
                          AND hu_id = @in_vchHUID) 
        BEGIN--3
            BEGIN TRY              
                DELETE FROM t_hu_master
                    WHERE wh_id = @in_vchWhID
                        AND hu_id = @in_vchHUID
            END TRY

            BEGIN CATCH    
                SET @v_nSysErrorNum = ERROR_NUMBER()
                SET @v_vchCode = N'-20006'
                SET @v_vchMsg = N'A SQL error occured while attempting to delete HUM record.'
                GOTO ERROR_HANDLER
            END CATCH    
        END--3
    END--2
END--1

GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + N'Deadlock error: 40001 ' 
                    + @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE() + N'.'
    ELSE    
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + @v_vchMsg
                    + N' SQL Error = ' + ERROR_MESSAGE() + N'.'


    RAISERROR(@v_vchMsg, 11, 1)
   
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

	-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

    -- Always leave the stored procedure from here.
RETURN
