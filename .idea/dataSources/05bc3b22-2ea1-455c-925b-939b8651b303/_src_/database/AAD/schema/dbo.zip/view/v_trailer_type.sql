
CREATE VIEW dbo.v_trailer_type
AS
SELECT
    e.equipment_id as trailer_type_id,
    e.equipment_name as trailer_type_name,
    e.description,
    e.weight_limit,
    e.volume_limit,
    e.pallet_limit,
    e.tare_weight,
    e.length,
    e.height,
    e.width,
    e.weight_minimum AS min_weight,
    e.volume_minimum AS min_volume,
    e.pallet_minimum AS min_pallets
FROM
    t_equipment e
