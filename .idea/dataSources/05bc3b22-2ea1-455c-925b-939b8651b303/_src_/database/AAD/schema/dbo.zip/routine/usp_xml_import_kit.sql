
CREATE PROCEDURE [dbo].[usp_xml_import_kit]
	(
		 @v_vchHostGroupID		NVARCHAR(36)
		,@out_vchCode           uddt_output_code   OUTPUT
		,@out_vchMsg            uddt_output_msg    OUTPUT
	)
	
AS
-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                         HighJump Software
--                         Minneapolis, Minnesota, USA
-- ********************************************************************************
-- 
--    PURPOSE:
--          The purpose of this stored procedure is to populate GHI Tables for 
--              Inbound Order Import
--
--    DESCRIPTION:
--	
--    INPUT:
--      Host Group ID
--
--    OUTPUT:
--        out_vchCode - Contains 'SUCCESS' or Error Code.
--        out_vchMsg - Contains the error message or informational log message.:
--      
--  TARGET: SQL Server 
--
-- *********************************************************************************	
DECLARE

----------------------------------------------------------------------------------------------------------------------------	
-- Procedure variables
----------------------------------------------------------------------------------------------------------------------------
		
	 @v_dtTranDateTime			DATETIME
	,@v_dtRecordCreateDate		DATETIME
	
		
----------------------------------------------------------------------------------------------------------------------------	
-- Local Variables
----------------------------------------------------------------------------------------------------------------------------
	,@c_vchObjName               uddt_obj_name	 	
	,@v_nSysErrorNum			INT
	,@v_vchMsg					NVARCHAR(4000)
    ,@v_vchCode					NVARCHAR(10)
    ,@v_nRetryCount				INT
	,@v_nTranCount				INT	
	,@v_nXstate					INT			



SET NOCOUNT ON

----------------------------------------------------------------------------------------------------------------------------	
-- Set Constants
----------------------------------------------------------------------------------------------------------------------------

SET @c_vchObjName = N'usp_xml_import_kit'
SET @v_vchCode = N'SUCCESS'
SET @v_vchMsg  = N'NONE'
SET @v_nSysErrorNum = 0
SET @v_nTranCount = 0


----------------------------------------------------------------------------------------------------------------------------	
-- Insert GHI Records
----------------------------------------------------------------------------------------------------------------------------

---- Insert BOM Master ------------------------------

SET @v_dtRecordCreateDate = GETDATE()	
SET @v_nRetryCount = 3

INS_AL:

BEGIN TRY
	SET @v_nTranCount = @@TRANCOUNT
	
	IF @v_nTranCount = 0 
        BEGIN TRANSACTION 
    ELSE 
        SAVE TRANSACTION SAVEPOINT
		
    SET XACT_ABORT ON
	
		INSERT INTO t_al_host_bom_master(
			 host_group_id
			,record_create_date
			,processing_code
			,kit_id
			,display_kit_id
			,wh_id
			,client_code
			,description
			,location_id
			,status			
			)
		SELECT
			 @v_vchHostGroupID
			,@v_dtRecordCreateDate
			,kti.TransactionCode
			,ktm.KitID
			,ktm.DisplayKitID
			,ktm.WarehouseID
			,ktm.ClientCode
			,kti.Description
			,kti.LocationID
			,SUBSTRING(ISNULL(kti.Status, 'A'),1,1)
		 FROM t_xml_imp_kit_master ktm WITH (NOLOCK)
		INNER JOIN t_xml_imp_kit_info kti WITH (NOLOCK)
		   ON kti.hjs_parent_id = ktm.hjs_node_id
		WHERE ktm.hjs_parent_id = @v_vchHostGroupID
		ORDER BY ktm.hjs_sequence    
		 
		 
		 
------ Insert BOM Detail ------------------------------
		 
		 INSERT INTO t_al_host_bom_detail(
			 host_bom_master_id
			,host_group_id
			,record_create_date
			,processing_code
			,kit_id
			,display_kit_id
			,wh_id
			,client_code
			,item_number
			,display_item_number
			,quantity
			,gen_attribute_value1
			,gen_attribute_value2
			,gen_attribute_value3
			,gen_attribute_value4
			,gen_attribute_value5
			,gen_attribute_value6
			,gen_attribute_value7
			,gen_attribute_value8
			,gen_attribute_value9
			,gen_attribute_value10
			,gen_attribute_value11	
		)  
		SELECT 
			 ISNULL(bmm.host_bom_master_id, 0)
			,@v_vchHostGroupID
			,@v_dtRecordCreateDate
			,ktd.TransactionCode
			,ktm.KitID
			,ktm.DisplayKitID
			,ktm.WarehouseID
			,ktm.ClientCode
			,ktd.ItemNumber
			,ktd.DisplayItemNumber
			,ktd.Quantity
			,ktd.Attribute1
			,ktd.Attribute2
			,ktd.Attribute3
			,ktd.Attribute4
			,ktd.Attribute5
			,ktd.Attribute6
			,ktd.Attribute7
			,ktd.Attribute8
			,ktd.Attribute9
			,ktd.Attribute10
			,ktd.Attribute11  
		  FROM t_xml_imp_kit_detail ktd WITH (NOLOCK)
		 INNER JOIN t_xml_imp_kit_details kts WITH (NOLOCK) 
		    ON kts.hjs_node_id = ktd.hjs_parent_id
		 INNER JOIN t_xml_imp_kit_master ktm WITH (NOLOCK)
			ON ktm.hjs_node_id = kts.hjs_parent_id
		 LEFT OUTER JOIN t_al_host_bom_master bmm WITH (NOLOCK)
			ON bmm.host_group_id = ktm.hjs_parent_id
		   AND ISNULL(bmm.kit_id, 'x') = ISNULL(ktm.KitID, 'x')
		   AND ISNULL(bmm.display_kit_id, 'x') = ISNULL(ktm.DisplayKitID, 'x')
		   AND bmm.wh_id = ktm.WarehouseID
		   AND ISNULL(bmm.client_code, 'x') = ISNULL(ktm.ClientCode, 'x')	
		 WHERE ktm.hjs_parent_id = @v_vchHostGroupID  	
		 ORDER BY ktm.hjs_sequence, ktd.hjs_sequence

----- Insert BOM Request ------------------------------

		INSERT INTO t_al_host_bom_request(
			 host_group_id
			,record_create_date
			,processing_code
			,kit_id
			,display_kit_id
			,wh_id
			,client_code
			,quantity	
			)
		SELECT
			 @v_vchHostGroupID
			,@v_dtRecordCreateDate
			,kti.TransactionCode
			,ktm.KitID
			,ktm.DisplayKitID
			,ktm.WarehouseID
			,ktm.ClientCode
			,ktr.Quantity	
		  FROM t_xml_imp_kit_request ktr WITH (NOLOCK)
		 INNER JOIN t_xml_imp_kit_master ktm WITH (NOLOCK)
			ON ktm.hjs_node_id = ktr.hjs_parent_id
		 INNER JOIN t_xml_imp_kit_info kti WITH (NOLOCK)
			ON kti.hjs_parent_id = ktm.hjs_node_id
		 WHERE ktm.hjs_parent_id = @v_vchHostGroupID 
		 ORDER BY ktm.hjs_sequence 

	COMMIT TRANSACTION
	
	SET XACT_ABORT OFF		
	
	
END TRY
 
BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
	SET @v_nTranCount = @@TRANCOUNT
	SET @v_nXstate = XACT_STATE() 
  
	IF @v_nXstate = -1 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount = 0 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount > 0 
        ROLLBACK TRANSACTION SAVEPOINT   

		
-- Check for Deadlock and Retry as long as the Retry Counter is greater than zero  
    IF (@v_nRetryCount > 0 AND @v_nSysErrorNum = 1205) 
	BEGIN
		SET @v_nRetryCount = @v_nRetryCount - 1
		SET XACT_ABORT OFF;	
		GOTO INS_AL
	END

	SET @v_vchCode = N'-20001'    
    SET @v_vchMsg = N'A SQL error occured while inserting t_xml_exp records for Kit Import.'	
	SET @v_vchMsg = @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE()
	GOTO ERROR_HANDLER
END CATCH

GOTO EXIT_LABEL
	
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + N'Deadlock error: 40001 ' + @v_vchMsg
    ELSE    
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + @v_vchMsg 
		
    --Should only raise error in the parent sproc
    RAISERROR(@v_vchMsg, 11, 1)
    
    -- Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg
    
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

-- Always leave the stored procedure from here.
RETURN 
