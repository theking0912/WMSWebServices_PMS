




-- =======================================    
-- Author: Laver  
-- Create Date: 09 Nov 2015    
-- Description: 
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Kit_y]    
     @wh_id						NVARCHAR(10)  
    ,@location					NVARCHAR(30)  
	,@hu_id						NVARCHAR(30)
	,@dest_stored_attribute_id	NVARCHAR(30)			
	,@user_id					NVARCHAR(30)
	,@tran_type					NVARCHAR(20)
	,@tran_description			NVARCHAR(50)
	,@kit_uom_qty				FLOAT
	,@dest_hu_id				NVARCHAR(30)
	,@dest_location				NVARCHAR(30)
	,@passornot					NVARCHAR(1)		output
	,@msg						NVARCHAR(200)	output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
		DECLARE	@item_number			Nvarchar(30)
		DECLARE	@lot_number				Nvarchar(30)
		DECLARE	@stored_attribute_id	Nvarchar(30)
		DECLARE	@qty					float
		DECLARE	@damage_flag			NVARCHAR(1)
		DECLARE	@expiration_date		DATETIME
		DECLARE @type					INT
		DECLARE @min_expiration_date	DATETIME	= '1900-01-01'
		DECLARE @min_lot				NVARCHAR(30)
		--DECLARE @conversion_factor		INT		= 0
		DECLARE @conversion_factor		FLOAT		= 0
		DECLARE @sum_kit_qty			FLOAT	= 0
		DECLARE	@except_qty				FLOAT	= 0
		DECLARE @sum_sto_qty			FLOAT	= 0

		SELECT @min_expiration_date = MIN(expiration_date)
			   ,@item_number = item_number
			   ,@sum_sto_qty = SUM(actual_qty)
			   ,@min_lot = MIN(lot_number)
						FROM t_stored_item
						WHERE wh_id = @wh_id
						AND	hu_id = @hu_id
						AND location_id = @location
						AND type = 0
						GROUP BY item_number

		SELECT TOP 1 @conversion_factor = conversion_factor FROM t_item_uom tiu WITH(NOLOCK) 
						INNER JOIN t_sto_attrib_collection_detail tsac WITH(NOLOCK)
							ON tiu.uom_prompt = tsac.attribute_value
							WHERE wh_id = @wh_id AND item_number = @item_number
								AND stored_attribute_id = @dest_stored_attribute_id

		select @conversion_factor=cast (@conversion_factor as decimal (18,6))
		IF @conversion_factor = 0
		BEGIN
			SET @passornot = 4
			SET @msg = '无效的打包规格'
			RETURN
		END

		IF EXISTS (SELECT 1
				   FROM t_stored_item
				   WHERE wh_id = @wh_id
						AND hu_id = @hu_id
						AND (EXISTS(SELECT 1 FROM tbl_allocation 
											WHERE location_id = t_stored_item.location_id
												AND wh_id = t_stored_item.wh_id
												AND item_number = t_stored_item.item_number
												AND ISNULL(hu_id,'') = ISNULL(t_stored_item.hu_id,'')
												AND status NOT IN ('E','C'))
							OR type <> 0 )
					)
		BEGIN
			SET @passornot = 3
			SET @msg = '库存已经被预约'
			RETURN
		END

		IF EXISTS(SELECT 1 FROM t_stored_item 
						WHERE hu_id = @dest_hu_id
							AND wh_id = @wh_id
							AND (item_number <> @item_number 
								OR ISNULL(stored_attribute_id,0) <> ISNULL(@dest_stored_attribute_id,0)))
		BEGIN
			SET @passornot = 6
			SET @msg = '目标托盘不能混物料规格'
			RETURN			
		END

		SET @sum_kit_qty = @kit_uom_qty * @conversion_factor
		SET @except_qty = @sum_kit_qty
		IF @sum_kit_qty > @sum_sto_qty
		BEGIN
			SET @passornot = 5
			--SET @msg = '托盘中打包数量不匹配'
			SET @msg = '没有足够的打包库存'
			RETURN
		END

		BEGIN TRANSACTION
		--get stored 
		WHILE (1 = 1)
			BEGIN
				SELECT TOP 1 @item_number = item_number
							,@lot_number = lot_number
							,@expiration_date = expiration_date
							,@damage_flag = damage_flag
							,@qty = actual_qty
							,@stored_attribute_id = stored_attribute_id
							,@type = type
						FROM t_stored_item
						WHERE wh_id = @wh_id
						AND	hu_id = @hu_id
						AND location_id = @location
						AND ISNULL(stored_attribute_id,0) <> ISNULL(@dest_stored_attribute_id,0)
						AND type = 0
						ORDER BY expiration_date ASC

				IF @@ROWCOUNT = 0
					BEGIN
						BREAK
					END
				
				IF @qty >= @except_qty
				BEGIN
					SET @qty = @except_qty
					SET @except_qty = @except_qty - @qty
				END
				ELSE
				BEGIN
					SET @except_qty = @except_qty - @qty
				END

				-- Create kit stock 
				EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @dest_location,
						@in_nType = @type,
						@in_vchHUID = @dest_hu_id,
						@in_vchLotNumber =@min_lot,
						@in_nStoredAttributeID = @dest_stored_attribute_id,
						@in_fQty = @qty,
						@in_dtFifoDate = NULL,
						@in_dtExpirationDate = @min_expiration_date,
						@in_vchHUType = 'IV',
						@in_vchShipmentNumber = NULL,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT

				
				--Create tran log
				--Insert t_tran_log_holding
				INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
					,wh_id_2,location_id_2,hu_id_2
					,generic_attribute_1,
					generic_attribute_2,
					generic_attribute_3,
					generic_attribute_4,
					generic_attribute_5,
					generic_attribute_6,
					generic_attribute_7,
					generic_attribute_8,
					generic_attribute_9,
					generic_attribute_10,
					generic_attribute_11)
				VALUES
					('273','Kit Completion (Create Kit)',getdate(),getdate(),getdate(),getdate(),@user_id,NULL,@dest_stored_attribute_id
					,@wh_id,@dest_location,@dest_hu_id,@item_number,@min_lot,@qty
					,@wh_id,@location,@hu_id
					,(SELECT TOP 1 a.attribute_value
    				FROM t_sto_attrib_collection_detail a
						INNER JOIN t_attribute_collection_detail b
						ON a.attribute_id = b.attribute_id
						INNER JOIN t_item_master c
						ON c.attribute_collection_id = b.attribute_collection_id
    				WHERE c.item_number = @item_number
						AND c.wh_id = @wh_id
					AND  a.stored_attribute_id = @dest_stored_attribute_id),					 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_2), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_3), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_4), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_5), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_6), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_7), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_8), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_9), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_10), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @dest_stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_11)
					)

				SET @qty = @qty * -1
				-- remove original stock 
				EXEC	[dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @location,
						@in_nType = @type,
						@in_vchHUID = @hu_id,
						@in_vchLotNumber =@lot_number,
						@in_nStoredAttributeID = @stored_attribute_id,
						@in_fQty = @qty,
						@in_dtFifoDate = NULL,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = 'IV',
						@in_vchShipmentNumber = NULL,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT

				--Create tran log
				--Insert t_tran_log_holding
				INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
					,wh_id_2,location_id_2,hu_id_2
					,generic_attribute_1,
					generic_attribute_2,
					generic_attribute_3,
					generic_attribute_4,
					generic_attribute_5,
					generic_attribute_6,
					generic_attribute_7,
					generic_attribute_8,
					generic_attribute_9,
					generic_attribute_10,
					generic_attribute_11)
				VALUES
					('272','Kit Completion (Remove Component)',getdate(),getdate(),getdate(),getdate(),@user_id,NULL,0
					,@wh_id,@location,@hu_id,@item_number,@lot_number,@qty
					,@wh_id,@location,@hu_id
					,(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_1),    
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_2), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_3), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_4), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_5), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_6), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_7), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_8), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_9), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_10), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_11)
					)

					IF @except_qty = 0 
					BEGIN
						BREAK
					END
			END
			
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    





