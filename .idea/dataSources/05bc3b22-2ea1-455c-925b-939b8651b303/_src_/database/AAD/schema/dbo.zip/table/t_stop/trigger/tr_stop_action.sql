
CREATE TRIGGER dbo.tr_stop_action
ON t_stop
FOR UPDATE
AS

BEGIN
    DECLARE
        @v_nTriggerAction       INT,
        @v_vchWhID              NVARCHAR(10),
        @v_vchLoadID            NVARCHAR(30),
        @v_nStopID              INT,
        @v_vchCurrStatus        NVARCHAR(30),
        @v_dtCurrentDate        DATETIME,
        @v_vchEventData         NVARCHAR(500)

	-- Error handling and logging variables.
    DECLARE
        @c_nModuleNumber        INT,
        @c_nFileNumber          INT,
        @v_vchLogMsg            NVARCHAR(250),
        @v_vchParam             NVARCHAR(100),
        @v_nRaiseErrorNumber    INT,
        @v_nError               INT,
        @v_nRowCount            INT,
        @v_nCustomError         INT

    -- Exceptions
    DECLARE
        @e_ClearTriggerSqlError             INT,
        @e_ClearTriggerZeroRows             INT,
        @e_PODReqUpdateStopSqlError         INT,
        @e_PODReqUpdateStopZeroRows         INT,
        @e_PODReqAddEventFailed             INT,
        @e_PODReqInsertHistorySqlError      INT,
        @e_PODReqInsertHistoryZeroRows      INT,
        @e_PODRespUpdateStopSqlError        INT,
        @e_PODRespUpdateStopZeroRows        INT,
        @e_PODRespInsertHistorySqlError     INT,
        @e_PODRespInsertHistoryZeroRows     INT,
        @e_GetInfoSqlError                  INT,
        @e_GetInfoZeroRows                  INT,
        @e_PODReqGetCurrStatusSqlError      INT,
        @e_PODReqGetCurrStatusZeroRows      INT,
        @e_PODReqInvalidStatus              INT

    DECLARE @v_nNoCount INT
    SET @v_nNoCount = @@OPTIONS & 512
    SET NOCOUNT ON

    -- Set Log/Local Error Constants
    SET @e_ClearTriggerSqlError             = 1
    SET @e_ClearTriggerZeroRows             = 2
    SET @e_PODReqUpdateStopSqlError         = 3
    SET @e_PODReqUpdateStopZeroRows         = 4
    SET @e_PODReqAddEventFailed             = 5
    SET @e_PODReqInsertHistorySqlError      = 6
    SET @e_PODReqInsertHistoryZeroRows      = 7
    SET @e_PODRespUpdateStopSqlError        = 8
    SET @e_PODRespUpdateStopZeroRows        = 9
    SET @e_PODRespInsertHistorySqlError     = 10
    SET @e_PODRespInsertHistoryZeroRows     = 11
    SET @e_GetInfoSqlError                  = 12
    SET @e_GetInfoZeroRows                  = 13
    SET @e_PODReqGetCurrStatusSqlError      = 14
    SET @e_PODReqGetCurrStatusZeroRows      = 15
    SET @e_PODReqInvalidStatus              = 16

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 302

    IF UPDATE (trigger_action)
    BEGIN
        SELECT
            @v_nTriggerAction = trigger_action,
            @v_vchWhID = wh_id,
            @v_vchLoadID = load_id,
            @v_nStopID = stop_id
        FROM
            Inserted

        SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nRowCount = 0 OR @v_nError <> 0
        BEGIN
            IF @v_nError <> 0
                SET @v_nCustomError = @e_GetInfoSqlError
            ELSE
                SET @v_nCustomError = @e_GetInfoZeroRows
            GOTO ErrorHandler
        END

        -- Clear trigger_action column
        UPDATE
            s
        SET
            s.trigger_action = 0
        FROM
            t_stop s
        INNER JOIN
            Inserted i
            ON
                s.stop_id = i.stop_id

        SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nRowCount = 0 OR @v_nError <> 0
        BEGIN
            IF @v_nError <> 0
                SET @v_nCustomError = @e_ClearTriggerSqlError
            ELSE
                SET @v_nCustomError = @e_ClearTriggerZeroRows
            GOTO ErrorHandler
        END

        SET @v_dtCurrentDate = GETDATE()

        IF @v_nTriggerAction = 1 -- POD Request
        BEGIN

            -- Get current shipment status
            SELECT
                @v_vchCurrStatus = ISNULL(shipment_status, 'Pending')
            FROM
                t_load_master
            WHERE
                wh_id = @v_vchWhID AND
                load_id = @v_vchLoadID

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_PODReqGetCurrStatusSqlError
                ELSE
                    SET @v_nCustomError = @e_PODReqGetCurrStatusZeroRows
                GOTO ErrorHandler
            END

            -- Check if current shipment status is valid.
            IF @v_vchCurrStatus <> 'In Transit' AND
                @v_vchCurrStatus <> 'Tender Accepted' AND
                @v_vchCurrStatus <> 'Delivered'
            BEGIN
                SET @v_nCustomError = @e_PODReqInvalidStatus
                GOTO ErrorHandler
            END

            -- Set POD request pending
            UPDATE
                s
            SET
                s.pod_request_date = @v_dtCurrentDate,
                s.pod_request_pending = 1,
                s.pod_response_date = NULL,
                s.pod_updated_by = NULL
            FROM
                t_stop s
            INNER JOIN
                Inserted i
                ON
                    s.stop_id = i.stop_id

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_PODReqUpdateStopSqlError
                ELSE
                    SET @v_nCustomError = @e_PODReqUpdateStopZeroRows
                GOTO ErrorHandler
            END

            -- Raise event for POD Request
            /*SET @v_vchEventData = 'Warehouse ID|' + @v_vchWhID +
                '|Stop ID|' + CONVERT(VARCHAR, @v_nStopID) + '|Message Type|POD Request'
            EXEC @v_nError =
                ADV_DB_NAME..usp_AdvAddEvent 6, 'AL.Process Requests From TA', @v_vchEventData, 50

            IF @v_nError <> 0
            BEGIN
                SET @v_nCustomError = @e_PODReqAddEventFailed
                GOTO ErrorHandler
            END*/

            -- Insert activity history row
            /*INSERT INTO t_ta_load_activity_history (
                wh_id,
                load_id,
                stop_id,
                activity_date,
                activity,
                carrier_id,
                mode_id )
            SELECT
                s.wh_id,
                s.load_id,
                s.stop_id,
                s.pod_request_date,
                'POD Request',
                l.carrier_id,
                l.mode_id
            FROM
                Inserted i
            INNER JOIN
                t_stop s
                ON
                    i.stop_id = s.stop_id
            INNER JOIN
                t_load_master l
                ON
                    l.wh_id = s.wh_id AND
                    l.load_id = s.load_id

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_PODReqInsertHistorySqlError
                ELSE
                    SET @v_nCustomError = @e_PODReqInsertHistoryZeroRows
                GOTO ErrorHandler
            END*/

        END

        ELSE

        IF @v_nTriggerAction = 2 -- POD Response
        BEGIN

            -- Clear the POD request flag and set POD response date in t_stop
            UPDATE
                s
            SET
                s.pod_request_pending = 0,
                s.pod_response_date = @v_dtCurrentDate
            FROM
                Inserted i
            INNER JOIN
                t_stop s
                ON
                    s.stop_id = i.stop_id

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_PODRespUpdateStopSqlError
                ELSE
                    SET @v_nCustomError = @e_PODRespUpdateStopZeroRows
                GOTO ErrorHandler
            END

            -- Insert activity history row
            /*INSERT INTO t_ta_load_activity_history (
                wh_id,
                load_id,
                stop_id,
                activity_date,
                activity,
                carrier_id,
                mode_id,
                received_by,
                pod_delivery_date,
                updated_by )
            SELECT
                s.wh_id,
                s.load_id,
                s.stop_id,
                s.pod_response_date,
                'POD Update',
                l.carrier_id,
                l.mode_id,
                s.received_by,
                s.actual_delivery_date,
                s.pod_updated_by
            FROM
                Inserted i
            INNER JOIN
                t_stop s
                ON
                    i.stop_id = s.stop_id
            INNER JOIN
                t_load_master l
                ON
                    l.wh_id = s.wh_id AND
                    l.load_id = s.load_id

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_PODRespInsertHistorySqlError
                ELSE
                    SET @v_nCustomError = @e_PODRespInsertHistoryZeroRows
                GOTO ErrorHandler
            END*/

        END -- pod request or response
    END -- if trigger action updated

    GOTO ExitLabel

ErrorHandler:

    ROLLBACK TRAN

    IF @v_nCustomError = @e_ClearTriggerSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred resetting trigger field in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_ClearTriggerZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to reset trigger field in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_stop'
        SET @v_nRaiseErrorNumber = 50003 -- Update Error
    END

    ELSE IF @v_nCustomError = @e_PODReqGetCurrStatusSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred selecting current POD Request status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_PODReqGetCurrStatusZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to select current POD Request status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_PODReqInvalidStatus
    BEGIN
        SET @v_vchLogMsg = 'Current status [' + @v_vchCurrStatus + '] not valid for POD' +
            ' Request. Status must be Tender Accepted, In Transit, or Delivered.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_PODReqUpdateStopSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred updating POD Request information in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_PODReqUpdateStopZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to update POD Request information in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_stop'
        SET @v_nRaiseErrorNumber = 50003 -- Update Error
    END

    ELSE IF @v_nCustomError = @e_PODReqAddEventFailed
    BEGIN
        SET @v_vchLogMsg = 'Failed to add POD Request event for wh_id [' +
            @v_vchWhID + '] and stop_id [' + CONVERT(VARCHAR, @v_nStopID) + '].'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

    ELSE IF @v_nCustomError = @e_PODReqInsertHistorySqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred inserting history row in t_ta_load_activity_history for' +
            ' POD Request.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_PODReqInsertHistoryZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to insert history row in t_ta_load_activity_history' +
            ' for POD Request.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_ta_load_activity_history'
        SET @v_nRaiseErrorNumber = 50002 -- Insert Error
    END

    ELSE IF @v_nCustomError = @e_PODRespUpdateStopSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred updating POD Update information in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_PODRespUpdateStopZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to update POD Update information in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_stop'
        SET @v_nRaiseErrorNumber = 50003 -- Update Error
    END

    ELSE IF @v_nCustomError = @e_PODRespInsertHistorySqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred inserting history row in t_ta_load_activity_history for' +
            ' POD Update.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_PODRespInsertHistoryZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to insert history row in t_ta_load_activity_history' +
            ' for POD Update.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_ta_load_activity_history'
        SET @v_nRaiseErrorNumber = 50002 -- Insert Error
    END

    ELSE IF @v_nCustomError = @e_GetInfoSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred selecting affected row information from t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_GetInfoZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to select affected row information from t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_stop'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    -- Raise error message instead of number so informative message will show on WebWise screen
    RAISERROR (@v_vchLogMsg, 11, 1)

ExitLabel:
    IF @v_nNoCount = 0
        SET NOCOUNT OFF

    RETURN
END
