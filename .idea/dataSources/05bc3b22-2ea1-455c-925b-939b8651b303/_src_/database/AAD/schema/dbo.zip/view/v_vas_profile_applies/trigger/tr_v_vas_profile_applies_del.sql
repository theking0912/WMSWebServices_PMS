
CREATE TRIGGER tr_v_vas_profile_applies_del ON v_vas_profile_applies
INSTEAD OF DELETE
AS
BEGIN
SET NOCOUNT ON
   DELETE t_vas_profile_applies
   FROM deleted del
   WHERE t_vas_profile_applies.vas_applies_id = del.vas_applies_id
END


