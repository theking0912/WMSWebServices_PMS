CREATE PROCEDURE  [dbo].[csp_PrintPackage_Label]   
    @in_WarehouseID     nvarchar(20),
    @in_ParameKey       nvarchar(255),	
	@in_PrintNum        int,
    @in_Station         nvarchar(100),
	@in_PrintType       nvarchar(50),
    @in_Carrier         nvarchar(100),
	@in_Client         nvarchar(100),
	@in_User            nvarchar(50),
	@out_Result         int out,
	@out_ErrMess        nvarchar(150) out
AS
 DECLARE      
        @v_CurrentValue      int,
        @v_NextValue         nvarchar(20),
		@v_ClValue           varchar(5),
        @v_nError            INT,      
        @v_nRowCount         INT,
		@loop_num            int,
		@in_vchEventId       nvarchar(40),
		@v_PackageLabel      nvarchar(40)

	 set @loop_num=1

while(1=1)
  begin
    
	 if @loop_num=@in_PrintNum 
	  begin
	   GOTO ExitLabel
	  end 

      select 
	  @v_CurrentValue= next_value,
	  @v_ClValue=c1  from t_control 
	  where control_type='PACKAGE'

      
    SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT

    IF @v_nRowCount = 0 OR @v_nError <> 0
		BEGIN
		  RAISERROR(' Select table t_control failed',16, 1, @in_vchEventId )
		  GOTO ExitLabel
		END

	BEGIN
	   update  t_control set next_value=next_value+1
	    where control_type='PACKAGE'
	END
	
	set @v_NextValue=@v_CurrentValue+1;
	set @v_PackageLabel=@v_ClValue+REPLICATE('0',9-len(@v_NextValue))+@v_NextValue

	set @loop_num+=1

	exec csp_Add_Printdata  @in_WarehouseID,@v_PackageLabel,1,@in_Station,@in_PrintType,@in_Carrier,@in_Client,@in_User,@out_Result out,@out_ErrMess out
	
	if @out_Result=-1 
	  begin 
	   GOTO ExitLabel
	  end 
end
     GOTO ExitLabel
ExitLabel:  
RETURN
