



CREATE PROCEDURE [dbo].[csp_OST_SendTOSAP] 

AS
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
	BEGIN TRANSACTION
		declare @wh_id nvarchar(30)
		declare @order_number nvarchar(30)
		
		IF EXISTS(SELECT 1 FROM t_order 
				WHERE status ='LOADED' 
				AND order_type IN ('ZTT','ZTH'))
		BEGIN 
			WHILE (1=1)
			BEGIN 
				SELECT TOP 1 @wh_id = wh_id
					,@order_number = order_number
				FROM t_order 
				WHERE status ='LOADED' 
				AND order_type IN ('ZTT','ZTH')
				ORDER BY wh_id,order_number

				IF @@ROWCOUNT =0
					BEGIN 
						BREAK
					END
				
				--UPDATE SO to be shipped
				UPDATE t_order
				SET status ='SHIPPED'
				WHERE wh_id = @wh_id
				AND order_number = @order_number

				UPDATE t_pick_detail
				SET status ='SHIPPED'
					,shipped_quantity = loaded_quantity
				WHERE wh_id = @wh_id
				AND order_number = @order_number
				--create EDI
				INSERT INTO tbl_inf_exp_so_master
					([order_number],[user_id],[warehouse_id],[client_code],[process_status],carrier_code,shipped_date,order_type,display_order_number,sap_ordertype
					  ,move_code,cost_code,profit_code,ledger_code,stock_indicator_code,department)
				SELECT order_number,'JOB', wh_id,client_code,'NEW',carrier_scac,actual_ship_date,order_type,display_order_number,sap_ordertype
						,move_code,cost_code,profit_code,ledger_code,stock_indicator_code,department
				FROM t_order
				WHERE wh_id = @wh_id
				and order_number = @order_number

				INSERT INTO tbl_inf_exp_so_detail
					([line_number],[item_number],[lot_number],[quantity_shipped],[hu_id],[user_id],[warehouse_id]
					 ,client_code,uom,order_number,display_order_number
					 ,[process_status],storage_location,parent_line_number,factory
					)
				SELECT od.line_number,od.item_number,od.lot_number,ISNULL(tpd.shipped_quantity,0),NULL,'JOB',@wh_id
					,NULL
					,(SELECT TOP 1 uom FROM t_item_uom WITH(NOLOCK) 
									WHERE od.item_number = t_item_uom.item_number
										AND od.wh_id = t_item_uom.wh_id 
										ORDER BY conversion_factor ASC)
					,@order_number,ord.display_order_number			
					,'NEW',od.storage_location,od.parent_line_number,od.factory
				FROM t_order_detail od
				INNER JOIN t_order ord WITH(NOLOCK)
				ON od.wh_id = ord.wh_id
				AND od.order_number = ord.order_number
				LEFT OUTER JOIN t_pick_detail tpd WITH (NOLOCK)
				ON tpd.wh_id = od.wh_id
				AND tpd.order_number = od.order_number
				AND tpd.item_number = od.item_number
				AND tpd.line_number = od.line_number
				--AND tpd.type in( 'PP','PO')
				WHERE ord.wh_id = @wh_id				
				and ord.order_number = @order_number
				and ISNULL(od.cancel_flag,'N') = 'N'

 /********** Added by Trevor on 20160402 started ******/
				update tbl_inf_exp_so_master
			     set process_status = 'Ready' 
				WHERE order_number = @order_number

			  update tbl_inf_exp_so_detail
				 set process_status = 'Ready' 
			   where  order_number = @order_number
/********** Added by Trevor on 20160402 ended ******/


			END
		END

		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION

        RETURN
    END CATCH
  
END    
    



