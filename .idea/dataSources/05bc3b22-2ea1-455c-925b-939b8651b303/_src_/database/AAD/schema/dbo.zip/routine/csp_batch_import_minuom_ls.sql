



-- ======================================= 
-- Description: batch_import_set_minuom
-- Create Date: LS add 20160820
-- =======================================
CREATE  PROCEDURE [dbo].[csp_batch_import_minuom_ls]
	   @in_number           NVARCHAR(100),
	   @in_vchWhID          NVARCHAR(10),
	   @out_vchMsg          NVARCHAR(200) OUTPUT
AS

declare @msg			nvarchar(1000);
declare @item_number	nvarchar(20) = '';
declare @client_code	nvarchar(20);
declare @wh_id			nvarchar(20);
declare @MATNR			nvarchar(20);
declare @uom			nvarchar(20);
declare	@process_status nvarchar(20);
declare	@process_msg	nvarchar(100);
declare @v_count		int

begin	----begin 0
SET NOCOUNT ON;
--BEGIN TRY
BEGIN TRANSACTION

update tbl_import_item_uom set FLAG_MINUOM = 'N' WHERE FLAG_MINUOM is null

--1、新增G的单位
while 1=1
	begin----begin 1 开始循环取出需要校验的物料
	select @item_number = item_number,
		   @wh_id = wh_id,
		   @uom = MEINH 
	  from [dbo].[tbl_import_item_uom] 
	 where MEINH = 'G' 
	   and STATUS = 'ACTIVE' 
	   and item_number > @item_number 
	 order by item_number desc;
		if @@ROWCOUNT <= 0 or @item_number = ''
		break;
			--校验需要增加G单位的物料是否已经在SAP单位表中存在
			select @v_count = count(1) 
			  from tbl_sap_item_uom 
			 where MEINH = 'G' 
			   and item_number = @item_number 
			--如果存在报错
			if @v_count > 0
			begin----begin 2
				set @msg= @item_number + '已经存在G的单位';
				insert into tbl_set_minuom_log 
				     values (@wh_id,@item_number,@uom,'error',@msg,getdate());
				continue;
			end	----end 2
			--如果不存在，开始向SAP单位表中插入该条G单位
			if @v_count = 0 
			BEGIN----begin 3
				INSERT INTO tbl_sap_item_uom
				select SUBSTRING(wh_id,4,3) as ZPOSITION,
					   wh_id,
					   substring(item_number,6,12) AS MATNR,
					   MEINH as MEINH,
					   MEINS as MEINS,
					   MEINH_PROMPT AS MEINH_PROMPT,
					   MEINS_PROMPT AS MEINS_PROMPT,
					   UMREN,
					   UMREZ,
					   UMREZ/UMREN AS CONVERT_FACTOR,
					   FLAG_MINUOM,
					   STATUS,
					   'N' AS FLAG_WMS_DELETE,
					   getdate() AS CREATE_DATE,
					   item_number,
					   substring(item_number,0,5) as client_code 
				  from [dbo].[tbl_import_item_uom]  
				 where MEINH = 'G' 
				   and STATUS = 'ACTIVE'
				   and item_number = @item_number;
			END----END 3
	END----END 1
COMMIT	TRANSACTION
--2、更新商品主档的[单位状态]、[最小单位标识]和[转换系数]
update tbl_sap_item_uom   
   set tbl_sap_item_uom.STATUS = RTrim(LTrim([tbl_import_item_uom].STATUS)),
       tbl_sap_item_uom.FLAG_MINUOM =  RTrim(LTrim([tbl_import_item_uom].FLAG_MINUOM)),
       tbl_sap_item_uom.CONVERT_FACTOR = RTrim(LTrim([tbl_import_item_uom].UMREZ/[tbl_import_item_uom].UMREN))
  from tbl_sap_item_uom ,[tbl_import_item_uom] 
 where tbl_sap_item_uom.item_number = RTrim(LTrim([tbl_import_item_uom].item_number))
   AND tbl_sap_item_uom.MEINH = RTrim(LTrim([tbl_import_item_uom].MEINH))
   AND tbl_sap_item_uom.MEINS = RTrim(LTrim([tbl_import_item_uom].MEINS));

--3、根据单位状态更新删除标识
update tbl_sap_item_uom set FLAG_WMS_DELETE = 'Y' WHERE STATUS = 'INACTIVE' AND item_number in (select distinct item_number from tbl_import_item_uom);
update tbl_sap_item_uom set FLAG_WMS_DELETE = 'N' WHERE STATUS = 'ACTIVE' AND item_number in (select distinct item_number from tbl_import_item_uom);
BEGIN TRANSACTION
set @item_number = '';
while 1=1
	begin----begin 2.1
	--4、查询出应该设置成最小单位的物料单位
	select @wh_id = wh_id,
		   @client_code = client_code,
		   @item_number = item_number,
		   @MATNR = MATNR,
		   @uom = MEINH 
	 from tbl_sap_item_uom 
	where FLAG_MINUOM = 'Y' 
	  and STATUS = 'ACTIVE'
	  and item_number > @item_number
	  and item_number in (select distinct item_number from tbl_import_item_uom)
	order by item_number desc

	if @@ROWCOUNT <= 0 or @item_number = ''
		break;

	--校验不可存在多于1个设置最小操作单位的物料
	SELECT @v_count = count(1) 
	 FROM tbl_sap_item_uom 
	where STATUS = 'ACTIVE' 
	  AND item_number = @item_number 
	  AND CONVERT_FACTOR < (SELECT CONVERT_FACTOR 
							  FROM tbl_sap_item_uom	
							 where STATUS = 'ACTIVE' 
							   AND FLAG_MINUOM = 'Y' 
							   AND item_number = @item_number)
		if @v_count > 1
			begin----begin 2.2
				set @msg= @item_number + '该物料存在状态为ACTIVE并且小于最小操作单位的单位，请核实数据';
				insert into tbl_set_minuom_log values(@wh_id,@item_number,@uom,'error1',@msg,getdate());
				continue;
			end	----end 2.2
	--校验不可存在多于1个设置最小操作单位的物料
	select @v_count = count(1) from tbl_sap_item_uom where item_number = @item_number and FLAG_MINUOM = 'Y';
		if @v_count > 1
			begin----begin 2.2
				set @msg= @item_number + '该物料存在多个最小操作单位，请核实数据';
				insert into tbl_set_minuom_log values(@wh_id,@item_number,@uom,'error1',@msg,getdate());
				continue;
			end	----end 2.2
	--根据要设置的最小单位校验该商品是否存在库存，如果存在则跳过该物料
	select @v_count = count(1) from t_stored_item where item_number = @item_number;
		if @v_count > 0
			begin----begin 2.2
				set @msg= @item_number + '已经存在库存，无法设置';
				insert into tbl_set_minuom_log values(@wh_id,@item_number,@uom,'error1',@msg,getdate());
				continue;
			end	----end 2.2
	--判断是否存在未完成的预到货通知单,存在则报错
	select @v_count = count(1) from t_rcpt_ship_po_detail trspd,t_rcpt_ship trs 
	 where trspd.shipment_number = trs.shipment_number 
	   and trspd.item_number = @item_number
	   and trs.status <> 'C'
		if @v_count > 0
			begin----begin 2.3
				set @msg = @item_number + '存在未完成的预到货通知单'
				insert into tbl_set_minuom_log values(@wh_id,@item_number,@uom,'error1',@msg,getdate());
				continue;
			end----end 2.3

	select @v_count = count(1) from t_order_detail tpd,t_order tod
	 where tpd.order_number = tod.order_number
	   and tpd.item_number = @item_number
	   and tod.status <> 'SHIPPED'
		if @v_count > 0
			begin----begin 2.4
				set @msg = @item_number + '存在未完成的出库单'
				insert into tbl_set_minuom_log values(@wh_id,@item_number,@uom,'error1',@msg,getdate());
				continue;
			end----end 2.4
		--5、设置最小操作单位
		EXEC [dbo].[csp_gen_item_uom_wms] 
			 @wh_id,
			 @client_code,
			 @MATNR,@uom,
			 @process_status OUTPUT,
			 @process_msg OUTPUT

		SELECT	@process_status as N'@process_status', 
				@process_msg as N'@process_msg'
		--6、将错误信息插入日志表
		insert into tbl_set_minuom_log values(@wh_id,@client_code + '-' + @MATNR,@uom,@process_status,ISNULL(@process_msg,'SUCCESS'),getdate());
	    continue;
	end----2.1
COMMIT	TRANSACTION
RETURN
--END TRY
	--BEGIN CATCH
	--	SET NOCOUNT OFF
	--	SET @msg = ERROR_MESSAGE()
	--	RAISERROR (@msg,11,1)
	--	RETURN
	--END CATCH
END----end 0




