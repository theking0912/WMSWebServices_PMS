


-- =============================================
-- Author:		WILL
-- Create date: 2016-02-23
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Check_ItemPCB_NBO]
	-- Add the parameters for the stored procedure here
	@WHID				NVARCHAR(30),
	@ITEMID		        NVARCHAR(30),
	@LOCATIONID		    NVARCHAR(30),
	@LOTNUMBER          NVARCHAR(30),
	@out_passornot		INT output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	set @out_passornot	=1
	DECLARE @TYPE1		NVARCHAR(30)
	DECLARE @TYPE2		NVARCHAR(30)
	DECLARE @TYPE3		NVARCHAR(30)
	DECLARE @TYPE4		NVARCHAR(30)
	DECLARE @TYPE5		NVARCHAR(30)
	DECLARE @lot_number    NVARCHAR(30)
	set @TYPE1='B'
	set @TYPE2='C'
	set @TYPE3=''
	set @TYPE4=''
	set @TYPE5=''



--select @TYPE3=t.type from t_location t where t.location_id in
--(select b.location_id from tbl_loc_item b where b.item_number=@ITEMID) 
--and t.wh_id=@WHID and t.type='B'
	

--select @TYPE4=t.type from t_location t where t.location_id in
--(select b.location_id from tbl_loc_item b where b.item_number=@ITEMID) 
--and t.wh_id=@WHID and t.type='C'

--if (@TYPE3 ='B' AND @TYPE4 <>'C')
--begin
--   set @out_passornot	=1    ------must check lot
--end

--if (@TYPE3 <>'B' AND @TYPE4 ='C')
--begin
--   set @out_passornot	=0    ------do not check lot
--end
    
--if (@TYPE3 <>'B' AND @TYPE4 <>'C')
--begin
--   set @out_passornot	=1    ------must check lot
--end

--if (@TYPE3 ='B' AND @TYPE4 ='C')
--begin
--   select @TYPE5 =type from t_location where location_id=@LOCATIONID  and wh_id=@WHID 
--   if(@TYPE5='B')
--   begin
--      set @out_passornot	=0    ------do not check lot
--   end
--   else 
--   begin
--      set @out_passornot	=1    ------must check lot
--   end
--end

	IF EXISTS (SELECT 1 FROM t_location WHERE location_id=@LOCATIONID AND wh_id=@WHID AND item_hu_indicator='H')
	BEGIN
	  RETURN
	END

IF EXISTS (SELECT 1 FROM t_location WHERE type in ('H','L','P') 
                                     AND location_id =@LOCATIONID 
									 AND wh_id =@WHID)
	   BEGIN
	   IF EXISTS (SELECT 1 FROM t_stored_item where  location_id =@LOCATIONID 
									 AND wh_id =@WHID
									 AND item_number =@ITEMID)
		begin
	      IF EXISTS (SELECT 1 FROM t_stored_item WHERE 
                                     location_id =@LOCATIONID 
									 AND wh_id =@WHID
									 AND item_number =@ITEMID
									 AND SUBSTRING (lot_number ,1,8)<>SUBSTRING(@LOTNUMBER,1,8))
				BEGIN
				     SET @out_passornot=2  -------------------存货位不允许混批次
					 RETURN
				END
		 end
	   END
	   
END



IF EXISTS (SELECT 1 FROM t_location WHERE type in ('B','Z','C') 
                                     AND location_id =@LOCATIONID 
									 AND wh_id =@WHID)
	   BEGIN
	    IF EXISTS (SELECT 1 FROM t_stored_item where  location_id =@LOCATIONID 
									 AND wh_id =@WHID
									 AND item_number =@ITEMID)
		begin
	      IF  NOT EXISTS (SELECT 1 FROM t_stored_item WHERE 
                                     location_id =@LOCATIONID 
									 AND wh_id =@WHID
									 AND item_number =@ITEMID
									 AND SUBSTRING (lot_number ,1,8)>=SUBSTRING(@LOTNUMBER,1,8))
				BEGIN
				     SET @out_passornot=3  -------------------上架批次必须小于等于拣货位的现有批次
					 RETURN
				END
		end

     END



