CREATE proc dbo.usp_Order_ShippingLabel
@wh_id nvarchar(10),
@order_number nvarchar(30)
--@EventDate ntext,
--@priority int
as
begin
	declare @whId nvarchar(10)
	declare @shipLabelBarcode nvarchar(30)

	
	--select @whId,@orderNumber
	set @shipLabelBarcode = 0

	while 1=1
	begin
				--declare @whId nvarchar(10)
				--declare @shipLabelBarcode nvarchar(30)
				select top 1 @whId=label.wh_id,@shipLabelBarcode=ship_label_barcode
				from t_order o,tbl_shipping_label label  
				where o.wh_id=label.wh_id 
				and o.order_number=label.order_number 
				and o.wh_id=@wh_id 
				and o.order_number=@order_number 
				and label.ship_label_barcode > @shipLabelBarcode
				order by ship_label_barcode asc 
				--select @whId,@shipLabelBarcode
		
			if @whId is not null and @shipLabelBarcode is not null
				exec ADV.dbo.usp_AdvAddEvent  4,'SEND PRINT','{{wh_id}}|{{order_id}}|1|QCHOLD|P|01|admin|T',25 
			else
				break
	end
end
