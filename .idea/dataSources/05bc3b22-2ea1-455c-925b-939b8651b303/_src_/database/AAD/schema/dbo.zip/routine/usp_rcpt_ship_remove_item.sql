

CREATE PROCEDURE [dbo].[usp_rcpt_ship_remove_item] 
@in_vchItemNumber       NVARCHAR(30),
@in_vchLineNumber       NVARCHAR(5),
@in_vchShipmentNumber   NVARCHAR(30),
@in_vchPo               NVARCHAR(30),
@in_vchWarehouseID      NVARCHAR(10) ,
@out_vchMessage         NVARCHAR(200) OUTPUT
AS

DECLARE

    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER,
    @v_vchErrorNumber       NVARCHAR(10)
    
    SET NOCOUNT ON

    SELECT @v_nRowCount = COUNT(*) FROM t_receipt
    WHERE po_number = @in_vchPo
       AND item_number = @in_vchItemNumber
       AND line_number = @in_vchLineNumber
       AND shipment_number = @in_vchShipmentNumber
       AND wh_id = @in_vchWarehouseID
       AND qty_received > 0;

    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR --, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
       BEGIN 
         SET @v_vchErrorNumber = '50001'
         SET @out_vchMessage   = 'A SQL error occured while count from t_receipt.'
       END

    IF @v_nRowCount > 0
       BEGIN
         SET @out_vchMessage = 'PO DETAIL BEING RECEIVED'
         GOTO ExitLabel
       END


    BEGIN TRANSACTION
    
    DELETE FROM t_rcpt_ship_po_detail 
    WHERE   po_number        = @in_vchPo
        AND item_number      = @in_vchItemNumber
        AND line_number      = @in_vchLineNumber
        AND shipment_number  = @in_vchShipmentNumber
        AND wh_id            = @in_vchWarehouseID
        AND received_qty     = 0
		AND status			 = 'O'   --只能删除状态为新建的行明细
      
    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN 
           SET @v_vchErrorNumber = '50001'
           SET @out_vchMessage   = 'A SQL error occured while deleting from t_rcpt_ship_po_detail.'
        END
        ELSE
        BEGIN
           SET @v_vchErrorNumber = '50002'
           SET @out_vchMessage   = 'Some items may already have been received.  Please refresh the previous screen.'
        END
        GOTO ErrorHandler
    END
    
    -- Delete the master, if no details for the po exist.
    DELETE FROM t_rcpt_ship_po
    WHERE po_number = @in_vchPo
        AND shipment_number = @in_vchShipmentNumber
        AND wh_id = @in_vchWarehouseID
        AND NOT EXISTS
        (SELECT 1
            FROM t_rcpt_ship_po_detail
            WHERE po_number = @in_vchPo
                AND shipment_number = @in_vchShipmentNumber
				AND status			= 'O'   --只能删除状态为新建的行明细
                AND wh_id			= @in_vchWarehouseID);
    
    -- Check for Errors.
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
       SET @v_vchErrorNumber = '50001'
       SET @out_vchMessage   = 'A SQL error occured while deleting from t_rcpt_ship_po.'
       GOTO ErrorHandler
    END
    
    COMMIT TRANSACTION
    SET @out_vchMessage = 'SUCCESS'
    
    GOTO ExitLabel 

ErrorHandler:
    SET @out_vchMessage = @v_vchErrorNumber + ' - ' + @out_vchMessage
    ROLLBACK TRANSACTION
    RAISERROR (@out_vchMessage, 16, 1)        

ExitLabel:
    RETURN


