
CREATE PROCEDURE [dbo].[csp_remove_information_id]
   @in_Information_Collection_ID INT
 , @in_Information_ID INT
AS
DECLARE 
   @n_seq INT

SET NOCOUNT ON

SELECT @n_seq = sequence_id 
FROM tbl_information_collection_detail
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @in_Information_ID

delete from tbl_information_collection_detail 
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @in_Information_ID

UPDATE tbl_information_collection_detail 
  SET sequence_id = sequence_id-1 
WHERE
     sequence_id > @n_seq
AND  information_collection_id = @in_Information_Collection_ID

ExitLabel:
    RETURN
