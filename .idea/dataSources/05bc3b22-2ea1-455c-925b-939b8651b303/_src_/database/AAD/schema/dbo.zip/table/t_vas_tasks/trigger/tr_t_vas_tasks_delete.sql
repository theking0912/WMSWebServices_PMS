
CREATE TRIGGER tr_t_vas_tasks_delete ON dbo.t_vas_tasks
INSTEAD OF DELETE
AS
   DECLARE
      @TaskID     INT

      SELECT @TaskID = vas_task_id
        FROM deleted

      IF EXISTS (SELECT 1 
          FROM deleted, t_vas_task_pending, t_work_q
         WHERE t_vas_task_pending.vas_task_id = deleted.vas_task_id
           AND t_vas_task_pending.work_q_id   = t_work_q.work_q_id
           AND t_work_q.work_status IN ('U','A') ) 
	    BEGIN 
            RAISERROR('There are pending work to be executed for this VAS Task ID', 10, 1)
            ROLLBACK TRANSACTION
            RETURN
	    END
    ELSE
        BEGIN
	        DELETE FROM t_vas_task_response WHERE vas_task_id = @TaskID
	    	DELETE FROM t_vas_task_image WHERE vas_task_id = @TaskID
	    	DELETE FROM t_vas_task_group WHERE vas_task_id = @TaskID
	    	DELETE FROM t_vas_task_describe WHERE vas_task_id = @TaskID
	    	DELETE FROM t_vas_task_pending WHERE vas_task_id = @TaskID
	    	DELETE FROM t_vas_profile_step WHERE vas_task_id = @TaskID
                DELETE FROM t_vas_tasks WHERE vas_task_id = @TaskID
            RETURN
        END
    
