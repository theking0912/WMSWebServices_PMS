
CREATE PROCEDURE [dbo].[csp_check_status] @user NVARCHAR(20)
AS
    DECLARE @r NVARCHAR(2)

    SET @r = ( SELECT   c1
               FROM     t_control
               WHERE    control_type = 'C_LOCK_SALE'
             )

    IF ( @r = 'N' )
        BEGIN 
            EXEC csp_imp_order_status_so_start


           -- INSERT  t_tran_log_holding
           --         ( tran_type ,
           --           description ,
           --           start_tran_date ,
           --           end_tran_date ,
           --           employee_id ,
           --           control_number ,
           --           line_number ,
           --           wh_id ,
           --           location_id ,
           --           item_number ,
           --           lot_number ,
           --           uom ,
           --           tran_qty ,
           --           wh_id_2 ,
           --           location_id_2 ,
           --           src_storage_device_id ,
           --           det_storage_device_id ,
           --           generic_attribute_1 ,
           --           generic_attribute_2 ,
           --           generic_attribute_3 ,
           --           generic_attribute_4 ,
           --           generic_attribute_5 ,
           --           generic_attribute_6 ,
           --           generic_attribute_7 ,
           --           generic_attribute_8 ,
           --           generic_attribute_9 ,
           --           generic_attribute_10 ,
           --           generic_attribute_11
			        --)
           -- VALUES  ( '000' ,
           --           '销售订单状态是否检查开关（接口）-----开' ,
           --           GETDATE() ,
           --           GETDATE() ,
           --           @user ,
           --           '' ,
           --           '' ,
           --           'HDLSH' ,
           --           NULL ,
           --           '' ,
           --           '' ,
           --           NULL ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           NULL ,
           --           NULL ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           ''
			        --)
         
            
 
            PRINT 'ok' 
        END 

    ELSE
        BEGIN
            EXEC csp_imp_order_status_so_stop


           -- INSERT  t_tran_log_holding
           --         ( tran_type ,
           --           description ,
           --           start_tran_date ,
           --           end_tran_date ,
           --           employee_id ,
           --           control_number ,
           --           line_number ,
           --           wh_id ,
           --           location_id ,
           --           item_number ,
           --           lot_number ,
           --           uom ,
           --           tran_qty ,
           --           wh_id_2 ,
           --           location_id_2 ,
           --           src_storage_device_id ,
           --           det_storage_device_id ,
           --           generic_attribute_1 ,
           --           generic_attribute_2 ,
           --           generic_attribute_3 ,
           --           generic_attribute_4 ,
           --           generic_attribute_5 ,
           --           generic_attribute_6 ,
           --           generic_attribute_7 ,
           --           generic_attribute_8 ,
           --           generic_attribute_9 ,
           --           generic_attribute_10 ,
           --           generic_attribute_11
			        --)
           -- VALUES  ( '001' ,
           --           '销售订单状态是否检查开关（接口）-----关' ,
           --           GETDATE() ,
           --           GETDATE() ,
           --           @user ,
           --           '' ,
           --           '' ,
           --           'HDLSH' ,
           --           NULL ,
           --           '' ,
           --           '' ,
           --           NULL ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           NULL ,
           --           NULL ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           '' ,
           --           ''
			        --)

        END