



--存储过程调用总过程	
CREATE PROCEDURE [dbo].[execproc]
@instr1 text,
@outint1 int output,
@outstr1 nvarchar(64) output,
@outstr2 nvarchar(256) output

 AS
BEGIN

	

	set lock_timeout 900000
	set nocount on
	SET DEADLOCK_PRIORITY  LOW
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	SET XACT_ABORT  ON
	--begin transaction

	IF  (isnull(object_id('tempdb..#returnresult'),0)=0) 
	begin
		create table #returnresult(outint1 int,outstr1 nvarchar(64),outstr2 nvarchar(256))
	end

	BEGIN TRY
		exec (@instr1)
 
		if exists(select * from #returnresult WITH(NOLOCK))
		begin
			select top 1 @outint1=outint1,@outstr1=outstr1,@outstr2=outstr2 from #returnresult WITH(NOLOCK)
			IF ( @@TRANCOUNT>0 ) commit transaction
		end
		else
		begin
			IF ( @@TRANCOUNT>0 ) rollback transaction
			select @outint1=0,@outstr1='0',@outstr2='执行出现异常！'
		END
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT>0 ROLLBACK TRANSACTIOn
		DECLARE @error NVARCHAR(100)
		SET @error=substring(ERROR_MESSAGE(),1,90)
		select @outint1=0,@outstr1='0',@outstr2='异常A:'+@error
	END CATCH

	IF  (isnull(object_id('tempdb..#returnresult'),0)>0) 
	begin
		drop table #returnresult
	END

	
	RETURN
end


