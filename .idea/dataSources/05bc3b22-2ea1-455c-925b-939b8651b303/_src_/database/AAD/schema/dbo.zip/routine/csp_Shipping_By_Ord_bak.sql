-- =============================================
-- Author:		Laver
-- Create date: 2014-08-26
-- Description:	
-- =============================================

CREATE PROCEDURE [dbo].[csp_Shipping_By_Ord_bak]
    @in_wh_id NVARCHAR(10) ,
    @in_order_number NVARCHAR(30) ,
    @in_user_id NVARCHAR(10) ,
    @out_passornot NVARCHAR(1) OUTPUT --0:Pass 1: Fail
    ,
    @out_msg NVARCHAR(200) OUTPUT
AS
    BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
        SET NOCOUNT ON;
		
		DECLARE @lot_number		AS	NVARCHAR(30)
		DECLARE	@item_number	AS	NVARCHAR(30)
		DECLARE @display_ord_no	AS	NVARCHAR(30)
		DECLARE @qty			AS	FLOAT
		DECLARE @qty_received	AS	FLOAT
		DECLARE @shipment_no	AS	NVARCHAR(30)
		DECLARE @ord_dtl_id		AS	INT = 0
		DECLARE @receipt_date	AS	Datetime
		DECLARE @line_number	AS	NVARCHAR(5)
		DECLARE @order_type		AS	NVARCHAR(20)
		DECLARE @original_ln	AS	NVARCHAR(5)
		DECLARE @msg			AS  NVARCHAR(100)		
		DECLARE @customer_type		AS	NVARCHAR(20)

        SET @out_passornot = 0
        BEGIN TRY
			
			SELECT @customer_type = customer_type
				FROM t_order o WITH(NOLOCK)
				INNER JOIN t_customer c
				ON o.wh_id = c.wh_id
				AND o.customer_id = c.customer_id
				WHERE o.order_number = @in_order_number
				AND o.wh_id = @in_wh_id

            IF EXISTS ( SELECT  1
                        FROM    t_order
                        WHERE   order_number = @in_order_number
                                AND wh_id = @in_wh_id
                                AND status = 'SHIPPED' )
                BEGIN
                    SET @out_passornot = 1
                    SET @out_msg = '已发运的订单.'
                    RETURN
                END
	
			IF NOT EXISTS( SELECT 1
						FROM t_pick_detail
						WHERE wh_id = @in_wh_id
							AND order_number = @in_order_number
							AND type = 'PP')
				BEGIN
					SET @out_passornot = 1
                    SET @out_msg = '订单没有发货物料'
                    RETURN
				END

			IF NOT EXISTS ( SELECT 1 FROM t_pick_detail 
							WHERE order_number = @in_order_number
                                AND  wh_id = @in_wh_id 
								AND picked_quantity <> 0
								AND type = 'PP')
			BEGIN
				SET @out_passornot = 1
                    SET @out_msg = '订单没有发货物料.'
                    RETURN
			END



			IF ISNULL(@customer_type,'') = 'SHWX-ND'
			BEGIN
				IF EXISTS ( SELECT  1 
							FROM    t_order_detail od 
							left outer join t_pick_detail tpd
							on od.wh_id = tpd.wh_id
							and od.order_number = tpd.order_number
							and od.item_number = tpd.item_number
							and od.line_number = tpd.line_number
							WHERE   od.order_number = @in_order_number
									AND od.wh_id = @in_wh_id
									AND tpd.type = 'PP'
									AND EXISTS ( SELECT 1 FROM tbl_allocation
																WHERE pick_id = tpd.pick_id)
									AND tpd.status NOT IN ('STAGED','LOADED') 
									AND tpd.type = 'PP'
									--and (tpd.pick_id IS NULL
			--                        OR tpd.status <> 'LOADED')
								)
					BEGIN
						SET @out_passornot = 1
						SET @out_msg = '订单还有物料没有完成拣货.'
						RETURN
					END
			END
			ELSE
			BEGIN
				IF EXISTS ( SELECT  1 
							FROM    t_order_detail od 
							left outer join t_pick_detail tpd
							on od.wh_id = tpd.wh_id
							and od.order_number = tpd.order_number
							and od.item_number = tpd.item_number
							and od.line_number = tpd.line_number
							WHERE   od.order_number = @in_order_number
									AND od.wh_id = @in_wh_id
									AND tpd.type = 'PP'
									AND EXISTS ( SELECT 1 FROM tbl_allocation
																WHERE pick_id = tpd.pick_id)
									AND tpd.status <> 'LOADED' 
									AND tpd.type = 'PP'
									--and (tpd.pick_id IS NULL
			--                        OR tpd.status <> 'LOADED')
								)
					BEGIN
						SET @out_passornot = 1
						SET @out_msg = '订单还有物料没有完成拣货.'
						RETURN
					END
			END
			

            BEGIN TRANSACTION

			--update order line
            UPDATE  od
            SET     od.qty_shipped = od.qty_shipped
                    + (( SELECT  SUM(tpd.picked_quantity)
                        FROM    t_pick_detail tpd
                        WHERE   tpd.wh_id = od.wh_id
                                AND tpd.item_number = od.item_number
                                AND tpd.line_number = od.line_number
                                AND tpd.order_number = od.order_number
								AND tpd.type = 'PP'
                      ) / (SELECT TOP 1 conversion_factor FROM t_item_uom uom
												WHERE uom.wh_id = od.wh_id
													AND uom.item_number = od.item_number
													AND uom.uom = od.order_uom))
            FROM    t_order_detail od
            WHERE   od.wh_id = @in_wh_id
                    AND od.order_number = @in_order_number

			--Update PKD
            UPDATE  pkd
            SET     status = 'SHIPPED' ,
                    pkd.shipped_quantity = pkd.picked_quantity
            FROM    t_pick_detail pkd
            WHERE   pkd.wh_id = @in_wh_id
                    AND pkd.order_number = @in_order_number
					AND pkd.type = 'PP'

			--UPDATE order status 
            UPDATE  t_order
            SET     status = 'SHIPPED' ,
                    actual_ship_date = GETDATE()
            WHERE   wh_id = @in_wh_id
                    AND order_number = @in_order_number
    
			--Create Log
			--Insert t_tran_log_holding
            INSERT  INTO t_tran_log_holding
                    ( [tran_type] ,
                      [description] ,
                      [start_tran_date] ,
                      [start_tran_time] ,
                      [end_tran_date] ,
                      [end_tran_time] ,
                      [employee_id] ,
                      [control_number] ,
                      [control_number_2] ,
                      [wh_id] ,
                      [location_id] ,
                      [hu_id] ,
                      [item_number] ,
                      [lot_number] ,
                      [tran_qty] ,
                      generic_attribute_1 ,
                      generic_attribute_2 ,
                      generic_attribute_3 ,
                      generic_attribute_4 ,
                      generic_attribute_5 ,
                      generic_attribute_6 ,
                      generic_attribute_7 ,
                      generic_attribute_8 ,
                      generic_attribute_9 ,
                      generic_attribute_10 ,
                      generic_attribute_11
                    )
                    SELECT  '341' ,
                            'Shipping' ,
                            GETDATE() ,
                            GETDATE() ,
                            GETDATE() ,
                            GETDATE() ,
                            @in_user_id ,
                            @in_order_number ,
                            NULL ,
                            @in_wh_id ,
                            sto.location_id ,
                            sto.hu_id ,
                            sto.item_number ,
                            sto.lot_number ,
                            sto.actual_qty ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_1
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_2
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_3
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_4
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_5
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_6
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_7
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_8
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_9
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_10
                            ) ,
                            ( SELECT    a.attribute_value
                              FROM      t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                              WHERE     a.stored_attribute_id = sto.stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_11
                            )
                    FROM    t_stored_item sto
                            INNER JOIN t_pick_detail tpd WITH(NOLOCK) ON sto.wh_id = tpd.wh_id
                                                            AND sto.type = tpd.pick_id
                    WHERE   sto.wh_id = @in_wh_id
                            AND tpd.order_number = @in_order_number
			
			SELECT @display_ord_no = display_order_number 
					,@order_type = order_type
			FROM t_order 
				WHERE order_number = @in_order_number
					AND wh_id = @in_wh_id
			

			--IF @order_type <> 'OO' OR @order_type <> '3PLO'
			IF @order_type NOT IN('OO','3PLO','SWP')
			BEGIN
				--Create interface for shipping
				INSERT INTO tbl_inf_exp_so_master
					([order_number],[user_id],[warehouse_id],[client_code],[process_status],carrier_code,shipped_date,order_type,display_order_number,sap_ordertype
					  ,move_code,cost_code,profit_code,ledger_code,stock_indicator_code,department)
				SELECT order_number,@in_user_id, wh_id,client_code,'Ready',carrier_scac,actual_ship_date,order_type,display_order_number,sap_ordertype
						,move_code,cost_code,profit_code,ledger_code,stock_indicator_code,department
				FROM t_order
				WHERE wh_id = @in_wh_id
				and order_number = @in_order_number

				INSERT INTO tbl_inf_exp_so_detail
					([line_number],[item_number],[lot_number],[quantity_shipped],[hu_id],[user_id],[warehouse_id]
					 ,client_code,uom,order_number,display_order_number
					 ,[process_status],storage_location,parent_line_number,factory
					)
				SELECT od.line_number,od.item_number,od.lot_number,ISNULL(tpd.shipped_quantity,0),NULL,@in_user_id,@in_wh_id
					,NULL
					,(SELECT TOP 1 uom FROM t_item_uom WITH(NOLOCK) 
									WHERE od.item_number = t_item_uom.item_number
										AND od.wh_id = t_item_uom.wh_id 
										ORDER BY conversion_factor ASC)
					,@in_order_number,ord.display_order_number			
					,'Ready',od.storage_location,od.parent_line_number,od.factory
				FROM t_order_detail od
				INNER JOIN t_order ord WITH(NOLOCK)
				ON od.wh_id = ord.wh_id
				AND od.order_number = ord.order_number
				LEFT OUTER JOIN t_pick_detail tpd WITH (NOLOCK)
				ON tpd.wh_id = od.wh_id
				AND tpd.order_number = od.order_number
				AND tpd.item_number = od.item_number
				AND tpd.line_number = od.line_number
				AND tpd.type = 'PP'
				WHERE ord.wh_id = @in_wh_id				
				and ord.order_number = @in_order_number
				and ISNULL(od.cancel_flag,'N') = 'N'
				--and tpd.shipped_quantity > 0

			END

			insert into tbl_shipping_label
			(wh_id,ship_label_barcode,route,carrier,weight,status,order_number,weight_time,create_time,remark,pack_type)
			select @in_wh_id,@in_order_number,route,carrier_scac,0,'SHIPPED',@in_order_number,null,getdate(),null,null
			from t_order
			where wh_id = @in_wh_id
			and order_number = @in_order_number

			insert into tbl_shipping_label_detail
			(wh_id,ship_label_barcode,item_number,lot_number,stored_attribute_id,quantity,create_time,remark,line_number)
			SELECT @in_wh_id,@in_order_number,item_number,lot_number,stored_attribute_id,actual_qty,getdate(),null,NULL
			 FROM t_stored_item
			 WHERE   wh_id = @in_wh_id
                    AND shipment_number = @in_order_number

			
			--Delete STO
            DELETE  FROM t_stored_item
            WHERE   wh_id = @in_wh_id
                    AND shipment_number = @in_order_number

			--Delete HU
            DELETE  FROM t_hu_master
            WHERE   wh_id = @in_wh_id
                    AND control_number = @in_order_number
					AND NOT EXISTS(SELECT 1 FROM t_stored_item where hu_id = t_hu_master.hu_id)

		    
			EXEC [dbo].[csp_add_account_page]    
			 @in_wh_id				  
			,NULL          
			,NULL		
			,NULL			
			,NULL	
			,@in_order_number			
			,NULL		
			,NULL
			,'OUT'		
			,@msg	OUTPUT		


			
						
			----IF @order_type = 'RVO'
			----BEGIN
			----	WHILE(1=1)
			----	BEGIN
			----		SELECT TOP 1 @item_number = tod.item_number,
			----				@lot_number = lot_number,
			----				@qty = tiu.conversion_factor * tod.qty,
			----				@ord_dtl_id = order_detail_id,
			----				@original_ln = tod.parent_line_number
			----			FROM t_order_detail tod
			----			INNER JOIN t_item_uom tiu WITH(NOLOCK)
			----			ON tod.item_number = tiu.item_number
			----			AND tod.wh_id = tiu.wh_id
			----			AND tod.order_uom = tiu.uom
			----			WHERE order_number = @in_order_number
			----				AND tod.wh_id = @in_wh_id
			----				AND tod.order_detail_id > @ord_dtl_id
			----			ORDER BY order_detail_id ASC

			----		IF @@ROWCOUNT = 0
			----		BEGIN
			----			BREAK
			----		END

			----		SET @receipt_date = '1900-01-01'
			----		WHILE(1 = 1)
			----		BEGIN
			----			--SELECT TOP 1
			----			--	@shipment_no = receipt_id,
			----			--	@qty_received = qty_received,
			----			--	@receipt_date = receipt_date,
			----			--	@line_number = line_number
			----			--FROM t_receipt
			----			--WHERE po_number = @display_ord_no
			----			--	AND wh_id = @in_wh_id
			----			--	AND item_number = @item_number
			----			--	AND lot_number = @lot_number
			----			--	AND receipt_date > @receipt_date
			----			--ORDER BY receipt_date ASC
			----			SELECT TOP 1
			----						@shipment_no = rspd.shipment_number,
			----						@qty_received = rspd.received_qty - ISNULL(rspd.return_qty,0),
			----						@receipt_date = rs.date_posting
			----						--@line_number = rspd.line_number
			----				 FROM t_rcpt_ship rs
			----				 INNER JOIN t_rcpt_ship_po rsp
			----				 ON rs.wh_id = rsp.wh_id
			----				 AND rs.shipment_number = rsp.shipment_number
			----				 INNER JOIN t_rcpt_ship_po_detail rspd
			----				 ON rsp.wh_id = rspd.wh_id
			----				 AND rsp.shipment_number = rspd.shipment_number
			----				 AND rsp.po_number = rspd.po_number
			----				 WHERE rspd.po_number = @display_ord_no
			----					AND rspd.wh_id = @in_wh_id
			----					AND rspd.item_number = @item_number
			----					AND rspd.line_number = @original_ln
			----					--AND rspd.received_qty - rspd.return_qty > 0 
			----				ORDER BY rs.date_posting DESC

			----			IF @@ROWCOUNT = 0
			----			BEGIN
			----				BREAK
			----			END						

			----			IF @qty < @qty_received
			----			BEGIN
			----				--UPDATE t_receipt
			----				--	SET qty_received = qty_received - @qty
			----				--	WHERE po_number = @display_ord_no
			----				--		AND wh_id = @in_wh_id
			----				--		AND item_number = @item_number
			----				--		AND lot_number = @lot_number
			----				--		AND line_number = @line_number
			----				--		AND receipt_date = @receipt_date
							
			----				UPDATE t_rcpt_ship_po_detail
			----				--SET received_qty = received_qty - @qty
			----				SET return_qty = ISNULL(return_qty,0) + @qty
			----				WHERE po_number = @display_ord_no
			----					AND item_number = @item_number
			----					AND shipment_number = @shipment_no
			----					AND line_number = @original_ln
			----					AND wh_id = @in_wh_id
													
			----				SET @qty = 0
			----				--SET @qty_received = @qty
			----			END
			----			ELSE
			----			BEGIN
			----				--DELETE FROM t_receipt
			----				--	WHERE po_number = @display_ord_no
			----				--		AND wh_id = @in_wh_id
			----				--		AND item_number = @item_number
			----				--		AND lot_number = @lot_number
			----				--		AND line_number = @line_number
			----				--		AND receipt_date = @receipt_date
			----				--		AND ISNULL(qty_discount,0) = 0

			----				--IF @@ROWCOUNT = 0
			----				--BEGIN
			----				--	UPDATE t_receipt
			----				--	SET qty_received = qty_received - @qty
			----				--	WHERE po_number = @display_ord_no
			----				--		AND wh_id = @in_wh_id
			----				--		AND item_number = @item_number
			----				--		AND lot_number = @lot_number
			----				--		AND line_number = @line_number
			----				--		AND receipt_date = @receipt_date
			----				--END

			----				UPDATE t_rcpt_ship_po_detail
			----				--SET received_qty = received_qty - @qty_received
			----				SET return_qty = ISNULL(return_qty,0) + @qty_received
			----				WHERE po_number = @display_ord_no
			----					AND item_number = @item_number
			----					AND shipment_number = @shipment_no
			----					AND line_number = @original_ln
			----					AND wh_id = @in_wh_id

			----				SET @qty = @qty - @qty_received
			----			END						

						

			----			IF @qty = 0
			----			BEGIN
			----				BREAK
			----			END
			----		END					
			----	END

			----END

			--CREATE SN Interface
            SET @out_passornot = 0
            SET @out_msg = ''
            COMMIT		
            RETURN
        END TRY
        BEGIN CATCH
            ROLLBACK
            SET @out_msg = ERROR_MESSAGE()
            SET @out_passornot = 1
            RETURN
        END CATCH

    END
