CREATE VIEW dbo.view_item_inventory
AS
SELECT     TOP (100) PERCENT itm.wh_id, itm.client_code, itm.display_item_number, itm.item_number, itm.description, ISNULL(sto_1.total_qty, 0) AS total_qty, 
                      ISNULL(sto_1.available_qty, 0) AS available_qty, ISNULL(sto_1.allo_qty, 0) AS allo_qty, ISNULL(sto_1.inbound_qty, 0) AS inbound_qty, ISNULL(sto_1.outbound_qty, 0) 
                      AS outbound_qty, ISNULL(sto_1.hold_qty, 0) AS hold_qty, itu.uom_prompt, itm.uom, itm.alt_item_number, itm.msds_url AS LinkURL, itm.class_id
FROM         dbo.t_item_master AS itm WITH (NOLOCK) INNER JOIN
                      dbo.t_whse AS whse WITH (NOLOCK) ON whse.wh_id = itm.wh_id LEFT OUTER JOIN
                          (SELECT     sto.wh_id, sto.item_number, SUM(sto.actual_qty) AS total_qty, SUM(CASE WHEN (loc.type = 'M' OR
                                                   loc.type = 'I' OR
                                                   loc.type = 'P') AND sto.type = 0 AND sto.status = 'A' THEN sto.actual_qty ELSE 0 END) - ISNULL(MAX(ABS(allo.allo_qty)), 0) AS available_qty, 
                                                   SUM(CASE WHEN (loc.type = 'S' OR
                                                   loc.type = 'F' OR
                                                   loc.type = 'X' OR
                                                   loc.type = 'D') AND sto.type = 0 THEN sto.actual_qty ELSE 0 END) AS inbound_qty, SUM(CASE WHEN sto.type <> 0 THEN sto.actual_qty ELSE 0 END) 
                                                   AS outbound_qty, SUM(CASE WHEN sto.status IN ('U', 'H') THEN sto.actual_qty ELSE 0 END) AS hold_qty, ISNULL(MAX(ABS(allo.allo_qty)), 0) 
                                                   AS allo_qty
                            FROM          dbo.t_stored_item AS sto WITH (NOLOCK) INNER JOIN
                                                   dbo.t_location AS loc WITH (NOLOCK) ON loc.location_id = sto.location_id AND loc.wh_id = sto.wh_id LEFT OUTER JOIN
                                                       (SELECT     wh_id, item_number, SUM(ABS(allocated_qty) - picked_qty) AS allo_qty
                                                         FROM          dbo.tbl_allocation AS tblal WITH (NOLOCK)
                                                         WHERE      (status IN ('U', 'A'))
                                                         GROUP BY wh_id, item_number) AS allo ON allo.wh_id = sto.wh_id AND allo.item_number = sto.item_number
                            GROUP BY sto.wh_id, sto.item_number) AS sto_1 ON sto_1.wh_id = itm.wh_id AND sto_1.item_number = itm.item_number LEFT OUTER JOIN
                          (SELECT     TOP (1) item_uom_id, item_master_id, item_number, wh_id, uom, conversion_factor, package_weight, units_per_layer, layers_per_uom, uom_weight, 
                                                   pickable, box_type, length, width, height, no_overhang_on_top, stack_code, batch, use_orientation_data, turnable, on_bottom_ok, on_side_ok, 
                                                   on_end_ok, bottom_only, top_only, max_in_layer, max_support_weight, stack_index, container_value, load_separately, nesting_height_increase, 
                                                   nested_volume, unit_volume, pattern, priority, status, uom_prompt, default_receipt_uom, default_pick_uom, class_id, pick_put_id, conveyable, 
                                                   std_hand_qty, min_hand_qty, max_hand_qty, default_pick_area, pick_location, display_config, vas_profile, cartonization_flag, gtin, shippable_uom, 
                                                   units_per_grab
                            FROM          dbo.t_item_uom WITH (NOLOCK)
                            WHERE      (conversion_factor = '1')) AS itu ON itu.item_number = itm.item_number AND itu.wh_id = itm.wh_id
ORDER BY itm.wh_id, itm.item_number, itm.inventory_type, itm.uom
