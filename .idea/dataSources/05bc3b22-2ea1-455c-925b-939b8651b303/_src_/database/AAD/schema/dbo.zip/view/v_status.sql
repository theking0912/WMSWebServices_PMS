
CREATE VIEW dbo.v_status
AS
SELECT lookup_id as status_id, locale_id, source, sequence, text AS status, description, lookup_type
    FROM t_lookup
    WHERE lookup_type = 'STATUS'

