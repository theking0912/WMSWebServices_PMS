
CREATE VIEW dbo.v_afa_lines
AS
SELECT
    lm.wh_id,
    lm.load_id,
    s.stop_id,
    s.stop_sequence,
    ln.freight_class_id,
    ln.commodity_type_id,
    ld.order_number,
    ISNULL(fc.freight_class_number, 'Not Specified') AS freight_class_number,
    ISNULL(fc.name, 'Not Specified')       AS freight_class_name,
    ISNULL(fc.description, 'Not Specified') AS freight_class_description,
--    ISNULL(ct.name, 'Not Specified')       AS commodity_type_name,
--    ISNULL(ct.description, 'Not Specified') AS commodity_type_description,
    SUM(ln.planned_qty)                    AS num_items,
    SUM(ln.planned_qty * i.unit_weight)    AS total_weight,
    SUM(ln.planned_qty * i.unit_volume)    AS total_cube,
    MAX(i.haz_material)                    AS haz_material
FROM
    t_afa_load_detail_line ln
INNER JOIN
    t_afa_load_detail ld
    ON
        ln.load_detail_id = ld.load_detail_id AND
        ln.wh_id = ld.wh_id
INNER JOIN
    t_item_master i
    ON
        ln.item_number = i.item_number AND
        ln.wh_id = i.wh_id
INNER JOIN
    t_stop s
    ON
        ld.stop_id = s.stop_id
INNER JOIN
    t_load_master lm
    ON
        s.load_id = lm.load_id AND
        s.wh_id = lm.wh_id
--LEFT JOIN
--    t_commodity_type ct
--    ON
--        ln.commodity_type_id = ct.commodity_type_id
LEFT JOIN
    t_freight_class fc
    ON
        ln.freight_class_id = fc.freight_class_id
GROUP BY
    lm.wh_id,
    lm.load_id,
    s.stop_id,
    s.stop_sequence,
    ln.freight_class_id,
    ln.commodity_type_id,
    ld.order_number,
    fc.freight_class_number,
    fc.name,    
    fc.description
--    ct.name,
--    ct.description

