




create  PROCEDURE [dbo].[csp_Rp_PBestQtyFIFO]    
		@in_vchWhID NVARCHAR(10)
	,	@in_vchItemID nvarchar(30)
	,   @in_vchLot nvarchar(30)
	,	@in_fQuantiry FLOAT
    ,   @in_packflag NVARCHAR(1)
	,   @in_stored_attribute_id BIGINT
	,   @in_damageflag  nvarchar(1)
	,   @c_vchLocTypes  NVARCHAR(30)
	,	@out_vchLot nvarchar(30) output
    ,   @out_expiration_date DATETIME OUTPUT
	,	@out_vchLocationID nvarchar(30) output
	,   @out_vchLp nvarchar(22)output
	,	@out_fAllocatedQty float output
AS    
BEGIN 
    DECLARE @Result    NVARCHAR(30)
	DECLARE @c_nStorageType	INT
	BEGIN TRY
        SET @out_vchLocationID = ''
        SET @out_fAllocatedQty = 0
        SET @c_nStorageType = 0
        SET @Result = ''

        SELECT TOP 1
                @out_vchLocationID = ito.location_id ,
                @out_vchLot = ito.lot_number ,
				@out_expiration_date = ito.expiration_date ,
                @out_vchLp = ito.hu_id ,
                @out_fAllocatedQty = ( CASE WHEN ito.actual_qty
                                                 - ito.unavailable_qty
                                                 - ISNULL(alloc.allocated_qty,
                                                          0) >= @in_fQuantiry
                                            THEN @in_fQuantiry
                                            ELSE ito.actual_qty
                                                 - ito.unavailable_qty
                                                 - ISNULL(alloc.allocated_qty,
                                                          0)
                                       END ) ,
                @in_damageflag = ito.damage_flag
        FROM    t_stored_item ito
                INNER JOIN t_zone_loca zl ON ito.wh_id = zl.wh_id
                                             AND ito.location_id = zl.location_id
                INNER JOIN t_location loc ON zl.wh_id = loc.wh_id
                                             AND zl.location_id = loc.location_id
                LEFT JOIN ( SELECT  location_id ,
                                    item_number ,
                                    wh_id ,
                                    SUM(ISNULL(allocated_qty, 0)
                                        - ISNULL(picked_qty, 0)) AS allocated_qty ,
                                    lot_number ,
                                    hu_id,
									stored_attribute_id
                            FROM    tbl_allocation
                            WHERE   item_number = @in_vchItemID
                                    AND ( isnull(@in_vchLot,'') =''
                                          OR lot_number = @in_vchLot
                                        )
                                    AND wh_id = @in_vchWhID
									AND allocated_qty > 0
										--AND status != 'C'  --delete by will  20160716  F7报空
									   AND status in ('A','U')  --add by will  20160716  F7报空
                            GROUP BY location_id ,
                                    item_number ,
                                    wh_id ,
                                    lot_number ,
                                    hu_id,
									stored_attribute_id
                          ) alloc ON ito.wh_id = alloc.wh_id
                                     AND ito.item_number = alloc.item_number
                                     AND ito.location_id = alloc.location_id 
                                     AND ISNULL(ito.lot_number, '') = ISNULL(alloc.lot_number,
                                                              '')
                                     AND ISNULL(ito.hu_id, '') = ISNULL(alloc.hu_id,
                                                              '')
									 AND ISNULL(ito.stored_attribute_id, 0) = ISNULL(alloc.stored_attribute_id, 0)
        WHERE   ito.item_number = @in_vchItemID
                AND CHARINDEX(loc.type, @c_vchLocTypes) > 0
                AND ito.type = @c_nStorageType
                AND ( isnull(@in_vchLot,'') =''
                      OR ito.lot_number = @in_vchLot
                    )
                AND ito.wh_id = @in_vchWhID
				AND ito.damage_flag = @in_damageflag
                AND ito.actual_qty - ito.unavailable_qty > ISNULL(alloc.allocated_qty, 0)
                AND loc.status NOT IN ( 'I', 'H' )
                AND ito.status = 'A'
               AND ( ISNULL(ito.stored_attribute_id,'') = ISNULL(@in_stored_attribute_id,'')
                      --OR @in_stored_attribute_id IS NULL
                      OR EXISTS ( SELECT    fnc.stored_attribute_id
                                  FROM      usf_get_pick_attribute_id(@in_vchItemID,
                                                              @in_stored_attribute_id) fnc
                                  WHERE     fnc.stored_attribute_id = ito.stored_attribute_id )
                    )
        ORDER BY ito.lot_number,
				CHARINDEX(loc.type, @c_vchLocTypes) ,
				--Added by George 20160620 CR NO.5
				CASE WHEN (ito.actual_qty - ito.unavailable_qty - ISNULL(alloc.allocated_qty, 0) - @in_fQuantiry>=0) 
				THEN ito.actual_qty - ito.unavailable_qty - ISNULL(alloc.allocated_qty, 0) - @in_fQuantiry 
				ELSE 99999999 + @in_fQuantiry - (ito.actual_qty - ito.unavailable_qty - ISNULL(alloc.allocated_qty, 0))   
				END ASC,
				--Added by George 20160620 CR NO.5                
                zl.pick_seq ,
                loc.location_id,
				ito.fifo_date DESC

		RETURN
	END TRY

    BEGIN CATCH
        SET @out_vchLocationID = ''
        SET @out_fAllocatedQty = 0
        RETURN
    END CATCH
END

--GRANT EXEC ON csp_Rp_PBestQtyFIFO TO AAD_USER,WA_USER



