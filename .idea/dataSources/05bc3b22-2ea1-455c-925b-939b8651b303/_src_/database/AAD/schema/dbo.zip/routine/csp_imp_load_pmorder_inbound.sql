
 

CREATE  PROCEDURE [dbo].[csp_imp_load_pmorder_inbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id nvarchar(10),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG varchar(100)
AS
BEGIN
        /*
		//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //AFKO-AUFNR	生产订单号
        //AUFK-AUART	订单类型
        //AUFK-ERDAT	订单日期
        //AUFK-WERKS	工厂
        //ZFLAG	        出入库标识
        //AFPO-POSNR	行号
        //AFPO-MATNR	物料号
        //AFPO-PSMNG	数量
        //AFPO-MEINS	订单单位
        //AFPO-LGORT	库存地点
        //AFPO-UEBTO	过量交货限度
        //AFPO-UETTO	交货不足限度
        //ZCOPRD        联副产品标志
		
		*/
	    declare @ZPOSITION varchar(100)
        declare @AUFNR varchar(100)
        declare @AUART varchar(100)
        declare @ERDAT varchar(100)
		declare @EINDT varchar(100)
        declare @LOEKZ varchar(100)
        declare @WERKS varchar(100)
        declare @POSNR varchar(100)
        declare @MATNR varchar(100)
        declare @PSMNG varchar(100)

        declare @MEINS varchar(100)
        declare @LGORT varchar(100)
        declare @UEBTO varchar(100)
        declare @UETTO varchar(100)
		declare @ZCOPRD varchar(100)
 
		declare @order_typeid int
	    declare @order_type varchar(100)
	    declare @cancel_flag varchar(100)

	  	/*if exists(select top 1 * from t_po_master WITH(NOLOCK)  where po_number=@order_no  and status<>'O')
		begin
		   insert into #returnresult values(-101,'Fail','订单号['+@order_no+']订单状态已经变化，不能修改.')
		   return
		end


		if exists(select top 1 * from t_po_detail WITH(NOLOCK)  where po_number=@order_no and line_number=@line_no and complete_flag='Y')
		begin
		   insert into #returnresult values(-101,'Fail','订单号['+@order_no+']-行号['+@line_no+']订单明细处理状态已经完成，不能修改.')
		   return
		end*/

		--如果这个入库单下存在未关闭的 运单，提示SAP不能更新该入库单
		if exists(SELECT 1 from t_rcpt_ship trs WITH(NOLOCK) 
					 INNER JOIN t_rcpt_ship_po rsp WITH(NOLOCK) 
					 ON trs.wh_id = rsp.wh_id
					 AND trs.shipment_number = rsp.shipment_number
					 WHERE   rsp.po_number = @order_no  and  trs.wh_id =@wh_id
					 AND (status <> 'C' 
					      OR (ISNULL(trs.is_confirm,'N') = 'N' 
						       AND EXISTS(SELECT 1 FROM t_control WHERE control_type = 'C_RECEIPT_CONFIRM' AND c1='Y')
						     )
                         )
					)
		begin
			insert into #returnresult values(-101,'Fail','订单号['+@order_no+'],该入库单下存在未关闭的运单，SAP不能更新该入库单.')
		   RETURN
		end

		select top 1    @ZPOSITION =ZPOSITION,
						@AUFNR =AUFNR,
						@AUART =AUART,
						@ERDAT =ERDAT,
						@LOEKZ =LOEKZ,
						@WERKS =WERKS,
						@ZFLAG =ZFLAG,
						@POSNR =POSNR,
						@MATNR =MATNR,
						@PSMNG =PSMNG,
						@MEINS =MEINS,
						@LGORT =LGORT,
						@UEBTO =UEBTO,
						@UETTO =UEBTO,
						@ZCOPRD=isnull(ZCOPRD,'')
		  from  tbl_inf_imp_pmorder  WITH(NOLOCK) 
		  where DATA_ID=@DataID and PROCESS_STATUS=@process_status
		        and AUFNR=@order_no and POSNR=@line_no and  ZFLAG=@ZFLAG

		 if (@LOEKZ='X') 
		 begin
		      set @cancel_flag='Y'
		 end
		 else 
		      set @cancel_flag='N'

		 select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype  WITH(NOLOCK) 
		 where sap_ordertype=@AUART  and flag_inoutbound=@ZFLAG 

		/*text	description
		CANCELLED	已取消
		LOADED	已装载
		NEW	新建
		PACKED	已包装
		PICKED	已拣货
		RELEASED	波次释放
		SHIPPED	已发货
		STAGED	准备包装
		WAVED	已建波次*/
 
		if not exists(select top 1 po_number from t_po_master WITH(NOLOCK)  where po_number=@order_no)
			 insert into t_po_master([po_number]
							  ,[type_id]
							  ,[create_date]
							  ,[wh_id]
							  ,[status]
							  ,[display_po_number]
							  ,[client_code]
							  ,[residential_flag]
							  ,[locked_flag]
							  ,sap_ordertype 
							   )
					values( @order_no
					            ,@order_typeid
								,cast(@ERDAT as date)
								,@wh_id
								,'O'
								,@order_no
								,@client_code
								,'N'
								,'N'
								,@AUART)
					--from tbl_inf_imp_pmorder 
					--where DATA_ID=@DataID and AUFNR=@order_no and POSNR=@line_no
	else
		   update t_po_master
		   set   create_date=cast(@ERDAT as date),
				 type_id =@order_typeid,
		         sap_ordertype=@AUART
		   from  t_po_master 
		   where  po_number=@order_no 

		declare @storage_location1 nvarchar(30), @storage_location2 nvarchar(30)
		select  @storage_location2=@WERKS, @storage_location1=@LGORT
   
		if not exists(select top 1 po_number from t_po_detail WITH(NOLOCK) where  po_number=@order_no and line_number=@line_no)
				insert into  t_po_detail([po_number]
							  ,[line_number]
							  ,[item_number]
							  ,[qty]
							  ,[wh_id]
							  ,[order_uom]
							  ,[more_qty]
							  ,[less_qty]
							  ,[upper_percent]
							  ,[lower_percent]
							  ,cancel_flag
							  ,storage_location
							  ,factory
							  ,complete_flag
							  ,schedule_number
							  ,item_type
							  )
							  values(@order_no,
							         @line_no,
									@WERKS+'-'+@MATNR,
									 cast(@PSMNG as float),
									 @wh_id,
									 @MEINS
									 ,cast((cast(isnull(@UEBTO,0) as float)/100*CAST(@PSMNG as float)) as INT)
									 ,cast((cast(isnull(@UETTO,0) as float)/100*CAST(@PSMNG as float)) as INT)
									 ,cast(isnull(@UEBTO,0) as float)/100
									 ,cast(isnull(@UETTO,0) as float)/100
									,@cancel_flag
									,@storage_location1
									,@storage_location2
									 ,'N'
									 ,1
									 ,@ZCOPRD
									 )
		else 
		    update t_po_detail
			set item_number=@WERKS+'-'+@MATNR
				,qty=@PSMNG
				,wh_id=@wh_id
				,order_uom=@MEINS
				,more_qty=cast((cast(isnull(@UEBTO,0) as float)/100*CAST(@PSMNG as float)) as int)
				,less_qty=CAST((cast(isnull(@UETTO,0) as float)/100*CAST(@PSMNG as float)) as int)
				,upper_percent=cast(isnull(@UEBTO,0) as float)/100
				,lower_percent=cast(isnull(@UETTO,0) as float)/100
				,cancel_flag=@cancel_flag
				,storage_location=@storage_location1
				,factory=@storage_location2
				,complete_flag='N'
				,item_type=@ZCOPRD
			where po_number=@order_no and line_number=@line_no

     insert into #returnresult values(1,N'OK',N'PM Inbound成功.')
END




