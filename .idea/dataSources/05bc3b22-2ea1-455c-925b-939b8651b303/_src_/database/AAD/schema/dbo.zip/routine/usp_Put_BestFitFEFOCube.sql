
CREATE PROCEDURE usp_Put_BestFitFEFOCube
    @in_vchItem		NVARCHAR(30),
    @in_vchLot		NVARCHAR(30),
    @in_nQty		INT,
    @in_dtFIFODate	DATETIME,
    @in_vchForkZone	NVARCHAR(10),
    @in_vchWhID		NVARCHAR(10),
	@in_nStoAttID	BIGINT,
    @out_vchLoc		NVARCHAR(50) = NULL OUTPUT

AS
DECLARE 
	@v_fNestedVolume FLOAT,
	@v_fUnitVolume	 FLOAT,
	@c_nStorageType	INT

-- Set Constants
SET @c_nStorageType = 0

    -- Retreive the nested_volume, and unit_volume from t_item_uom.
    -- Only a single t_item_uom record may be used.  This is determined by taking the
    -- greatest conversion factor less than or equal to the quantity passed in.
	SELECT TOP 1 @v_fNestedVolume = itu.nested_volume,
				 @v_fUnitVolume	= itu.unit_volume
    FROM t_item_uom itu
    WHERE itu.conversion_factor <= @in_nQty
        AND itu.item_number = @in_vchItem
        AND itu.wh_id = @in_vchWhID
	ORDER BY itu.conversion_factor DESC

	IF @in_nStoAttID IS NULL 
	   OR NOT EXISTS (SELECT * 
					  FROM t_item_master itm
					  INNER JOIN t_attribute_collection_detail acd
							ON itm.attribute_collection_id = acd.attribute_collection_id
					  INNER JOIN t_attribute_type tat
							ON acd.attribute_id = tat.attribute_id	
					  WHERE itm.item_number = @in_vchItem
  					      AND itm.wh_id = @in_vchWhID	
  						  AND tat.allow_mix = 'N'
					  )
	BEGIN
		SELECT TOP 1 @out_vchLoc = loc.location_id
		FROM t_item_master itm
		INNER JOIN t_item_uom itu
		ON itm.wh_id = itu.wh_id
			AND itm.item_number = itu.item_number
		INNER JOIN t_stored_item sto
			ON itu.wh_id = sto.wh_id
			AND itu.item_number = sto.item_number
		INNER JOIN t_location loc
			ON sto.wh_id = loc.wh_id
			AND sto.location_id = loc.location_id
        INNER JOIN t_pick_area pka
            ON pka.pick_area = loc.pick_area
            AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND @in_nStoAttID IS NULL AND @in_vchLot IS NULL) )
            AND pka.wh_id = loc.wh_id
            AND (pka.pick_area_type = 'R' OR (pka.pick_area_type = 'V' and @in_nStoAttID IS NULL))
		INNER JOIN t_zone_loca zlc
			ON loc.wh_id = zlc.wh_id
			AND loc.location_id = zlc.location_id
		WHERE itm.item_number = @in_vchItem
			AND itm.wh_id = @in_vchWhID
			AND zlc.zone = @in_vchForkZone
			AND loc.status <> 'F'
			AND loc.status <> 'I'
			AND sto.type = @c_nStorageType
			AND (
				  (itm.inspection_code = 'H' AND sto.status = 'H')
			   OR (itm.inspection_code <> 'H' AND sto.status = 'A'
			   AND sto.expiration_date >= (DATEADD (day, - itm.shelf_life, @in_dtFIFODate))  	-- Lower FIFO Date
	  		   AND sto.expiration_date <= (DATEADD (day, 1, @in_dtFIFODate))
					  )						-- FIFO Date
				  )
			   AND (loc.type = 'M' 
					OR (loc.type = 'I' AND itu.unit_volume = 0 AND itu.nested_volume = 0)
					OR (loc.type = 'I' AND loc.capacity_volume = 0)
					OR (loc.type = 'I' AND loc.capacity_volume >= 
						   (SELECT SUM (
										   -- Start with the volume currently in the location
										   (@v_fUnitVolume + ((sto.actual_qty - 1) *
											   CASE 
												   WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume 
												   ELSE @v_fNestedVolume 
											   END)
										   )
										)
										   -- Then add the volume to putaway to see if it less than or
										   -- equal to the capacity volume of the location
										   + (@v_fUnitVolume + ((@in_nQty  - 1) *
												   CASE
													   WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume
													   ELSE @v_fNestedVolume
												   END)
											   )
						   FROM t_stored_item sto  -- Sum the item in the location to determine volume
							   WHERE sto.wh_id = @in_vchWhID
							   AND sto.item_number = @in_vchItem
							   AND sto.location_id = loc.location_id
							   AND sto.actual_qty > 0
						   )

			))
			-- capacity_volume is used here to allow fulfillment of a bulk like location 
			-- first then picking_flow.
		ORDER BY loc.type, loc.user_count, loc.capacity_volume, sto.expiration_date DESC, loc.picking_flow, loc.location_id 
	END
	ELSE
	BEGIN
		SELECT TOP 1 @out_vchLoc = loc.location_id
		FROM t_item_master itm
		INNER JOIN t_item_uom itu
		ON itm.wh_id = itu.wh_id
			AND itm.item_number = itu.item_number
		INNER JOIN t_stored_item sto
			ON itu.wh_id = sto.wh_id
			AND itu.item_number = sto.item_number
		INNER JOIN t_location loc
			ON sto.wh_id = loc.wh_id
			AND sto.location_id = loc.location_id
        INNER JOIN t_pick_area pka
            ON pka.pick_area = loc.pick_area
            AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND @in_nStoAttID IS NULL AND @in_vchLot IS NULL) )
            AND pka.wh_id = loc.wh_id
            AND (pka.pick_area_type = 'R' OR (pka.pick_area_type = 'V' and @in_nStoAttID IS NULL))
		INNER JOIN t_zone_loca zlc
			ON loc.wh_id = zlc.wh_id
			AND loc.location_id = zlc.location_id
		WHERE itm.item_number = @in_vchItem
			AND itm.wh_id = @in_vchWhID
			AND zlc.zone = @in_vchForkZone
			AND loc.status <> 'F'
			AND loc.status <> 'I'
			AND sto.type = @c_nStorageType
			AND (
				  (itm.inspection_code = 'H' AND sto.status = 'H')
			   OR (itm.inspection_code <> 'H' AND sto.status = 'A'
			   AND sto.expiration_date >= (DATEADD (day, - itm.shelf_life, @in_dtFIFODate))  	-- Lower FIFO Date
	  		   AND sto.expiration_date <= (DATEADD (day, 1, @in_dtFIFODate))
					  )						-- FIFO Date
				  )
			   AND (loc.type = 'M' 
					OR (loc.type = 'I' AND itu.unit_volume = 0 AND itu.nested_volume = 0)
					OR (loc.type = 'I' AND loc.capacity_volume = 0)
					OR (loc.type = 'I' AND loc.capacity_volume >= 
						   (SELECT SUM (
										   -- Start with the volume currently in the location
										   (@v_fUnitVolume + ((sto.actual_qty - 1) *
											   CASE 
												   WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume 
												   ELSE @v_fNestedVolume 
											   END)
										   )
										)
										   -- Then add the volume to putaway to see if it less than or
										   -- equal to the capacity volume of the location
										   + (@v_fUnitVolume + ((@in_nQty  - 1) *
												   CASE
													   WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume
													   ELSE @v_fNestedVolume
												   END)
											   )
						   FROM t_stored_item sto  -- Sum the item in the location to determine volume
							   WHERE sto.wh_id = @in_vchWhID
							   AND sto.item_number = @in_vchItem
							   AND sto.location_id = loc.location_id
							   AND sto.actual_qty > 0
						   )

			))
			-- capacity_volume is used here to allow fulfillment of a bulk like location 
			-- first then picking_flow.
			AND NOT EXISTS (
							SELECT * 
							FROM t_item_master itm
							INNER JOIN t_attribute_collection_detail acd
								ON itm.attribute_collection_id = acd.attribute_collection_id
							INNER JOIN t_attribute_type tat
								ON acd.attribute_id = tat.attribute_id	
							INNER JOIN t_sto_attrib_collection_detail sad
								ON sad.attribute_id = tat.attribute_id
							INNER JOIN t_stored_item sto1
								ON sto1.stored_attribute_id = sad.stored_attribute_id
							INNER JOIN t_sto_attrib_collection_detail sad1
								ON sad.attribute_id = sad1.attribute_id
							WHERE itm.item_number = @in_vchItem
		      					  AND itm.wh_id = @in_vchWhID	
		      					  AND sad1.stored_attribute_id = @in_nStoAttID
		      					  AND tat.allow_mix = 'N'
		      					  AND sto.wh_id = sto1.wh_id
            					  AND sto.location_id = sto1.location_id
            					  AND sad.attribute_value <> sad1.attribute_value
						  )
		ORDER BY loc.type, loc.user_count, loc.capacity_volume, sto.expiration_date DESC, loc.picking_flow, loc.location_id 
	END
ExitLabel:
  RETURN
