
CREATE TRIGGER dbo.ea_tr_AlertHistoryUserUpd ON dbo.ea_t_alert_history_user AFTER UPDATE AS
BEGIN

    -- Get previous NOCOUNT value, in case we need to turn it back off
    DECLARE @v_nPrevNoCount INT
    SET @v_nPrevNoCount = @@OPTIONS & 512
    SET NOCOUNT ON

    IF UPDATE (acknowledged)
    BEGIN
        -- Check if acknowledged changed from 0 to 1, and if date_acknowledged is null
        IF EXISTS
            (
                SELECT 'True'
                FROM Inserted i
                JOIN Deleted d
                    ON i.alert_event_id = d.alert_event_id
                    AND i.userid = d.userid
                WHERE i.date_acknowledged IS NULL
                    AND d.acknowledged = 0
                    AND i.acknowledged = 1
            )
        BEGIN
            UPDATE u
                SET u.date_acknowledged = GETDATE()
                FROM ea_t_alert_history_user u
                JOIN Inserted i
                    ON u.alert_event_id = i.alert_event_id
                    AND u.userid = i.userid
        END -- IF EXISTS
    END -- IF UPDATE (acknowledged)

    IF UPDATE (resolved)
    BEGIN
        -- Check if resolved changed from 0 to 1, and if date_resolved is null
        IF EXISTS
            (
                SELECT 'True'
                FROM Inserted i
                JOIN Deleted d
                    ON i.alert_event_id = d.alert_event_id
                    AND i.userid = d.userid
                WHERE i.date_resolved IS NULL
                    AND d.resolved = 0
                    AND i.resolved = 1
            )
        BEGIN
            UPDATE u
                SET u.date_resolved = GETDATE()
                FROM ea_t_alert_history_user u
                JOIN Inserted i
                    ON u.alert_event_id = i.alert_event_id
                    AND u.userid = i.userid
        END -- IF EXISTS
    END -- IF UPDATE (resolved)

    -- Turn NOCOUNT back off if it was previously off
    IF @v_nPrevNoCount = 0
    BEGIN
        SET NOCOUNT OFF
    END

END


