


-- =======================================    
-- Author: LAVER    
-- Create Date: 2014-08-29  
-- Description:         
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Rep_Allocate_Pick]
    @wh_id NVARCHAR(10) ,
    @pick_loc NVARCHAR(30) ,
    @hu_id NVARCHAR(30) ,
    @put_loc NVARCHAR(30) ,
    @user_id NVARCHAR(30) ,
    @passornot NVARCHAR(1) OUTPUT ,
    @msg NVARCHAR(200) OUTPUT
AS
    BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
        SET NOCOUNT ON;    

        BEGIN TRY
            DECLARE @pick_id BIGINT
            DECLARE @allocated_qty FLOAT
            DECLARE @picked_qty FLOAT
			DECLARE @row_no	AS INT	= 0
            DECLARE @seq_id BIGINT
            DECLARE @remove_qty FLOAT		
            DECLARE @out_vchCode uddt_output_code ,
                @out_vchMsg uddt_output_msg
            DECLARE @ref_number NVARCHAR(30)
            DECLARE @zone NVARCHAR(30)
            DECLARE @zone_group NVARCHAR(10)
            DECLARE @type NVARCHAR(2)
        
            DECLARE @item_number NVARCHAR(30)	= ''
            DECLARE @order_number NVARCHAR(30)
            DECLARE @line_number NVARCHAR(5)
            DECLARE @lot_number NVARCHAR(30)
            DECLARE @stored_attribute_id NVARCHAR(30)
            DECLARE @damage_flag NVARCHAR(1)
            DECLARE @expiration_date DATETIME
            DECLARE @qty FLOAT

            SET @remove_qty = @qty * -1

            BEGIN TRANSACTION
            WHILE ( 1 = 1 )
                BEGIN
                    SELECT 
							@row_no = rn,
                            @item_number = item_number ,
                            @lot_number = lot_number ,
                            @stored_attribute_id = stored_attribute_id ,
                            @expiration_date = expiration_date ,
                            @qty = actual_qty
					FROM
					(select ROW_NUMBER() OVER(ORDER BY item_number) as rn
							,item_number
							,lot_number
							,stored_attribute_id
							,expiration_date
							,actual_qty
                    FROM    t_stored_item
                    WHERE   hu_id = @hu_id
                            AND wh_id = @wh_id
                   )  tsi
					where tsi.rn > @row_no
					

                    IF @@ROWCOUNT = 0
                        BEGIN
                            BREAK
                        END

                    WHILE ( @qty > 0 )
                        BEGIN

                            SELECT TOP 1
                                    @pick_id = pick_id ,
                                    @allocated_qty = ABS(allocated_qty)
                                    - picked_qty ,
                                    @seq_id = seq_id ,
                                    @order_number = order_number ,
                                    @line_number = line_number ,
                                    @ref_number = ref_number
                            FROM    tbl_allocation
                            WHERE   wh_id = @wh_id
                                    AND item_number = @item_number
                                    AND allocated_qty < 0
                                    AND status <> 'C'
                            ORDER BY pick_id

                            IF @@ROWCOUNT = 0
                                BEGIN
                                    RETURN
                                END
		
							--check the multi-wall sku into 1 location End
                            IF @qty <= @allocated_qty
                                BEGIN
                                    SET @picked_qty = @qty
                                    SET @qty = 0
                                END
                            ELSE
                                BEGIN
                                    SET @picked_qty = @allocated_qty
                                    SET @qty = @qty - @allocated_qty
                                END

                            --update pick allocate
							UPDATE tbl_allocation
								SET allocated_qty = allocated_qty + @picked_qty
							WHERE hu_id = @hu_id
								AND location_id = @put_loc
								AND wh_id = @wh_id
								AND item_number = @item_number
								AND lot_number = @lot_number
								AND stored_attribute_id = @stored_attribute_id
								AND status <> 'C'

                            IF @@ROWCOUNT = 0
							BEGIN
								INSERT INTO [dbo].[tbl_allocation]
								SELECT
								   [wave_id]
								   ,[order_number]
								   ,[pick_id]
								   ,[item_number]
								   ,@lot_number
								   ,@stored_attribute_id
								   ,@put_loc
								   ,@hu_id
								   ,@picked_qty
								   ,0
								   ,0
								   ,'U'
								   ,[released_date]
								   ,[ref_number]
								   ,[pick_wall_loc]
								   ,[pick_wall_slot]
								   ,[pick_conveyor_node]
								   ,[zone]
								   ,[wh_id]
								   ,[user_assign]
								   ,[line_number]
								   ,[shipping_label]
								   ,[picking_flow]
								   ,[allo_type]
								   ,[damage_flag]
								   ,@expiration_date
								from dbo.tbl_allocation
								where seq_id = @seq_id
							END

							-- update xdoc and rep allocate
							UPDATE dbo.tbl_allocation 
							SET picked_qty = picked_qty + @picked_qty
							,allocated_qty = (CASE allocated_qty + @picked_qty  WHEN 0 THEN picked_qty + @picked_qty ELSE allocated_qty + @picked_qty END)
							,status = (CASE allocated_qty + @picked_qty  WHEN 0 THEN 'C' ELSE status END)
							WHERE wh_id = @wh_id
							AND seq_id = @seq_id
							AND status <> 'C'

							-- delete finished allocated(xodc,rep)
							DELETE FROM tbl_allocation
							WHERE seq_id = @seq_id and allocated_qty = picked_qty				

							--Create tran log
							--Insert t_tran_log_holding
                            INSERT  INTO t_tran_log_holding
                                    ( [tran_type] ,
                                      [description] ,
                                      [start_tran_date] ,
                                      [start_tran_time] ,
                                      [end_tran_date] ,
                                      [end_tran_time] ,
                                      [employee_id] ,
                                      [control_number] ,
                                      [control_number_2] ,
                                      [wh_id] ,
                                      [location_id] ,
                                      [hu_id] ,
                                      [item_number] ,
                                      [lot_number] ,
                                      [tran_qty] ,
                                      wh_id_2 ,
                                      location_id_2 ,
                                      hu_id_2 ,
                                      generic_attribute_1 ,
                                      generic_attribute_2 ,
                                      generic_attribute_3 ,
                                      generic_attribute_4 ,
                                      generic_attribute_5 ,
                                      generic_attribute_6 ,
                                      generic_attribute_7 ,
                                      generic_attribute_8 ,
                                      generic_attribute_9 ,
                                      generic_attribute_10 ,
                                      generic_attribute_11
                                    )
                            VALUES  ( '306' ,
                                      'Replenishment (Put)' ,
                                      GETDATE() ,
                                      GETDATE() ,
                                      GETDATE() ,
                                      GETDATE() ,
                                      @user_id ,
                                      @order_number ,
                                      @pick_id ,
                                      @wh_id ,
                                      @pick_loc ,
                                      @hu_id ,
                                      @item_number ,
                                      @lot_number ,
                                      @picked_qty ,
                                      @wh_id ,
                                      @put_loc ,
                                      @hu_id ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_1
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_2
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_3
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_4
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_5
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_6
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_7
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_8
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_9
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_10
                                      ) ,
                                      ( SELECT  a.attribute_value
                                        FROM    t_sto_attrib_collection_detail a ,
                                                t_attribute_legacy_map alm
                                        WHERE   a.stored_attribute_id = @stored_attribute_id
                                                AND a.attribute_id = alm.generic_attribute_11
                                      )
                                    )
                        END
                END
        
		

		--Remove the stock from pick location
			EXEC usp_lp_move_remove 
					@wh_id,
					@hu_id, 
					@pick_loc,
					@put_loc,
					'IV',
					@out_vchCode OUTPUT,
					@out_vchMsg OUTPUT
			
            SET @passornot = 0
            SET @msg = ''
            COMMIT	TRANSACTION
            RETURN

        END TRY

        BEGIN CATCH
            ROLLBACK TRANSACTION
            SET @msg = ERROR_MESSAGE()
            SET @passornot = 1
            RETURN
        END CATCH
  
    END    
    



