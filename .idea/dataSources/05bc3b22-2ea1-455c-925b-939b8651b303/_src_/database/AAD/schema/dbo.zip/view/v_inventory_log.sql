
CREATE VIEW v_inventory_log AS
   SELECT wh_id, item_number, end_tran_date,
          delta_qty = (CASE WHEN tran_type IN ('542','301','311','540','253','272','276')
                           THEN -tran_qty
                           ELSE tran_qty
                       END)
   FROM t_tran_log
   WHERE tran_type IN ('111','151','273','275','391','521','543','851','852','853', '542','301','311','540','253','272','276')
