
CREATE VIEW v_al_host_order_detail AS
SELECT
host_order_detail_id,
host_order_master_id,
host_group_id,
record_create_date,
processing_code,
wh_id,
order_number,
line_number,
item_number,
item_description,
cust_part,
lot_number,
qty,
unit_weight,
unit_volume,
extended_weight,
extended_volume,
haz_material,
bol_class,
bol_code,
order_uom,
host_wave_id
  FROM t_al_host_order_detail
