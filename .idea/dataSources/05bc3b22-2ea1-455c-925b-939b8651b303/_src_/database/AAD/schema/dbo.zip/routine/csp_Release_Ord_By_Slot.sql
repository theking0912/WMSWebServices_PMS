
CREATE PROCEDURE [dbo].[csp_Release_Ord_By_Slot]
	@dpsPickId					AS  BIGINT,
	@in_wh_id					AS	NVARCHAR(30),
	@in_order_number			AS	NVARCHAR(30),
	@in_slot					AS	NVARCHAR(30),
	@Out_Nvch_Err_Code			AS	NVARCHAR(1)			OUTPUT,
	@Out_Nvch_Err_Msg			AS	NVARCHAR(200)		OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET XACT_ABORT ON
	SET @Out_Nvch_Err_Code = 1
		SET @Out_Nvch_Err_Msg = N'错误:csp_Release_Ord_By_Slot'
	BEGIN TRY

	-- Insert statements for procedure here
	DECLARE @ord_number			AS	NVARCHAR(30)	= ''
	DECLARE @wave_id			as	nvarchar(30)


	SELECT TOP 1 @wave_id = wave_id
			FROM tbl_inf_dps_order_release WITH(NOLOCK)
			WHERE id = @dpsPickId

	IF NOT EXISTS(SELECT 1 FROM tbl_pick_wall_slot WItH(NOLOCK)
					WHERE slot = @in_slot
						AND wave_id = @wave_id)
	BEGIN
		update work_pointer set PointerId=@dpsPickId where PointerName='DpsOrderRelease' and PointerId<@dpsPickId
		SET @Out_Nvch_Err_Code = 1
		SET @Out_Nvch_Err_Msg = N'没有找到可释放的槽位'
		RETURN
	END

	BEGIN TRANSACTION
    

	IF EXISTS(SELECT 1 FROM tbl_allocation  WITH(NOLOCK)
				WHERE order_number IN 
				(SELECT order_number FROM tbl_pick_wall_slot_detail WITH(NOLOCK) WHERE slot = @in_slot)
				AND status NOT IN ('C','E')
				AND allocated_qty > 0
				AND wh_id = @in_wh_id
				AND wave_id = @wave_id
				AND pick_wall_slot = @in_slot)
		  OR EXISTS(select 1 from t_stored_item si
							inner join t_pick_detail pd
							on si.type = pd.pick_id
							inner join t_location tl WITH(NOLOCK)
							ON si.location_id = tl.location_id
							AND si.wh_id = tl.wh_id
							where pd.order_number IN (SELECT order_number FROM tbl_pick_wall_slot_detail WITH(NOLOCK) WHERE slot = @in_slot)
							and pd.wave_id = @wave_id
							AND tl.type = 'X'
							AND EXISTS (SELECT 1 FROM tbl_inf_dps_lp WITH(NOLOCK) 
												WHERE wave_id = @wave_id
													AND pick_wall_slot = @in_slot
													AND item_number = si.item_number
													AND hu_id = si.hu_id)
					)
		--OR EXISTS(SELECT 1 FROM tbl_allocation allo
		--				INNER JOIN t_stored_item si
		--				ON allo.pick_id = si.type
		--				INNER JOIN t_location tl
		--				ON si.location_id = tl.location_id
		--				AND si.wh_id = tl.wh_id
		--				WHERE tl.type = 'X'
		--				AND allo.pick_wall_slot = @in_slot
		--				AND allo.wh_id = @in_wh_id
		--				AND allo.wave_id = @wave_id)						
	BEGIN
		-- sp error
		--update tbl_inf_dps_order_release set status=-2 where id=@dpsPickId
		update work_pointer set PointerId=@dpsPickId where PointerName='DpsOrderRelease' and PointerId<@dpsPickId
		SET @Out_Nvch_Err_Code = 1
		SET @Out_Nvch_Err_Msg = N'存在未释放的拣货任务'
		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK
		END
		RETURN
	END
	ELSE
	BEGIN  
		WHILE(1=1)
		BEGIN
				SELECT TOP 1 @ord_number = order_number
				 FROM tbl_pick_wall_slot_detail sd WITH(NOLOCK)
						WHERE wh_id = @in_wh_id
							--AND order_number = @in_order_number
							AND slot = @in_slot
							AND order_number > @ord_number
							ORDER BY order_number
			
				IF @@rowcount = 0
				BEGIN
					BREAK;
				END

				-- update order status
				UPDATE t_order
					SET status = 'LOADED'
					WHERE wh_id = @in_wh_id
					AND order_number = @in_order_number
					AND NOT EXISTS(SELECT 1 FROM t_pick_detail
									WHERE wh_id = @in_wh_id
										AND order_number = @in_order_number
										AND status <> 'LOADED'
										AND type = 'PP')
	
				-- release the slot
				DELETE FROM tbl_pick_wall_slot_detail
						WHERE wh_id = @in_wh_id
						AND	order_number = @ord_number
						AND slot = @in_slot

				IF NOT EXISTS(SELECT 1 FROM tbl_pick_wall_slot_detail
						WHERE wh_id = @in_wh_id
						AND	order_number = @ord_number
						AND slot = @in_slot)
				BEGIN
					UPDATE tbl_pick_wall_slot
						SET status = 'U',
							ship_label_barcode = '',
							order_number = '',
							customer_code = NULL,
							wave_id = NULL
						WHERE wh_id = @in_wh_id
						AND slot = @in_slot
						AND NOT EXISTS( SELECT 1 FROM tbl_pick_wall_slot_detail
											WHERE wh_id = @in_wh_id
												AND slot = @in_slot)
				END
		END
	

		 update work_pointer set PointerId=@dpsPickId where PointerName='DpsOrderRelease' and PointerId<@dpsPickId
	 
		 update tbl_inf_dps_order_release set status= -1 where id=@dpsPickId and status=-2
	  
		SET @Out_Nvch_Err_Code = 0
		 SET @Out_Nvch_Err_Msg = N'操作成功'
	END

	COMMIT
	RETURN

	END TRY
	BEGIN CATCH
		ROLLBACK
		-- sp error
		update tbl_inf_dps_order_release set status=-2 where id=@dpsPickId
		SET @Out_Nvch_Err_Code = 1
		SET @Out_Nvch_Err_Msg = ERROR_MESSAGE()
		RETURN
	END CATCH
END
