CREATE FUNCTION [dbo].[fn_Get_ZoneType_ByItem]
(
    @in_wh_id		  NVARCHAR(50),
    @in_item_number   NVARCHAR(50),
    @in_type		  NVARCHAR(10) --D:Damage; B:Blind; N:Normal
)
RETURNS NVARCHAR(10)
AS
BEGIN
    DECLARE
    -- Local Variables
    @v_zone_type             NVARCHAR(10),
	@v_client_type           NVARCHAR(10),
	@v_vip_flag				 NVARCHAR(10)

	SELECT @v_client_type = clt.client_type
		,@v_vip_flag = clt.vip_flag
	FROM t_item_master itm
		inner join t_client clt on itm.wh_id = clt.wh_id
								and itm.client_code = clt.client_code
	WHERE itm.wh_id = @in_wh_id
	AND itm.item_number = @in_item_number

	IF @in_type = 'N' 
		BEGIN
			SET @v_zone_type = @v_client_type + @v_vip_flag
		END
	ELSE
		BEGIN
			SET @v_zone_type = @v_client_type + @in_type
		END

----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

    -- Always leave from here.
    RETURN @v_zone_type 
END
