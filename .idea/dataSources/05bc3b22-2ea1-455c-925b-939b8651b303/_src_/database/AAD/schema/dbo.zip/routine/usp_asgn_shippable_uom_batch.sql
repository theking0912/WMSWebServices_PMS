

CREATE  PROCEDURE usp_asgn_shippable_uom_batch
    @in_OrderNumber  	AS NVARCHAR(20) = NULL,
    @in_LoadNumber	AS NVARCHAR(20) = NULL,
    @in_WaveNumber	AS NVARCHAR(20) = NULL,
    @in_ItemNumber	AS NVARCHAR(30) = NULL, -- item specific not yet supported
    @in_LotNumber	AS NVARCHAR(15) = NULL, -- lot specific not yet supported
    @in_PickArea	AS NVARCHAR(10) = 'ALL',
    @in_vchType         AS NVARCHAR(2) = 'PP',
    @in_WHID		AS NVARCHAR(10) = '01',
    @in_nResultsFlag    AS INT     -- 1 means return results;  0 means don't return results

AS

    --declare variables
    DECLARE
    @v_nCount                   INT,
    @v_nRange                   INT,
    @v_nStartManifestId         INT,
    @v_nFinishManifestId        INT,
    @v_nStartContinerId         INT,
    @v_nFinishContinerId        INT,
    @v_nStartWKQ                INT,
    @v_nFinishWKQ               INT,
     -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_vchOutMsg		        NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @v_nTranCount		        INT,
    @v_nContAdvFlag             INT,
    @v_vchContainerType         NVARCHAR(10),
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_GetContIdRangeError      INT,
    @e_UpdPkdContErr            INT,
    @e_InsPkdContErr            INT,
    @e_GetWKQRangeError         INT,
    @e_SetWKQTempError          INT,
    @e_UpdPKDWKQError           INT,
    @e_AddWKQError              INT


    SET NOCOUNT ON

    SET @v_nReturn = 0
    -- Set error nums
    SET @e_GenSqlError = 1
    SET @e_GetContIdRangeError = 2
    SET @e_UpdPkdContErr = 3
    SET @e_InsPkdContErr = 4
    SET @e_GetWKQRangeError = 5
    SET @e_SetWKQTempError = 6
    SET @e_UpdPKDWKQError  = 7
    SET @e_AddWKQError = 8
 
    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 14       -- This # must be unique per object.



    -- Check for PKD Records with work type 16 and shippable unit of measure
    SELECT @v_nCount = COUNT (*)
    FROM #tmp_pick_details_to_update pkd,  
         t_item_uom itu
    WHERE pkd.work_type = '16'
	AND pkd.item_number = itu.item_number
	AND pkd.uom = itu.uom
	AND pkd.wh_id = itu.wh_id
	AND pkd.wh_id = @in_WHID
    AND itu.shippable_uom = 'Y'
    AND pkd.manifest_carrier_flag = 'Y' 


    IF (@v_nCount = 0)
	    BEGIN
            -- No records to process so exit
       		GOTO ExitLabel
	    END

    -- create temp table for creating unique ids per shippable UoM PKD Task record
    CREATE TABLE #t_shippable_uom_task (
       id                      INT IDENTITY(1,1)  NOT NULL,
       pick_id                 NVARCHAR(60)       COLLATE DATABASE_DEFAULT  NULL,
       order_number            NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
       load_id                 NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
       wave_id                 NVARCHAR(20)       COLLATE DATABASE_DEFAULT NULL,
       wh_id                   NVARCHAR(10)       COLLATE DATABASE_DEFAULT NULL,
       work_q_id               NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
       pick_area               NVARCHAR(10)       COLLATE DATABASE_DEFAULT NULL
       )

    -- Get the default container from t_control
    SELECT @v_vchContainerType = c1
    FROM t_whse_control
    WHERE control_type = 'DEFAULT_CONTNR_TYPE'
      AND wh_id = @in_WHID

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
	    BEGIN
            -- Just set to carton if no records so we can continue processing
            SET @v_vchContainerType = 'CARTON'
	    END

    -- Determine what shippable uom pkds need a container id assigned
    INSERT INTO #t_shippable_uom_task (pick_id, order_number, wh_id, wave_id, load_id, pick_area )
    SELECT pkd.pick_id, pkd.order_number, pkd.wh_id, pkd.wave_id, pkd.load_id, pkd.pick_area
    FROM #tmp_pick_details_to_update pkd, 
         t_item_uom itu, t_pick_area pka
    WHERE pkd.wh_id = itu.wh_id 
        AND pkd.item_number = itu.item_number 
        AND pkd.uom = itu.uom 
        AND itu.shippable_uom = 'Y'
        AND pkd.manifest_carrier_flag = 'Y' 
        AND pkd.pick_area = pka.pick_area
        AND pka.wh_id = @in_WHID
        AND pka.work_type = '16'

    -- Check for errors
    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
	    BEGIN
            -- No records to process so exit
       		GOTO ExitLabel
	    END

    -- Determine how many container id's we need
    SELECT @v_nCount = COUNT (*)
    FROM #t_shippable_uom_task
    
    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END

    -- Set the range equal to the number of records 
    SET @v_nRange = @v_nCount
    -- Increment the t_control CONTAINER_ID entry for the number of unique id's needed
    EXEC @v_nReturn = usp_get_next_value_range @in_vchType = 'CONTAINER_ID', @in_nIncrement = @v_nRange,
                      @out_nUIDFirst = @v_nStartContinerId OUTPUT, @out_nUIDLast = @v_nFinishContinerId OUTPUT ,
                      @out_nErrorNumber = @v_nErrorNumber OUTPUT, @out_vchLogMsg = @v_vchOutMsg OUTPUT

    IF @v_nReturn <> 0
    BEGIN
        SET @v_vchErrorMsg = @v_vchOutMsg
        SET @v_nLogErrorNum = @e_GetContIdRangeError
	    GOTO ErrorHandler
    END

    -- decrement the start id
    SET  @v_nStartContinerId =  @v_nStartContinerId - 1


    -- Set the range equal to the number of records 
    SET @v_nRange = @v_nCount
    -- Increment the t_control MANIFEST_ID entry for the number of unique id's needed
    EXEC @v_nReturn = usp_get_next_value_range @in_vchType = 'MANIFEST_BATCH_ID', @in_nIncrement = @v_nRange,
                      @out_nUIDFirst = @v_nStartManifestId OUTPUT, @out_nUIDLast = @v_nFinishManifestId OUTPUT ,
                      @out_nErrorNumber = @v_nErrorNumber OUTPUT, @out_vchLogMsg = @v_vchOutMsg OUTPUT

    IF @v_nReturn <> 0
    BEGIN
        SET @v_vchErrorMsg = @v_vchOutMsg
        SET @v_nLogErrorNum = @e_GetContIdRangeError
	    GOTO ErrorHandler
    END

    -- decrement the start id
    SET  @v_nStartManifestId =  @v_nStartManifestId - 1

    -- Update the records with their unique container ids
    UPDATE pkd
    SET container_id = @v_nStartContinerId + stk.id, -- id is always 1 to n in any block
        manifest_batch_id = CASE WHEN (pkd.manifest_carrier_flag = 'Y' AND pkd.premanifest_flag = 'Y') 
				   THEN @v_nStartManifestId + stk.id -- set to same. needed in afo ato if split
				 ELSE NULL
				 END
    FROM #t_shippable_uom_task stk, 
         #tmp_pick_details_to_update pkd
    WHERE stk.pick_id = pkd.pick_id


    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END
    IF @v_nRowCount = 0
    BEGIN
    	SET @v_vchErrorMsg = 'Error encountered while updating container id in the pick detail table.'
   		SET @v_nLogErrorNum = @e_UpdPkdContErr
  		GOTO ErrorHandler
    END

    -- Insert records into t_pick_container
    INSERT INTO t_pick_container (container_id, wh_id, container_type, order_number,
                                  status, container_label, cartonization_batch_id, manifest_status )
    SELECT pkd.container_id, pkd.wh_id, 'UOM', pkd.order_number, 
           'ACTIVE', pkd.container_id, '0', 'NONE'
    FROM #tmp_pick_details_to_update pkd,
         #t_shippable_uom_task stk
    WHERE pkd.pick_id = stk.pick_id

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END
    IF @v_nRowCount = 0
    BEGIN
    	SET @v_vchErrorMsg = 'Error attempting to insert records into the t_pick_container table.'
   		SET @v_nLogErrorNum = @e_InsPkdContErr
  		GOTO ErrorHandler
    END

	-- Update t_pick_container with parcel manifest information if manifesting is on
	IF (SELECT next_value FROM t_whse_control 
	   WHERE control_type = 'MANIFEST_SYSTEM'
			AND wh_id = @in_WHID) = 1
	BEGIN --IF (SELECT next_value
	    UPDATE t_pick_container 
	    SET   manifest_status = 'NEW'
	        , carrier_id = ISNULL(ldm.carrier_id, orm.carrier_id)
	        , manifest_carrier_id = CASE WHEN ldm.service_type_id IS NULL THEN orm.manifest_carrier_id 
	                                ELSE (SELECT manifest_carrier_id
										 FROM t_manifest_carrier
	                                     WHERE carrier_id = ldm.carrier_id)
	                                END
	        , ship_via_id = CASE WHEN ldm.load_id IS NULL THEN orm.ship_via_id 
	                        ELSE NULL 
	                        END
	        , sat_delivery_flag = mor.sat_delivery_flag
	        , registered_mail_flag = mor.registered_mail_flag
	        , restricted_mail_flag = mor.restricted_mail_flag
	        , insurance_flag = mor.insurance_flag
	        , target_ship_date = ISNULL(ldm.earliest_ship_date, orm.earliest_ship_date)
            FROM  t_pick_container
                  JOIN #tmp_pick_details_to_update pkd 
                  ON (t_pick_container.container_id = pkd.container_id)
	          JOIN #t_shippable_uom_task stk
    		  ON (pkd.pick_id = stk.pick_id)
	          JOIN t_order orm
	          ON (pkd.order_number = orm.order_number AND pkd.wh_id = orm.wh_id)
	          JOIN t_order_manifest mor
	          ON (orm.order_id = mor.order_id)
	          LEFT JOIN t_load_master ldm
	          ON (pkd.load_id = ldm.load_id and pkd.wh_id = ldm.wh_id)
            WHERE pkd.manifest_carrier_flag = 'Y'
	
	    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
	    -- Check for any errors. If so, error number will not be equal to zero.
	    IF @v_nErrorNumber <> 0
	    	BEGIN
	        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
	       	     'the exact nature of the error.'
	       		SET @v_nLogErrorNum = @e_GenSqlError
	       		GOTO ErrorHandler
	    	END
	    IF @v_nRowCount = 0
	    BEGIN
	    	SET @v_vchErrorMsg = 'Error attempting to insert records into the t_pick_container table.'
	   		SET @v_nLogErrorNum = @e_InsPkdContErr
	  		GOTO ErrorHandler
	    END
	END --IF (SELECT next_value

    -- Create one work q entry per order (each order is only assigned to one container so this is okay.
    -- Count number of groups in order to determine how many Work Q ID's to get
    SELECT @v_nCount = COUNT(*) FROM #t_shippable_uom_task

    -- Increment the t_control WORK_Q_ID entry for the number of Work Q's needed
        SET @v_nRange = @v_nCount

        EXEC @v_nReturn = usp_get_next_value_range @in_vchType = 'WORK_Q_ID', @in_nIncrement = @v_nRange ,
                      @out_nUIDFirst = @v_nStartWKQ OUTPUT, @out_nUIDLast = @v_nFinishWKQ OUTPUT ,
                      @out_nErrorNumber = @v_nErrorNumber OUTPUT, @out_vchLogMsg = @v_vchOutMsg OUTPUT
    	-- Check for errors
        IF @v_nReturn <> 0
	        BEGIN
	            SET @v_vchErrorMsg = @v_vchOutMsg
	            SET @v_nLogErrorNum = @e_GetWKQRangeError
		        GOTO ErrorHandler
	        END

    -- Print a trace level log message.
    IF @v_nLogLevel >= 5  PRINT 'Starting WKQ: ' + CAST(@v_nStartWKQ as NVARCHAR(20)) +
							    ' Ending WKQ: ' + CAST((@v_nFinishWKQ)as NVARCHAR(20))

    --decrement starting work q because the first id in the table is 1
    SET @v_nStartWKQ = @v_nStartWKQ - 1

    -- Update the temp table with reseved work q ids
    UPDATE #t_shippable_uom_task
        SET work_q_id = (id + @v_nStartWKQ)
    FROM #t_shippable_uom_task

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
	    BEGIN
	        SET @v_vchErrorMsg = 'Failed to update temp table with Work Q ID''s for Picks.'
	        SET @v_nLogErrorNum = @e_SetWKQTempError
	        GOTO ErrorHandler
	    END

    -- Update temp table with the Work Q ID's that have been created
    UPDATE pkd

	    SET pkd.work_q_id = stk.work_q_id , pkd.status = 'PRERLSE'
	    FROM #tmp_pick_details_to_update pkd, 
             #t_shippable_uom_task stk
	    WHERE pkd.wh_id = @in_WHID
    		AND pkd.pick_id = stk.pick_id
            AND pkd.status = 'CREATED'


    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
	    BEGIN
	        SET @v_vchErrorMsg = 'Failed to update the t_pick_detail table with Work Q ID''s for Picks, '
	        SET @v_nLogErrorNum = @e_UpdPKDWKQError
	        GOTO ErrorHandler
	    END

    -- Create Work Q entries from PKD with a PRERLSE status.
    INSERT t_work_q (work_q_id, work_type, priority, description, date_due, time_due, wh_id, 
					work_status, workers_required, workers_assigned, zone)
    	SELECT pkd.work_q_id, pkd.work_type , MIN(wkt.default_priority), MIN(wkt.description), GETDATE(), GETDATE(), pkd.wh_id,
			   'U', 1 , 0 , pkd.pick_area
	FROM #tmp_pick_details_to_update pkd,
         t_work_types wkt, #t_shippable_uom_task stk
	WHERE pkd.status = 'PRERLSE'
         AND pkd.work_type = wkt.work_type
         AND pkd.work_q_id = stk.work_q_id
	GROUP BY pkd.work_q_id, pkd.work_type, pkd.wh_id , pkd.pick_area 

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END

    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
        BEGIN
            SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Picks. '
            SET @v_nLogErrorNum = @e_AddWKQError
            GOTO ErrorHandler
        END

    -- Success
    DROP TABLE #t_shippable_uom_task
    GOTO ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    
	
    SET @v_nReturn = @v_nLogErrorNum

    DROP TABLE #t_shippable_uom_task

    IF @v_nTranCount > 0
        ROLLBACK TRANSACTION

ExitLabel:
    -- Always leave the stored procedure from here.
    RETURN @v_nReturn





