
CREATE VIEW dbo.v_afa_order
AS
SELECT
    o.wh_id,
    o.order_number,
    o.type_id,
    orderPackageID = (o.order_number + '@' + o.wh_id),
    weight = ROUND(ISNULL(SUM(i.unit_weight*d.tran_plan_qty),0),0),
    volume = ROUND(ISNULL(SUM(i.unit_volume*d.tran_plan_qty),0),0),
    baseLineCost = o.baseline_rate,
    poolPointID = 0, 
    poolPointCost = 0,
    crossDockCost = ROUND(ISNULL(SUM(i.unit_weight*d.tran_plan_qty),0),0) * 0.05, -- This is a customization point, could be based on weight or pool point, etc
    pallets = 0, --(SELECT SUM(ISNULL(d1.remaining_qty/CASE i1.std_hand_qty
                --          WHEN 0 THEN 1 ELSE i1.std_hand_qty END,0) )
       -- FROM t_order_detail d1, t_item_master i1
       -- WHERE d1.item_number = i1.item_number AND d1.wh_id = i1.wh_id AND d1.order_number = o.order_number AND d1.wh_id = o.wh_id),
    locationString = UPPER(
                        LTRIM(RTRIM(ISNULL(o.ship_to_country_code, ''))) +
                        LTRIM(RTRIM(ISNULL(o.ship_to_addr1, ''))) +
                        LTRIM(RTRIM(ISNULL(o.ship_to_addr2, ''))) +
                        LTRIM(RTRIM(ISNULL(o.ship_to_addr3, ''))) +
                        LTRIM(RTRIM(ISNULL(o.ship_to_city, ''))) +
                        LTRIM(RTRIM(ISNULL(o.ship_to_state, ''))) +
                        LTRIM(RTRIM(ISNULL(o.ship_to_zip, '')))
                     ), -- used by ATO to help assign unique ID to each unique address
    compatibilityType = (SELECT MAX(i2.compatibility_id) --Since compatibility type is per line we have to aggregate the types for all lines.
        FROM t_item_master i2, t_order_detail d2
        WHERE i2.item_number = d2.item_number AND i2.wh_id = d2.wh_id and d2.order_number = d.order_number AND d2.wh_id = d.wh_id),
    -- Check for null values for earliest and latest date. If earliest
    -- is null, it will be set to current date. If latest is null, it
    -- will be set to earliest date plus 3 days, resulting in a 3-day
    -- delivery window. Note: the possible situation where latest
    -- date is set to a value earlier than the earliest date is not
    -- currently handled by this logic. Note 2: this logic only applies
    -- to delivery date; NULL ship dates are handled properly by ATO.
    o.earliest_ship_date AS earliestShipDate,
    o.latest_ship_date AS latestShipDate,
    ISNULL(o.earliest_delivery_date, GETDATE()) AS earliestDeliveryDate,
    ISNULL(o.latest_delivery_date, ISNULL(o.earliest_delivery_date, GETDATE()) + 3) AS latestDeliveryDate,
    orderZip = o.ship_to_zip,
    ISNULL(o.planning_rate, 2) as planning_rate
FROM t_order o, 
     t_order_detail d, 
     t_item_master i
WHERE
    o.order_number = d.order_number AND
    o.wh_id = d.wh_id AND
    d.item_number = i.item_number AND
    d.wh_id = i.wh_id AND
    d.tran_plan_qty = 0
GROUP BY o.order_number,
    o.wh_id,
    o.type_id,
    o.earliest_ship_date,
    o.latest_ship_date,
    o.earliest_delivery_date,
    o.latest_delivery_date,
    o.ship_to_country_code,
    o.ship_to_addr1,
    o.ship_to_addr2,
    o.ship_to_addr3,
    o.ship_to_city,
    o.ship_to_state,
    o.ship_to_zip,
    o.baseline_rate,
    o.planning_rate,
    d.order_number,
    d.wh_id


