
CREATE VIEW dbo.ea_v_RuntimeAlertUsers AS
SELECT
    ahu.alert_event_id,
    ah.alert_id,
    a.priority,
    a.alert_name,
    ah.date_added,
    ahu.userid,
    u.webwise_username,
    u.display_name,
    ahu.acknowledged,
    ahu.date_acknowledged,
    ahu.resolved,
    ahu.date_resolved,
    ahu.resolution_public,
    notes = CASE ahu.resolution_public
        WHEN 1 THEN SUBSTRING(ahu.resolution_notes, 1, 4000)
        ELSE ''
    END
FROM
    ea_t_alert_history_user ahu,
    ea_t_alert_history ah,
    ea_t_alert a,
    ea_t_user u
WHERE
    ahu.alert_event_id = ah.alert_event_id AND
    ah.alert_id = a.alert_id AND
    ahu.userid = u.userid
