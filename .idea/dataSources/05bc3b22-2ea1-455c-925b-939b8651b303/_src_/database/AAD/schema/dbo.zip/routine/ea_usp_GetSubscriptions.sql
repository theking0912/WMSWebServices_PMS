
CREATE PROCEDURE dbo.ea_usp_GetSubscriptions
    @in_vchUsername    NVARCHAR(50)  = '',
    @in_nUserID        BIGINT       = 0
AS
    DECLARE
        @v_nUserID          BIGINT,
        @v_vchDisplayName   NVARCHAR(100),
        @v_nAlertID         BIGINT,
        @v_vchAlertName     NVARCHAR(256)

    DECLARE @v_t_Subscriptions TABLE (
        id bigint IDENTITY,
        userid              BIGINT,
        display_name        NVARCHAR(100),
        alert_id            BIGINT,
        alert_name          NVARCHAR(256),
        subscription_id     BIGINT,
        notifyprofile_id    BIGINT,
        notifyprofile_name  NVARCHAR(256),
        filter_id               BIGINT,
        filter_name    NVARCHAR(256),
        link                NVARCHAR(16)
    )

    SET NOCOUNT ON

    IF @in_nUserID > 0
    BEGIN
        SELECT
            @v_nUserID = userid,
            @v_vchDisplayName = display_name
        FROM
            ea_t_user
        WHERE
            userid = @in_nUserID
    END
    ELSE
    BEGIN
        SELECT
            @v_nUserID = userid,
            @v_vchDisplayName = display_name
        FROM
            ea_t_user
        WHERE
            webwise_username = @in_vchUsername
    END

    IF @@ROWCOUNT = 1
    BEGIN

        DECLARE cur_Alerts CURSOR FOR
            SELECT DISTINCT
                ag.alert_id,
                a.alert_name
            FROM
                ea_t_alert_alertgroup ag,
                ea_t_alert a
            WHERE
                a.alert_id = ag.alert_id AND
                ag.alertgroup_id IN
                    (SELECT ug.alertgroup_id
                        FROM ea_t_user_alertgroup ug
                        WHERE ug.userid = @v_nUserID)
            ORDER BY
                a.alert_name

        OPEN cur_Alerts
        FETCH NEXT FROM cur_Alerts INTO @v_nAlertID, @v_vchAlertName

        WHILE @@FETCH_STATUS = 0
        BEGIN

            -- Get sebscriptions for current alert.
            INSERT INTO @v_t_Subscriptions (
                userid,
                display_name,
                alert_id,
                alert_name,
                subscription_id,
                notifyprofile_id,
                notifyprofile_name,
                filter_id,
                filter_name,
                link
            )
              SELECT
                    @v_nUserID,
                    @v_vchDisplayName,
                    @v_nAlertID,
                    @v_vchAlertName,
                    s.subscription_id,
                    s.notifyprofile_id,
                    n.notifyprofile_name,
                    s.filter_id,
                    f.filter_name,
                    CASE s.active
                        WHEN 1 THEN 'Active'
                        ELSE 'Inactive'
                    END AS link
                FROM
                    ea_t_subscription s LEFT OUTER JOIN
                    ea_t_notifyprofile n ON s.notifyprofile_id = n.notifyprofile_id LEFT OUTER JOIN
                    ea_t_filter f ON s.filter_id = f.filter_id
                WHERE
                    s.userid = @v_nUserID  AND
                    s.alert_id =  @v_nAlertID
                ORDER BY
                    n.notifyprofile_name

            -- Insert empty row to provide a link to add a subscription.
            INSERT INTO @v_t_Subscriptions (
                userid,
                display_name,
                alert_id,
                alert_name,
                subscription_id,
                notifyprofile_id,
                notifyprofile_name,
                filter_id,
                filter_name,
                link
            )
            VALUES (
                @v_nUserID,
                @v_vchDisplayName,
                @v_nAlertID,
                @v_vchAlertName,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                'Add Subscription'
            )

            FETCH NEXT FROM cur_Alerts INTO @v_nAlertID, @v_vchAlertName
        END

        CLOSE cur_Alerts
        DEALLOCATE cur_Alerts

    END
    SELECT
        userid,
        display_name,
        alert_id,
        alert_name,
        subscription_id,
        notifyprofile_id,
        notifyprofile_name,
        filter_id,
        filter_name,
        link
    FROM
        @v_t_Subscriptions
    ORDER BY id
