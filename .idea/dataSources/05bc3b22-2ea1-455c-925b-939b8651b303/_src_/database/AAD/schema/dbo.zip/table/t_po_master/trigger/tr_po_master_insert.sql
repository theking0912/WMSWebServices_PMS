

CREATE TRIGGER dbo.tr_po_master_insert ON dbo.t_po_master FOR INSERT AS 
BEGIN

DECLARE	
    -- Error handling variables
    @c_vchObjName               NVARCHAR(30),  -- The name that uniquely tags this object.
    @v_nSysErrorNum             INTEGER,
    @v_nRowCount                INTEGER,
    @v_vchCode                  NVARCHAR(30),
    @v_vchMsg                   NVARCHAR(1000),    

    -- Local Variables
    @v_vchClientCode            NVARCHAR(30),
    @v_vchDisplayPoNumber       NVARCHAR(30)

    -- Set Constants
    SET @c_vchObjName = 'tr_po_master_insert'

    SET NOCOUNT ON
  
    -- Get the new values.
    SELECT
        @v_vchClientCode = client_code,
        @v_vchDisplayPoNumber = display_po_number
    FROM
        inserted

    --Update po master
    IF @v_vchClientCode IS NULL OR @v_vchDisplayPoNumber IS NULL 
	BEGIN
		UPDATE pom
		     SET pom.client_code = ISNULL(ins.client_code, pom.wh_id),
			     pom.display_po_number = ISNULL(ins.display_po_number, pom.po_number) 
		FROM t_po_master pom
		INNER JOIN inserted ins
			ON pom.po_number = ins.po_number
		    AND pom.wh_id = ins.wh_id
	      
		 SELECT @v_nSysErrorNum = @@ERROR
		 IF @v_nSysErrorNum <> 0
		 BEGIN
			 SET @v_vchCode = '-20001'
			 SET @v_vchMsg = 'An error occured in trigger tr_po_master_insert while ' +
							'attempting update.'
			 GOTO ERROR_HANDLER
		 END
     END

GOTO EXIT_LABEL
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:

    SET @v_vchMsg = @c_vchObjName + ': [' + @v_vchCode + '] ' + @v_vchMsg
                          + ' SQL Error = ' + CONVERT(VARCHAR(30), ISNULL(@v_nSysErrorNum,0)) + '.'

    RAISERROR(@v_vchMsg, 11, 1)

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:
    RETURN
END

