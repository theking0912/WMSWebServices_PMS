
CREATE PROCEDURE usp_consolidate_sto_trace
@in_vchWarehouse      NVARCHAR(20),  -- Required. 
@in_nType             BIGINT,  -- Required, this may be 0 for STORAGE or -1 for Shipment Number in RoS.
@in_vchItem           NVARCHAR(60) = 'ALL', -- Optional, defaults to 'ALL' affecting all possible records.
@in_vchLocation       NVARCHAR(60) = 'ALL',  -- Optional, defaults to 'ALL' affecting all possible records.
@in_vchShipmentNumber NVARCHAR(30)

AS

DECLARE 
-- Error handling variables    
@c_vchObjName           NVARCHAR(30), -- The name that uniquely tags this object.   
@v_nSysErrorNum         INTEGER,
@v_vchErrorMsg          NVARCHAR(2000),
@v_nErrorCode           INTEGER,

--Constants
@c_nStorageType			INT,
@c_nReconcile			INT
 
SET NOCOUNT ON

-- Set Constants
SET @c_vchObjName = 'usp_consolidate_sto_trace'    
SET @c_nStorageType = 0

-----------------------------------------------------------------------------------
--    Move trace lot inventory from in_nType to an existing STORAGE record,
--    if it exists.  The location_id is optional.
--
--    Note: When working with inventory on the fork, this statement won't likely do
--    find any records to update, but the insert (the next statement) will.
-----------------------------------------------------------------------------------

UPDATE t_stored_item
SET actual_qty = sto1.actual_qty + sto2.sum_qty
FROM 
    t_stored_item sto1,
    (
    SELECT
        type,
        wh_id,
        location_id,
        item_number,
        SUM(actual_qty) AS sum_qty,
        stored_attribute_id,
        hu_id
    FROM
        t_stored_item
    WHERE -- inventory to be consolidated (has a lot)
        type = @in_nType
        AND wh_id = @in_vchWarehouse
        AND (item_number = @in_vchItem OR @in_vchItem = 'ALL')
        AND (location_id = @in_vchLocation OR @in_vchLocation = 'ALL')
        AND lot_number IS NOT NULL
        AND EXISTS (SELECT 1
                    FROM t_item_master
                    WHERE item_number = t_stored_item.item_number
                        AND wh_id = t_stored_item.wh_id
                        AND lot_control IN ('T', 'I')
                    )
    GROUP BY
        type,
        wh_id,
        location_id,
        item_number,
		    stored_attribute_id,
        hu_id
    ) sto2
WHERE -- inventory that has already been consolidated (no lot).
    sto1.item_number = sto2.item_number
    AND sto1.lot_number IS NULL
	AND ((sto1.stored_attribute_id = sto2.stored_attribute_id) 
			OR (ISNULL(sto1.stored_attribute_id,'') = ISNULL(sto2.stored_attribute_id,'')))
	AND ((sto1.hu_id = sto2.hu_id) 
			OR (ISNULL(sto1.hu_id,'') = ISNULL(sto2.hu_id,'')))
	AND sto1.location_id = sto2.location_id
    AND sto1.wh_id = sto2.wh_id
    AND sto1.type = @c_nStorageType
       
SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0     
BEGIN 
    SET @v_nErrorCode = -20001
    SET @v_vchErrorMsg = 'A SQL error occured while updating t_stored_item.'
    GOTO ERROR_HANDLER
END

-----------------------------------------------------------------------------------
-- Create inventory STORAGE records for every record WITH a lot number that doesn't
-- already exist WITH NO lot number.
--
-- Note: Because the update would have already accounted for the records that
-- already have been consolidated. (Those records with no lot number).
-----------------------------------------------------------------------------------

INSERT INTO t_stored_item 
(
    wh_id, 
    location_id, 
    item_number, 
    actual_qty, 
    status, 
    fifo_date,   
    type,
    inspection_code,
    stored_attribute_id,
    hu_id
)
SELECT 
    sto.wh_id, 
    sto.location_id, 
    item_number, 
    SUM(actual_qty) AS actual_qty,
    'A' AS status, 
    MIN(fifo_date) AS fifo_date,
    @c_nStorageType AS type,
    CASE loc.type
      WHEN 'F' THEN sto.inspection_code
      WHEN 'S' THEN sto.inspection_code
      WHEN 'O' THEN sto.inspection_code
      ELSE NULL
    END AS inspection_code,
	  sto.stored_attribute_id,
    sto.hu_id
FROM
    t_stored_item sto,
    (SELECT type,location_id FROM t_location 
        WHERE wh_id = @in_vchWarehouse 
         AND ( location_id = @in_vchLocation OR @in_vchLocation = 'ALL') ) loc
WHERE 
    sto.type = @in_nType
    AND sto.location_id = loc.location_id
    AND sto.wh_id = @in_vchWarehouse
    AND (sto.item_number = @in_vchItem OR @in_vchItem = 'ALL')
    AND (sto.location_id = @in_vchLocation OR @in_vchLocation = 'ALL')
	AND sto.shipment_number = @in_vchShipmentNumber
    AND EXISTS (SELECT 1
                FROM t_item_master
                WHERE item_number = sto.item_number
                    AND wh_id = sto.wh_id
                    AND lot_control IN ('T', 'I')
                )
    AND NOT EXISTS 
    (
        SELECT 1
        FROM t_stored_item
        WHERE item_number = sto.item_number
			AND ((stored_attribute_id = sto.stored_attribute_id) 
				OR (ISNULL(stored_attribute_id,'') = ISNULL(sto.stored_attribute_id,'')))
			AND ((hu_id = sto.hu_id) 
				OR (ISNULL(hu_id,'') = ISNULL(sto.hu_id,'')))
            AND type = @c_nStorageType
            AND location_id = sto.location_id
            AND wh_id = sto.wh_id
            AND lot_number IS NULL
    )
GROUP BY
    wh_id, 
    sto.location_id, 
    item_number,
    loc.type,
    inspection_code,
	  stored_attribute_id,
    hu_id

SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0     
BEGIN 
    SET @v_nErrorCode = -20002
    SET @v_vchErrorMsg = 'A SQL error occured while inserting into t_stored_item.'
    GOTO ERROR_HANDLER
END      

-----------------------------------------------------------------------------------
--  Now that all the inventory has been consolidated, delete all STO records for
--  the type/item/warehouse (Trace items, meaning those records with a lot number.)
-----------------------------------------------------------------------------------

DELETE t_stored_item
WHERE type = @in_nType
    AND wh_id = @in_vchWarehouse          
    AND (item_number = @in_vchItem OR @in_vchItem = 'ALL')
    AND (location_id = @in_vchLocation OR @in_vchLocation = 'ALL')
	AND shipment_number = @in_vchShipmentNumber
    AND lot_number IS NOT NULL
    AND EXISTS (SELECT 1
                FROM t_item_master
                WHERE item_number = t_stored_item.item_number
                    AND wh_id = t_stored_item.wh_id
                    AND lot_control IN ('T', 'I')
                )
 
SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
BEGIN    
    SET @v_nErrorCode = -20003
    SET @v_vchErrorMsg = 'A SQL error occured while deleting records from t_stored_item.'
    GOTO ERROR_HANDLER
END
        
GOTO EXIT_LABEL 
    
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------  
ERROR_HANDLER:
    
    SET @v_vchErrorMsg = @c_vchObjName + ': ' + CONVERT(VARCHAR(10), @v_nErrorCode) + ' ' + @v_vchErrorMsg
                          + ' SQL Error = ' + CONVERT(VARCHAR(30), @v_nSysErrorNum) + '.'

    RAISERROR(@v_vchErrorMsg, 11, 1)    
    
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

    RETURN
