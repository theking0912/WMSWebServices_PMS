
CREATE TRIGGER tr_v_vas_profile_applies_upd ON v_vas_profile_applies
INSTEAD OF UPDATE
AS
BEGIN
SET NOCOUNT ON
   UPDATE t_vas_profile_applies
      SET vas_profile_id        = ins.vas_profile_id,
          item_number           = ins.item_number, 
          display_item_number   = ins.display_item_number, 
          client_code           = ins.client_code, 
          uom                   = ins.uom, 
          inv_class             = ins.inv_class, 
          inv_cat               = ins.inv_cat, 
          inventory_type        = ins.inventory_type, 
          inbound_order_type    = ins.inbound_order_type, 
          tran_type             = ins.tran_type, 
          vendor_code           = ins.vendor_code, 
          carrier_id            = ins.carrier_id, 
          gen_attribute_value1  = ins.gen_attribute_value1, 
          gen_attribute_value2  = ins.gen_attribute_value2, 
          gen_attribute_value3  = ins.gen_attribute_value3, 
          gen_attribute_value4  = ins.gen_attribute_value4, 
          gen_attribute_value5  = ins.gen_attribute_value5, 
          gen_attribute_value6  = ins.gen_attribute_value6, 
          gen_attribute_value7  = ins.gen_attribute_value7, 
          gen_attribute_value8  = ins.gen_attribute_value8, 
          gen_attribute_value9  = ins.gen_attribute_value9, 
          gen_attribute_value10 = ins.gen_attribute_value10, 
          gen_attribute_value11 = ins.gen_attribute_value11
      FROM inserted ins
      WHERE t_vas_profile_applies.vas_applies_id = ins.vas_applies_id
END



