
CREATE PROCEDURE usp_afa_unbuild_shipment
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchLoadId         NVARCHAR(60),
@out_vchMessage       NVARCHAR(500) OUTPUT -- Contians "SUCCESS" or the message to be displayed.

AS

DECLARE 
    @v_nErrorNumber       INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(500),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,
 
    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,
    @v_nReturn            INTEGER,
    @v_vchErrorMsg        NVARCHAR(500),

    @e_GenSqlError          INTEGER,
    @e_UpdOrderDetailFailed INTEGER,
    @e_DelLDDFailed         INTEGER,
    @e_DelLDLineFailed      INTEGER,
    @e_DelStopsFailed       INTEGER,
    @e_DelLoadMasterFailed  INTEGER,
    @v_nTranCount           INTEGER

    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 7

    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_UpdOrderDetailFailed = 2
    SET @e_DelLDDFailed = 3
    SET @e_DelLDLineFailed = 4
    SET @e_DelStopsFailed = 5
    SET @e_DelLoadMasterFailed = 6 
 
    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

            --Increment the remaining_qty on the order
            UPDATE t_order_detail
            SET tran_plan_qty = tran_plan_qty + ldl.planned_qty 
            FROM t_order_detail d, t_afa_load_detail ldd, t_afa_load_detail_line ldl
            WHERE d.order_number = ldd.order_number
                AND d.wh_id = ldd.wh_id
                AND ldd.load_detail_id = ldl.load_detail_id
		        AND d.line_number      = ldl.line_number
		        AND d.item_number      = ldl.item_number                
                AND ldd.load_id = @in_vchLoadId
                AND ldd.wh_id = @in_vchWarehouseId
 
            --Make sure the update was successful       
            SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_vchSqlErrorNumber <> 0 
            BEGIN
                SET @v_nErrorNumber = @e_GenSqlError
                GOTO ErrorHandler                                
            END


            --Delete Load detail line records
            DELETE FROM t_afa_load_detail_line
            WHERE load_detail_id IN 
                 (SELECT load_detail_id 
                  FROM t_afa_load_detail 
                  WHERE load_id = @in_vchLoadId
                  AND wh_id = @in_vchWarehouseId)
            AND wh_id = @in_vchWarehouseId
            
            --Make sure the update was successful   
            SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_vchSqlErrorNumber <> 0 
            BEGIN
                SET @v_nErrorNumber = @e_GenSqlError
                GOTO ErrorHandler                                
            END

            --Delete the Load detail records
            DELETE FROM t_afa_load_detail
            WHERE load_id = @in_vchLoadId
                AND wh_id = @in_vchWarehouseId
             
            --Make sure the delete worked.
            SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_vchSqlErrorNumber <> 0 
            BEGIN
                SET @v_nErrorNumber = @e_GenSqlError
                GOTO ErrorHandler                                
            END
 
            --Delete the Stop Records
            DELETE FROM t_stop 
            WHERE load_id = @in_vchLoadId 
                AND wh_id = @in_vchWarehouseId
                AND stop_id NOT IN (SELECT DISTINCT stop_id from t_afa_load_detail)

            --Make sure the delete worked.
            SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_vchSqlErrorNumber <> 0 
            BEGIN
                SET @v_nErrorNumber = @e_GenSqlError
                GOTO ErrorHandler                                
            END

            --Delete the Load Master row
            DELETE FROM t_load_master 
            WHERE load_id = @in_vchLoadId 
                AND wh_id = @in_vchWarehouseId

            --Make sure the delete worked.
            IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
            BEGIN
            IF @v_vchSqlErrorNumber <> 0
                SET @v_nErrorNumber = @e_GenSqlError
            ELSE
                SET @v_nErrorNumber = @e_DelLoadMasterFailed
            GOTO ErrorHandler                                
            END

    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel


ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_UpdOrderDetailFailed
    BEGIN -- 
        -- Log Error    
        SET @v_vchLogMsg = 'An update to the t_order_detail table for shipment ' +
            ISNULL(@in_vchLoadId,'(NULL)') + ' failed while unbuilding the shipment.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50003 -- Update Failed
    END
    IF @v_nErrorNumber = @e_DelLDLineFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'Error while deleting t_afa_load_detail_line records for shipment ' + ISNULL(@in_vchLoadId,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General
    END
    IF @v_nErrorNumber = @e_DelLDDFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'Error while deleting t_afa_load_detail records for shipment ' + ISNULL(@in_vchLoadId,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General
    END
    IF @v_nErrorNumber = @e_DelStopsFailed
    BEGIN 
        -- Log Error    
        SET @v_vchLogMsg = 'Error while deleting t_stop records for shipment ' + ISNULL(@in_vchLoadId,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General
    END
    IF @v_nErrorNumber = @e_DelLoadMasterFailed
    BEGIN 
        -- Log Error    
        SET @v_vchLogMsg = 'Error while deleting t_load_master record for shipment ' + ISNULL(@in_vchLoadId,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General
    END

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

ExitLabel:
    RETURN

