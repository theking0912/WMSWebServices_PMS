
CREATE VIEW dbo.v_priority
AS
SELECT lookup_id as prioriy_id, locale_id, source, sequence, text AS priority, description, lookup_type
    FROM t_lookup
    WHERE lookup_type = 'PRIORITY'

