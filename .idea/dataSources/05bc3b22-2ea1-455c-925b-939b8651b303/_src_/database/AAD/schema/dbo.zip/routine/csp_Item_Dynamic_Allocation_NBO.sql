

CREATE PROCEDURE [dbo].[csp_Item_Dynamic_Allocation_NBO] @wh_id NVARCHAR(10)
	,@item_number NVARCHAR(30)
	,@lot_number NVARCHAR(30)
	,@leave_allocate_qty FLOAT
	,@sto_att BIGINT	
	,@alloc_lot_number nvarchar(30) OUTPUT
	,@expiration_date DATETIME OUTPUT
	,@location_id nvarchar(30) OUTPUT
	,@hu_id nvarchar(30) OUTPUT
	,@alloc_qty float OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from    
	SET NOCOUNT ON;	

	--先分配未被分配的库存，如果可分配库存数量不足，则分配物理库存
	if @leave_allocate_qty > 0
	BEGIN
		IF isnull(@location_id, '') = ''
			OR @alloc_qty = 0
		BEGIN
			EXEC csp_Pk_PCBBestQtyFIFO @wh_id
				,@item_number
				,NULL--lot_number
				,@leave_allocate_qty
				,NULL--packflag
				,@sto_att
				,'N'
				,@alloc_lot_number OUTPUT
				,@expiration_date OUTPUT
				,@location_id OUTPUT
				,@hu_id OUTPUT
				,@alloc_qty OUTPUT
										
			IF isnull(@location_id, '') = ''
				OR @alloc_qty = 0
			BEGIN
				EXEC csp_Pk_Physical_BestQtyFIFO @wh_id
					,@item_number
					,NULL--lot_number
					,@leave_allocate_qty
					,NULL--packflag
					,@sto_att
					,'N'
					,@alloc_lot_number OUTPUT
					,@expiration_date OUTPUT
					,@location_id OUTPUT
					,@hu_id OUTPUT
					,@alloc_qty OUTPUT
										
			END
		END
	END

	RETURN	
END

