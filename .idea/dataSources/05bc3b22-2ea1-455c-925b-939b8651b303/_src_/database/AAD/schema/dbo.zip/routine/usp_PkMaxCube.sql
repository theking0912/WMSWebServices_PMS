
CREATE PROCEDURE usp_PkMaxCube
	@in_vchPickPutID	NVARCHAR(15)

AS
-- *******************************************************************************
-- Stored Procedure: usp_PkMaxCube
-- *******************************************************************************
-- Database Name: AAD
-- Database User Name: dbo
-- *******************************************************************************
--
--  The purpose of this stored procedure is to Maximize Available Cube
--
--
--  Notes:
--  In short, when each sproc called, a list of rules are built in a temporary RuleSet table
--  for each item, baised on the itm.pick_put_id field.  Each rule, executes another
--  sproc which finds a location (and sometimes additional information) and returns to the parent
--  sproc which updates the appropriate field.
--
--  If the location is to be returned to the application, the t_employee.sp_return field is
--  updated, thus allowing the application to select this result immediately following.
--  
--  Output:
--	
--  Target:
--	    SQL Server
--
-- ********************************************************************************
--                          Copyright ⌐ 2003-2013.
--                           All Rights Reserved.
--                            HighJump Software
--                         Minneapolis, Minnesota, USA
-- ********************************************************************************
DECLARE 
	@c_vchLocTypes	NVARCHAR(30),
	@c_nStorageType	INT

	--Create temp table to hold location metrics
	CREATE TABLE #tmp_loc_metrics (
		pick_id         		INTEGER               NOT NULL,
		location_id     		NVARCHAR(50)          COLLATE DATABASE_DEFAULT NOT NULL,
		picking_flow    		NVARCHAR(3)           COLLATE DATABASE_DEFAULT NULL,
		space_freed      		FLOAT				  NULL,
		space_consumed       	FLOAT                 NULL,
        work_type       		NVARCHAR(15)      	  COLLATE DATABASE_DEFAULT NULL,
		fifo_date               DATETIME              NULL,
        user_count              INTEGER               NULL,
		stored_attribute_id  	BIGINT     			  NULL
    )
	           
-- Set Constants
SET @c_nStorageType = 0

SET NOCOUNT ON

-- Check the type of PKD. Either it's a 'PP'(Planned Pick), then include X and P type locations,
-- otherwise assume, for now, it's an 'RP' (Replenishments), where X and P shouldn't be considered
-- locations to pick from. (X = Crossdock and P = Forward Pick)
IF (SELECT TOP 1 type
    FROM #tmp_pick_details_to_update) = 'PP'
    SET @c_vchLocTypes = 'XPASMI'
ELSE SET @c_vchLocTypes = 'ASMI'

/* Load all qualifying locations into the temporary table in optimal order */
INSERT INTO #tmp_loc_metrics( pick_id, location_id, picking_flow, space_freed, space_consumed, 
								work_type, user_count, fifo_date, stored_attribute_id )
SELECT dtu.pick_id, loc.location_id, loc.picking_flow, 
	   (itu.nested_volume * dtu.pick_quantity - 1) + itu.unit_volume AS space_freed,
       SUM((itu.nested_volume * sto.actual_qty - 1) + itu.unit_volume) AS space_consumed,
       loc.type, loc.user_count, sto.fifo_date, dtu.stored_attribute_id
  FROM #tmp_pick_details_to_update dtu
  INNER JOIN t_stored_item sto WITH (NOLOCK)
     ON sto.wh_id = dtu.wh_id
    AND sto.item_number = dtu.item_number
  INNER JOIN t_item_uom itu WITH (NOLOCK)
     ON itu.wh_id = dtu.wh_id
    AND itu.uom = dtu.uom
    AND itu.item_number = dtu.item_number
  INNER JOIN t_location loc WITH (NOLOCK)
     ON loc.wh_id = sto.wh_id
    AND loc.location_id = sto.location_id
  WHERE dtu.pick_put_id = @in_vchPickPutID
    AND (dtu.lot_number IS NULL OR dtu.lot_number = sto.lot_number)
    AND CHARINDEX(loc.type,@c_vchLocTypes) > 0
    AND loc.status <> 'I'
    AND (sto.actual_qty - sto.unavailable_qty) > 0
    AND sto.type = @c_nStorageType
    AND sto.status = 'A'
    AND (sto.stored_attribute_id = dtu.stored_attribute_id
         OR dtu.stored_attribute_id IS NULL
         OR EXISTS (SELECT fnc.stored_attribute_id
                          FROM usf_get_pick_attribute_id(dtu.item_number, dtu.stored_attribute_id) fnc
                          WHERE fnc.stored_attribute_id = sto.stored_attribute_id)
        )
    AND dtu.location_id IS NULL
  GROUP BY pick_id, dtu.wh_id, dtu.item_number, loc.picking_flow, dtu.pick_quantity, dtu.stored_attribute_id,
		   loc.location_id, itu.nested_volume, itu.unit_volume, loc.type, loc.user_count, sto.fifo_date
  ORDER BY loc.location_id

INSERT INTO #tmp_locations_found ( pick_id, location_id, picking_flow, stored_attribute_id )
  SELECT lm.pick_id, ISNULL(lm.location_id, ''), lm.picking_flow, lm.stored_attribute_id
    FROM #tmp_loc_metrics lm
  ORDER BY (lm.space_consumed - lm.space_freed) ASC,
           CHARINDEX( lm.work_type, @c_vchLocTypes ), lm.user_count, lm.fifo_date,
           RIGHT( '000' + RTRIM(ISNULL(lm.picking_flow,'0')), 3 )


/* Skim off the optimal locations (the ones with the lowest seq) */
SELECT pick_id, MIN(seq) as seq
  INTO #tmp_best_locations
  FROM #tmp_locations_found
  GROUP BY pick_id
  
/* Update the the temp table with the results */
UPDATE #tmp_pick_details_to_update
  SET location_id = locf.location_id,
      picking_flow = locf.picking_flow,
      pick_location = locf.location_id,
      pick_area = loc.pick_area, 
      work_type = pka.work_type,
      stored_attribute_id = locf.stored_attribute_id
  FROM #tmp_pick_details_to_update dtu
  INNER JOIN #tmp_locations_found locf
     ON locf.pick_id = dtu.pick_id
  INNER JOIN #tmp_best_locations bloc
     ON bloc.pick_id = locf.pick_id
    AND bloc.seq = locf.seq
  INNER JOIN t_location loc
   ON loc.location_id = locf.location_id
  INNER JOIN t_pick_area pka
   ON pka.wh_id = loc.wh_id
  AND pka.pick_area = loc.pick_area
WHERE dtu.pick_put_id = @in_vchPickPutID

--Exit
RETURN
