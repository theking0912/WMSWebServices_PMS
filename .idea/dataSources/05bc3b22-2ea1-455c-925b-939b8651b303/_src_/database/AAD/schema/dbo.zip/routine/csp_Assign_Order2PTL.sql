CREATE PROCEDURE [dbo].[csp_Assign_Order2PTL]    
     @wh_id				NVARCHAR(10)   
    ,@wave_id		    NVARCHAR(30) 
	,@assigned_count	int output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

		
		DECLARE @status				NVARCHAR(20)
		DECLARE @wave_type			NVARCHAR(20)
		DECLARE @order_number		NVARCHAR(30)
		DECLARE @wall_id			NVARCHAR(30)
		DECLARE @slot				NVARCHAR(30)
		DECLARE @client_code		NVARCHAR(30)
		DECLARE @pick_wall_loc		NVARCHAR(30)
		DECLARE @pick_conveyor_node	NVARCHAR(30)
		DECLARE @shipping_label		NVARCHAR(30)
		DECLARE @detail_id			INT
		DECLARE @carrier_code		NVARCHAR(30)
		DECLARE @event_data			NVARCHAR(2000)
		DECLARE @msg     			NVARCHAR(2000)
		DECLARE @result             INT
		DECLARE @vip                NVARCHAR(30)
		DECLARE @process_lot_no     NVARCHAR(30)
		DECLARE @route              NVARCHAR(30)
		DECLARE @schedule_code		NVARCHAR(30)
		DECLARE @ass_cnt			int
		DECLARE @zone				NVARCHAR(30)
		DECLARE @seq_id				INT		=	0
		DECLARE @customer_code		NVARCHAR(30)  =''
		DECLARE @customer_name		NVARCHAR(30)
		DECLARE @orderby_id			INT
		DECLARE @temp_seq_id				SMALLINT	= 0

		
	BEGIN TRY
		BEGIN TRANSACTION

		set @detail_id = 0
		set @ass_cnt = 0
		set @assigned_count = 0
		set @orderby_id = 0

		-- Temp table used to hold a list of pick put rules for a given Pick Put ID
		CREATE TABLE #tmp_rule_set (
		   sequence        BIGINT ,   -- The sequencial order in which to execute the rule		   
		   customer_seq		BIGINT,
		   order_number		NVARCHAR(30) COLLATE DATABASE_DEFAULT ,
		   client_code		NVARCHAR(30) COLLATE DATABASE_DEFAULT ,
		   wave_detail_id	BIGINT,
		   carrier_code		NVARCHAR(30) COLLATE DATABASE_DEFAULT ,
		   route			NVARCHAR(30) COLLATE DATABASE_DEFAULT ,
		   customer_code	NVARCHAR(30) COLLATE DATABASE_DEFAULT ,
		   customer_name	NVARCHAR(30) COLLATE DATABASE_DEFAULT 
		)

		INSERT INTO #tmp_rule_set
		select  
			ROW_NUMBER() OVER (ORDER BY ISNULL(pick_seq,999999) ,c.customer_code,  wave_detail_id),
			ISNULL(c.pick_seq,999999),
			 o.order_number ,
			   o.client_code ,
			     wave_detail_id ,
				   o.carrier_scac ,
				    o.route ,
					 c.customer_code ,
					  c.customer_name
			from  t_afo_wave_detail wd, t_order o,dbo.t_customer c
			where wd.wh_id = o.wh_id 
			and wd.order_number = o.order_number 
			and wd.wh_id = @wh_id 
			and wd.wave_id = @wave_id
			AND o.customer_id = c.customer_id
			AND o.wh_id = c.wh_id
			AND ISNULL(c.customer_type,'') <> 'SHWX-ND'
			AND exists (select 1 from tbl_allocation alloc
					where o.wh_id = alloc.wh_id
					and o.order_number = alloc.order_number
					and ABS(alloc.allocated_qty) - alloc.picked_qty > 0)
			ORDER BY ISNULL(pick_seq,999999) ,
					 c.customer_code,  wave_detail_id
		

		while (1=1)
		begin
			
			--select top 1 
			--@orderby_id = (CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
			--										 ELSE 2
			--								   END ),
			--@order_number = o.order_number , @client_code = o.client_code, @detail_id = wave_detail_id, @carrier_code = o.carrier_scac,@route = o.route
			--,@customer_code = c.customer_code, @customer_name = c.customer_name
			--from  t_afo_wave_detail wd, t_order o,dbo.t_customer c
			--where wd.wh_id = o.wh_id 
			--and wd.order_number = o.order_number 
			--and wd.wh_id = @wh_id 
			--and wd.wave_id = @wave_id
			--AND o.customer_id = c.customer_id
			--AND o.wh_id = c.wh_id
			----and wd.wave_detail_id > @detail_id
			--and exists (select 1 from tbl_allocation alloc
			--		where o.wh_id = alloc.wh_id
			--		and o.order_number = alloc.order_number
			--		and ABS(alloc.allocated_qty) - alloc.picked_qty > 0)
			--		AND (
			--			 ((CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
			--										 ELSE 2
			--								   END ) = @orderby_id AND customer_code  = @customer_code AND wave_detail_id > @detail_id)
			--			OR
			--			 ((CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
			--										 ELSE 2
			--								   END ) = @orderby_id AND customer_code  > @customer_code)
			--			OR
			--			(CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
			--										 ELSE 2
			--								   END ) > @orderby_id)
			--order by ( CASE WHEN LEFT(c.customer_code, 2) = 'SH' THEN 1
			--				 ELSE 2
			--		   END ) ,
			--		 c.customer_code,  wave_detail_id


			--select top 1 
			--@orderby_id = ISNULL(c.pick_seq,999999),
			--@order_number = o.order_number , @client_code = o.client_code, @detail_id = wave_detail_id, @carrier_code = o.carrier_scac,@route = o.route
			--,@customer_code = c.customer_code, @customer_name = c.customer_name
			--from  t_afo_wave_detail wd, t_order o,dbo.t_customer c
			--where wd.wh_id = o.wh_id 
			--and wd.order_number = o.order_number 
			--and wd.wh_id = @wh_id 
			--and wd.wave_id = @wave_id
			--AND o.customer_id = c.customer_id
			--AND o.wh_id = c.wh_id
			--AND ISNULL(c.customer_type,'') <> 'SHWX-ND'
			----and wd.wave_detail_id > @detail_id
			--and exists (select 1 from tbl_allocation alloc
			--		where o.wh_id = alloc.wh_id
			--		and o.order_number = alloc.order_number
			--		and ABS(alloc.allocated_qty) - alloc.picked_qty > 0)
			--AND ( 
			--			(ISNULL(pick_seq,999999) = @orderby_id AND customer_code = @customer_code AND wave_detail_id >@detail_id)
			--		 OR (ISNULL(pick_seq,999999) = @orderby_id AND customer_code > @customer_code)
			--		 OR (ISNULL(pick_seq,999999) > @orderby_id)
			--		 )
			--ORDER BY ISNULL(pick_seq,999999) ,
			--		 c.customer_code,  wave_detail_id


			select  TOP 1 
			@temp_seq_id = sequence,
			@order_number = order_number , @client_code = client_code, @detail_id = wave_detail_id, @carrier_code = carrier_code,@route = route
			,@customer_code = customer_code, @customer_name = customer_name
			from  #tmp_rule_set 
			where sequence > @temp_seq_id
			ORDER BY sequence

			if @@ROWCOUNT = 0
			break;

			SET @seq_id = 0
			

			WHILE (1=1)
			BEGIN
				SELECT TOP 1 @seq_id = MAX(seq_id),@zone = zone FROM tbl_allocation
						WHERE order_number = @order_number
							and wave_id = @wave_id
							and wh_id = @wh_id
							and ABS(allocated_qty) - picked_qty > 0
							AND pick_wall_loc IS null
							AND allo_type = 'S'
							AND seq_id > @seq_id
						GROUP BY zone
						ORDER BY MAX(seq_id),zone ASC

				if @@ROWCOUNT = 0
				break;

				EXEC csp_Get_PTL_Slot @wh_id,@order_number,@zone,@customer_code,@wave_id,@wall_id output,@slot output

				if @wall_id is not null and @slot is not null
				begin
					select @pick_wall_loc = location_id,@pick_conveyor_node = node
					from tbl_pick_wall
					where wh_id = @wh_id
					and wall_id = @wall_id					

					update tbl_allocation
					set pick_wall_loc = @pick_wall_loc
					,	pick_wall_slot = @slot
					,	pick_conveyor_node = @pick_conveyor_node
					,	ref_number = @wall_id
					,   shipping_label = @shipping_label
					where order_number = @order_number
					and wh_id = @wh_id
					--and zone = @zone
					AND allo_type = 'S'
					AND zone IN (SELECT zone FROM tbl_pick_wall_zone WITH(NOLOCK)
										WHERE wh_id = @wh_id
											AND wall_id = @wall_id)
					
					update tbl_pick_wall_slot
					set ship_label_barcode = ''
					,	order_number = ''
					,customer_code = @customer_code
					,	status = 'A'
					,wave_id = @wave_id
					where wh_id = @wh_id
					AND wall_id = @wall_id
					AND slot = @slot
					
					set @ass_cnt = @ass_cnt + 1
											
	                --SEND WCS IF DATA ADD BY David
					select @vip = vip_flag
					from t_client tc
					where tc.wh_id = @wh_id
					and tc.client_code = @client_code

					update t_control
					set next_value = next_value + 1
					where control_type = 'IF_ORDER_WCS'

					--Get process_lot_no from t_control
					select @process_lot_no = next_value
					from t_control
					where control_type = 'IF_ORDER_WCS'

					--get schedule_code from t_wave_master
					SELECT @schedule_code = wave_schedule
					  FROM t_wave_master
					 WHERE wave_id = @wave_id
					   AND wh_id = @wh_id


					   --select * from tbl_inf_dps_wave_order
					   insert into tbl_inf_dps_wave_order
					(wave_id,order_number,customer_code,customer_name,item_number,item_name,pick_wall_slot,allocated_qty,uom,uom_prompt,create_date,inf_date)
					select @wave_id			as wave_id
						,  @order_number	as order_num
						,  @customer_code
						,  @customer_name
						,  allo.item_number		as item_number
						,  max(item.description) as item_name
						,  @slot			as pick_wall_slot
						--,  sum(ABS(allocated_qty) - picked_qty)	as qty
						,CASE  WHEN ISNULL(MAX(item.pack_flag),'N') = 'Y' AND ISNULL(MAX(allo.stored_attribute_id),'') <> ''
							THEN sum(ISNULL(ABS(allocated_qty),0) - ISNULL(picked_qty,0)) / ISNULL((SELECT tiu.conversion_factor 
									FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
										INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
										ON tscd.attribute_id = tacd.attribute_id
										INNER JOIN t_item_uom tiu WITH(NOLOCK)
										ON tiu.uom_prompt = tscd.attribute_value
										WHERE tacd.attribute_collection_id = MAX(item.attribute_collection_id)
											AND tscd.stored_attribute_id = MAX(allo.stored_attribute_id)
											AND tiu.item_number = MAX(item.item_number)
											AND tiu.wh_id = allo.wh_id),1)
							WHEN ISNULL(MAX(item.ed_flag),'N') = 'Y'
								THEN SUM(ISNULL(ABS(allocated_qty),0) - ISNULL(picked_qty,0)) / 
									ISNULL((SELECT TOP 1 tiu.conversion_factor FROM t_order_detail od
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON od.wh_id = tiu.wh_id
											AND od.item_number = tiu.item_number
											AND od.order_uom = tiu.uom
												WHERE od.wh_id = allo.wh_id
												AND od.order_number = allo.order_number
												AND od.item_number = allo.item_number ),1)
							ELSE
									sum(ISNULL(ABS(allocated_qty),0) - ISNULL(picked_qty,0))
							END 	as qty

						,CASE  WHEN ISNULL(MAX(item.pack_flag),'N') = 'Y' AND ISNULL(MAX(allo.stored_attribute_id),'') <> ''
								THEN (SELECT tiu.uom 
										FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
											INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
											ON tscd.attribute_id = tacd.attribute_id
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON tiu.uom_prompt = tscd.attribute_value
											WHERE tacd.attribute_collection_id = MAX(item.attribute_collection_id)
												AND tscd.stored_attribute_id = MAX(allo.stored_attribute_id)
												AND tiu.item_number = MAX(item.item_number)
												AND tiu.wh_id = allo.wh_id)
								WHEN ISNULL(MAX(item.ed_flag),'N') = 'Y'
								THEN 
									(SELECT TOP 1 tiu.uom FROM t_order_detail od
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON od.wh_id = tiu.wh_id
											AND od.item_number = tiu.item_number
											AND od.order_uom = tiu.uom
												WHERE od.wh_id = allo.wh_id
												AND od.order_number = allo.order_number
												AND od.item_number = allo.item_number )

								ELSE
									(SELECT TOP 1 tiu.uom 
											FROM t_item_uom tiu WITH(NOLOCK)
												WHERE wh_id = allo.wh_id
													AND item_number = allo.item_number
												ORDER BY conversion_factor ASC)
								END
						,CASE  WHEN ISNULL(MAX(item.pack_flag),'N') = 'Y' AND ISNULL(MAX(allo.stored_attribute_id),'') <> ''
								THEN (SELECT tiu.uom_prompt 
										FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
											INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
											ON tscd.attribute_id = tacd.attribute_id
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON tiu.uom_prompt = tscd.attribute_value
											WHERE tacd.attribute_collection_id = MAX(item.attribute_collection_id)
												AND tscd.stored_attribute_id = MAX(allo.stored_attribute_id)
												AND tiu.item_number = MAX(item.item_number)
												AND tiu.wh_id = allo.wh_id)
								WHEN ISNULL(MAX(item.ed_flag),'N') = 'Y'
								THEN 
									(SELECT TOP 1 tiu.uom_prompt FROM t_order_detail od
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON od.wh_id = tiu.wh_id
											AND od.item_number = tiu.item_number
											AND od.order_uom = tiu.uom
												WHERE od.wh_id = allo.wh_id
												AND od.order_number = allo.order_number
												AND od.item_number = allo.item_number)
								ELSE
									(SELECT TOP 1 tiu.uom_prompt 
											FROM t_item_uom tiu WITH(NOLOCK)
												WHERE wh_id = allo.wh_id
													AND item_number = allo.item_number
												ORDER BY conversion_factor ASC)
								END
						,  GETDATE()
						,NULL
					from tbl_allocation allo left join t_item_master item with(nolock) 
					on allo.wh_id = item.wh_id and allo.item_number = item.item_number
					where allo.wh_id = @wh_id
					and allo.order_number = @order_number
					and allo.allo_type = 'S'
					and allo.zone IN (SELECT zone FROM tbl_pick_wall_zone WITH(NOLOCK)
										WHERE wh_id = @wh_id
											AND wall_id = @wall_id)
					group by allo.item_number,allo.wh_id,allo.order_number


				end
			END
		end

		set @assigned_count = @ass_cnt

		commit	
        RETURN

    END TRY

    BEGIN CATCH
		set @msg = ERROR_MESSAGE()
		ROLLBACK
        RETURN
    END CATCH
  
END
