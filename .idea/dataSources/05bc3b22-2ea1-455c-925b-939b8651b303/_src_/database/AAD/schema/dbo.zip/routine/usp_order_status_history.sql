
CREATE PROCEDURE usp_order_status_history
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchOrderNumber    NVARCHAR(60),
@in_vchStatus         NVARCHAR(60)

AS

DECLARE 
    @v_vchCustomerID     NVARCHAR(60)
   
    SET NOCOUNT ON
   
    --Get the customer ID
    SELECT @v_vchCustomerID = customer_id FROM t_order 
	WHERE order_number = @in_vchOrderNumber AND wh_id = @in_vchWarehouseId

    --Do the insert
    INSERT INTO t_csa_order_status_history (wh_id, customer_id, order_number, status) 
        VALUES (@in_vchWarehouseId,ISNULL(@v_vchCustomerID, 'NONE'),'@in_vchOrderNumber','@v_vchStatus') 

ExitLabel:
    RETURN
