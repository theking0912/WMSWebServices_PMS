



 
CREATE PROCEDURE [dbo].[csp_imp_test_pm]
 

 AS
begin


	create table #returnresult
	(
	outint1 int,
	outstr1 nvarchar(64),
	outstr2 nvarchar(256)
	)
 

	declare  @data_id varchar(64),@source_row int=0
	set @data_id=newid()

	declare @zposition varchar(100),@wh_id nvarchar(10)

   select @zposition='SH',@wh_id='HDLSH'
	update tbl_inf_imp_pmorder 
    set PROCESS_STATUS='NO',SUCCESS_STATUS='NO',PROCESS_MSG='',DATA_ID=@data_id
    select  @source_row=count(*) from  tbl_inf_imp_pmorder

	insert into tbl_inf_imp_master(data_id,begin_date,source_rows,interface_type,zposition,wh_id)
	select @data_id,getdate(),@source_row,'SAPWMSInterface_PMORDER',@zposition,@wh_id

	 exec  csp_imp_load_pmorder  @data_id,'NO'
	 if (@@ERROR)<0 print 'Exception'+@@ERROR
  
	 drop table  #returnresult
end
  





