

CREATE FUNCTION [dbo].[fn_Get128Code_NBO]
(
	-- Add the parameters for the function here
	@in_barcode nvarchar(100)
)
RETURNS nvarchar(100)
AS
BEGIN

	Declare @DataToEncode nvarchar(100)
--'Change the next line to connect to your data source; for example:
	set @DataToEncode = @in_barcode
--'DataToEncode = "Ê8100712345Ê2112345678"

    Declare @PrintableString nvarchar(100)
    Declare @DataToFormat nvarchar(100)
    Declare @WeightedTotal int
    Declare @CurrentValue int
    Declare @CheckDigitValue int
    Declare @C128CheckDigit nvarchar(100)
    Declare @StringLength int
    Declare @I int
    Declare @CurrentCharNum int
    Declare @CurrentEncoding nvarchar(100)
    Declare @C128Start nvarchar(100)
    Declare @CorrectFNC int
    Declare @CurrentChar nvarchar(100)
    set @CorrectFNC = 0
    set @PrintableString = ''
    set @DataToFormat = @DataToEncode
    set @DataToEncode = ''
    --'Here we select character set A, B or C for the START character
    set @StringLength = Len(@DataToFormat)
    set @CurrentCharNum = ASCII(SUBSTRING(@DataToFormat, 1, 1))
    If @CurrentCharNum < 32 
    BEGIN
		SET @C128Start = NChar(203)
	END
    If @CurrentCharNum > 31 And @CurrentCharNum < 127
    BEGIN
		SET @C128Start = NChar(204)
	END
    If ((@StringLength > 4) And IsNumeric(SUBSTRING(@DataToFormat, 1, 4)) = 1)
    BEGIN
		SET @C128Start = NChar(205)
	END
    --'202 & 212-215 is for the FNC1, with this Start C is mandatory
    If @CurrentCharNum = 202 
	BEGIN
		set @C128Start = NChar(205)
	END
    If @CurrentCharNum = 212
    BEGIN
		SET @C128Start = NChar(205)
	END
    If @CurrentCharNum = 213
    BEGIN
		SET @C128Start = NChar(205)
	END
    If @CurrentCharNum = 214
    BEGIN
		SET @C128Start = NChar(205)
	END
    If @CurrentCharNum = 215 
    BEGIN
		SET @C128Start = NChar(205)
	END
    If @C128Start = NChar(203) 
    BEGIN
		SET @CurrentEncoding = 'A'
	END
    If @C128Start = NChar(204) 
    BEGIN 
		SET @CurrentEncoding = 'B'
	END
    If @C128Start = NChar(205) 
    BEGIN
		SET @CurrentEncoding = 'C'
	END
	SET @I = 1
	WHILE(@I<=@StringLength)
	BEGIN
        --'check for FNC1 in any set which is ASCII 202 and ASCII 212-215
        set @CurrentCharNum = Ascii(substring(@DataToFormat, @I, 1))
        If ((@CurrentCharNum = 202) Or (@CurrentCharNum = 212) Or (@CurrentCharNum = 213) Or (@CurrentCharNum = 214) Or (@CurrentCharNum = 215))
        begin
            set @DataToEncode = @DataToEncode + NChar(202)
        end
        --'check for switching to character set C
        Else If ((@I < @StringLength - 2) And (IsNumeric(substring(@DataToFormat, @I, 1))=1) And (IsNumeric(substring(@DataToFormat, @I + 1, 1))=1) And (IsNumeric(substring(@DataToFormat, @I, 4))=1)) Or ((@I < @StringLength) And (IsNumeric(substring(@DataToFormat, @I, 1))=1) And (IsNumeric(substring(@DataToFormat, @I + 1, 1))=1) And (@CurrentEncoding = 'C'))
        BEGIN
        --'switch to set C if not already in it
            If @CurrentEncoding <> 'C' 
            Begin 
				set @DataToEncode = @DataToEncode + NChar(199)
			END
            SET @CurrentEncoding = 'C'
            SET @CurrentChar = substring(@DataToFormat, @I, 2)
            if ISNUMERIC(@CurrentChar)=1
            begin
				set @CurrentValue = CAST(@CurrentChar as int)
            end
            else
            begin
				set @CurrentValue = 0
            end
            --set @CurrentValue = Val(CurrentChar)
        --'set the CurrentValue to the number of String CurrentChar
            If (@CurrentValue < 95 And @CurrentValue > 0) 
            begin
				set @DataToEncode = @DataToEncode + NChar(@CurrentValue + 32)
			end
            If @CurrentValue > 94 
            begin 
				set @DataToEncode = @DataToEncode + NChar(@CurrentValue + 100)
			end
            If @CurrentValue = 0 
            begin 
				set @DataToEncode = @DataToEncode + NChar(194)
			end
            set @I = @I + 1
        end
        --'check for switching to character set A
        Else If (@I <= @StringLength) And ((Ascii(substring(@DataToFormat, @I, 1)) < 31) Or ((@CurrentEncoding = 'A') And (Ascii(substring(@DataToFormat, @I, 1)) > 32 And (Ascii(substring(@DataToFormat, @I, 1))) < 96))) 
        begin
        --'switch to set A if not already in it
            If @CurrentEncoding <> 'A' 
            begin
				set @DataToEncode = @DataToEncode + NChar(201)
			end
			set @CurrentEncoding = 'A'
        --'Get the ASCII value of the next character
            set @CurrentCharNum = Ascii(substring(@DataToFormat, @I, 1))
            If @CurrentCharNum = 32
            begin
                set @DataToEncode = @DataToEncode + NChar(194)
            end
            Else If @CurrentCharNum < 32
            begin
                set @DataToEncode = @DataToEncode + NChar(@CurrentCharNum + 96)
            end
            Else If @CurrentCharNum > 32
            begin
                set @DataToEncode = @DataToEncode + NChar(@CurrentCharNum)
            end
        END
        --'check for switching to character set B
        Else If (@I <= @StringLength) And (((Ascii(substring(@DataToFormat, @I, 1))) > 31) And ((Ascii(substring(@DataToFormat, @I, 1)))) < 127)
        begin
        --'switch to set B if not already in it
            If @CurrentEncoding <> 'B' 
            Begin 
				set @DataToEncode = @DataToEncode + NChar(200)
				
			end
			set @CurrentEncoding = 'B'
        --'Get the ASCII value of the next character
            set @CurrentCharNum = Ascii(substring(@DataToFormat, @I, 1))
            If @CurrentCharNum = 32
            begin
                set @DataToEncode = @DataToEncode + NChar(194)
            end
            Else
            begin
                set @DataToEncode = @DataToEncode + NChar(@CurrentCharNum)
            End
        End
		set @I = @I + 1
    END
    
     --'<<<< Calculate Modulo 103 Check Digit >>>>
    set @WeightedTotal = Ascii(@C128Start) - 100
    set @StringLength = Len(@DataToEncode)
    set @I = 1
    while(@I <= @StringLength)
    begin
        set @CurrentCharNum = Ascii(substring(@DataToEncode, @I, 1))
        If @CurrentCharNum < 135 
        Begin 
			set @CurrentValue = @CurrentCharNum - 32
		end
        If @CurrentCharNum > 134 
        begin
			set @CurrentValue = @CurrentCharNum - 100
		end
        If @CurrentCharNum = 194 
        begin 
			set @CurrentValue = 0
		end
        set @CurrentValue = @CurrentValue * @I
        set @WeightedTotal = @WeightedTotal + @CurrentValue
        If @CurrentCharNum = 32 
        begin
			set @CurrentCharNum = 194
		end
        set @PrintableString = @PrintableString + NChar(@CurrentCharNum)
		set @I = @I + 1
    end
    SET @CheckDigitValue = (@WeightedTotal % 103)
    If @CheckDigitValue < 95 And @CheckDigitValue > 0 
    BEGIN
		SET @C128CheckDigit = NChar(@CheckDigitValue + 32)
	end
    If @CheckDigitValue > 94 
    begin
		set @C128CheckDigit = NChar(@CheckDigitValue + 100)
	end
    If @CheckDigitValue = 0 
    begin
		set @C128CheckDigit = NChar(194)
	end
    set @DataToEncode = ''
    return @C128Start + @PrintableString + @C128CheckDigit + NChar(206) + ' '

END


