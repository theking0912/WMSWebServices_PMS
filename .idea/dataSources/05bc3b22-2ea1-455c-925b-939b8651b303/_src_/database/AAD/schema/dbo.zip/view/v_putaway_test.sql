


CREATE VIEW [dbo].[v_putaway_test]
AS

select tl.type,vt.description,tli.item_number,tsi.lot_number,tli.location_id,thm.hu_id,tli.max_qty,tsi.actual_qty
from tbl_loc_item tli 
inner join t_location tl on tli.location_id=tl.location_id
inner join t_stored_item tsi on tsi.location_id=tl.location_id
inner join v_type vt on vt.type=tl.type 
inner join t_hu_master thm on thm.hu_id=tsi.hu_id
where vt.source='t_location' and locale_id='2052'


