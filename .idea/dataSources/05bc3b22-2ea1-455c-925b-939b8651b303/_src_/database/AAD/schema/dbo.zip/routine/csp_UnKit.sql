


-- =======================================    
-- Author: Laver  
-- Create Date: 20150125  
-- Description: 
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_UnKit]    
     @wh_id						NVARCHAR(10)  
    ,@location					NVARCHAR(30)  
	,@hu_id						NVARCHAR(30)		
	,@user_id					NVARCHAR(30)
	,@tran_type					NVARCHAR(20)
	,@tran_description			NVARCHAR(50)
	,@passornot					NVARCHAR(1)		OUTPUT
	,@msg						NVARCHAR(200)	OUTPUT
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
		DECLARE	@item_number			Nvarchar(30)
		DECLARE	@lot_number				Nvarchar(30)	=''
		DECLARE	@stored_attribute_id	Nvarchar(30)
		DECLARE	@qty					float	

		DECLARE @rec_count				as	int =0


		
		SELECT @rec_count = count(1) 
		FROM t_stored_item 
		WHERE hu_id = @hu_id
			AND wh_id = @wh_id
			AND stored_attribute_id IS NOT NULL
			GROUP BY stored_attribute_id

		IF @@ROWCOUNT = 0
		BEGIN
			SET @passornot = 1
			SET @msg = '不存在可取消的规格'
			RETURN
		END

		IF @rec_count > 1
		BEGIN
			SET @passornot = 2
			SET @msg = '存在多种规格'
			RETURN
		END	

		IF EXISTS (SELECT 1
				   FROM t_stored_item
				   WHERE wh_id = @wh_id
						AND hu_id = @hu_id
						AND (EXISTS(SELECT 1 FROM tbl_allocation 
											WHERE location_id = t_stored_item.location_id
												AND wh_id = t_stored_item.wh_id
												AND item_number = t_stored_item.item_number
												AND ISNULL(stored_attribute_id,'') = ISNULL(t_stored_item.stored_attribute_id,'')
												AND ISNULL(lot_number,'') = ISNULL(t_stored_item.lot_number,'')
												AND ISNULL(hu_id,'') = ISNULL(t_stored_item.hu_id,'')
												AND status NOT IN ('E','C'))
							 OR type <> 0)
					)
		BEGIN
			SET @passornot = 3
			SET @msg = '库存已经被预约'
			RETURN
		END

		BEGIN TRANSACTION

		WHILE(1=1)
		BEGIN
			SELECT TOP 1 @item_number = item_number,
				   @lot_number = lot_number,
				   @stored_attribute_id = stored_attribute_id,
				   @qty = actual_qty
				   FROM t_stored_item
				   WHERE wh_id = @wh_id
						AND hu_id = @hu_id
						AND ISNULL(lot_number,'#') > ISNULL(@lot_number,'#')
					ORDER BY lot_number ASC
			
			IF @@ROWCOUNT = 0
			BEGIN
				BREAK;
			END 

			UPDATE t_stored_item
			SET stored_attribute_id = NULL
			WHERE hu_id = @hu_id
				AND wh_id = @wh_id
				AND stored_attribute_id = @stored_attribute_id
			--	AND lot_number = @lot_number
				AND item_number = @item_number
			
			--Create tran log
				--Insert t_tran_log_holding
				INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
					,wh_id_2,location_id_2,hu_id_2
					,generic_attribute_1,
					generic_attribute_2,
					generic_attribute_3,
					generic_attribute_4,
					generic_attribute_5,
					generic_attribute_6,
					generic_attribute_7,
					generic_attribute_8,
					generic_attribute_9,
					generic_attribute_10,
					generic_attribute_11)
				VALUES
					('276',N'恢复成原料',getdate(),getdate(),getdate(),getdate(),@user_id,NULL,@stored_attribute_id
					,@wh_id,@location,@hu_id,@item_number,@lot_number,@qty
					,@wh_id,@location,@hu_id
					,(SELECT TOP 1 a.attribute_value
    				FROM t_sto_attrib_collection_detail a
						INNER JOIN t_attribute_collection_detail b
						ON a.attribute_id = b.attribute_id
						INNER JOIN t_item_master c
						ON c.attribute_collection_id = b.attribute_collection_id
    				WHERE c.item_number = @item_number
						AND c.wh_id = @wh_id
					AND  a.stored_attribute_id = @stored_attribute_id),					 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_2), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_3), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_4), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_5), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_6), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_7), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_8), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_9), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_10), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_11)
					)
		END
		
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    



