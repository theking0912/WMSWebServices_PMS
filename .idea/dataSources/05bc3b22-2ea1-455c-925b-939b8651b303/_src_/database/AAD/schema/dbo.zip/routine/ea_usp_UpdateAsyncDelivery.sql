
CREATE PROCEDURE dbo.ea_usp_UpdateAsyncDelivery
    @in_vchEventId  varchar(40),
    @in_bSuccessful integer
AS
DECLARE
    @v_nEventId BIGINT

    --  The following is necessary when using ADO Recordsets
    SET NOCOUNT ON

    SET @v_nEventId = CONVERT(BIGINT, @in_vchEventId)

    --  Update the given event
    IF @in_bSuccessful = 0
        BEGIN
        --  ROLLBACK
            UPDATE ea_t_async_work_queue
               SET status = 'RETRY',
                   date_started = NULL,
                   priority = 100,
                   retry_count = retry_count + 1
             WHERE event_id = @v_nEventId
        END
    ELSE
        BEGIN
        --  COMMIT
            UPDATE ea_t_async_work_queue
               SET status = 'SUCCESS',
                   date_finished = GETDATE()
             WHERE event_id = @v_nEventId
        END

-- Error handling
    --  Be sure one row was updated
    IF @@ROWCOUNT <> 1
    BEGIN
        RAISERROR( 'The Update failed while closing out Async Delivery with ID [%s].',
                    16, 1, @in_vchEventId )
        GOTO ExitLabel
    END

    IF @@ERROR <> 0
    BEGIN
        RAISERROR( 'A SQL Server error occurred while closing out Async Delivery with ID [%s].',
                    16, 1, @in_vchEventId )
        GOTO ExitLabel
    END
ExitLabel:
    RETURN
