
-- =============================================
-- Author:		Lij
-- Create date: 2016-1-20 15:52:13
-- Description:	创建补货任务
-- =============================================
CREATE PROCEDURE [dbo].[csp_Replenishment_Task_Gener]
	-- Add the parameters for the stored procedure here
	@item_number NVARCHAR(50),
	@zone_type NVARCHAR(50),
	@replenishment_qty DECIMAL(30, 8)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRANSACTION;
	--如果临时表不为空则删除
	IF OBJECT_ID('#tmp_gener') IS NOT NULL
	DROP TABLE #tmp_gener;
	IF OBJECT_ID('#tmpin_replenishment') IS NOT NULL
	DROP TABLE #tmpin_replenishment;

	DECLARE @i INT --循环变量
	SET @i = 1;
	DECLARE @row_count INT --总行数
	DECLARE @from_location_id NVARCHAR(50) --从哪个货位拣货
	DECLARE @bh_location_id NVARCHAR(50)  --补货货位
	DECLARE @lot_number NVARCHAR(50) --批次号
	DECLARE @pick_qty DECIMAL(30, 8) --拣货数量
	DECLARE @jh_zone_type NVARCHAR(50)  --捡货区域类型
	DECLARE @stored_attribute_id BIGINT --规格
	DECLARE @zone NVARCHAR(50)  --区域
	DECLARE @wh_id NVARCHAR(50)  --仓库
	DECLARE @sum_qty DECIMAL(30, 8) = 0 --累加拣货数量之和
	DECLARE @jh_qty DECIMAL(30, 8) --拣货数量
	DECLARE @bh_qty DECIMAL(30, 8) --补货数量
	DECLARE @bh1_qty DECIMAL(30, 8) --补货数量
	DECLARE @work_id NVARCHAR(500) --补货Id
	DECLARE @del_work_id NVARCHAR(MAX) = N'' --待删除补货任务Id

	IF @zone_type = 'C'
	BEGIN
	    SET @jh_zone_type = 'P';
	END
	ELSE IF @zone_type = 'B'
    BEGIN
        SET @jh_zone_type = 'C';
    END
	ELSE IF @zone_type = 'B-1'
	BEGIN
	    SET @jh_zone_type = 'P';
	END

	BEGIN TRY
		--创建补货临时表
		CREATE TABLE #tmpin_replenishment (Id INT IDENTITY(1, 1), location_id NVARCHAR(50), lot_number NVARCHAR(50), bh_qty FLOAT, zone NVARCHAR(50), wh_id NVARCHAR(50));
		INSERT INTO #tmpin_replenishment 
		SELECT tlo.location_id,ts.lot_number,@replenishment_qty,tzl.zone, tzl.wh_id
		FROM dbo.t_location tlo 
		INNER JOIN dbo.t_zone_loca tzl ON tlo.wh_id = tzl.wh_id AND tlo.location_id = tzl.location_id 
		INNER JOIN tbl_loc_item AS tli ON tli.wh_id = tzl.wh_id AND tli.location_id = tzl.location_id
		LEFT OUTER JOIN dbo.t_stored_item AS ts ON ts.wh_id = tli.wh_id AND ts.location_id = tli.location_id AND ts.item_number = tli.item_number
		WHERE tlo.type = SUBSTRING(@zone_type,1,1) AND ISNULL(ts.actual_qty, 0) >= 0 
		AND tli.item_number = @item_number AND NOT EXISTS (SELECT 1 FROM dbo.t_work_q WHERE work_status IN ('U', 'A') AND work_type = '05' AND location_id = tli.location_id)  ORDER BY ts.lot_number ASC,tzl.pick_seq ASC;
		
		
		--获取行数
		SELECT @row_count = COUNT(*) FROM #tmpin_replenishment;
		--生成补货任务循环开始
		WHILE @i <= @row_count
		BEGIN
			--IF EXISTS(select 1 from t_work_q where work_status in ('U','A') and item_number = @item_number and work_type in ('05','06'))
			--BEGIN
			--	SET @i = @i + 1;
			--    CONTINUE;
			--END
		    --获取货位，批次，补货数量，区域类型，仓库
			SELECT @bh_location_id = location_id,@lot_number = lot_number,@bh_qty = bh_qty,@zone = zone,
			@wh_id =wh_id FROM #tmpin_replenishment WHERE Id = @i;
			--判断补货数量是否小于总的补货数量
			IF @sum_qty < @replenishment_qty
			BEGIN
				--获取补货Id
				SELECT @work_id = CAST((ISNULL(MAX(work_q_id), 0) + 1) AS NVARCHAR(500)) FROM dbo.t_work_q;
				SET @del_work_id = @del_work_id + @work_id + N',';
				--如果总补货数量减累加补货数量减补货数量大于0
				--则累加补货数量加上补货数量
				--否则再判断总补货数量减累加补货数量减补货数量等于0
				--则累加补货数量加上补货数量
				--否则总补货数量减累加补货数量+累加补货数量
			    IF (@replenishment_qty - @sum_qty - @bh_qty) > 0
				BEGIN
				    SET @sum_qty = @sum_qty + @bh_qty;
					SET @bh1_qty = @bh_qty;
				END
				ELSE
				BEGIN
				    IF (@replenishment_qty - @sum_qty - @bh_qty) = 0
					BEGIN
					    SET @sum_qty = @sum_qty + @bh_qty;
						SET @bh1_qty = @bh_qty;
					END
					ELSE
                    BEGIN
						SET @bh1_qty = @replenishment_qty - @sum_qty;
                        SET @sum_qty = @replenishment_qty - @sum_qty + @sum_qty;
                    END
				END

				--新增补货任务
				INSERT INTO dbo.t_work_q
				        ( work_q_id ,
				          work_type ,
				          date_due ,
				          time_due ,
				          item_number ,
				          wh_id ,
				          location_id ,
				          work_status ,
				          qty ,
				          workers_required ,
				          workers_assigned ,
				          zone ,
				          datetime_stamp ,
				          lot_number,
						  description
				        )
				--VALUES  ( @work_id , -- work_q_id - nvarchar(30)
				--          N'05' , -- work_type - nvarchar(2)
				--          GETDATE() , -- date_due - datetime
				--          GETDATE() , -- time_due - datetime
				--          @item_number , -- item_number - nvarchar(30)
				--          @wh_id , -- wh_id - nvarchar(10)
				--          @bh_location_id , -- location_id - nvarchar(50)
				--          N'U' , -- work_status - nvarchar(2)
				--          @bh1_qty , -- qty - float
				--          0 , -- workers_required - int
				--          0 , -- workers_assigned - int
				--          @zone , -- zone - nvarchar(10)
				--          GETDATE() , -- datetime_stamp - datetime
				--          @lot_number,  -- lot_number - nvarchar(30)
				--		  N'例常补货'
				--        );


				-------------------will add
				VALUES  ( @work_id , -- work_q_id - nvarchar(30)
				          N'05' , -- work_type - nvarchar(2)
				          GETDATE() , -- date_due - datetime
				          GETDATE() , -- time_due - datetime
				          @item_number , -- item_number - nvarchar(30)
				          @wh_id , -- wh_id - nvarchar(10)
				          @bh_location_id , -- location_id - nvarchar(50)
				          N'U' , -- work_status - nvarchar(2)
				          @bh1_qty , -- qty - float
				          0 , -- workers_required - int
				          0 , -- workers_assigned - int
				          @zone , -- zone - nvarchar(10)
				          GETDATE() , -- datetime_stamp - datetime
				          NULL,  -- lot_number - nvarchar(30)
						  N'例常补货'
				        );
			END

			SET @i = @i + 1;
		END
		IF @row_count <> 0
		BEGIN
			--创建拣货临时表
			CREATE TABLE #tmp_gener (Id INT IDENTITY(1, 1), location_id NVARCHAR(50), lot_number NVARCHAR(50), pick_qty FLOAT, stored_attribute_id BIGINT, zone NVARCHAR(50), wh_id NVARCHAR(50));
			INSERT INTO #tmp_gener 
			SELECT tlo.location_id,ts.lot_number,ISNULL(ts.actual_qty, 0) AS actual_qty,ISNULL(ts.stored_attribute_id, 0) AS stored_attribute_id
			,tzl.zone, ts.wh_id 
			FROM dbo.t_location tlo 
			INNER JOIN dbo.t_zone_loca tzl ON tlo.wh_id = tzl.wh_id AND tlo.location_id = tzl.location_id 
			INNER JOIN t_stored_item ts ON tzl.wh_id = ts.wh_id AND tzl.location_id = ts.location_id 
			WHERE tlo.type = @jh_zone_type AND ISNULL(ts.actual_qty, 0) >= 0 
			AND ts.item_number = @item_number AND NOT EXISTS (SELECT * FROM dbo.tbl_allocation WHERE allo_type = 'R1' AND status IN ('U', 'A') AND location_id = ts.location_id) ORDER BY ts.lot_number ASC,tzl.pick_seq ASC;
			--获取行数
			SELECT @row_count = COUNT(*) FROM #tmp_gener;
			SET @i = 1;  --重新设置循环变量为1
			SET @sum_qty = 0; --重置总的补货数量
			--生成拣货任务循环开始
			WHILE @i <= @row_count
			BEGIN
				--IF Exists(select 1 from tbl_allocation where status in ('U','A') and item_number = @item_number)
				--BEGIN
				--	SET @i = @i + 1;
				--    CONTINUE;
				--END
				--获取货位号，数量，批次
				SELECT @from_location_id = location_id, @lot_number = lot_number, @pick_qty = pick_qty, 
				@stored_attribute_id = stored_attribute_id, @zone = zone, @wh_id = wh_id
				FROM #tmp_gener WHERE Id = @i;
				--判断拣货数量是否小于补货的数量
				IF @sum_qty < @replenishment_qty
				BEGIN
					--判断补货数量减去累加拣货数量减去待拣货数量是否大于0
					--如果大于0，则累加拣货数量加等于待拣货数量，并设置拣货数量等于待拣货数量
					--如果小于0，则累加拣货数量加等于补货数量减去累加拣货数量之和，并设置拣货数量等于补货数量减去累加拣货数量之和
					IF (@replenishment_qty - @sum_qty - @pick_qty) > 0
					BEGIN
						SET @sum_qty = @sum_qty + @pick_qty;
						SET @jh_qty = @pick_qty;
					END
					ELSE
					BEGIN
						SET @jh_qty = @replenishment_qty - @sum_qty;
						SET @sum_qty = @replenishment_qty - @sum_qty + @sum_qty;
					END

					--新增拣货任务
					INSERT INTO dbo.tbl_allocation
							( item_number ,--
							  lot_number ,--
							  stored_attribute_id ,--
							  location_id ,--
							  allocated_qty ,--
							  status ,
							  zone ,
							  wh_id ,
							  allo_type
							)
					VALUES  ( @item_number , -- item_number - nvarchar(30)
							  @lot_number , -- lot_number - nvarchar(30)
							  @stored_attribute_id , -- stored_attribute_id - bigint
							  @from_location_id , -- location_id - nvarchar(30)
							  @jh_qty , -- allocated_qty - float
							  N'U' , -- status - nvarchar(10)
							  @zone , -- zone - nvarchar(30)
							  @wh_id , -- wh_id - nvarchar(10)
							  N'R1' -- allo_type - nvarchar(10)
							);
				END
				ELSE
				BEGIN
					BREAK;
				END
				SET @i = @i + 1;
			END
		END
		IF @row_count = 0 AND @del_work_id != N''
		BEGIN
		    DELETE FROM dbo.t_work_q WHERE work_q_id IN (SUBSTRING(@del_work_id, 1, LEN(@del_work_id) - 1));
		END
		COMMIT;
    END TRY

	BEGIN CATCH
		ROLLBACK;
	END CATCH

END

