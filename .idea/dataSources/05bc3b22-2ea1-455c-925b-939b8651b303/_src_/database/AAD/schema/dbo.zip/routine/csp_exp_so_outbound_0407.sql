
 

CREATE  PROCEDURE [dbo].[csp_exp_so_outbound_0407]
	 
AS
BEGIN
	 
	 DECLARE  @DataID varchar(100)=null,
	  @process_status varchar(100)=null,
	  @wh_id varchar(100)='HDLSH',
	  @ZPOSITION varchar(100) ='SH' 

	 SET  @DataID=NEWID()

	  insert INTO tbl_inf_exp_inoutbound0407
	  (		DATA_HEADID
			  ,DATA_DETAILID
			  ,ZPOSITION
			  ,ZBSART  --订单类型
			  ,BUDAT   --记账日期
			  ,BLDAT   --凭证日期
			  ,ZFLAG   --出入库标志
			  ,MATNR   --物料
			  ,WMS_ZMENGE  --免费接受数量
			  ,WMS_MENGE   --订单数量
			  ,WMS_MEINS   --订单数量
			  ,ZMENGE  --免费接受数量
			  ,MENGE   --订单数量
			  ,MEINS   --订单单位
			  ,EBELN   --凭证号（单号）
			  ,EBELP   --凭证行（行）
			  ,BWART	 --移动类型
			  ,SOBKZ	 --特殊库存标识
			  ,SAKTO   --总账科目
			  ,LIFNR	 --供应商
			  ,KOSTL   --成本中心
			  ,PRCTR   --利润中心
			  ,WERKS   --工厂(3199)  [jieshou]
			  ,LGORT   --库存地(1007)[fahuo]
			  ,ZCOPRD  --联副产品标识
			  ,ZTIME   --时间
			  ,PROCESS_STATUS 
			  ,DATA_ID
			  ,PROCESS_MSG
			  ,DOC_NO
			  ,DEPARTMENT)
			 

	  SELECT  b.id AS DATA_HEADID
			  ,a.id AS DATA_DETAILID
			  ,@ZPOSITION AS ZPOSITION
			  ,isnull(b.sap_ordertype,order_type) AS ZBSART  --订单类型
			  ,REPLACE(CONVERT(VARCHAR(10),a.inf_date,120),'-','') AS BUDAT   --记账日期
			  ,REPLACE(CONVERT(VARCHAR(10),ISNULL(b.shipped_date,a.inf_date),120),'-','') AS BLDAT   --凭证日期
			  ,'O' AS ZFLAG   --出入库标志
			  ,a.item_number AS MATNR   --物料
			  ,0 AS WMS_ZMENGE  --免费接受数量
			  ,a.quantity_shipped AS WMS_MENGE   --订单数量
              ,a.uom AS WMS_MEINS   --订单数量
			  ,0 AS ZMENGE  --免费接受数量
			  ,0 AS MENGE   --订单数量
			  ,'' AS MEINS   --订单单位
			  ,isnull(a.display_order_number,a.order_number) AS EBELN   --凭证号（单号）
			  ,ISNULL(a.parent_line_number,line_number)  AS EBELP   --凭证行（行）
			  ,ISNULL(b.move_code,'') AS BWART	 --移动类型 (order_type)
			  ,isnull(b.stock_indicator_code,'')  AS SOBKZ	 --特殊库存标识
			  ,isnull(b.ledger_code,'')  AS SAKTO   --总账科目
			  ,'' AS LIFNR	 --供应商
			  ,isnull(b.cost_code,'') AS KOSTL   --成本中心
			  ,isnull(b.profit_code,'') AS PRCTR   --利润中心
			  ,ISNULL(a.factory,'')  AS WERKS    --工厂(1007 send factory )
			  ,isnull(a.storage_location,'')   AS LGORT--库存地(3105 receive factory)
			  ,'' AS ZCOPRD  --联副产品标识
			  ,'000000' AS ZTIME   --时间
			  ,'NO' AS PROCESS_STATUS 
			  ,@DataID AS DATA_ID
			  ,'' AS PROCESS_MSG
			  ,a.order_number as DOC_NO
			  ,isnull(b.department,'') as DEPARTMENT
	   FROM tbl_inf_exp_so_detail a,
	        tbl_inf_exp_so_master b
	 where  a.order_number=b.order_number
	       and lower(a.process_status)='ready'

	  update tbl_inf_exp_inoutbound0407
	  set   WMS_MEINS=b.uom
	  from  tbl_inf_exp_inoutbound0407 a,
			t_item_uom b
	  where  a.MATNR=b.item_number 
			and a.ZFLAG='O' 
			and a.PROCESS_STATUS='NO'
			and a.DATA_ID=@DataID
			and isnull(a.EBELN,'')<>''
			and b.conversion_factor=1

	  update tbl_inf_exp_inoutbound0407
	  set   MEINS=b.order_uom
	  from  tbl_inf_exp_inoutbound0407 a,t_order_detail b
	  where  a.EBELN=b.order_number 
			and a.EBELP=b.line_number
			and a.ZFLAG='O' 
			and a.PROCESS_STATUS='NO'
			and a.DATA_ID=@DataID
			and isnull(a.EBELN,'')<>''
 
	  update tbl_inf_exp_inoutbound0407
	  set    MEINS=b.uom
	  from  tbl_inf_exp_inoutbound0407 a,
			t_item_master b
	  where  a.MATNR=b.item_number 
			and isnull(a.MEINS,'')=''
			and a.ZFLAG='O' 
			and a.PROCESS_STATUS='NO'
			and a.DATA_ID=@DataID
			and isnull(a.EBELN,'')<>''

	  update tbl_inf_exp_inoutbound0407
	  set    MEINS=b.uom
	  from  tbl_inf_exp_inoutbound0407 a,
			t_item_master b
	  where  a.MATNR=b.item_number 
			and a.ZFLAG='O' 
			and a.PROCESS_STATUS='NO'
			and a.DATA_ID=@DataID
			and isnull(a.EBELN,'')<>''
			and b.ed_flag='Y'

	  update tbl_inf_exp_inoutbound0407
	  set   CONVERT_FACTOR=dbo.csf_sap_uom_convert(@wh_id,MATNR,MEINS) 
	  from  tbl_inf_exp_inoutbound0407 
	  where ZFLAG='O' 
			and PROCESS_STATUS='NO'
			and DATA_ID=@DataID
			and isnull(EBELN,'')<>''
 

	  update tbl_inf_exp_inoutbound0407
	  set   MENGE=CAST(ROUND(WMS_MENGE/CONVERT_FACTOR,3) as VARCHAR(100)),
	        ZMENGE=0
	  from  tbl_inf_exp_inoutbound0407 
	  where   ZFLAG='O' 
			and PROCESS_STATUS='NO'
			and DATA_ID=@DataID
			and isnull(EBELN,'')<>''
 
END

 




