


CREATE FUNCTION [dbo].[csf_stored_qty]
(
    @in_vchWarehouseID           NVARCHAR(30),
	@in_vchItem_Number           NVARCHAR(50),
	@stored_attribute_id		 BIGINT,
	@conversion_factor			 BIGINT
)
RETURNS FLOAT
AS
BEGIN
    DECLARE
        @stored_qty           FLOAT =0,
		@alloc_qty	          FLOAT =0,
        @avail_qty			  FLOAT =0

	DECLARE @c_vchLocTypes    NVARCHAR(30)

		SET @c_vchLocTypes = 'BZCLP' 

		SELECT @stored_qty = SUM(ISNULL(ito.actual_qty,0)-ISNULL(ito.unavailable_qty,0))
			from dbo.t_stored_item ito WITH(NOLOCK) 
			inner join t_location loc WITH(NOLOCK) 
			on ito.wh_id=loc.wh_id and ito.location_id=loc.location_id 
		WHERE ito.item_number = @in_vchItem_Number
		   AND ito.wh_id = @in_vchWarehouseID
		   AND ISNULL(ito.stored_attribute_id,99999) =ISNULL(@stored_attribute_id,99999) 
		   AND CHARINDEX(loc.type, @c_vchLocTypes) > 0 
		   AND loc.status NOT IN ( 'I', 'H' )
		   AND ito.status='A'



		SELECT @alloc_qty = sum(ISNULL(allocated_qty,0)-ISNULL(picked_qty,0))
			from dbo.tbl_allocation WITH(NOLOCK)
		WHERE item_number = @in_vchItem_Number
			AND ISNULL(stored_attribute_id,99999) =ISNULL(@stored_attribute_id,99999) 
			AND  status in ('U','A')

		IF ISNULL(@conversion_factor,0)>0 
		BEGIN
			SELECT @avail_qty =ROUND((ISNULL(@stored_qty,0) -ISNULL(@alloc_qty,0))/@conversion_factor,2)
		END
		ELSE
		BEGIN
			SELECT @avail_qty = @stored_qty - @alloc_qty
		END
            
    RETURN @avail_qty

END


