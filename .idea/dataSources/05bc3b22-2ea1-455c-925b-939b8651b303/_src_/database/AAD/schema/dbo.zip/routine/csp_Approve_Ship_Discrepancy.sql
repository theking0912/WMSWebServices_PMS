


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Approve_Ship_Discrepancy] @in_wh_id NVARCHAR(10)
	,@in_order_number NVARCHAR(30)
	,@in_user_id NVARCHAR(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @msg AS NVARCHAR(200)
	DECLARE @customer_type AS NVARCHAR(20)

	SELECT @customer_type = customer_type
	FROM t_order o
	INNER JOIN t_customer c ON o.wh_id = c.wh_id
		AND o.customer_id = c.customer_id
	WHERE o.order_number = @in_order_number
		AND o.wh_id = @in_wh_id
	
	--供应链不用RF拣选，Deleted by George on 20160820
	--IF EXISTS (
	--	select 1 from t_pick_detail pk
	--	where packed_quantity=0 
	--		and picked_quantity>0 
	--		and loaded_quantity=0
	--		and type in ('PP','PO') 
	--		and status in ('PICKED','STAGED','LOADED') 
	--		and wh_id=@in_wh_id 
	--		and order_number=@in_order_number
	--		and Exists(select 1 from t_stored_item st 
	--					inner join t_location loc on st.wh_id=loc.wh_id and st.location_id=loc.location_id 
	--					where st.type=pk.pick_id 
	--					and st.wh_id=pk.wh_id
	--					and loc.type='F')
	--	)
	--BEGIN
	--	SET @msg = '订单拣出的库存在叉车上'
	--	RAISERROR(@msg, 11, 1) 

	--	RETURN
	--END

	--供应链不用校验，Deleted by George on 20160820
	--IF ISNULL(@customer_type, '') <> 'SHWX-ND'
	--BEGIN
	--	IF EXISTS (
	--		select 1 from t_pick_detail pk
	--		where packed_quantity=0 
	--			and picked_quantity>0 
	--			and loaded_quantity=0
	--			and type='PP' 
	--			and status in ('PICKED','STAGED','LOADED') 
	--			and wh_id=@in_wh_id 
	--			and order_number=@in_order_number
	--			and Exists(select 1 from t_stored_item st 
	--						inner join t_location loc on st.wh_id=loc.wh_id and st.location_id=loc.location_id 
	--						where st.type=pk.pick_id 
	--						and st.wh_id=pk.wh_id
	--						and loc.type<>'F')
	--		)
	--	BEGIN
	--		SET @msg = '订单存在装载数量为0的拣货任务'
	--		RAISERROR(@msg, 11, 1) 

	--		RETURN
	--	END
	--END

	IF EXISTS (
			SELECT 1
			FROM dbo.t_order
			WHERE wh_id = @in_wh_id
				AND order_number = @in_order_number
				AND status IN (
					'SHIPPED'
					,'NEW'
					,'WAVED'
					)
			)
	BEGIN
		SET @msg = '执行失败，订单状态不符合差异条件' + @in_order_number

		RAISERROR (
				@msg
				,11
				,1
				)

		RETURN
	END

	IF EXISTS (
			SELECT 1
			FROM dbo.tbl_allocation
			WHERE wh_id = @in_wh_id
				AND order_number = @in_order_number
				AND status NOT IN (
					'C'
					,'E'
					)
				AND allocated_qty > 0
			)
	BEGIN
		SET @msg = '有物料还没有完成拣货' + @in_order_number

		RAISERROR (
				@msg
				,11
				,1
				)

		RETURN
	END


	--------------will  add check  po  is  done 20160531-------------
	IF EXISTS (
			SELECT 1
			FROM dbo.t_pick_detail
			WHERE wh_id = @in_wh_id
				AND order_number = @in_order_number
				AND user_assigned is not null
				AND type='PO'
			)
	BEGIN
		SET @msg = '有物料还没有完成拣货' + @in_order_number

		RAISERROR (
				@msg
				,11
				,1
				)

		RETURN
	END
	--------------will  add check  po  is  done 20160531-------------
	--供应链无播种，删除这段逻辑校验 Updated by George on 20160808
	--IF ISNULL(@customer_type, '') <> 'SHWX-ND'
	--BEGIN
	--	------- Added by Trevor on 20160409 for 未完成播种
	--	IF EXISTS (
	--			SELECT 1
	--			FROM dbo.t_stored_item sto
	--			WHERE sto.type IN (
	--					SELECT pk.pick_id
	--					FROM t_pick_detail pk 
	--					inner join tbl_allocation al on pk.order_number=al.order_number and pk.item_number=al.item_number 
	--					WHERE pk.order_number = @in_order_number
	--						AND pk.wh_id = @in_wh_id 
	--						AND al.allo_type='S'
	--					)
	--				AND sto.location_id IN (
	--					SELECT location_id
	--					FROM t_location
	--					WHERE type = 'X'
	--						AND wh_id = @in_wh_id
	--					)
	--				AND CHARINDEX(sto.location_id, sto.hu_id) <= 0
	--				AND NOT EXISTS(select 1 from t_item_master itm
	--								where itm.wh_id=sto.wh_id 
	--								and itm.item_number=sto.item_number
	--								and itm.pick_type in ('B','M'))
	--			)
	--	BEGIN
	--		SET @msg = '有播种未完成' + @in_order_number

	--		RAISERROR (
	--				@msg
	--				,11
	--				,1
	--				)

	--		RETURN
	--	END
	--END

	BEGIN TRY
		BEGIN TRANSACTION

		-- add by jerry 150422
		INSERT INTO dbo.t_pick_detail (
			order_number
			,line_number
			,type
			,status
			,item_number
			,unplanned_quantity
			,planned_quantity
			,picked_quantity
			,staged_quantity
			,loaded_quantity
			,packed_quantity
			,shipped_quantity
			,pick_location
			,wave_id
			,wh_id
			,create_date
			,stored_attribute_id
			)
		SELECT ta.order_number
			,ta.line_number
			,'PP'
			,'LOADED'
			,ta.item_number
			,0
			,ta.qty * td.conversion_factor
			,0
			,0
			,0
			,0
			,0
			,NULL
			,tc.wave_id
			,ta.wh_id
			,GETDATE()
			,NULL
		FROM dbo.t_order_detail ta
			,dbo.t_item_master tb
			,dbo.t_afo_wave_detail tc
			,dbo.t_item_uom td
		WHERE ta.item_number = tb.item_number
			AND ta.wh_id = tb.wh_id
			AND ta.item_number = td.item_number
			AND ta.order_uom = td.uom
			AND NOT EXISTS (
				SELECT 1
				FROM dbo.t_pick_detail
				WHERE order_number = ta.order_number
					AND line_number = ta.line_number
					AND item_number = ta.item_number
				)
			-- and tb.pick_type IN('B','M')
			AND ta.order_number = @in_order_number
			AND ta.wh_id = @in_wh_id
			AND ta.order_number = tc.order_number
			AND ta.wh_id = tc.wh_id

		--- deleted by Trevor on 20160327
		--UPDATE dbo.t_pick_detail
		--	SET planned_quantity = planned_quantity - ISNULL((SELECT ABS(SUM(allocated_qty)) 
		--													FROM tbl_allocation 
		--													WHERE tbl_allocation.pick_id = t_pick_detail.pick_id
		--														AND tbl_allocation.allocated_qty < 0
		--														),0)
		--	WHERE wh_id = @in_wh_id
		--		AND order_number = @in_order_number
		--		AND work_type IS NULL
		--		AND type = 'PP'
		--		AND picked_quantity <> planned_quantity 
		--- Modify by Trevor on 20160327
		--DELETE FROM dbo.tbl_allocation
		--WHERE wh_id = @in_wh_id
		--		AND order_number = @in_order_number
		--		AND allocated_qty < 0
		UPDATE dbo.tbl_allocation
		SET status = 'C'
		WHERE wh_id = @in_wh_id
			AND order_number = @in_order_number
			AND allocated_qty < 0
			AND status <> 'C'

		--- deleted by Trevor on 20160327
		--DELETE FROM t_pick_detail 
		--	WHERE wh_id = @in_wh_id
		--		AND order_number = @in_order_number
		--		AND planned_quantity = 0

		--供应链修改，Deleted by George on 20160820
		--IF ISNULL(@customer_type, '') = 'SHWX-ND'
		--BEGIN
		--	UPDATE t_pick_detail
		--	SET status = 'LOADED'
		--		,loaded_quantity = staged_quantity
		--	WHERE wh_id = @in_wh_id
		--		AND order_number = @in_order_number
		--		AND work_type IS NULL
		--		--AND type = 'PP'          ---- deleted by Trevor on 20160412
		--		--AND planned_quantity = loaded_quantity
		--		AND NOT EXISTS (
		--			SELECT 1
		--			FROM tbl_allocation allo
		--			WHERE allo.wh_id = @in_wh_id
		--				AND t_pick_detail.pick_id = allo.pick_id
		--				AND status NOT IN (
		--					'C'
		--					,'E'
		--					)
		--			)
		--		AND picked_quantity = staged_quantity
		--END
		--ELSE
		--BEGIN
		--	UPDATE t_pick_detail
		--	SET status = 'LOADED'
		--	WHERE wh_id = @in_wh_id
		--		AND order_number = @in_order_number
		--		AND work_type IS NULL
		--		--AND type = 'PP'  ---- deleted by Trevor on 20160412
		--		--AND planned_quantity = loaded_quantity
		--		AND NOT EXISTS (
		--			SELECT 1
		--			FROM tbl_allocation allo
		--			WHERE allo.wh_id = @in_wh_id
		--				AND t_pick_detail.pick_id = allo.pick_id
		--				AND status NOT IN (
		--					'C'
		--					,'E'
		--					)
		--			)
		--		--AND picked_quantity = loaded_quantity+packed_quantity   --- deleted by Trevor on 20160327
		--END

		--供应链新增校验，Added by George on 20160820
		UPDATE t_pick_detail
		SET status = 'LOADED'
			,loaded_quantity = staged_quantity
		WHERE wh_id = @in_wh_id
			AND order_number = @in_order_number
			AND work_type IS NULL
			AND NOT EXISTS (
				SELECT 1
				FROM tbl_allocation allo
				WHERE allo.wh_id = @in_wh_id
					AND t_pick_detail.pick_id = allo.pick_id
					AND status NOT IN (
						'C'
						,'E'
						)
				)
			AND picked_quantity = staged_quantity

		IF ISNULL(@customer_type, '') = 'SHWX-ND'
		BEGIN
			UPDATE t_order
			SET status = 'LOADED'
			WHERE order_number = @in_order_number
				AND NOT EXISTS (
					SELECT 1
					FROM dbo.t_pick_detail
					WHERE wh_id = @in_wh_id
						AND order_number = @in_order_number
						AND planned_quantity <> staged_quantity
						AND work_type IS NULL
						--AND type = 'PP' ---- deleted by Trevor on 20160412
						AND status <> 'LOADED'
					)
				AND wh_id = @in_wh_id
		END
		ELSE
		BEGIN
			UPDATE t_order
			SET status = 'LOADED'
			WHERE order_number = @in_order_number
				AND NOT EXISTS (
					SELECT 1
					FROM dbo.t_pick_detail
					WHERE wh_id = @in_wh_id
						AND order_number = @in_order_number
						AND work_type IS NULL
						--	AND planned_quantity <> loaded_quantity --- deleted by Trevor on 20160327
						-- 	AND type = 'PP'                   ---- deleted by Trevor on 20160412
						AND status <> 'LOADED'
					)
				AND wh_id = @in_wh_id
		END

		INSERT INTO t_tran_log_holding (
			[tran_type]
			,[description]
			,[start_tran_date]
			,[start_tran_time]
			,[end_tran_date]
			,[end_tran_time]
			,[employee_id]
			,[control_number]
			,[control_number_2]
			,[wh_id]
			,[location_id]
			,[hu_id]
			,[item_number]
			,[lot_number]
			,[tran_qty]
			,generic_attribute_1
			,generic_attribute_2
			,generic_attribute_3
			,generic_attribute_4
			,generic_attribute_5
			,generic_attribute_6
			,generic_attribute_7
			,generic_attribute_8
			,generic_attribute_9
			,generic_attribute_10
			,generic_attribute_11
			)
		VALUES (
			'342'
			,N'发货差异承认'
			,GETDATE()
			,GETDATE()
			,GETDATE()
			,GETDATE()
			,@in_user_id
			,@in_order_number
			,NULL
			,@in_wh_id
			,NULL
			,NULL
			,NULL
			,NULL
			,0
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			)

		COMMIT

		RETURN
	END TRY

	BEGIN CATCH
		SET NOCOUNT OFF

		ROLLBACK

		SET @msg = ERROR_MESSAGE()

		RAISERROR (
				@msg
				,11
				,1
				)

		RETURN
	END CATCH
END


