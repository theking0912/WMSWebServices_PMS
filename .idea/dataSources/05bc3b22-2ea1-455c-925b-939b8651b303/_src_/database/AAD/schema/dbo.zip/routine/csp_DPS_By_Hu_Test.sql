
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_DPS_By_Hu_Test]
	-- Add the parameters for the stored procedure here
	@hu_id			AS	NVARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @item_number AS NVARCHAR(40) = ''
	DECLARE @qty AS float
	DECLARE @type					BIGINT
	DECLARE @order_number	AS nvarchar(30) = ''
	declare @dest_hu		as nvarchar(100)
	DECLARE @ptl_loc		as nvarchar(50)
	declare @wall_id		as nvarchar(50)
	DECLARE @location_id	AS	NVARCHAR(50)
	DECLARE @wh_id			AS	NVARCHAR(30)
	DECLARE @lot_number		AS	NVARCHAR(30)
	DECLARE @stored_attribute_id	AS BIGINT
	DECLARE @expiration_date	AS	DATETIME
	DECLARE @damage_flag	AS	NVARCHAR(10)
	DECLARE @remove_qty AS FLOAT
	DECLARE @short_qty				FLOAT
	
	DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg

    -- Insert statements for procedure here
	--UPDATE t_stored_item SET location_id = 'PTL002'
	--WHERE hu_id = @hu_id
	--AND wh_id = 'HDLSH'
	
	BEGIN TRY
		BEGIN TRANSACTION

	WHILE(1=1)
	BEGIN
		SELECT TOP 1 @item_number = si.item_number
					--,@qty = actual_qty--delete by George 20160403
					,@qty =(case when pd.picked_quantity<=si.actual_qty then pd.picked_quantity else si.actual_qty end)--add by George 20160403
					, @type = si.type
					,@order_number = pd.order_number
					,@wall_id = shipment_number
					,@location_id = location_id
					,@lot_number = si.lot_number
					,@wh_id = si.wh_id
					,@stored_attribute_id = si.stored_attribute_id
					,@expiration_date = si.expiration_date
					,@damage_flag = si.damage_flag
			FROM t_stored_item si
			INNER JOIN t_pick_detail pd
			ON si.type = pd.pick_id
			AND si.wh_id = pd.wh_id
			WHERE  hu_id = @hu_id
			 AND si.type <> 0
			AND pd.order_number > @order_number
			ORDER BY pd.order_number
		
		IF @@ROWCOUNT = 0
		BEGIN 
			BREAK;
		END

		select TOP 1 @ptl_loc = location_id from tbl_pick_wall where wall_id = @wall_id
		IF ISNULL(@ptl_loc,'') = ''
		BEGIN
			SET @ptl_loc = @location_id
		END
		set @dest_hu = @ptl_loc + '_' + @order_number

		--IF NOT EXISTS( SELECT 1 FROM t_hu_master WHERE hu_id = @source_hu)
		--BEGIN
		--	insert into t_hu_master
		--	values(@source_hu,'SO',@order_number,@ptl_loc,NULL,'A',GETDATE(),'HDLSH',0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL)	
		--END
		--UPDATE dbo.t_stored_item
		--	SET location_id = @ptl_loc
		--		,hu_id = @source_hu
		--		,shipment_number = @order_number
		--		WHERE  hu_id = @hu_id
		--		and type = @type


		UPDATE t_pick_detail
				SET loaded_quantity = loaded_quantity + @qty
					,status = CASE WHEN planned_quantity = loaded_quantity + @qty THEN 'LOADED'
								ELSE status END
					WHERE pick_id = @type
		-- update order status
				UPDATE t_order
					SET status = 'LOADED'
					WHERE wh_id = @wh_id
					AND order_number = @order_number
					--AND NOT EXISTS(SELECT 1 FROM t_pick_detail
					--				WHERE wh_id = @wh_id
					--					AND order_number = @order_number
					--					AND status <> 'LOADED'
					--					AND type = 'PP')
	--Modified by Trevor on 20160327
 					AND NOT EXISTS(SELECT 1 FROM t_order_detail a left join t_pick_detail b
					                        on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
									WHERE a.wh_id = @wh_id
										AND a.order_number = @order_number
										AND isnull(b.status,'') <> 'LOADED'
										and isnull(b.work_type,'')=''
										--AND b.type = 'PP'
										)

					--Move the stock to fork
				EXEC [dbo].[csp_Inventory_Adjust]
					@in_vchWhID = @wh_id,
					@in_vchItemNumber = @item_number,
					@in_vchLocationID = @ptl_loc,
					@in_nType = @type,
					@in_vchHUID = @dest_hu,
					@in_vchLotNumber = @lot_number,
					@in_nStoredAttributeID = @stored_attribute_id,
					@in_fQty = @qty,
					@in_dtFifoDate = NULL,
					@in_dtExpirationDate = @expiration_date,
					@in_vchHUType = 'SO',
					@in_vchShipmentNumber = @order_number,
					@in_damage_flag = @damage_flag,
					@out_vchCode = @out_vchCode OUTPUT,
					@out_vchMsg = @out_vchMsg OUTPUT

				SET @remove_qty = @qty * -1

				--ReMove the stock to fork
				EXEC [dbo].[csp_Inventory_Adjust]
					@in_vchWhID = @wh_id,
					@in_vchItemNumber = @item_number,
					@in_vchLocationID = @location_id,
					@in_nType = @type,
					@in_vchHUID = @hu_id,
					@in_vchLotNumber = @lot_number,
					@in_nStoredAttributeID = @stored_attribute_id,
					@in_fQty = @remove_qty,
					@in_dtFifoDate = NULL,
					@in_dtExpirationDate = @expiration_date,
					@in_vchHUType = 'SO',
					@in_vchShipmentNumber = NULL,
					@in_damage_flag = @damage_flag,
					@out_vchCode = @out_vchCode OUTPUT,
					@out_vchMsg = @out_vchMsg OUTPUT

				INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],location_id,[location_id_2],[hu_id],[item_number],[lot_number],[tran_qty])
				values('201','Move(Pick)',getdate(),getdate(),getdate(),getdate(),'Vir PTW',@order_number,null,
				@wh_id,@location_id,null,@hu_id,@item_number,@lot_number,@qty)

				INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],location_id,[location_id_2],[hu_id],[item_number],[lot_number],[tran_qty])
				values('202','Move(Put)',getdate(),getdate(),getdate(),getdate(),'Vir PTW',@order_number,null,
				@wh_id,@ptl_loc,NULL,@dest_hu,@item_number,@lot_number,@qty) 

				--Add by George 20160403 DPS模拟播种后，托盘上剩余的库存调整属性，使其可做RF播种
				SELECT TOP 1 
					@lot_number = si.lot_number,
					@stored_attribute_id = si.stored_attribute_id,
					@expiration_date = expiration_date,
					@type = si.type,
					@location_id = location_id,
					@damage_flag = damage_flag,
					@short_qty = actual_qty
				FROM t_stored_item si
				INNER JOIN t_pick_detail pd
				ON si.type = pd.pick_id
				AND si.wh_id = pd.wh_id
				WHERE si.wh_id = @wh_id
					AND hu_id = @hu_id
					AND si.item_number = @item_number
					AND pd.order_number = @order_number
					AND si.type <> 0

				IF @@ROWCOUNT > 0
				BEGIN
					INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],location_id,[location_id_2],[hu_id],[item_number],[lot_number],[tran_qty])
					values('990',N'调整超分配库存属性',getdate(),getdate(),getdate(),getdate(),'DPS',@order_number,null,
					@wh_id,@location_id,null,@hu_id,@item_number,@lot_number,@short_qty)

					--Move the stock to fork
					EXEC [dbo].[csp_Inventory_Adjust]
							@in_vchWhID = @wh_id,
							@in_vchItemNumber = @item_number,
							@in_vchLocationID = @location_id,
							@in_nType = 0,
							@in_vchHUID = @hu_id,
							@in_vchLotNumber = @lot_number,
							@in_nStoredAttributeID = @stored_attribute_id,
							@in_fQty = @short_qty,
							@in_dtFifoDate = NULL,
							@in_dtExpirationDate = @expiration_date,
							@in_vchHUType = 'IV',
							@in_vchShipmentNumber = '',
							@in_damage_flag = @damage_flag,
							@out_vchCode = @out_vchCode OUTPUT,
							@out_vchMsg = @out_vchMsg OUTPUT					

					SET @short_qty = @short_qty * -1

					--ReMove the stock to fork
					EXEC [dbo].[csp_Inventory_Adjust]
						@in_vchWhID = @wh_id,
						@in_vchItemNumber = @item_number,
						@in_vchLocationID = @location_id,
						@in_nType = @type,
						@in_vchHUID = @hu_id,
						@in_vchLotNumber = @lot_number,
						@in_nStoredAttributeID = @stored_attribute_id,
						@in_fQty = @short_qty,
						@in_dtFifoDate = NULL,
						@in_dtExpirationDate = @expiration_date,
						@in_vchHUType = 'SO',
						@in_vchShipmentNumber = NULL,
						@in_damage_flag = @damage_flag,
						@out_vchCode = @out_vchCode OUTPUT,
						@out_vchMsg = @out_vchMsg OUTPUT		
				END

	END

	 

		COMMIT
		RETURN
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION
		END
		RETURN
	END CATCH
END

