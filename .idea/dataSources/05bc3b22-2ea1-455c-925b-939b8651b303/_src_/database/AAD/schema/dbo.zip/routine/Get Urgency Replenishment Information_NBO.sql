







------02 17 2016 by will

CREATE PROCEDURE [dbo].[Get Urgency Replenishment Information_NBO]    
		@wh_id NVARCHAR(10)
	,	@zone nvarchar(30)
	,   @item nvarchar(30)
	--@ItemID nvarchar(30)
	--  @LotNumber nvarchar(30)
	--@location nvarchar(30) 
	--  @Getlocation nvarchar(30) 
	,   @outlotnumber nvarchar(30) output
	,   @outlocation nvarchar(30) output
	,   @Repqty  float          output
	   , @attribute  float          output----will add
	,   @out_vchErrCode nvarchar(10) output
AS    
BEGIN 
declare @ItemID nvarchar(30)
declare @LotNumber nvarchar(30)
declare @location nvarchar(30) 
declare @Getlocation nvarchar(30) 
set @out_vchErrCode=0
SELECT TOP 1 @LotNumber = allo.lot_number
FROM dbo.tbl_allocation allo 
INNER JOIN dbo.t_stored_item sto ON allo.wh_id = sto.wh_id 
AND allo.location_id = sto.location_id 
AND allo.item_number = sto.item_number
INNER JOIN dbo.t_location loc ON loc.wh_id = allo.wh_id 
AND loc.location_id = allo.location_id
INNER JOIN dbo.t_work_q tq ON tq.wh_id = allo.wh_id 
AND tq.item_number = allo.item_number 
AND allo.pick_id=tq.pick_ref_number AND tq.lot_number=allo.lot_number 
--AND tq.zone=allo.zone
INNER JOIN dbo.t_zone_loca loca ON loca.wh_id=allo.wh_id 
AND loca.location_id=allo.location_id
WHERE --loc.type IN ('C', 'B') AND 
tq.work_type = '06' 
AND allo.allo_type = 'R2' 
AND allo.wh_id=@wh_id  AND allo.zone=@zone AND allo.status='A' 
AND (tq.work_status='U' OR tq.work_status='A')
AND allo.item_number=@item
AND allo.allocated_qty - ISNULL(allo.picked_qty,0) > 0
order by allo.lot_number
if @LotNumber <>''
begin
    set @outlotnumber =@LotNumber
end
else
begin
set @out_vchErrCode=1
end

SELECT TOP 1 @location=allo.location_id,@attribute=allo.stored_attribute_id
FROM dbo.tbl_allocation allo 
INNER JOIN dbo.t_stored_item sto ON allo.wh_id = sto.wh_id 
AND allo.location_id = sto.location_id 
AND allo.item_number = sto.item_number
INNER JOIN dbo.t_location loc ON loc.wh_id = allo.wh_id 
AND loc.location_id = allo.location_id
INNER JOIN dbo.t_work_q tq ON tq.wh_id = allo.wh_id 
AND tq.item_number = allo.item_number 
AND allo.pick_id=tq.pick_ref_number AND tq.lot_number=allo.lot_number 
--AND tq.zone=allo.zone
INNER JOIN dbo.t_zone_loca loca ON loca.wh_id=allo.wh_id 
AND loca.location_id=allo.location_id
WHERE --loc.type IN ('C', 'B') AND 
tq.work_type = '06'
AND allo.allo_type = 'R2' 
AND allo.wh_id=@wh_id AND allo.zone=@zone
AND allo.status='A' 
AND (tq.work_status='U' OR tq.work_status='A')
AND allo.item_number=@item 
AND allo.lot_number =@LotNumber 
AND allo.allocated_qty - ISNULL(allo.picked_qty,0) > 0
order by loca.pick_seq ASC
--GROUP BY allo.location_id   

--select TOP 1 @Getlocation=location_id from t_zone_loca  where location_id =@location 
--AND wh_id =@wh_id order by pick_seq ASC

if @location<>''
begin
    set @outlocation=@location
end
else
begin
set @out_vchErrCode=1
end

select @Repqty =(sum(allocated_qty) -sum(ISNULL(picked_qty,0))) from tbl_allocation where location_id =@outlocation 
and item_number =@item and wh_id=@wh_id and lot_number =@LotNumber and status='A'
--and sum(allocated_qty)-sum(ISNULL(picked_qty,0))>0
if @Repqty <=0
begin
set @out_vchErrCode=1
end

END






