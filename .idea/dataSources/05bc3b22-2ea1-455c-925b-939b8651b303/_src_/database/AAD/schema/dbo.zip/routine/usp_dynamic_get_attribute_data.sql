
CREATE PROCEDURE usp_dynamic_get_attribute_data
(
    @in_vchStoredAttributeID     VARCHAR(30),
    @out_vchGenericAttribute_1   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_2   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_3   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_4   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_5   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_6   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_7   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_8   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_9   VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_10  VARCHAR(50) OUTPUT,
    @out_vchGenericAttribute_11  VARCHAR(50) OUTPUT
)
AS


DECLARE
  -- Log Error numbers used for branching in the Error HANDler.
    @e_GenSqlError               INT,
    @e_SprocError                INT,
    @e_CollectionNotBelongToItem INT,
    @e_NotDataInTable            INT,
    @out1_vchGenericAttribute_1   VARCHAR(50) ,
    @out1_vchGenericAttribute_2   VARCHAR(50) ,
    @out1_vchGenericAttribute_3   VARCHAR(50) ,
    @out1_vchGenericAttribute_4   VARCHAR(50) ,
    @out1_vchGenericAttribute_5   VARCHAR(50) ,
    @out1_vchGenericAttribute_6   VARCHAR(50) ,
    @out1_vchGenericAttribute_7   VARCHAR(50) ,
    @out1_vchGenericAttribute_8   VARCHAR(50) ,
    @out1_vchGenericAttribute_9   VARCHAR(50) ,
    @out1_vchGenericAttribute_10  VARCHAR(50) ,
    @out1_vchGenericAttribute_11  VARCHAR(50) 

SET NOCOUNT ON

    SELECT @out_vchGenericAttribute_1 = a.col1,
           @out_vchGenericAttribute_2 = a.col2,
           @out_vchGenericAttribute_3 = a.col3,
           @out_vchGenericAttribute_4 = a.col4,
           @out_vchGenericAttribute_5 = a.col5,
           @out_vchGenericAttribute_6 = a.col6,
           @out_vchGenericAttribute_7 = a.col7,
           @out_vchGenericAttribute_8 = a.col8,
           @out_vchGenericAttribute_9 = a.col9,
           @out_vchGenericAttribute_10 = a.col10,
           @out_vchGenericAttribute_11 = a.col11
  FROM (
     SELECT 
     (SELECT d.attribute_value
        FROM t_sto_attrib_collection_master m
           , t_sto_attrib_collection_detail d
       WHERE m.stored_attribute_id = d.stored_attribute_id
         AND m.stored_attribute_id = @in_vchStoredAttributeID
         AND d.attribute_id = p.generic_attribute_1
     ) AS col1
     ,(SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_2
		         ) AS col2
     ,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_3
		         ) AS col3
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_4
		         ) AS col4
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_5
		         ) AS col5
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_6
		         ) AS col6
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_7
		         ) AS col7
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_8
		         ) AS col8
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_9
		         ) AS col9
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_10
		         ) AS col10
		,  (SELECT d.attribute_value
		            FROM t_sto_attrib_collection_master m
		               , t_sto_attrib_collection_detail d
		           WHERE m.stored_attribute_id = d.stored_attribute_id
		             AND m.stored_attribute_id = @in_vchStoredAttributeID
		             AND d.attribute_id = p.generic_attribute_11
		         ) AS col11
     FROM t_attribute_legacy_map p
      ) a


-- Always leave the stored procedure FROM here.
RETURN
