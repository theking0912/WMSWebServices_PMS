
CREATE PROCEDURE usp_db_obj_log_level
    @out_snLogLevel      SMALLINT OUTPUT

AS

    SET NOCOUNT ON

    BEGIN TRANSACTION

    -- Grab the Database Log Level from t_control.  If it doesn't exist, insert it.
    -- 0 = Off, 1 = On
    SELECT @out_snLogLevel = next_value
        FROM t_control
        WHERE control_type = 'DB OBJ LOG LEVEL'
    
    IF @@ROWCOUNT = 0
    BEGIN
       INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit)
           VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', 3, 'SHOW_VA', '1')

       SET @out_snLogLevel = 3
    END
    
    COMMIT TRANSACTION
    
ExitLabel:

    RETURN
