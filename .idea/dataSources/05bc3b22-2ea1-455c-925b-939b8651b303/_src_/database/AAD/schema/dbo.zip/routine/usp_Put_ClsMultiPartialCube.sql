
CREATE PROCEDURE usp_Put_ClsMultiPartialCube
    @in_vchItem         NVARCHAR(30),
    @in_vchLot			NVARCHAR(30),
    @in_nQty            INT,
    @in_dtFIFODate      DATETIME,  -- Unused here.
    @in_vchForkZone     NVARCHAR(10),
    @in_vchWhID         NVARCHAR(10),
	@in_nStoAttID		BIGINT,
    @out_vchLoc         NVARCHAR(50) = NULL OUTPUT

AS
DECLARE 
	@v_vchClassID	NVARCHAR(10),
	@v_fNestedVolume FLOAT,
	@v_fUnitVolume	 FLOAT
		
    -- Retreive the class_id, nested_volume, and unit_volume from t_item_uom.
    -- Only a single t_item_uom record may be used.  This is determined by taking the
    -- greatest conversion factor less than or equal to the quantity passed in.
    SELECT TOP 1 @v_vchClassID = ISNULL(dbo.usf_get_item_class_dia_ovrd
                                            (@in_vchItem, @in_vchWhID, itu.uom, @in_nStoAttID),
                                        itu.class_id),
                 @v_fNestedVolume = itu.nested_volume,
                 @v_fUnitVolume	= itu.unit_volume
    FROM t_item_uom itu
    WHERE itu.conversion_factor <= @in_nQty
        AND itu.item_number = @in_vchItem
        AND itu.wh_id = @in_vchWhID
    ORDER BY itu.conversion_factor DESC

	IF @in_nStoAttID IS NULL 
	   OR NOT EXISTS (SELECT * 
					  FROM t_item_master itm
					  INNER JOIN t_attribute_collection_detail acd
							ON itm.attribute_collection_id = acd.attribute_collection_id
					  INNER JOIN t_attribute_type tat
							ON acd.attribute_id = tat.attribute_id	
					  WHERE itm.item_number = @in_vchItem
  					      AND itm.wh_id = @in_vchWhID	
  						  AND tat.allow_mix = 'N'
					  )
	BEGIN
		SELECT TOP 1 @out_vchLoc = loc.location_id
		FROM t_item_uom itu
			INNER JOIN t_class_loca clc
				ON itu.wh_id = clc.wh_id 
				AND ISNULL(dbo.usf_get_item_class_dia_ovrd
                               (@in_vchItem, @in_vchWhID, itu.uom, @in_nStoAttID),
                           itu.class_id) = clc.class_id
			INNER JOIN t_location loc
				ON clc.wh_id = loc.wh_id
				AND clc.location_id = loc.location_id
            INNER JOIN t_pick_area pka
                ON pka.pick_area = loc.pick_area
                AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND @in_nStoAttID IS NULL AND @in_vchLot IS NULL) )
                AND pka.wh_id = loc.wh_id
                AND (pka.pick_area_type = 'R' OR (pka.pick_area_type = 'V' and @in_nStoAttID IS NULL))
			INNER JOIN t_stored_item sto
				ON itu.wh_id = sto.wh_id
				AND itu.item_number = sto.item_number
				AND sto.location_id = loc.location_id
			INNER JOIN t_zone_loca zlc
				ON loc.wh_id = zlc.wh_id
				AND loc.location_id = zlc.location_id
		WHERE loc.status = 'P'
			AND(
				(loc.type = 'M' AND itu.unit_volume = 0 AND itu.nested_volume = 0)
				OR (loc.type = 'M' AND loc.capacity_volume = 0)
				OR (loc.type = 'M' AND loc.capacity_volume >= 
					-- Start with the volume currently in the location
					(itu.unit_volume + ((sto.actual_qty - 1) *
						CASE 
							WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume 
								ELSE @v_fNestedVolume 
							END)
					)
					-- Then add the volume to putaway to see if it less than or
					-- equal to the capacity volume of the location
					+ (@v_fUnitVolume + ((@in_nQty  - 1) *
						CASE
							WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume
								ELSE @v_fNestedVolume
							END)))
				)
			AND clc.class_id = @v_vchClassID
			AND itu.item_number = @in_vchItem
			AND itu.wh_id = @in_vchWhID
			AND zlc.zone = @in_vchForkZone			
		ORDER BY loc.user_count, loc.picking_flow, loc.location_id
	END
	ELSE
	BEGIN
		SELECT TOP 1 @out_vchLoc = loc.location_id
		FROM t_item_uom itu
			INNER JOIN t_class_loca clc
				ON itu.wh_id = clc.wh_id 
				AND ISNULL(dbo.usf_get_item_class_dia_ovrd
                               (@in_vchItem, @in_vchWhID, itu.uom, @in_nStoAttID),
                           itu.class_id) = clc.class_id
			INNER JOIN t_location loc
				ON clc.wh_id = loc.wh_id
				AND clc.location_id = loc.location_id
			INNER JOIN t_pick_area pka
				ON pka.pick_area = loc.pick_area
				AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND @in_nStoAttID IS NULL AND @in_vchLot IS NULL) )
				AND pka.wh_id = loc.wh_id
				AND (pka.pick_area_type = 'R' OR (pka.pick_area_type = 'V' and @in_nStoAttID IS NULL))
			INNER JOIN t_stored_item sto
				ON itu.wh_id = sto.wh_id
				AND itu.item_number = sto.item_number
				AND sto.location_id = loc.location_id
			INNER JOIN t_zone_loca zlc
				ON loc.wh_id = zlc.wh_id
				AND loc.location_id = zlc.location_id
		WHERE loc.status = 'P'
			AND(
				(loc.type = 'M' AND itu.unit_volume = 0 AND itu.nested_volume = 0)
				OR (loc.type = 'M' AND loc.capacity_volume = 0)
				OR (loc.type = 'M' AND loc.capacity_volume >= 
					-- Start with the volume currently in the location
					(itu.unit_volume + ((sto.actual_qty - 1) *
						CASE 
							WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume 
								ELSE @v_fNestedVolume 
							END)
					)
					-- Then add the volume to putaway to see if it less than or
					-- equal to the capacity volume of the location
					+ (@v_fUnitVolume + ((@in_nQty  - 1) *
						CASE
							WHEN @v_fNestedVolume = 0 THEN @v_fUnitVolume
								ELSE @v_fNestedVolume
							END)))
				)
			AND clc.class_id = @v_vchClassID
			AND itu.item_number = @in_vchItem
			AND itu.wh_id = @in_vchWhID
			AND zlc.zone = @in_vchForkZone
			AND NOT EXISTS (
							SELECT * 
							FROM t_item_master itm
							INNER JOIN t_attribute_collection_detail acd
								ON itm.attribute_collection_id = acd.attribute_collection_id
							INNER JOIN t_attribute_type tat
								ON acd.attribute_id = tat.attribute_id	
							INNER JOIN t_sto_attrib_collection_detail sad
								ON sad.attribute_id = tat.attribute_id
							INNER JOIN t_stored_item sto1
								ON sto1.stored_attribute_id = sad.stored_attribute_id
							INNER JOIN t_sto_attrib_collection_detail sad1
								ON sad.attribute_id = sad1.attribute_id
							WHERE itm.item_number = @in_vchItem
		      					  AND itm.wh_id = @in_vchWhID	
		      					  AND sad1.stored_attribute_id = @in_nStoAttID
		      					  AND tat.allow_mix = 'N'
		      					  AND sto.wh_id = sto1.wh_id
            					  AND sto.location_id = sto1.location_id
            					  AND sad.attribute_value <> sad1.attribute_value
						  )
		ORDER BY loc.user_count, loc.picking_flow, loc.location_id
	END

ExitLabel:
  RETURN
