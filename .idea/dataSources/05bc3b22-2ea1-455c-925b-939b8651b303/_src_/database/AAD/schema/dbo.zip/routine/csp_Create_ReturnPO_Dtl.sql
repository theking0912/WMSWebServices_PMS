-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Create_ReturnPO_Dtl] 
	-- Add the parameters for the stored procedure here
	@action				AS	NVARCHAR(10),
	@wh_id				AS	NVARCHAR(10),
	@order_number		AS	NVARCHAR(30),
	@item_number		AS	NVARCHAR(30),
	@lot_number			AS	NVARCHAR(30),
	@qty				AS	NVARCHAR(30),
	@order_uom			AS	NVARCHAR(20),
	@ord_dtl_id			AS	INT,
	@date_excepted		AS	DATETIME,
	@client_code		AS	NVARCHAR(30),
	@page_title			AS	NVARCHAR(200),
	@out_msg			AS	NVARCHAR(200)	OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @display_ord_no		AS	NVARCHAR(30)
	DECLARE @po_number			AS	NVARCHAR(30)
	DECLARE @line_number		AS	NVARCHAR(5)
	DECLARE	@received_qty		AS	FLOAT
	DECLARE @order_id			AS	INT
	DECLARE	@unit_of_ea			AS	FLOAT
	DECLARE @ord_status			AS	NVARCHAR(10)
	DECLARE @sap_ord_typ		AS	NVARCHAR(20)
	DECLARE @vdr_code			AS	NVARCHAR(10)

	BEGIN TRY

	SELECT @display_ord_no = display_order_number
			,@order_id = order_id
			,@ord_status = status
			,@vdr_code = vendor_code
		FROM t_order WITH(NOLOCK)
		WHERE order_number = @order_number
			AND wh_id = @wh_id
	
	IF @ord_status <> 'NEW'
	BEGIN
		SET @out_msg = '订单已经加入波次，不能修改'
		RAISERROR('ERR', 11, 1)
	END

	IF ISNULL(@display_ord_no,'') = '' OR ISNULL(@display_ord_no,'') = @order_number
	BEGIN
		--SELECT TOP 1 
		--	 @po_number = rc.po_number
		--	,@line_number = rc.line_number
		--	,@received_qty = SUM(rc.qty_received)  
		--	,@sap_ord_typ = MAX(po.sap_ordertype)
		--	 FROM t_receipt rc WITH(NOLOCK) 
		--	 INNER JOIN t_po_master po WITH(NOLOCK)
		--	 ON rc.wh_id = po.wh_id
		--		AND rc.po_number = po.po_number
		--	INNER JOIN (select lookup_id,text from t_lookup where source = 't_po_master' 
		--						AND locale_id = 2052 AND lookup_type = 'TYPE') lk
		--	ON po.type_id = lk.lookup_id
		--	 WHERE ISNULL(rc.lot_number,'') = ISNULL(@lot_number,'')
		--	 AND rc.wh_id = @wh_id 
		--	 AND rc.item_number = @item_number
		--	 AND lk.text IN ('PO','TO')
		--	 AND po.vendor_code = @vdr_code 
		--	GROUP BY rc.po_number,rc.item_number,rc.line_number
		--	ORDER BY MAX(rc.receipt_date) DESC

			SELECT TOP 1 
			 @po_number = rc.po_number
			,@line_number = rc.line_number
			,@received_qty = MAX(rspd.received_qty) - ISNULL(MAX(rspd.return_qty),0)
			,@sap_ord_typ = MAX(po.sap_ordertype)
			 FROM t_receipt rc WITH(NOLOCK)
			 INNER JOIN t_rcpt_ship_po_detail rspd WITH(NOLOCK)
			 ON rc.wh_id = rspd.wh_id
			 AND rc.receipt_id = rspd.shipment_number
			 AND rc.po_number = rspd.po_number
			 AND rc.item_number = rspd.item_number
			 AND rc.line_number = rspd.line_number
			 INNER JOIN t_po_master po WITH(NOLOCK)
			 ON rc.wh_id = po.wh_id
				AND rc.po_number = po.po_number
			INNER JOIN (select lookup_id,text from t_lookup where source = 't_po_master' 
								AND locale_id = 2052 AND lookup_type = 'TYPE') lk
			ON po.type_id = lk.lookup_id
			 WHERE ISNULL(rc.lot_number,'') = ISNULL(@lot_number,'')
			 AND rc.wh_id = @wh_id 
			 AND rc.item_number = @item_number
			 AND lk.text IN ('PO','TO')
			 AND po.vendor_code = @vdr_code
			 AND ISNULL(rspd.received_qty,0) - ISNULL(return_qty,0) > 0
			GROUP BY rc.po_number,rc.item_number,rc.line_number
			ORDER BY MAX(rc.receipt_date) DESC
	END
	ELSE
	BEGIN
		--SELECT TOP 1
		--	 @po_number = po_number
		--	,@line_number = line_number
		--	,@received_qty = SUM(qty_received) 
		--	FROM t_receipt rc WITH(NOLOCK)
		--	WHERE 
		--		ISNULL(rc.lot_number,'') = ISNULL(@lot_number,'') 
		--		AND wh_id = @wh_id 
		--		AND item_number = @item_number
		--		AND po_number = @display_ord_no
		--	GROUP BY po_number,item_number,line_number
		--	ORDER BY MAX(receipt_date) DESC

		SELECT TOP 1
			 @po_number = rc.po_number
			,@line_number = rc.line_number
			,@received_qty = MAX(rspd.received_qty) - ISNULL(MAX(rspd.return_qty),0) 
			FROM t_receipt rc WITH(NOLOCK)
			INNER JOIN t_rcpt_ship_po_detail rspd WITH(NOLOCK)
			 ON rc.wh_id = rspd.wh_id
			 AND rc.receipt_id = rspd.shipment_number
			 AND rc.po_number = rspd.po_number
			 AND rc.item_number = rspd.item_number
			 AND rc.line_number = rspd.line_number
			WHERE 
				ISNULL(rc.lot_number,'') = ISNULL(@lot_number,'')
				AND rc.wh_id = @wh_id 
				AND rc.item_number = @item_number
				AND rc.po_number = @display_ord_no
				AND ISNULL(rspd.received_qty,0) - ISNULL(return_qty,0) > 0 
			GROUP BY rc.po_number,rc.item_number,rc.line_number
			ORDER BY MAX(receipt_date) DESC
		
	END
	
	SELECT @unit_of_ea = conversion_factor * @qty
		FROM t_item_uom WITH(NOLOCK)
		WHERE wh_id = @wh_id
			AND item_number = @item_number
			AND uom = @order_uom

	IF @received_qty < @unit_of_ea
	BEGIN
		SET @out_msg = '出库数量超过入库单对应的入库数量(' + CONVERT(NVARCHAR,@received_qty) + ')'
		RAISERROR('ERR', 11, 1)
	END

	IF ISNULL(@po_number,'') = ''
	BEGIN
		SET @out_msg = '没有找到对应的入库信息'
		RAISERROR('ERR', 11, 1)
	END

	BEGIN TRANSACTION

	IF @action = 'ADD'
	BEGIN
		UPDATE t_order
			SET display_order_number = @po_number
				,sap_ordertype = @sap_ord_typ
			WHERE order_number = @order_number
				AND wh_id = @wh_id

		INSERT INTO [dbo].[t_order_detail]
			   ([order_id]
			   ,[item_master_id]
			   ,[wh_id]
			   ,[order_number]
			   ,[line_number]
			   ,[item_number]
			   ,[bo_qty]
			   ,[bo_description]
			   ,[bo_weight]
			   ,[qty]
			   ,[afo_plan_qty]
			   ,[unit_pack]
			   ,[item_weight]
			   ,[item_tare_weight]
			   ,[haz_material]
			   ,[b_o_l_class]
			   ,[b_o_l_line1]
			   ,[b_o_l_line2]
			   ,[b_o_l_line3]
			   ,[b_o_l_plac_code]
			   ,[b_o_l_plac_desc]
			   ,[b_o_l_code]
			   ,[qty_shipped]
			   ,[line_type]
			   ,[item_description]
			   ,[stacking_seq]
			   ,[cust_part]
			   ,[lot_number]
			   ,[picking_flow]
			   ,[unit_weight]
			   ,[unit_volume]
			   ,[extended_weight]
			   ,[extended_volume]
			   ,[over_alloc_qty]
			   ,[date_expected]
			   ,[order_uom]
			   ,[host_wave_id]
			   ,[tran_plan_qty]
			   ,[use_shippable_uom]
			   ,[unit_insurance_amount]
			   ,[stored_attribute_id]
			   ,[cancel_flag]
			   ,[tax_rate]
			   ,[storage_location]
			   ,[price]
			   ,[price_uom]
			   ,[parent_line_number]
			   ,factory)
		 VALUES
			   (@order_id
			   ,NULL
			   ,@wh_id
			   ,@order_number
			   ,(SELECT ISNULL(MAX(cast(line_number as int)),0) + 1 as line_max from t_order_detail where wh_id = @wh_id and order_number = @order_number)
			   ,@item_number
			   ,0
			   ,NULL
			   ,0
			   ,@qty
			   ,0
			   ,NULL
			   ,0
			   ,0
			   ,NULL
			   ,NULL
			   ,NULL
			   ,NULL
			   ,NULL
			   ,NULL
			   ,NULL
			   ,NULL
			   ,0
			   ,NULL
			   ,NULL
			   ,NULL
			   ,NULL
			   ,@lot_number
			   ,NULL
			   ,0
			   ,0
			   ,0
			   ,0
			   ,0
			   ,@date_excepted
			   ,@order_uom
			   ,0
			   ,0
			   ,'N'
			   ,0
			   ,NULL
			   ,'N'
			   ,NULL
			   ,NULL
			   ,NULL
			   ,NULL
			   ,@line_number
			   ,(SELECT TOP 1 factory FROM t_po_detail
								WHERE wh_id = @wh_id
									AND po_number = @po_number))
		END
		ELSE
		BEGIN
			UPDATE t_order_detail
				SET order_uom = @order_uom
					,qty = @qty
					,lot_number = @lot_number
					,parent_line_number = @line_number
				WHERE order_detail_id = @ord_dtl_id
		END

		COMMIT
		RETURN
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0 
		BEGIN
			ROLLBACK TRANSACTION
		END
		IF ISNULL(@out_msg,'') = ''
		BEGIN
			SET @out_msg = ERROR_MESSAGE()
		END
		
		RAISERROR(@out_msg, 11, 1)
		RETURN
	END CATCH
END
