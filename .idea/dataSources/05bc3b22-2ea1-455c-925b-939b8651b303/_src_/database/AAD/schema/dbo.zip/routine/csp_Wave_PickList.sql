
--播种的单据按以区域为单位进行打印，不区分订单
--摘果的单据按区域、订单为单位进行打印
CREATE PROCEDURE [dbo].[csp_Wave_PickList] @wh_id NVARCHAR(10)
	,@wave_id NVARCHAR(30)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @pick_list NVARCHAR(30)
		,@next_value INTEGER
		,@v_vchOutMsg NVARCHAR(500)
		,@v_nErrorNumber INTEGER
		,@v_nSysErrorNum INTEGER
		,@seq INTEGER
		,@order_number NVARCHAR(30)
		,@zone NVARCHAR(30)
		,@type NVARCHAR(10)
		,@v_nRowCount INTEGER
		,@item_number NVARCHAR(30)
		,@customer_id NVARCHAR(30)
		,@list_number NVARCHAR(30)
		,@client_code NVARCHAR(30)
		,@count  INTEGER
		,@remain_count  BIGINT
		,@item_count  BIGINT
		,@v_item_count  VARCHAR(10)

	SET @item_number=''
	SET @customer_id=''

	CREATE TABLE #temp_picktype (
		seq_id SMALLINT IDENTITY(1, 1) NOT NULL
		,wh_id NVARCHAR(10)
		,wave_id NVARCHAR(30)
		,order_number NVARCHAR(30)
		,zone NVARCHAR(30)
		,type NVARCHAR(10)
		)

	--Lij实施，ZouHua提供 2015年11月27日01:01:15 加入创建临时表索引
	CREATE CLUSTERED INDEX PK_temp_picktype ON #temp_picktype (seq_id)

	CREATE NONCLUSTERED INDEX IX_temp_picktype_wh_id ON #temp_picktype (
		wave_id
		,wh_id
		)

	CREATE TABLE #temp_picklist (
		seq_id SMALLINT IDENTITY(1, 1) NOT NULL
		,list_number NVARCHAR(30)
		,client_code NVARCHAR(30)
		,item_number NVARCHAR(30)
		,pick_seq    NVARCHAR(50)
		)

	BEGIN TRY
		INSERT INTO #temp_picktype (
			wh_id
			,wave_id
			,order_number
			,zone
			,type
			)
		SELECT DISTINCT wh_id
			,wave_id
			,CASE allo_type
				WHEN 'S'
					THEN NULL
				ELSE order_number
				END AS order_number
			,zone
			,allo_type
		FROM tbl_allocation WITH (NOLOCK)
		WHERE wh_id = @wh_id
			AND wave_id = @wave_id 
			AND allo_type in ('S','O')
		ORDER BY wh_id
			,wave_id
			,zone
			,allo_type

		SELECT @seq = 0

		WHILE (1 = 1)
		BEGIN
			SELECT TOP 1 @seq = seq_id
				,@order_number = order_number
				,@zone = zone
				,@type = type
			FROM #temp_picktype
			WHERE wh_id = @wh_id
				AND wave_id = @wave_id
				AND seq_id > @seq
			ORDER BY seq_id

			SELECT @v_nErrorNumber = @@ERROR
				,@v_nRowCount = @@ROWCOUNT

			IF @v_nErrorNumber <> 0
			BEGIN
				BREAK
			END

			IF @v_nRowCount = 0
			BEGIN
				BREAK
			END

			EXEC usp_get_next_value 'PICK_LIST'
				,@next_value OUTPUT
				,@v_nErrorNumber OUTPUT
				,@v_vchOutMsg OUTPUT

			INSERT INTO tbl_pick_list (
				[list_number]
				,[seq_id]
				,[wave_id]
				,[order_number]
				,[pick_id]
				,[item_number]
				,[lot_number]
				,[stored_attribute_id]
				,[location_id]
				,[hu_id]
				,[allocated_qty]
				,[picked_qty]
				,[status]
				,[released_date]
				,[ref_number]
				,[pick_wall_loc]
				,[pick_wall_slot]
				,[pick_conveyor_node]
				,[zone]
				,[wh_id]
				,[user_assign]
				,[line_number]
				,[shipping_label]
				,[picking_flow]
				,[type]
				,[damage_flag]
				)
			SELECT @next_value
				,[seq_id]
				,[wave_id]
				,[order_number]
				,[pick_id]
				,[item_number]
				,[lot_number]
				,[stored_attribute_id]
				,[location_id]
				,[hu_id]
				,[allocated_qty]
				,[picked_qty]
				,[status]
				,[released_date]
				,[ref_number]
				,[pick_wall_loc]
				,[pick_wall_slot]
				,[pick_conveyor_node]
				,[zone]
				,[wh_id]
				,[user_assign]
				,[line_number]
				,[shipping_label]
				,[picking_flow]
				,[allo_type]
				,[damage_flag]
			FROM tbl_allocation WITH (NOLOCK)
			WHERE wave_id = @wave_id
				AND wh_id = @wh_id
				AND allo_type = @type
				AND zone = @zone
				AND ISNULL(location_id,'')<>''
				AND ISNULL(@order_number, '') = CASE 
					WHEN ISNULL(@order_number, '') = ''
						THEN ISNULL(@order_number, '')
					ELSE order_number
					END
				AND NOT EXISTS (
					SELECT 'x'
					FROM tbl_pick_list WITH (NOLOCK)
					WHERE seq_id = tbl_allocation.seq_id
						AND wave_id = tbl_allocation.wave_id
					)
		END

		--Delete by George 20160730
		--WHILE (1 = 1)
		--BEGIN
		--	SELECT TOP 1 @item_number = item_number
		--	FROM tbl_pick_list
		--	WHERE wh_id = @wh_id
		--		AND wave_id = @wave_id
		--		AND type = 'S' 
		--		AND ISNULL(shipping_label,'') =''
		--		AND item_number > @item_number
		--	ORDER BY item_number ASC

		--	IF @@ROWCOUNT = 0
		--		BREAK

		--	EXEC usp_get_next_value 'HU_ID'
		--		,@next_value OUTPUT
		--		,@v_nErrorNumber OUTPUT
		--		,@v_vchOutMsg OUTPUT

		--	UPDATE tbl_pick_list
		--	SET shipping_label = @next_value,released_date=GETDATE()
		--	WHERE wh_id = @wh_id
		--		AND wave_id = @wave_id
		--		AND item_number = @item_number
		--		AND type = 'S'
		--		AND ISNULL(shipping_label,'') =''
		--END
		--Delete by George 20160730

		--Add by George 20160730
		SELECT @v_item_count = item_count 
		FROM t_wave_master 
		WHERE wh_id = @wh_id
			AND wave_id = @wave_id

		IF ISNULL(@v_item_count,'')='' or @v_item_count='ALL'
			SET @item_count=999999
		ELSE
			SET @item_count=CAST(@v_item_count AS BIGINT)
		
		INSERT INTO #temp_picklist (
				list_number 
				,client_code 
				,item_number 
				,pick_seq
		)
		SELECT list_number 
				,im.client_code 
				,pl.item_number 
				,MIN(zl.pick_seq+zl.location_id) as pick_seq
			FROM tbl_pick_list pl 
			INNER JOIN t_item_master im on pl.wh_id=im.wh_id and pl.item_number=im.item_number
			INNER JOIN t_zone_loca zl on pl.wh_id=zl.wh_id and pl.location_id=zl.location_id
			WHERE pl.wh_id = @wh_id
				AND pl.wave_id = @wave_id
				AND type = 'S' 
				AND ISNULL(shipping_label,'') =''
			GROUP BY list_number,im.client_code,pl.item_number 
		
		SET @list_number=''

		WHILE (1 = 1)
		BEGIN
			SELECT TOP 1 @list_number = list_number
			FROM #temp_picklist
			WHERE list_number > @list_number
			ORDER BY list_number ASC

			IF @@ROWCOUNT = 0
				BREAK

			SET @client_code=''

			WHILE (1 = 1)
			BEGIN
				SELECT TOP 1 @client_code = client_code
				FROM #temp_picklist
				WHERE list_number = @list_number
					AND client_code>@client_code
				ORDER BY client_code ASC

				IF @@ROWCOUNT = 0
					BREAK

				SET @count=0

				WHILE (1 = 1)
				BEGIN
					SELECT TOP 1 @item_number = item_number
					FROM #temp_picklist
					WHERE list_number = @list_number 
						AND client_code = @client_code
					ORDER BY pick_seq ASC

					IF @@ROWCOUNT = 0
						BREAK

					IF @count=@item_count
					BEGIN
						SELECT @remain_count = count(1)
						FROM #temp_picklist
						WHERE list_number = @list_number 
							AND client_code = @client_code

						IF (@remain_count%@item_count>4 and @remain_count/@item_count=0) or @remain_count/@item_count>=1
							SET @count = 0
					END
					
					IF @count = 0
					BEGIN
						EXEC usp_get_next_value 'HU_ID'
							,@next_value OUTPUT
							,@v_nErrorNumber OUTPUT
							,@v_vchOutMsg OUTPUT
					END

					UPDATE tbl_pick_list
					SET shipping_label = @next_value,released_date=GETDATE()
					WHERE wh_id = @wh_id
						AND wave_id = @wave_id
						AND item_number = @item_number
						AND list_number = @list_number
						AND type = 'S'
						AND ISNULL(shipping_label,'') =''

					DELETE FROM #temp_picklist 
					WHERE list_number = @list_number 
						AND client_code = @client_code
						AND item_number = @item_number

					SET @count=@count+1
				END
			END
		END
		--Add by George 20160730

		WHILE (1 = 1)
		BEGIN
			SELECT TOP 1 @customer_id = cast(isnull(od.customer_id,'0') as nvarchar(30))+lt.zone
			FROM tbl_pick_list lt
			INNER JOIN t_order od ON lt.wh_id = od.wh_id
				AND lt.order_number = od.order_number
			WHERE lt.wh_id = @wh_id
				AND lt.wave_id = @wave_id
				AND lt.type = 'O'
				AND ISNULL(shipping_label,'') =''
				AND cast(isnull(od.customer_id,'0') as nvarchar(30))+lt.zone > @customer_id
			ORDER BY cast(isnull(od.customer_id,'0') as nvarchar(30))+lt.zone ASC

			IF @@ROWCOUNT = 0
				BREAK

			EXEC usp_get_next_value 'HU_ID'
				,@next_value OUTPUT
				,@v_nErrorNumber OUTPUT
				,@v_vchOutMsg OUTPUT

			UPDATE lt
			SET lt.shipping_label = @next_value,released_date=GETDATE()
			FROM tbl_pick_list lt
			INNER JOIN t_order od ON lt.wh_id = od.wh_id
				AND lt.order_number = od.order_number
			WHERE lt.wh_id = @wh_id
				AND lt.wave_id = @wave_id
				AND lt.type = 'O'
				AND ISNULL(shipping_label,'') =''
				AND cast(isnull(od.customer_id,'0') as nvarchar(30))+lt.zone = @customer_id
		END

		DROP TABLE #temp_picktype

		RETURN
	END TRY

	BEGIN CATCH
		RETURN
	END CATCH
END
