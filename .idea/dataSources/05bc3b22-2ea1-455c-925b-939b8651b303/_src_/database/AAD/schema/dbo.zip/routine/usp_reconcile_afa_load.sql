
CREATE PROCEDURE usp_reconcile_afa_load
    @in_HostGroupID     NVARCHAR(36),
    @out_vchMessage     NVARCHAR(200) OUTPUT -- Contains "SUCCESS" or the message to be displayed.

AS

DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(2000),
    @v_vchOutMsg                NVARCHAR(2000),
    @v_nSysErrorNum             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @v_nTranCount               INT,

    -- Local Variables
    @v_nCount               INT,
    @v_nTableExists         INT,
    @v_vchWhID              NVARCHAR(10), 
    @v_vchOrderNumber       NVARCHAR(30),
    @v_vchLoadNumber        NVARCHAR(20),
    @v_vchLoadStatus        NVARCHAR(20)

    SET NOCOUNT ON
    SELECT @out_vchMessage = 'SUCCESS'
    SET @v_nCount = 0

    /*This section removes all related order information when an order is 
      is coded to be Deleted.  All records in t_afa_load_detail and t_afa_load_detail_line
      will be delete and wave will be put on hold only if the current order is the only 
      order on the wave.*/
    DECLARE cur_orders_to_delete SCROLL CURSOR FOR
        SELECT orm.wh_id, 
               orm.order_number,
               wm.load_id,
               wm.status
          FROM #tmp_missing_order orm
              JOIN t_afa_load_detail wvd ON
                    wvd.wh_id        = orm.wh_id
                AND wvd.order_number = orm.order_number
              JOIN t_load_master wm  ON
                    wvd.wh_id        = wm.wh_id
                AND wvd.load_id      = wm.load_id
        
  
      OPEN cur_orders_to_delete
      FETCH NEXT FROM cur_orders_to_delete INTO @v_vchWhID, @v_vchOrderNumber, @v_vchLoadNumber, @v_vchLoadStatus
      
      WHILE @@FETCH_STATUS = 0
      BEGIN
          IF @v_vchLoadStatus = 'R'
              UPDATE t_load_master 
			     SET status = 'H'

          IF (SELECT COUNT(order_number) 
                FROM t_afa_wave_detail
               WHERE load_id = @v_vchLoadStatus) = 1
              BEGIN
     			  -- TODO: Set parameter values here.
				  EXECUTE @v_nReturn = usp_afa_hold_shipment  @v_vchWhID, @v_vchLoadNumber, @v_vchOutMsg OUTPUT
			  END

          --Remove all order master and detail records from wave.
          EXECUTE @v_nReturn = usp_afa_remove_order_data @v_vchOrderNumber, @v_vchWhID, @v_vchLoadNumber, @v_vchOutMsg OUTPUT 

          IF (SELECT COUNT(order_number) 
                FROM t_afa_load_detail
               WHERE load_id = @v_vchLoadStatus) > 0 AND @v_vchLoadStatus = 'R'
              BEGIN
     			  UPDATE t_load_master 
			        SET status = 'R'
			  END
          --Get next row in cursor.
          FETCH NEXT FROM cur_orders_to_delete INTO @v_vchWhID, @v_vchOrderNumber, @v_vchLoadNumber, @v_vchLoadStatus
      END

      CLOSE cur_orders_to_delete
      DEALLOCATE cur_orders_to_delete
    GoTo ExitLabel
    

ErrorHandler:
    -- Log the error message in ADV.t_log
    EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)
    SELECT @out_vchMessage = 'FAILURE'
    SET @v_nReturn = @v_nLogErrorNum



ExitLabel:
    -- Always leave the stored procedure from here.
    RETURN 

