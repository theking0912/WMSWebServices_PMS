


-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Return Receiving by LP   
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Upd_Slot_Full]    
     @wh_id					NVARCHAR(10)  
	,@fork_id				Nvarchar(30)
	,@slot					Nvarchar(30)
	,@source_hu_id			Nvarchar(30)
	,@user_id				nvarchar(30)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @hu_id			nvarchar(30)
		DECLARE @description	nvarchar(30)
		DECLARE @ref_number		nvarchar(30)

		set @description = 'Set slot to full.'

		select @hu_id = hu_id,@ref_number=ref_number
		from tbl_fork_slot
		where wh_id = @wh_id
		and fork_id = @fork_id
		and fork_slot_id = @slot

		update tbl_fork_slot
		set slot_status = 'F'
		where wh_id = @wh_id
		and fork_id = @fork_id
		and fork_slot_id = @slot 

		--Create tran log
		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
			,wh_id_2,location_id_2,hu_id_2
			,generic_attribute_1,
			generic_attribute_2,
			generic_attribute_3,
			generic_attribute_4,
			generic_attribute_5,
			generic_attribute_6,
			generic_attribute_7,
			generic_attribute_8,
			generic_attribute_9,
			generic_attribute_10,
			generic_attribute_11)
		VALUES
			('301',@description,getdate(),getdate(),getdate(),getdate(),@user_id,@ref_number,@slot
			,'',@fork_id,@hu_id,'','',0
			,@wh_id,'',''
			,null
			,null   
    		,null
			,null
			,null
			,null
			,null
			,null
			,null
			,null
			,null
			)

        RETURN

    END TRY

    BEGIN CATCH

        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    



