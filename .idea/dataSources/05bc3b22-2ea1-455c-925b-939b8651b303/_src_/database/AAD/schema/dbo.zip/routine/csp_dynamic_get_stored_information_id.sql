
CREATE procedure [dbo].[csp_dynamic_get_stored_information_id]
(
    @in_vchWhID	                NVARCHAR(10),
    @in_vchItemID               NVARCHAR(30),
    @in_vchEmpID                NVARCHAR(30),
    @in_vchIdentifier           VARCHAR(36) ,
    @out_nStored_Information_ID   BIGINT OUTPUT
)
AS


DECLARE
-- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nSysErrorNum             INT,
    @v_nSysRowCount             INT,
    @v_nReturn                  INT,
    @v_nCount                   INT,


  -- Log Error numbers used for branching in the Error Handler.
    @e_GenSqlError               INT,
    @e_SprocError                INT,
    @e_CollectionNotBelongToItem INT,
    @e_NotDataInTable            INT,
   
  -- Local variables	
    @v_nOrigNoCountState       INT,
    @v_nInformationCollectionId  INT,	
    @v_nCountStoredCollection  INT,
    @v_nGetIDCollection        BIGINT,
    @v_nchPlaceHolder          VARCHAR(36)
  
DECLARE -- checksum variables
    @v_vchAuxStr               NVARCHAR(3000),
    @v_vchQryStr               NVARCHAR(4000),
    @v_vchParamStr             NVARCHAR(1000),
    @v_nChecksum               INT


-- Set Constants
SET @c_nModuleNumber = 60     -- Always #60 for WA.
SET @c_nFileNumber = 15        -- This # must be unique per object.
SET @c_vchObjName = 'csp_dynamic_get_stored_attribute_id'

-- Log/Local Error Constants
SET @e_GenSqlError = 1
SET @e_SprocError = 2
SET @e_CollectionNotBelongToItem  = 3
SET @e_NotDataInTable = 4

-- Intialize Variables
SET @v_nReturn = 0
SET @v_nGetIDCollection = NULL

-- SET NOCOUNT to ON to no longer display the count message.
-- Save the current state so we can restore it at the end of
-- this procedure.
SET @v_nOrigNoCountState = @@OPTIONS & 512
-- 0 if NOCOUNT is off, 512 if on
IF @v_nOrigNoCountState = 0
	SET NOCOUNT ON




EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
IF @v_nReturn <> 0 -- A zero means success.
	BEGIN
		SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
    		ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
		SET @v_nLogErrorNum = @e_SprocError
		GOTO ERROR_HANDLER
	END
/*
 EXECUTE @v_nReturn = usp_clear_emp @in_vchWhID, @in_vchEmpID
    IF @v_nReturn <> 0
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
    	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ERROR_HANDLER
    END
*/

-- Body of procedure...

-- Check exceptions on the data entered by the user
 --BEGIN TRANSACTION
 --        DELETE FROM tbl_user_entered_information 
 --        WHERE tbl_user_entered_information.identifier = @in_vchIdentifier
 --          AND tbl_user_entered_information.information_id IN ( SELECT information_id 
	--						 FROM tbl_information_exception_control 
	--						 WHERE item_number = @in_vchItemID
	--						   AND wh_id = @in_vchWhID
	--						   AND information_id = tbl_user_entered_information.information_id
	--	  					   AND information_control <> 'F' )
 --          AND ISNULL(tbl_user_entered_information.information_value,'') = ''
           
 --        SELECT @v_nSysErrorNum = @@ERROR
 --        IF @v_nSysErrorNum <> 0
	--	BEGIN
	--		ROLLBACK
	--		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
	--				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
	--		SET @v_nLogErrorNum = @e_GenSqlError
	--		GOTO ERROR_HANDLER
	--	END 
 --COMMIT

-- Get the collection  collection assigned to the item
 SELECT @v_nInformationCollectionId = information_collection_id 
   FROM t_item_master WHERE item_number = @in_vchItemID AND wh_id = @in_vchWhID

-- Check if the collection is empty
IF ISNULL(@v_nInformationCollectionId,'') = ''
	BEGIN
--	   SET @v_vchErrorMsg = @c_vchObjName + ': Not found a collection that belong to the item [' + @in_vchItemID + 
--                             '] in the t_item_master table for the warehouse [' + @in_vchWhID + ']'
--	   SET @v_nLogErrorNum = @e_CollectionNotBelongToItem
--	   GOTO ERROR_HANDLER
	   SET @out_nStored_Information_ID = NULL --Formerly considered as error 
	   GOTO EXIT_LABEL
	END

-- Check the table with the user entered values

SELECT @v_nSysRowCount = COUNT(*) FROM tbl_user_entered_information WHERE identifier = @in_vchIdentifier
SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
                + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
    END
IF @v_nSysRowCount = 0
	BEGIN
--	   SET @v_vchErrorMsg = @c_vchObjName + ': The table t_user_entered_attributes for the identifier [' + @in_vchIdentifier +
--					'] not has data'
--	   SET @v_nLogErrorNum = @e_NotDataInTable
--	   GOTO ERROR_HANDLER
	   SET @out_nStored_Information_ID = NULL --Formerly considered as error 
	   GOTO EXIT_LABEL
	END
	
	
-- calculating checksum of the attribute values ordered by attribute_id
SET @v_vchAuxStr = N''

SELECT @v_vchAuxStr = @v_vchAuxStr + '''' + information_value + ''',' 
FROM tbl_user_entered_information tea
WHERE tea.information_value IS NOT NULL
  AND tea.information_id is NOT NULL
  AND tea.identifier = @in_vchIdentifier
ORDER BY tea.information_id ASC


SELECT @v_vchAuxStr = SUBSTRING(@v_vchAuxStr,1,LEN(@v_vchAuxStr)-1)
SELECT @v_vchQryStr = N'select @chksum = checksum('+@v_vchAuxStr+')'
SELECT @v_vchParamStr = N'@chksum int OUTPUT'

EXECUTE sp_executesql @v_vchQryStr, @v_vchParamStr,  @chksum = @v_nChecksum OUTPUT
-- end of checksum calculation


  -- Count if there are stored collection that can match with user entered values
  SELECT  @v_nCountStoredCollection = COUNT( stored_information_id )
	FROM  tbl_sto_information_collection_master 
	WHERE information_collection_id = @v_nInformationCollectionId
      
SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
	END

	  
IF @v_nCountStoredCollection > 0 
BEGIN
    -- Execute a dinamic qury 
--    EXECUTE  @v_nReturn = usp_dynamic_query_builder @v_nAtrributeCollectionId, @v_nMaxSeqCollection, @in_vchIdentifier, @v_nGetIDCollection OUTPUT
    EXECUTE  @v_nReturn = csp_dynamic_query_builder @v_nInformationCollectionId, @v_nChecksum, @in_vchIdentifier, @v_nGetIDCollection OUTPUT
    IF @v_nReturn <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
	END
END

BEGIN TRANSACTION

IF (@v_nGetIDCollection IS NULL)
	BEGIN
	   --SET @v_nchPlaceHolder = NEWID()  
	   
	   -- Create a new stored collection 
           INSERT INTO tbl_sto_information_collection_master 
                (information_collection_id, detail_checksum)
           VALUES (@v_nInformationCollectionId, @v_nChecksum)

           SELECT @v_nGetIDCollection = SCOPE_IDENTITY()

	   SELECT @v_nSysErrorNum = @@ERROR
	   IF @v_nSysErrorNum <> 0
		 BEGIN
		   SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		   SET @v_nLogErrorNum = @e_GenSqlError
		   GOTO ERROR_HANDLER
		 END
		 
	   -- Insert the detail of the stored collection
	   INSERT INTO tbl_sto_information_collection_detail (stored_information_id,information_id,information_value)   
	   SELECT @v_nGetIDCollection, 
			  information_id,
			  information_value
	   FROM tbl_user_entered_information
           WHERE identifier = @in_vchIdentifier 
             AND information_value IS NOT NULL
             AND information_id IS NOT NULL

	   SELECT @v_nSysErrorNum = @@ERROR
	   IF @v_nSysErrorNum <> 0
		 BEGIN
		   SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		   SET @v_nLogErrorNum = @e_GenSqlError
		   GOTO ERROR_HANDLER
		 END   

	END

SET @out_nStored_Information_ID = @v_nGetIDCollection
    

DELETE FROM tbl_user_entered_information WHERE identifier = @in_vchIdentifier
SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
 BEGIN
   SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
		+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
   SET @v_nLogErrorNum = @e_GenSqlError
   GOTO ERROR_HANDLER
 END   


GOTO EXIT_LABEL
-----------------------------------------------------------------------------------
--                            Error Handling Code
-----------------------------------------------------------------------------------
ERROR_HANDLER:

----------------------------------------------------------------------------------------------------
-- Delete these comments, they are only reminders...
-- Add each log message to the ...\RequiredData\InsertLogMap.sql script.
----------------------------------------------------------------------------------------------------
    --Roll back transaction if some error occurred    
    IF @@TRANCOUNT > 0
       ROLLBACK TRANSACTION

    -- Reset NOCOUNT
    IF @v_nOrigNoCountState = 0
       SET NOCOUNT OFF

    -- Log the error message in ADV.t_log
    -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)


-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

IF @@TRANCOUNT > 0
	COMMIT TRANSACTION

-- Reset NOCOUNT
IF @v_nOrigNoCountState = 0
    SET NOCOUNT OFF

-- Always leave the stored procedure from here.
RETURN
