CREATE  procedure [dbo].[csp_Add_Wave_Queue]
 (
   @wh_id nvarchar(10),
   @queue_data nvarchar(100),
   @queue_class nvarchar(10),
   @priority int
  ) as
  BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY

		BEGIN TRANSACTION
		
		insert into tbl_wave_queue
		(wh_id,queue_data,queue_class,priority,date_add)
		values(@wh_id,@queue_data,@queue_class,@priority,getdate())

		COMMIT		
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        RETURN
    END CATCH
  
END
