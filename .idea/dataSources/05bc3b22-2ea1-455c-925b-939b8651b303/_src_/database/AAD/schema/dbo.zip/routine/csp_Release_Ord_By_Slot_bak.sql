-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create  PROCEDURE [dbo].[csp_Release_Ord_By_Slot_bak]
	@in_wh_id					AS	NVARCHAR(30),
	@in_order_number			AS	NVARCHAR(30),
	@in_slot					AS	NVARCHAR(30),
	@Out_Nvch_Err_Code			AS	NVARCHAR(1)			OUTPUT,
	@Out_Nvch_Err_Msg			AS	NVARCHAR(200)		OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY

		BEGIN TRANSACTION
    -- Insert statements for procedure here
	-- release the slot
	DELETE FROM tbl_pick_wall_slot_detail
			WHERE wh_id = @in_wh_id
			AND	order_number = @in_order_number
			AND slot = @in_slot

	UPDATE tbl_pick_wall_slot
		SET status = 'U',
			ship_label_barcode = '',
			order_number = ''
		WHERE wh_id = @in_wh_id
		AND slot = @in_slot
		AND NOT EXISTS( SELECT 1 FROM tbl_pick_wall_slot_detail
							WHERE wh_id = @in_wh_id
								AND slot = @in_slot)

	
	-- update order status
	UPDATE t_order
		SET status = 'LOADED'
		WHERE wh_id = @in_wh_id
		AND order_number = @in_order_number
		AND EXISTS(SELECT 1 FROM t_pick_detail
						WHERE wh_id = @in_wh_id
							AND order_number = @in_order_number
							AND planned_quantity = loaded_quantity)

	SET @Out_Nvch_Err_Code = 0
	COMMIT
	RETURN

	END TRY
	BEGIN CATCH
		ROLLBACK
		-- sp error
		SET @Out_Nvch_Err_Code = 1
		SET @Out_Nvch_Err_Msg = ERROR_MESSAGE()
		RETURN
	END CATCH
END
