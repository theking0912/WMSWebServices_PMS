-- Function
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Check_CancelOrder_For_PTW] 
(
	@Wh_id								AS	NVARCHAR(30),
	@order_number						AS	NVARCHAR(30)
)
RETURNS NVARCHAR(1)
AS
BEGIN
	DECLARE @rtn nvarchar(1)  -- 0: can be canceled 1:can not be canceled
	DECLARE @sorted_qty float
	DECLARE @order_qty float
	DECLARE @error_qty float
	set @rtn = '0' 

	if exists(select 1 from t_order a , t_client b
					where a.wh_id = b.wh_id
					and a.client_code = b.client_code
					and b.client_type = 'B'
					and a.wh_id = @wh_id
					and a.order_number = @order_number)
	begin
		set @rtn = '1' 
		return @rtn;
	end

	if not exists(select 1
			from tbl_allocation
			where order_number = @order_number
			and wh_id = @wh_id
			and status = 'E')
	begin
		set @rtn = '1' 
		return @rtn;
	end

	if exists(select 1
			from tbl_allocation
			where order_number = @order_number
			and wh_id = @wh_id
			and status not in ('C','E'))
	begin
		set @rtn = '1' 
		return @rtn;
	end

	select @sorted_qty = sum(qty) 
	from tbl_if_tote_ptl 
	where wh_id = @wh_id
	and order_number = @order_number

	set @sorted_qty = isnull(@sorted_qty,0)
	--select * from t_order_detail
	select @order_qty = sum(qty) 
	from t_order_detail 
	where wh_id = @wh_id
	and order_number = @order_number

	set @order_qty = isnull(@order_qty,0)

	select @error_qty = isnull(sum(allocated_qty-picked_qty) ,0)
	from tbl_allocation 
	where wh_id = @wh_id
	and order_number = @order_number
	and status = 'E'

	set @error_qty = isnull(@error_qty,0)

	if @order_qty = 0
	begin
		set @rtn = '1' 
		return @rtn;
	end

	if @sorted_qty + @error_qty < @order_qty
	begin
		set @rtn = '1' 
		return @rtn;
	end

	set @rtn = '0'
	 
	RETURN @rtn	 

END
