


-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Return Receiving by LP   
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Bind_Release_Log]    
     @wh_id					NVARCHAR(10)  
	,@hu_id					Nvarchar(30)
	,@fork_id				Nvarchar(30)
	,@user_id				nvarchar(30)
	,@tran_type				nvarchar(20)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @pick_id		bigint
		DECLARE @allocated_qty	float
		DECLARE @picked_qty		float
		DECLARE @seq_id			bigint
		DECLARE @remove_qty		float
		DECLARE @order_number	nvarchar(30)
		DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
		DECLARE @ref_number		nvarchar(30)
		DECLARE @shiping_label	nvarchar(30)
		DECLARE @description	nvarchar(30)

		if(@tran_type = 'R')
		set @description = 'Release tote'
		else
		set @description = 'Bind tote'

		--Create tran log
		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
			,wh_id_2,location_id_2,hu_id_2
			,generic_attribute_1,
			generic_attribute_2,
			generic_attribute_3,
			generic_attribute_4,
			generic_attribute_5,
			generic_attribute_6,
			generic_attribute_7,
			generic_attribute_8,
			generic_attribute_9,
			generic_attribute_10,
			generic_attribute_11)
		VALUES
			('301',@description,getdate(),getdate(),getdate(),getdate(),@user_id,'',''
			,'',@fork_id,@hu_id,'','',0
			,@wh_id,'',''
			,null
			,null   
    		,null
			,null
			,null
			,null
			,null
			,null
			,null
			,null
			,null
			)

        RETURN

    END TRY

    BEGIN CATCH

        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    



