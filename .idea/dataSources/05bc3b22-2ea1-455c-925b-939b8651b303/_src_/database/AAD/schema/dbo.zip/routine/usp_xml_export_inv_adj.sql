
CREATE PROCEDURE [dbo].[usp_xml_export_inv_adj]
	(
		 @v_vchHostGroupID		NVARCHAR(36)
		,@out_vchCode           uddt_output_code   OUTPUT
		,@out_vchMsg            uddt_output_msg    OUTPUT
	)
	
AS

-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                            HighJump Software
--                        Minneapolis, Minnesota, USA
-- ********************************************************************************
--
--  The purpose of this stored procedure is to populate records into XML Staging Tables 
--  from GHI tables for Inventory Adjustment
--
--  Notes:
--	
--  Input:
--      See parameter list.
--	
--  Output:
--	    Return Code
--
--  Uses:
--	    Table(s) - 
--        t_xml_exp_export_adjustment
--        t_xml_exp_inv_adj
--		  
--
--  Target:
--	    SQL Server 
--
--
-- ********************************************************************************	
DECLARE

----------------------------------------------------------------------------------------------------------------------------	
-- Procedure variables
----------------------------------------------------------------------------------------------------------------------------
		
	@v_dtRecordCreateDate		DATETIME
	
		
----------------------------------------------------------------------------------------------------------------------------	
-- Local Variables
----------------------------------------------------------------------------------------------------------------------------
	,@c_vchObjName               uddt_obj_name	 	
	,@v_nSysErrorNum			INT
	,@v_vchMsg					NVARCHAR(4000)
    ,@v_vchCode					NVARCHAR(10)
    ,@v_nRetryCount				INT
	,@v_nTranCount				INT	
	,@v_nXstate					INT


SET NOCOUNT ON

----------------------------------------------------------------------------------------------------------------------------	
-- Set Constants
----------------------------------------------------------------------------------------------------------------------------

SET @c_vchObjName = N'usp_xml_export_inv_adj'
SET @v_vchCode = N'SUCCESS'
SET @v_vchMsg  = N'NONE'
SET @v_nSysErrorNum = 0
SET @v_nTranCount = 0

----------------------------------------------------------------------------------------------------------------------------	
-- Insert XML staging Records
----------------------------------------------------------------------------------------------------------------------------

SET @v_dtRecordCreateDate = GETDATE()	
SET @v_nRetryCount = 3


INS_AL:

BEGIN TRY

    SET @v_nTranCount = @@TRANCOUNT   
	
	IF @v_nTranCount = 0 
        BEGIN TRANSACTION 
    ELSE 
        SAVE TRANSACTION SAVEPOINT
		
    SET XACT_ABORT ON
	
	------------------------------------------------------------------------------------
	--		INSERT INTO t_xml_exp_export_adjustment
	------------------------------------------------------------------------------------
		INSERT INTO t_xml_exp_export_adjustment(
			 hjs_parent_id
			,hjs_node_id
			,hjs_sequence							
			)
		SELECT DISTINCT
			 adj.host_group_id
			,adj.host_group_id
			,0			
		 FROM t_al_host_inventory_adjustment adj WITH (NOLOCK)
		WHERE adj.host_group_id = @v_vchHostGroupID
		
	------------------------------------------------------------------------------------
	--		INSERT INTO t_xml_exp_inv_adj
	------------------------------------------------------------------------------------
		INSERT INTO t_xml_exp_inv_adj(
			 hjs_parent_id
			,hjs_node_id
			,hjs_sequence
			,WarehouseID
			,ItemNumber
			,DisplayItemNumber
			,ClientCode
			,TranCode
			,QuantityBefore
			,QuantityAfter
			,QuantityChanged
			,StatusBefore
			,StatusAfter
			,ReasonCode
			,Location
			,KitReference
			,UserID
			,HUID
			,LotNumber
			,Attribute1
			,Attribute2
			,Attribute3
			,Attribute4
			,Attribute5
			,Attribute6
			,Attribute7
			,Attribute8
			,Attribute9
			,Attribute10
			,Attribute11			
			)
		SELECT
			 adj.host_group_id
			,NEWID()
			,0
			,adj.wh_id
			,adj.item_number
			,adj.display_item_number
			,adj.client_code
			,adj.transaction_code
			,adj.quantity_before
			,adj.quantity_after
			,adj.quantity_change
			,adj.inventory_status_before
			,adj.inventory_status_after
			,adj.reason_code
			,adj.from_location_id
			,adj.reference_code
			,adj.user_id
			,adj.hu_id
			,adj.lot_number
			,adj.gen_attribute_value1
			,adj.gen_attribute_value2
			,adj.gen_attribute_value3
			,adj.gen_attribute_value4
			,adj.gen_attribute_value5
			,adj.gen_attribute_value6
			,adj.gen_attribute_value7
			,adj.gen_attribute_value8
			,adj.gen_attribute_value9
			,adj.gen_attribute_value10
			,adj.gen_attribute_value11
		 FROM t_al_host_inventory_adjustment adj WITH (NOLOCK)
		WHERE adj.host_group_id = @v_vchHostGroupID
		 
	COMMIT TRANSACTION
	
	SET XACT_ABORT OFF		
	
END TRY
 
BEGIN CATCH  

    SET @v_nSysErrorNum = ERROR_NUMBER()
	SET @v_nTranCount = @@TRANCOUNT
	SET @v_nXstate = XACT_STATE()  
  
	IF @v_nXstate = -1 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount = 0 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount > 0 
        ROLLBACK TRANSACTION SAVEPOINT   

		
	-- Check for Deadlock and Retry as long as the Retry Counter is greater than zero  
    IF (@v_nRetryCount > 0 AND @v_nSysErrorNum = 1205) 
	BEGIN
		SET @v_nRetryCount = @v_nRetryCount - 1
		SET XACT_ABORT OFF;	
		GOTO INS_AL
	END

	
	SET @v_vchCode = N'-20001'    
    SET @v_vchMsg = N'A SQL error occured while inserting t_xml_exp records for Inv Adjustment Export.'	
	SET @v_vchMsg = @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE()
	GOTO ERROR_HANDLER
	
END CATCH

GOTO EXIT_LABEL
	
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
--Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
--within the message string.
	IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + N'Deadlock error: 40001 ' + @v_vchMsg
    ELSE    
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + @v_vchMsg 
		
    --Should only raise error in the parent sproc
    RAISERROR(@v_vchMsg, 11, 1)
    
    -- Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg
    
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

-- Always leave the stored procedure from here.
RETURN 
