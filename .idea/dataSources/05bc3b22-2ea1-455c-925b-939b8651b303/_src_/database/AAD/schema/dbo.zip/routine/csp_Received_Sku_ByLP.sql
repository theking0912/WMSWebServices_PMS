
-- Batch submitted through debugger: SQLQuery6.sql|7|0|C:\Users\DEV01\AppData\Local\Temp\4\~vs41D1.sql


-- Procedure
-- =======================================    
-- Author: Laver.hu    
-- Create Date: 2014-07-09   
-- Description: Return Receiving by LP   
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Received_Sku_ByLP]    
     @wh_id					NVARCHAR(10)    
    ,@control_number		NVARCHAR(30) --shipment number/receipt id  
	,@control_number_2		NVARCHAR(30) --po number  
	,@item_number			Nvarchar(30)
	,@lot_number			Nvarchar(30)
	,@stored_attribute_id	Nvarchar(30)
	,@expiration_date		datetime
	,@discount_qty			float
	,@qty					float
	,@hu_id					Nvarchar(30)
	,@location_id			Nvarchar(30)
	,@type					Nvarchar(30) --D:Damage;  N:Normal
	,@user_id				nvarchar(30)
	,@tran_type				nvarchar(30)
	,@tran_description		nvarchar(50)
	--,@ciq_number			nvarchar(50)
	,@item_type				NVARCHAR(10)	--A:联产品 B:副产品 空：成品
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @zone_group			NVARCHAR(30)
		DECLARE @po_number			NVARCHAR(30)
		DECLARE @line_number		NVARCHAR(30)
		DECLARE @scheduler_number	NVARCHAR(30)
		DECLARE @received_qty		FLOAT
		DECLARE @expected_qty		FLOAT
		DECLARE @rcpt_qty			FLOAT
		DECLARE @total_rcpt_qty		FLOAT
		DECLARE @vendor				NVARCHAR(30)
		DECLARE @vendor1		    NVARCHAR(30)-------will add
		DECLARE @client_code		NVARCHAR(30)
		DECLARE @display_po_number	NVARCHAR(30)
		DECLARE @damage_flag		NVARCHAR(1) = 'N' -- Normal=0, Damage>0
		DECLARE @zone				NVARCHAR(10)
		DECLARE @sap_order_tpy		NVARCHAR(20)
		DECLARE @order_type			NVARCHAR(10)
		DECLARE @relation_order_number NVARCHAR(30)
		DECLARE @date_posting		DATETIME
		DECLARE @col1               NVARCHAR(250)  
		DECLARE @col2               NVARCHAR(250)  
		DECLARE @col3               NVARCHAR(250) 
		DECLARE @col4               NVARCHAR(250)  
		DECLARE @col5               NVARCHAR(250)  
		DECLARE @col6               NVARCHAR(250)  
		DECLARE @col7               NVARCHAR(250)  
		DECLARE @col8               NVARCHAR(250)  
		DECLARE @col9               NVARCHAR(250)  
		DECLARE @col10              NVARCHAR(250)  
		DECLARE @col11              NVARCHAR(250)
		DECLARE @production_date	DATETIME
		DECLARE @uom_convert		int 
		declare @qty_po				float

		IF @type = 'D'
			SET @damage_flag = 'Y'

		SET @total_rcpt_qty = @qty
		
		SET @expiration_date = CASE @expiration_date WHEN '01/01/1900' THEN NULL ELSE @expiration_date END 
		IF  @expiration_date IS NOT NULL AND @expiration_date <> '01/01/1900' AND @lot_number IS NULL
		begin
		SET @lot_number = CONVERT(NVARCHAR,@expiration_date,112)
        -- select @vendor1=po.vendor_code from t_po_master po  where exists(select ven.vendor_code from t_vendor ven)and po.po_number=@control_number_2
		--SET @lot_number =@lot_number+@vendor1 
		end  -------------will   add
		select top 1 @uom_convert = ta.conversion_factor,@qty_po=tb.qty
			from t_item_uom ta,t_po_detail tb,t_rcpt_ship_po_detail tc
			where ta.item_number = tb.item_number
			  and tb.po_number = tc.po_number
			  and tb.item_number = tc.item_number
			  and tb.line_number = tc.line_number
			and ta.uom = tb.order_uom
			and tc.shipment_number = @control_number
			and tb.item_number = @item_number

		--if @discount_qty/isnull(@uom_convert,1) >99999
		--BEGIN
		--	SET @msg = '让步数量过大!'
		----	SET @msg = ERROR_MESSAGE()
		--    SET @passornot = 1
		--	return
		--	--RAISERROR (66666, -- Message id.   
		--	--			16, -- Severity,   
		--	--			1 -- State,   
		--	--			) 

		--END

		if @discount_qty>CAST(isnull(@uom_convert,1)*@qty_po AS int)*0.3
		BEGIN
			SET @msg = '让步数量过大!'
		--	SET @msg = ERROR_MESSAGE()
		    SET @passornot = 1
			return
			--RAISERROR (66666, -- Message id.   
			--			16, -- Severity,   
			--			1 -- State,   
			--			) 

		END
		--IF @expiration_date IS NOT NULL
		--SET @lot_number = CONVERT(NVARCHAR,@expiration_date,112)


		BEGIN TRANSACTION
			SELECT @date_posting = date_posting 
				FROM t_rcpt_ship
				WHERE wh_id = @wh_id
					AND shipment_number = @control_number					

			IF @expiration_date is not null
			BEGIN
				SET @production_date = @expiration_date
				
				SELECT @expiration_date = DATEADD(DAY,shelf_life,@expiration_date) FROM t_item_master
				WHERE wh_id = @wh_id 
				AND item_number = @item_number											
			END
					 
			IF @qty > 0 
			BEGIN 
			--GET PO NUMBER
			WHILE (1=1)
				BEGIN

						SELECT TOP 1 @po_number = trspd.po_number
								,@line_number = trspd.line_number
								,@scheduler_number = trspd.schedule_number
								,@expected_qty = trspd.expected_qty
								,@received_qty = trspd.received_qty
						    FROM t_rcpt_ship_po_detail trspd
							WHERE trspd.wh_id = @wh_id
							  AND trspd.shipment_number = @control_number
							  AND trspd.item_number = @item_number
							  AND trspd.expected_qty > trspd.received_qty
							ORDER BY trspd.po_number
									,trspd.line_number
									,trspd.schedule_number

						IF @@ROWCOUNT = 0 
							BEGIN								

								SELECT TOP 1 @po_number = trspd.po_number
											,@line_number = trspd.line_number
											,@scheduler_number = trspd.schedule_number
											,@expected_qty = trspd.expected_qty + trspd.more_qty
											,@received_qty = trspd.received_qty
								FROM t_rcpt_ship_po_detail trspd
								WHERE trspd.wh_id = @wh_id
								  AND trspd.shipment_number = @control_number
								  AND trspd.item_number = @item_number
								  AND (trspd.expected_qty + trspd.more_qty) > trspd.received_qty
								ORDER BY trspd.po_number
										,trspd.line_number
										,trspd.schedule_number

								IF @@ROWCOUNT = 0
									BEGIN
										SET @msg = '收货数量已经超出预收数量!'
										RAISERROR (@msg, -- Message id.   
												   16, -- Severity,   
												   1 -- State,   
												  ) 
									END
								ELSE
									BEGIN
									 --   IF CAST(@total_rcpt_qty as int) =CAST(@expected_qty as int)
										--begin
										--   set @total_rcpt_qty=@total_rcpt_qty
										--end

										IF @total_rcpt_qty <= @expected_qty  - @received_qty 
											BEGIN
												SET @rcpt_qty = @total_rcpt_qty
												SET @total_rcpt_qty = 0
											END
										ELSE
											BEGIN
												SET @rcpt_qty = @expected_qty - @received_qty
												SET @total_rcpt_qty = @total_rcpt_qty - @rcpt_qty
											END
									END


									
							END
						ELSE
							BEGIN
							   -- IF CAST(@total_rcpt_qty as int) =CAST(@expected_qty as int)
										--begin
										--   set @total_rcpt_qty=@total_rcpt_qty
										--END
                                        
								IF @total_rcpt_qty <= @expected_qty - @received_qty
									BEGIN
										SET @rcpt_qty = @total_rcpt_qty
										SET @total_rcpt_qty = 0
									END
								ELSE
									BEGIN
										SET @rcpt_qty = @expected_qty - @received_qty
										SET @total_rcpt_qty = @total_rcpt_qty - @rcpt_qty
									END
							END
					
				
					SELECT @client_code = client_code
					FROM t_item_master 
					WHERE wh_id = @wh_id
					and item_number = @item_number

					SELECT @vendor = vendor_code
						,@display_po_number = display_po_number
						,@sap_order_tpy = sap_ordertype
						,@order_type = tl.text
						,@relation_order_number = relation_order_number
					FROM t_po_master pm
					INNER JOIN t_lookup tl
					ON pm.type_id = tl.lookup_id
					WHERE wh_id = @wh_id
					and po_number = @po_number

					--Insert into t_receipt
					UPDATE t_receipt
					SET [qty_received] = [qty_received] + @rcpt_qty
						,[qty_damaged] = [qty_damaged] + ( case @type when 'D' then @rcpt_qty else 0 end)
					WHERE receipt_id = @control_number
					and wh_id = @wh_id
					and po_number = @po_number
					and line_number = @line_number
					and item_number = @item_number
					and schedule_number = @scheduler_number
					and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
					--and (ciq_number = @ciq_number or (ciq_number is null and @ciq_number is null))
					and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
					and hu_id = @hu_id

					IF @@ROWCOUNT =0 
						BEGIN
							INSERT INTO t_receipt
								([receipt_id],[vendor_code],po_number,line_number,schedule_number,[receipt_date]
								,[item_number],[lot_number],[qty_received],[qty_damaged]
								,[hu_id],[fork_id],[wh_id],[stored_attribute_id],[shipment_number],item_type,expiration_date,production_date)
							VALUES
								(@control_number,@vendor,@po_number,@line_number,@scheduler_number,getdate()
								,@item_number,@lot_number,@rcpt_qty, case @type when 'D' then @rcpt_qty else 0 end
								,@hu_id,@location_id,@wh_id,@stored_attribute_id,NULL,(SELECT TOP 1 item_type
																								FROM t_po_detail
																								WHERE wh_id = @wh_id
																								AND po_number = @po_number
																								AND item_number = @item_number
																								AND line_number = @line_number)
																								,@expiration_date,
											@production_date)
						END

                     EXECUTE usp_dynamic_get_attribute_data 
					 @stored_attribute_id,
                     @col1 OUTPUT, 
					 @col2 OUTPUT,
					 @col3 OUTPUT,
                     @col4 OUTPUT, 
					 @col5 OUTPUT, 
					 @col6 OUTPUT,
                     @col7 OUTPUT, 
					 @col8 OUTPUT, 
					 @col9 OUTPUT,
                     @col10 OUTPUT, 
					 @col11 OUTPUT

					--IF @order_type <> '3PLO' AND @order_type <> 'OMO' 
					IF (@order_type NOT IN('3PLO','OMO','SWP','PPO','EO')
					AND NOT EXISTS(SELECT 1 FROM dbo.t_control where control_type = 'C_RECEIPT_CONFIRM' AND c1='Y'))
					OR @order_type = 'PPO'
					BEGIN
					--Insert into [dbo].[int_upd_receipt]
					Insert into [dbo].[tbl_inf_exp_receipt]
						(receipt_id,vendor_code,po_number,display_po_number,receipt_date
						,scac_code,status,item_number,display_item_number,lot_number
						,line_number,schedule_number,qty_received,qty_damaged,hu_id
						,packing_slip,fork_id,uom,shipment_number,warehouse_id,client_code
						,generic_attribute1	,generic_attribute2	,generic_attribute3
						,generic_attribute4	,generic_attribute5	,generic_attribute6
						,generic_attribute7	,generic_attribute8	,generic_attribute9
						,generic_attribute10,generic_attribute11,process_status,item_type,sap_ordertype,date_posting,expiration_date,production_date)
					VALUES
						(@control_number,@vendor,@po_number,CASE @order_type WHEN 'RO' THEN @relation_order_number
																	ELSE @display_po_number END,getdate()
						,null,'N',@item_number,NULL,@lot_number
						,@line_number,@scheduler_number,@rcpt_qty, case @type when 'D' then @rcpt_qty else 0 end,@hu_id
						,NULL,@location_id,NULL,NULL,@wh_id,@client_code
						,@col1
						,@col2
						,@col3
						,@col4
						,@col5
						,@col6
						,@col7
						,@col8
						,@col9
						,@col10
						,@col11
						,'NEW'
						,(SELECT TOP 1 item_type
																								FROM t_po_detail
																								WHERE wh_id = @wh_id
																								AND po_number = @po_number
																								AND item_number = @item_number
																								AND line_number = @line_number)
						,@sap_order_tpy
						,@date_posting
						,@expiration_date
						,@production_date
						)
					--记录流水帐页
						BEGIN
						EXEC [dbo].[csp_add_account_page]
						@wh_id  ,
						@item_number ,
						@lot_number ,
						@line_number,
						@rcpt_qty ,
						NULL ,
						@control_number ,
						NULL ,
						NULL  ,
						'IN' ,			----IN /OUT /INV  帐页类型
						@msg OUTPUT

						END   
					
					END

					UPDATE t_rcpt_ship_po_detail
					SET received_qty = received_qty + @rcpt_qty
					WHERE wh_id = @wh_id
					AND shipment_number = @control_number
					and po_number = @po_number
					and item_number = @item_number
					and line_number = @line_number
					and schedule_number = @scheduler_number

					IF @total_rcpt_qty <= 0
						BEGIN
							BREAK
						END
				END
			END
			-- Discount Receive
			---------------------------------------------------------------------
			IF @discount_qty > 0
			BEGIN
				SET @total_rcpt_qty = @discount_qty

				SELECT TOP 1 @po_number = trspd.po_number
								,@line_number = trspd.line_number
								,@scheduler_number = trspd.schedule_number
								,@expected_qty = trspd.expected_qty
								,@received_qty = trspd.received_qty
						    FROM t_rcpt_ship_po_detail trspd
							WHERE trspd.wh_id = @wh_id
							  AND trspd.shipment_number = @control_number
							  AND trspd.item_number = @item_number
							ORDER BY trspd.po_number
									,trspd.line_number
									,trspd.schedule_number

				IF @@ROWCOUNT > 0 
				BEGIN
					SELECT @client_code = client_code
					FROM t_item_master 
					WHERE wh_id = @wh_id
					and item_number = @item_number

					SELECT @vendor = vendor_code
						,@display_po_number = display_po_number
						,@sap_order_tpy = sap_ordertype
						,@order_type = tl.text						
						,@relation_order_number = relation_order_number
					FROM t_po_master pm
					INNER JOIN t_lookup tl
					ON pm.type_id = tl.lookup_id
					WHERE wh_id = @wh_id					
					and po_number = @po_number


					--Insert into t_receipt
					UPDATE t_receipt
					SET 
						[qty_discount] = [qty_discount] + @total_rcpt_qty
						,[qty_damaged] = [qty_damaged] + ( CASE @type WHEN 'D' THEN @total_rcpt_qty ELSE 0 END)
						--,[qty_discount] = [qty_discount] + @total_rcpt_qty
						--[qty_received] = [qty_received] + @total_rcpt_qty
					WHERE receipt_id = @control_number
					and wh_id = @wh_id
					and po_number = @po_number
					and line_number = @line_number
					and item_number = @item_number
					and schedule_number = @scheduler_number
					and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
					and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
					and hu_id = @hu_id

					IF @@ROWCOUNT = 0 
						BEGIN
							INSERT INTO t_receipt
								([receipt_id],[vendor_code],po_number,line_number,schedule_number,[receipt_date]
								,[item_number],[lot_number],[qty_received],[qty_damaged]
								,[hu_id],[fork_id],[wh_id],[stored_attribute_id],[shipment_number],qty_discount,expiration_date,production_date,item_type)
							VALUES
								(@control_number,@vendor,@po_number,@line_number,@scheduler_number,getdate()
								,@item_number,@lot_number,0, case @type when 'D' then @discount_qty else 0 end
								,@hu_id,@location_id,@wh_id,@stored_attribute_id,NULL,@discount_qty,@expiration_date,@production_date ,
								(SELECT TOP 1 item_type
																								FROM t_po_detail
																								WHERE wh_id = @wh_id
																								AND po_number = @po_number
																								AND item_number = @item_number
																								AND line_number = @line_number))
						END


					 EXECUTE usp_dynamic_get_attribute_data 
					 @stored_attribute_id,
                     @col1 OUTPUT, 
					 @col2 OUTPUT,
					 @col3 OUTPUT,
                     @col4 OUTPUT, 
					 @col5 OUTPUT, 
					 @col6 OUTPUT,
                     @col7 OUTPUT, 
					 @col8 OUTPUT, 
					 @col9 OUTPUT,
                     @col10 OUTPUT, 
					 @col11 OUTPUT

					
					--IF @order_type <> '3PLO' AND @order_type <> 'OMO'
					IF (@order_type NOT IN('3PLO','OMO','SWP','PPO','EO')
					AND NOT EXISTS(SELECT 1 FROM dbo.t_control where control_type = 'C_RECEIPT_CONFIRM' AND c1='Y'))
					OR @order_type = 'PPO'

					BEGIN
					--Insert into [dbo].[int_upd_receipt]
						Insert into [dbo].[tbl_inf_exp_receipt]
							(receipt_id,vendor_code,po_number,display_po_number,receipt_date
							,scac_code,status,item_number,display_item_number,lot_number
							,line_number,schedule_number,qty_discount,qty_damaged,hu_id
							,packing_slip,fork_id,uom,shipment_number,warehouse_id,client_code
							,generic_attribute1	,generic_attribute2	,generic_attribute3
							,generic_attribute4	,generic_attribute5	,generic_attribute6
							,generic_attribute7	,generic_attribute8	,generic_attribute9
							,generic_attribute10,generic_attribute11,process_status,sap_ordertype,item_type,date_posting,expiration_date,production_date)
						VALUES
							(@control_number,@vendor,@po_number,CASE @order_type WHEN 'RO' THEN @relation_order_number
																	ELSE @display_po_number END,getdate()
							,null,'N',@item_number,NULL,@lot_number
							,@line_number,@scheduler_number,@total_rcpt_qty, case @type when 'D' then @total_rcpt_qty else 0 end,@hu_id
							,NULL,@location_id,NULL,NULL,@wh_id,@client_code
							,@col1
							,@col2
							,@col3
							,@col4
							,@col5
							,@col6
							,@col7
							,@col8
							,@col9
							,@col10
							,@col11
							,'NEW'
							,@sap_order_tpy					
							,(SELECT TOP 1 item_type
																								FROM t_po_detail
																								WHERE wh_id = @wh_id
																								AND po_number = @po_number
																								AND item_number = @item_number
																								AND line_number = @line_number)
							,@date_posting
							,@expiration_date
							,@production_date
							)

								--记录流水帐页
							BEGIN
							EXEC [dbo].[csp_add_account_page]
							@wh_id  ,
							@item_number ,
							@lot_number ,
							@line_number,
							@total_rcpt_qty ,
							NULL ,
							@control_number ,
							NULL ,
							NULL  ,
							'IN' ,			----IN /OUT /INV  帐页类型
							@msg OUTPUT

							END   
						END
					--UPDATE t_rcpt_ship_po_detail
					--SET received_qty = received_qty + @rcpt_qty
					--WHERE wh_id = @wh_id
					--AND shipment_number = @control_number
					--and po_number = @po_number
					--and item_number = @item_number
					--and line_number = @line_number
					--and schedule_number = @scheduler_number
					UPDATE t_rcpt_ship_po_detail
					SET free_qty = ISNULL(free_qty,0) + @discount_qty
					WHERE wh_id = @wh_id
					AND shipment_number = @control_number
					and po_number = @po_number
					and item_number = @item_number
					and line_number = @line_number
					and schedule_number = @scheduler_number
				END	        					
			END
		-------------------------------------------------------------------------
		-------------------------------------------------------------------------

			--Create LP information
			IF NOT EXISTS(SELECT 1 FROM t_hu_master
					   WHERE wh_id = @wh_id
					   and hu_id = @hu_id)
				BEGIN
					
					SET @zone_group = dbo.fn_Get_StorageType_ByItem(@wh_id,@item_number,@type)
					SELECT TOP 1 @zone = zone 
					FROM t_zone 
					WHERE zone_type = @type and wh_id = @wh_id and zone_group = @zone_group

					INSERT INTO t_hu_master
					(wh_id,hu_id,type,control_number,location_id,subtype
					,status, fifo_date,zone)
					VALUES
					(@wh_id,@hu_id,'IV',@control_number,@location_id,@type + @zone_group
					,'A',GETDATE(),@zone)
				END
				
			--Insert into t_stored_item
			SET @qty = @qty + @discount_qty
			
			--IF @expiration_date IS NOT NULL
			--	SELECT @expiration_date = DATEADD(DAY,shelf_life,@expiration_date) FROM t_item_master
			--	WHERE wh_id = @wh_id 
			--	AND item_number = @item_number

			IF EXISTS (SELECT 1 FROM t_stored_item
						WHERE wh_id = @wh_id
						AND location_id = @location_id
						AND item_number = @item_number
						AND ISNULL(lot_number,'') =ISNULL( @lot_number,'')
						AND ISNULL(stored_attribute_id,0) = ISNULL(@stored_attribute_id,0)
						AND ISNULL(expiration_date,'') = ISNULL( @expiration_date,'')
						AND ISNULL(damage_flag,'N') = @damage_flag
						AND hu_id = @hu_id)
				BEGIN
					UPDATE t_stored_item
					SET [actual_qty] = [actual_qty] + @qty
					WHERE wh_id = @wh_id
					AND location_id = @location_id
					AND item_number = @item_number
					AND isnull(lot_number,'') =isnull( @lot_number,'')
					--and isnull(expiration_date,'') =isnull( @expiration_date,'')
					AND isnull(stored_attribute_id,0) = isnull(@stored_attribute_id,0)
					AND ISNULL(damage_flag,'N') = @damage_flag
					AND hu_id = @hu_id
					
					IF @@ROWCOUNT = 0
					BEGIN
						INSERT INTO t_stored_item
					([item_number],lot_number,[wh_id],[location_id],[actual_qty],[status],[fifo_date],[type],[stored_attribute_id],[hu_id],expiration_date,damage_flag)
					VALUES
					(@item_number,@lot_number,@wh_id,@location_id,@qty,'A',CAST(GETDATE() AS DATE),'0',@stored_attribute_id,@hu_id,@expiration_date,@damage_flag)
					 
					END 
				END
			ELSE
				BEGIN
					INSERT INTO t_stored_item
					([item_number],lot_number,[wh_id],[location_id],[actual_qty],[status],[fifo_date],[type],[stored_attribute_id],[hu_id],expiration_date,damage_flag)
					VALUES
					(@item_number,@lot_number,@wh_id,@location_id,@qty,'A',CAST(GETDATE() AS DATE),'0',@stored_attribute_id,@hu_id,@expiration_date,@damage_flag)
					 
				END
			
		

			--Insert t_tran_log_holding
			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
				,generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11)
			VALUES
				(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@user_id,@control_number,NULL
				,@wh_id,@location_id,@hu_id,@item_number,@lot_number,@qty,
				(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
				)

				--Interface 
				--INSERT INTO [dbo].[int_upd_receipt]

			 SET @passornot = 0
			 SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END



