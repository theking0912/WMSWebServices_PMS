


-- =============================================
-- Author:		<Author,peter,Name>
-- Create date: <Create Date,2016-2-27>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Binding_Blind_Receipt] 
	-- Add the parameters for the stored procedure here
	@wh_id				AS	NVARCHAR(20),
	@receipt_id		    AS	NVARCHAR(30),
	@po_number   	    AS	NVARCHAR(30),
    @item_number        AS	NVARCHAR(30),
	@line_number        AS	NVARCHAR(5),
	@schedule_number    AS	NVARCHAR(5),
	@vendor_code        AS  NVARCHAR(10),
	@quantity           AS  NVARCHAR(30),
	@order_uom          AS  NVARCHAR(100)

AS
BEGIN
	declare @shipment_number nvarchar(22)
	declare @qty_received float
	declare @qty_discount float
	declare @expected_qty float
	declare @received_qty float
	declare @qty float
	declare @loop_shipment_number nvarchar(22)
	--20160330 Added by tony Start
	create table #shipment_list(shipment_number varchar(50) Collate Database_Default )
	--20160330 Added by tony end


	SELECT top 1 @qty=(@quantity*conversion_factor)
	  from t_item_uom
     where wh_id=@wh_id 
	   and item_number=@item_number 
	   and (uom + ' - ' +uom_prompt)=@order_uom 
	   and status='ACTIVE'

	if NOT EXISTS( SELECT top 1  po_number 
	                 from t_receipt
					where wh_id=@wh_id
					  and item_number=@item_number
					  and po_number=@po_number
					  and receipt_id=@receipt_id 
					  and line_number=@line_number 
					  and schedule_number=@schedule_number)

    begin
	--20160330 Added by tony Start
	  WHILE (1=1) 
	  BEGIN
	--20160330 Added by tony END
	  select top 1 @shipment_number=tr.shipment_number,
	               @qty_received=tr.qty_received,
				   @qty_discount=tr.qty_discount 
	    from t_receipt tr
	     left join t_stored_item tsi
		  on tr.wh_id=tsi.wh_id 
		  and tr.item_number=tsi.item_number 
		  and tr.shipment_number=tsi.shipment_number
	   where tsi.status='U' 
	     and tr.wh_id=@wh_id 
		 and tr.item_number=@item_number  
		 and tr.po_number is null 
	  --20160330 Added by tony Start
	     and tr.vendor_code = @vendor_code
		and tr.shipment_number not in ( select shipment_number from #shipment_list)
	  	order by tr.lot_number asc, tr.qty_received desc

	  IF @@ROWCOUNT = 0
	  BEGIN
	     BREAK
	  END
	--20160330 Added by tony END
	
	  select top 1 @received_qty=received_qty,
	               @expected_qty=expected_qty 
	    from t_rcpt_ship_po_detail
	   where wh_id=@wh_id 
	     and item_number=@item_number 
		 and po_number=@po_number 
		 and shipment_number=@receipt_id 
		 and line_number=@line_number 
		 and schedule_number=@schedule_number
	--20160330 Added by tony Start
	 IF @expected_qty < @received_qty + @qty_received
	 BEGIN
		INSERT INTO #shipment_list
		(shipment_number)
		values (@shipment_number)
		continue
	 END 
	--20160330 Added by tony END
	
      update t_receipt       
	     set receipt_id=@receipt_id,
		     po_number=@po_number,
			 --vendor_code=@vendor_code,
			-- lot_number=(rtrim(lot_number)+rtrim(@vendor_code)),
			 line_number=@line_number,
			 schedule_number=cast(cast (@schedule_number as decimal(9,2)) as int)
	   where wh_id=@wh_id 
	     and item_number=@item_number 
		 and shipment_number=@shipment_number 
		 and po_number is null  
		 and qty_received!>convert(float,@quantity)
		 and vendor_code = @vendor_code --Added by Tony 20160330
 print 1
	  update t_stored_item 
	     --set status='A',lot_number=(rtrim(lot_number)+rtrim(@vendor_code))
		 --set status='A'
		 --20160509 Added by peter Start
		  set status='A',shipment_number=null
		  --20160509 Added by peter end 
	   where wh_id=@wh_id
	     and item_number=@item_number 
		 and shipment_number=@shipment_number
print 2
	  update t_rcpt_ship_po_detail 
	     --set received_qty=@qty_received,
		 SET received_qty=received_qty + @qty_received, --Added by tony 20160330
		     --free_qty=@qty_discount
			 free_qty=isnull(free_qty,0) + @qty_discount--Added by tony 20160330
	   where wh_id=@wh_id 
	     and item_number=@item_number 
		 and po_number=@po_number 
		 and shipment_number=@receipt_id 
	     and line_number=@line_number 
		 and schedule_number=@schedule_number

	--20160330 Added by tony Start
	  END

	  drop table #shipment_list
	--20160330 Added by tony END
	end
END
