create procedure dbo.csp_writeLog(
@tran_type nvarchar(3),
@description nvarchar(50),
@start_tran_date datetime,
@start_tran_time datetime,
@end_tran_date datetime,
@end_tran_time datetime,
@employee_id nvarchar(10),
@control_number nvarchar(30),
@line_number nvarchar(5),
@control_number_2 nvarchar(30),
@outside_id nvarchar(10),
@wh_id nvarchar(10),
@location_id nvarchar(50),
@hu_id nvarchar(22),
@num_items int,
@item_number nvarchar(30),
@lot_number nvarchar(15),
@uom nvarchar(10),
@tran_qty float,
@wh_id_2 nvarchar(10),
@location_id_2 nvarchar(50),
@verify_status nchar(1),
@employee_id_2 nvarchar(10),
@routing_code nvarchar(30),
@hu_id_2 nvarchar(22),
@return_disposition nvarchar(30),
@elapsed_time int,
@source_storage_type nvarchar(30),
@destination_storage_type nvarchar(30),
@generic_attribute_1 nvarchar(250),
@generic_attribute_2 nvarchar(250),
@generic_attribute_3 nvarchar(250),
@generic_attribute_4 nvarchar(250),
@generic_attribute_5 nvarchar(250),
@generic_attribute_6 nvarchar(250),
@generic_attribute_7 nvarchar(250),
@generic_attribute_8 nvarchar(250),
@generic_attribute_9 nvarchar(250),
@generic_attribute_10 nvarchar(250),
@generic_attribute_11 nvarchar(250),
@display_item_number nvarchar(30),
@client_code nvarchar(30)
)
as
 declare @Result int; 
begin
     begin transaction
     INSERT INTO t_tran_log (tran_type ,description ,start_tran_date,start_tran_time,end_tran_date
           ,end_tran_time ,employee_id,control_number,line_number,control_number_2,outside_id,wh_id
           ,location_id,hu_id,num_items,item_number,lot_number,uom,tran_qty,wh_id_2,location_id_2,verify_status
           ,employee_id_2,routing_code,hu_id_2,return_disposition ,elapsed_time,source_storage_type,
		   destination_storage_type,generic_attribute_1,generic_attribute_2,generic_attribute_3
           ,generic_attribute_4,generic_attribute_5,generic_attribute_6,generic_attribute_7
           ,generic_attribute_8,generic_attribute_9,generic_attribute_10,generic_attribute_11
           ,display_item_number,client_code)
     VALUES
           (@tran_type,@description,@start_tran_date,@start_tran_time
           ,@end_tran_date,@end_tran_time,@employee_id,@control_number
           ,@line_number,@control_number_2,@outside_id,@wh_id
           ,@location_id,@hu_id,@num_items,@item_number
		   ,@lot_number,@uom,@tran_qty,@wh_id_2,@location_id_2,@verify_status
           ,@employee_id_2,@routing_code,@hu_id_2,@return_disposition
           ,@elapsed_time,@source_storage_type,@destination_storage_type,@generic_attribute_1
           ,@generic_attribute_2,@generic_attribute_3,@generic_attribute_4,@generic_attribute_5
           ,@generic_attribute_6,@generic_attribute_7,@generic_attribute_8,@generic_attribute_9
           ,@generic_attribute_10,@generic_attribute_11,@display_item_number,@client_code)

    		if @@error<>0  --insert失败 
				begin 				    
					set @Result=0;
					rollback transaction
					return @Result;							
				end
			else --insert 成功
				begin					    			
					set @Result=1;
						commit transaction
					return @Result;																		
				end 
end
