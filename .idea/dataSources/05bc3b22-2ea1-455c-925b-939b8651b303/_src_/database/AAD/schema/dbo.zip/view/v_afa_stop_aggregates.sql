
CREATE VIEW dbo.v_afa_stop_aggregates
AS
SELECT
    s.wh_id,
    s.load_id,
    s.stop_id,
    s.stop_sequence,
    COUNT(DISTINCT ld.order_number)        AS num_orders,
    SUM(ln.planned_qty)                    AS num_items,
    SUM(ln.planned_qty * i.unit_weight)    AS total_weight,
    SUM(ln.planned_qty * i.unit_volume)    AS total_cube,
    SUM(ln.planned_qty /
        CASE ISNULL(i.std_hand_qty, 0) WHEN 0 THEN 1 ELSE i.std_hand_qty END
    ) AS num_pallets,
    MAX(i.haz_material)                     AS haz_material
FROM
    t_stop s
INNER JOIN
    t_afa_load_detail ld
    ON
        s.stop_id = ld.stop_id
INNER JOIN
    t_afa_load_detail_line ln
    ON
        ld.load_detail_id = ln.load_detail_id AND
        ld.wh_id = ln.wh_id
INNER JOIN
    t_item_master i
    ON
        ln.item_number = i.item_number AND
        ln.wh_id = i.wh_id
GROUP BY
    s.wh_id,
    s.load_id,
    s.stop_id,
    s.stop_sequence

