
CREATE  PROCEDURE usp_work_q_print_label
    @in_ClientCode         AS NVARCHAR(20) = NULL,
    @in_DisplayOrderNumber AS NVARCHAR(20) = NULL,
    @in_OrderNumber     	AS NVARCHAR(20) = NULL,
    @in_LoadNumber	AS NVARCHAR(20) = NULL,
    @in_WaveNumber	AS NVARCHAR(20) = NULL,
    @in_ItemNumber	AS NVARCHAR(30) = NULL, -- item specific not supported yet
    @in_LotNumber	AS NVARCHAR(15) = NULL, -- lot specific not supported yet
    @in_PickArea	As NVARCHAR(10) = 'ALL',
    @in_WHID		AS NVARCHAR(10) = '01',
    @in_Batch_id	AS NVARCHAR(20) = NULL,
    @in_Label_id       AS NVARCHAR(12) = NULL,
    @in_ww_UserName	AS NVARCHAR(30) = '',
    @in_Call	             AS INT = 0,               -- Indicate if is called for webwise (1) or other sp (0)
    @in_nResultsFlag       AS INT = 0                -- 1 means return results;  0 means don't return results
  
AS

    -- If @inCall = 3 the stored procedure is being called from page 'Number of Printed Labels' so the only task to do is return the previously printed labels
    IF (@in_Call = 3)  
        BEGIN
	   GOTO BeforeErrorHandler
        END

 DECLARE
    
    @str_SelectClause    NVARCHAR(1000),
    @str_WhereClause   NVARCHAR(1000),
    @str_UpdateClause  NVARCHAR(1000),
    @n_Count                 INT,
    --generated file variables.
    @v_path     NVARCHAR (50),
    @v_folder   NVARCHAR (50),
    @v_str        NVARCHAR (1000),
    -- Error handling and logging variables.
    @c_nModuleNumber       INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber             INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum          INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg             NVARCHAR(500),
    @v_nErrorNumber           INT,
    @v_nRowCount              INT,
    @v_nReturn                    INT,
    @v_vchLogMsg             NVARCHAR(500),
      -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError             INT,
    @e_SprocError               INT,
    @e_InsITMFailed            INT,              
     -- Local Variables
    @v_vchItem                 NVARCHAR(30),
    @v_vchUniqueLabelId        NVARCHAR(60)
    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 1        -- This # must be unique per object.
    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_InsITMFailed = 3
    
    SET @v_nRowCount = 0
    SET @v_nReturn = 1

    SET NOCOUNT ON
   
    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
   
     IF @v_nReturn <> 0 -- A zero means success.
         BEGIN
                 SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	           ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
                 SET @v_nLogErrorNum = @e_SprocError
                 GOTO ErrorHandler			
        END
      
    -- Body of procedure.
    CREATE TABLE ##t_order_temp
    (
       order_number            NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       display_order_number    NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       client_code             NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       wh_id                   NVARCHAR(10)   COLLATE DATABASE_DEFAULT NOT NULL
    ) 

        INSERT INTO ##t_order_temp
        SELECT order_number,
               display_order_number,
               client_code,
               wh_id
          FROM t_order
         WHERE display_order_number LIKE @in_DisplayOrderNumber
           AND client_code          LIKE @in_ClientCode
           AND display_order_number LIKE @in_OrderNumber
           AND wh_id                = @in_WHID


     --if existing temp. table with the same name of the one we will create the table is dropped
    IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[tempdb].[dbo].[##t_batch_label]'))
        BEGIN
               DROP TABLE ##t_batch_label
        END
    --Checks for existing records (labels) in t_label matching the entered parameters to be printed
    SELECT @n_Count = COUNT(*)
    FROM t_label lbl, 
	     #tmp_pick_details_to_update pkd, --t_pick_detail pkd,
         t_printer prn, 
         t_pick_area pka,
         ##t_order_temp orm
    WHERE lbl.label_status = 'NOT PRINTED' 
          AND ((pkd.status = 'RELEASED') OR (pkd.status = 'PRERLSE'))
          AND prn.status = 'A'
          AND prn.pick_area = pkd.pick_area  
          AND pka.pick_area = pkd.pick_area
          AND lbl.pick_id = pkd.pick_id
          AND pkd.order_number = orm.order_number
          AND pkd.wh_id        = orm.wh_id
          AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
          AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
          AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
          AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
          AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                OR (@in_PickArea = 'ALL') OR (@in_LotNumber = ''))
          AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
	  AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
          AND pkd.wh_id = @in_WHID 

    -- If no results were returned (@n_Count < 1) for the passed parameters the procedure jumps to end of sproc 
    --because no rows will be affected by the rest of the statements in the body of the procedure.          
    IF @n_Count < 1
        BEGIN
             
  		DELETE t_labels_being_printed
		WHERE w_user_name = @in_ww_UserName       
 	    -- As there are not existing labels matching the passed parameters to be printed we jump to the end of sproc.
                 GOTO BeforeErrorHandler 
        END

    --temp. table is created to be used when flat files are generated   
    CREATE TABLE ##t_batch_label(
       batch 	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL, 	
       sequence        INT 	      NOT NULL,
       label_name      NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,
       field_01	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Header: label_id; Label: batch_id
       field_02	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Header: pick_area; Label: pkd.item_number
       field_03	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.lot_number
       field_04	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.serial_number
       field_05	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.planned_quantity
       field_06	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.uom
       field_07	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.order_number       
       field_08	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.pick_location       
       field_09	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: door_location       
       field_10	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Header and Label: quantity label will be printed
       path            NVARCHAR(50)   COLLATE DATABASE_DEFAULT NULL,
       separator       NCHAR(1)       COLLATE DATABASE_DEFAULT NULL
       )
 
       --SET NOCOUNT OFF

	-- Print a trace level log message.
        IF @v_nLogLevel >= 4        
        BEGIN
            PRINT '##t_batch_label table created'
        END 

       --Insert batch's headers in the temp table
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
       INSERT INTO ##t_batch_label (batch,sequence,label_name,field_01,field_02,field_10,separator,path)
       SELECT DISTINCT lbl.batch_id,0,prn.name_label_batch,lbl.batch_id,pkd.pick_area,1,prn.separator,prn.folder
       FROM t_label lbl, 
            #tmp_pick_details_to_update pkd, --t_pick_detail pkd, 
            t_printer prn, ##t_order_temp orm
       WHERE lbl.pick_id = pkd.pick_id
                      AND prn.pick_area = pkd.pick_area  
                      AND lbl.label_status = 'NOT PRINTED'
                      AND ((pkd.status = 'RELEASED') OR (pkd.status = 'PRERLSE'))
                      AND prn.status = 'A'
                      AND pkd.order_number = orm.order_number
                      AND pkd.wh_id        = orm.wh_id
                      AND ((pkd.load_id = @in_LoadNumber) 
                                 OR (@in_LoadNumber is NULL) OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                      AND ((pkd.wave_id = @in_WaveNumber) 
                                 OR (@in_WaveNumber is NULL) OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                      AND ((pkd.item_number = @in_ItemNumber) 
                                 OR (@in_ItemNumber is NULL) OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                      AND ((pkd.lot_number = @in_LotNumber) 
                                 OR (@in_LotNumber is NULL) OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                      AND ((pkd.pick_area = @in_PickArea) 
                                 OR (@in_PickArea is NULL) OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                      AND ((lbl.batch_id = @in_Batch_id) 
                                 OR (@in_Batch_id is NULL)  OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
		      AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                		OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                      AND pkd.wh_id = @in_WHID
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------       


       SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
       -- Check for any errors. If so, error number will not be equal to zero.
	-- Check for Number of rows affected too.
       IF @v_nErrorNumber <> 0 OR @v_nRowCount = 0
           BEGIN
        	      SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	                                              'the exact nature of the error.'
       	      SET @v_nLogErrorNum = @e_GenSqlError
                   GOTO ErrorHandler
           END
       
        -- Print a trace level log message.
        IF @v_nLogLevel >= 4        
            BEGIN
                    PRINT 'Batch labels added to temp table:' + CAST(@v_nRowCount AS NVARCHAR(10))
            END 

       --Insert labels in the temp table
       -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        INSERT INTO ##t_batch_label (batch,sequence,label_name,field_01,field_02,field_03,
                                                            field_04,field_05,field_06,field_07,field_08,field_09,field_10,path,separator)
        SELECT  lbl.batch_id,lbl.print_sequence,prn.name_label,lbl.label_id,itm.display_item_number,
                        pkd.lot_number,pkd.serial_number,pkd.planned_quantity,pkd.uom,
                        orm.display_order_number,pkd.pick_location,ldm.door_loc,1,prn.folder,prn.separator
        FROM t_label lbl
             JOIN t_pick_detail pkd 
                ON lbl.pick_id = pkd.pick_id
             JOIN t_printer prn
                ON prn.pick_area = pkd.pick_area 
                   AND prn.wh_id = pkd.wh_id
             JOIN ##t_order_temp orm 
                ON pkd.order_number = orm.order_number
               AND pkd.wh_id = orm.wh_id
             JOIN t_item_master itm
                ON pkd.item_number = itm.item_number
               AND pkd.wh_id = itm.wh_id
             LEFT OUTER JOIN t_load_master ldm
                ON pkd.load_id = ldm.load_id
        WHERE  lbl.label_status = 'NOT PRINTED'
                       AND ((pkd.status = 'RELEASED') OR (pkd.status = 'PRERLSE'))
                       AND prn.status = 'A'
                       AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                                  OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                       AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                                OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                       AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                                 OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                       AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                                 OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                       AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                                 OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                       AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                                 OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
		       AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                		 OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                      AND pkd.wh_id = @in_WHID
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
      SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 

       -- Check for any errors. If so, error number will not be equal to zero.
	-- Check for Number of rows affected.
       IF @v_nErrorNumber <> 0 OR @v_nRowCount = 0
           BEGIN
        	      SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	                                              'the exact nature of the error.'
       	      SET @v_nLogErrorNum = @e_GenSqlError
                   GOTO ErrorHandler
           END

         
        -- Print a trace level log message.
        IF @v_nLogLevel >= 4        
        BEGIN
            PRINT 'Labels added to temp table:' + CAST(@v_nRowCount AS NVARCHAR(10))
        END 

        ----------------------------------------------------------------------------------------------------------
        --This cursor is declared to support labels printing for several pick areas.
        ----------------------------------------------------------------------------------------------------------
        DECLARE Path_Cursor CURSOR FOR
        SELECT DISTINCT path  FROM ##t_batch_label

        OPEN Path_Cursor
              FETCH NEXT FROM Path_Cursor
              INTO @v_path

             WHILE @@FETCH_STATUS = 0
                  BEGIN
                   -- Get unique id to identify the group for this user
                   SELECT @v_vchUniqueLabelId = newid()

                   -- Populate a regular table so we can issue the bcp command with no lock
                   INSERT INTO t_batch_label(label_data, group_batch_id)
                    SELECT ISNULL(label_name, 'UKNOWNN') + ',' +
                          ISNULL(separator, '')+ ISNULL(field_01, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(separator, '')+ ISNULL(field_02, '')+ ISNULL(separator, '') + ',' +  
                          ISNULL(separator, '')+ ISNULL(field_03, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(separator, '')+ ISNULL(field_04, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(separator, '')+ ISNULL(field_05, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(separator, '')+ ISNULL(field_06, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(separator, '')+ ISNULL(field_07, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(separator, '')+ ISNULL(field_08, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(separator, '')+ ISNULL(field_09, '')+ ISNULL(separator, '') + ',' + 
                          ISNULL(field_10, ''), @v_vchUniqueLabelId
                          FROM  ##t_batch_label 
                         WHERE path =  @v_path ORDER BY batch, sequence

                    -- Check for Number of rows affected.
                    IF @v_nErrorNumber <> 0 OR @v_nRowCount = 0
                    BEGIN
        	            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	                                              'the exact nature of the error.'
       	                SET @v_nLogErrorNum = @e_GenSqlError
                        GOTO ErrorHandler
                    END


                          --Generate file for  label  picking
                          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                          SET @v_folder = @v_path + REPLACE(convert(varchar(10),getdate(),102),'.','')+REPLACE(convert(varchar(13),getdate(),114),':','') + '.bch' 
                          -- SET @v_str = 'SELECT label_name,separator+field_01+separator,separator+field_02+separator,separator+field_03+separator,separator+field_04+separator,separator+field_05+separator,separator+field_06+separator,separator+field_07+separator,separator+field_08+separator,separator+field_09+separator,field_10 FROM  ##t_batch_label WHERE path = '''+ @v_path + ''' ORDER BY batch,sequence'
                          SET @v_str = 'SELECT label_data from t_batch_label WITH (NOLOCK)'
                          SET @v_str ='bcp "' + @v_str + '" queryout '
                          SET @v_str = @v_str + @v_folder
                          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                          -- I M P O R T A N T
                          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                          --Server role of the HJS user (Security --> Logins, SQL SERVER Console) 
                          --must have been declared with System Administrator privileges in order to be able to use the stored procedure master.dbo.xp_cmdshell with the bcp command  
                          SET @v_str = @v_str + ' -c -t, -S' + CONVERT(char(20), SERVERPROPERTY('servername')) + ' -UHJS -PHJSPASS#1 -q'                 

                          --EXEC master.dbo.xp_cmdshell @v_str, no_output
						  EXEC @v_nReturn = usp_execute_xpcmd @v_str	
        
                           
                           -- Check for any errors. If some, error number will not be equal to zero.
                           IF @v_nReturn <> 0
                               BEGIN
				       CLOSE Path_Cursor
       				       DEALLOCATE Path_Cursor
                                       SET @v_vchErrorMsg = 'SQL Stored Procedure error occured!  Check SQL Server System Log for ' + 
                                                      'the exact nature of the error.'
                                       SET @v_nLogErrorNum = @e_SprocError
                                       GOTO ErrorHandler
                               END
                        
                          -- Print a trace level log message.
                          IF @v_nLogLevel >= 4        
                              BEGIN
                                      PRINT 'BCH File Created with command: ' + @v_str
                              END 
                        FETCH NEXT FROM Path_Cursor
                        INTO @v_path
                        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                  END --END While
       CLOSE Path_Cursor
       DEALLOCATE Path_Cursor

    -- delete the table
    DELETE t_batch_label WHERE group_batch_id = @v_vchUniqueLabelId
    -- temporary table is dropped
    DROP TABLE ##t_batch_label


    --If the stored procedure is being called from WebWise, Labels being printed are stored in temporary table so can be accessed from a WebWise page once the files for Loftware have been created.
    -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    IF @in_Call	 = 1 -- called from webwise page: "Number of Printed Labels"
        BEGIN
                 
               	 DELETE t_labels_being_printed 
		 WHERE w_user_name = @in_ww_UserName 

 		  INSERT INTO t_labels_being_printed 
		  SELECT lbl.batch_id, lbl.label_id, pkd.order_number, pkd.wave_id, pkd.load_id, pkd.item_number, pkd.uom, pkd.planned_quantity, 
                                            'PRINTED' AS status_label, pkd.wh_id, prn.printer_name, @in_ww_UserName, getdate()
                   	  FROM t_label lbl, t_pick_detail pkd,t_printer prn, t_pick_area pka, ##t_order_temp orm
                   	  WHERE lbl.label_status = 'NOT PRINTED' 
                                            AND ((pkd.status = 'RELEASED') OR (pkd.status = 'PRERLSE'))
                                            AND prn.status = 'A'
                                            AND prn.pick_area = pkd.pick_area  
                                            AND pka.pick_area = pkd.pick_area
                                            AND lbl.pick_id = pkd.pick_id
                                            AND pkd.wh_id = pka.wh_id
                                            AND pkd.wh_id = prn.wh_id
                                            AND pkd.order_number = orm.order_number
                                            AND pkd.wh_id        = orm.wh_id
                                            AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                                                       OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                                            AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                                                       OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                                            AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                                                       OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                                            AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                                                       OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                                            AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                                                       OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                                            AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                                                       OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
					    AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                					OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                                             AND pkd.wh_id = @in_WHID 
                 	  ORDER BY lbl.batch_id, lbl.print_sequence ASC

  	 	  SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    		 -- Check for any errors. If so, error number will not be equal to zero.
    		 IF @v_nErrorNumber <> 0
    		     BEGIN
        			SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            				'the exact nature of the error.'
        			SET @v_nLogErrorNum = @e_GenSqlError
        			GOTO ErrorHandler
    		     END
  	 	 SELECT COUNT(*) AS number_of_printed_labels FROM  t_labels_being_printed WHERE w_user_name = @in_ww_UserName
                 END     
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        


	--The label_status is set to PRINTED for the printed labels
	----------------------------------------------------------------------------------------------------------------------------------
	UPDATE t_label 
        SET label_status = 'PRINTED'
        WHERE pick_id IN (SELECT pkd.pick_id
                                         FROM t_pick_detail pkd, t_label lbl, t_printer prn, t_pick_area pka, ##t_order_temp orm
                                         WHERE prn.status = 'A'
                                                        AND lbl.label_status = 'NOT PRINTED'
                                                        AND ((pkd.status = 'RELEASED') OR (pkd.status = 'PRERLSE'))
                                                        AND prn.status = 'A'
                                                        AND prn.pick_area = pkd.pick_area  
                                                        AND pka.pick_area = pkd.pick_area
                                                        AND lbl.pick_id = pkd.pick_id
                                                        AND pkd.wh_id = pka.wh_id
                                                        AND pkd.wh_id = prn.wh_id
                                                        AND pkd.order_number = orm.order_number
                                                        AND pkd.wh_id        = orm.wh_id
                                                        AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                                                                   OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                                                        AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                                                                   OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                                                        AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                                                                   OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                                                        AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                                                                   OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                                                        AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                                                                   OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                                                        AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                                                                   OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
							                            AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                						                           OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                                                        AND pkd.wh_id = @in_WHID) 
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
   
	--The work_status in t_work_q is set to A for the printed labels
	----------------------------------------------------------------------------------------------------------------------------------
	UPDATE t_work_q 
        SET work_status = 'A', workers_assigned = 1
        WHERE work_q_id IN (SELECT pkd.work_q_id
                                         FROM t_pick_detail pkd, t_label lbl, t_printer prn, t_pick_area pka, ##t_order_temp orm
                                         WHERE prn.status = 'A'
                                                        AND lbl.label_status = 'PRINTED'
                                                        AND ((pkd.status = 'RELEASED') OR (pkd.status = 'PRERLSE'))
                                                        AND prn.status = 'A'
                                                        AND prn.pick_area = pkd.pick_area  
                                                        AND pka.pick_area = pkd.pick_area
                                                        AND lbl.pick_id = pkd.pick_id
                                                        AND pkd.wh_id = pka.wh_id
                                                        AND pkd.wh_id = prn.wh_id
                                                        AND pkd.order_number = orm.order_number
                                                        AND pkd.wh_id        = orm.wh_id
                                                        AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                                                                   OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                                                        AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                                                                   OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                                                        AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                                                                   OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                                                        AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                                                                   OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                                                        AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                                                                   OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                                                        AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                                                                   OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
							AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                						   OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                                                        AND pkd.wh_id = @in_WHID) 
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    IF @v_nRowCount > 0    
         SET @v_nReturn = 0 

    GOTO ExitLabel

BeforeErrorHandler:

    IF (@in_Call = 1)  and (@n_Count < 1)
       BEGIN 
	  SELECT '0' AS number_of_printed_labels
       END 

    IF @in_Call = 3 
      BEGIN 
		 SELECT 
           lbp.batch_id AS out_batch_id, lbp.label_id AS out_label_id, orm.client_code, orm.display_order_number, 
           lbp.order_number AS out_order_number, lbp.wave_id AS out_wave_id, lbp.load_id AS out_load_id, 
           itm.display_item_number, lbp.item_number AS out_item_number, lbp.uom AS out_uom, lbp.planned_qty AS out_planned_qty, 
           lbp.status_label AS out_status_label, lbp.wh_id AS out_wh_id, lbp.printer_name AS out_printer_name
		 FROM t_labels_being_printed lbp
        INNER JOIN t_order_temp orm
           ON lbp.order_number = orm.order_number
          AND lbp.wh_id = orm.wh_id
        INNER JOIN t_item_master itm
           ON lbp.item_number = itm.item_number
          AND lbp.wh_id = itm.wh_id
		 WHERE w_user_name = @in_ww_UserName
	    
      END 

 
     GOTO ExitLabel

ErrorHandler:



IF @v_nLogErrorNum = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error  
        SELECT @v_vchErrorMsg = description 
	  FROM master.dbo.sysmessages 
	 WHERE error = @v_nErrorNumber
  
        SET @v_vchLogMsg = 'An SQL Server Error has occurred with a return code of ' +
		ISNULL(CONVERT(VARCHAR(30),@v_nErrorNumber),'(NULL)') + '. Error Message: ' + 
		ISNULL(CONVERT(varchar(400),@v_vchErrorMsg),'(NULL)') + '.'
	/*EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, @v_nLogLevel, @v_vchErrorMsg, 1*/
        --Raiserror
    END

IF @v_nLogErrorNum = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error
        SET @v_vchLogMsg = /*'An error occured in a stored procedure with a return code of ' +
                ISNULL(CONVERT(VARCHAR(30),@v_nErrorNumber),'(NULL)') + */'Error Message: ' +
                ISNULL(CONVERT(varchar(400),@v_vchErrorMsg),'(NULL)')
        /*EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, @v_nLogLevel, @v_vchErrorMsg, 1*/
        --Raiserror
    END


    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = @v_vchLogMsg + CONVERT(VARCHAR(3),@c_nModuleNumber) + ' -'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        -- + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)

ExitLabel:
     IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[tempdb].['+ USER  +'].[##t_order_temp]'))
        BEGIN
               DROP TABLE ##t_order_temp
        END

 	 DELETE t_labels_being_printed 
	 WHERE ((DATEDIFF(MINUTE, t_labels_being_printed.date_time, GETDATE())) > 60)

    -- Always leave the stored procedure from here.
    RETURN @v_nReturn

