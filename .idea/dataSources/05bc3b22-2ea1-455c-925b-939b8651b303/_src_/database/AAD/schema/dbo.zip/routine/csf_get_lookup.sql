

CREATE FUNCTION [dbo].[csf_get_lookup]
(
    @in_source          NVARCHAR(30),
	@in_type           NVARCHAR(50),
	@in_locale_id		INT,
	@in_text		 NVARCHAR(50)
)
RETURNS NVARCHAR(300)
AS
BEGIN
    DECLARE @v_desc NVARCHAR(200)

	SELECT @v_desc = description
	 FROM dbo.t_lookup
    WHERE source = @in_source
	  AND lookup_type = @in_type
	  AND locale_id =@in_locale_id
	  AND text = @in_text

            
    RETURN @v_desc

END

