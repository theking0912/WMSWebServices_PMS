
CREATE PROCEDURE usp_add_carrier
    @in_vchTranCode	            NVARCHAR(10),
    @in_vchCode                     NVARCHAR(30),
    @in_vchName                     NVARCHAR(100),
    @in_vchGroupName                NVARCHAR(100),
    @in_vchCDL                      NVARCHAR(3),
    @in_vchEarly                    NVARCHAR(12),
    @in_vchLate                     NVARCHAR(12),
    @in_vchDisposition              NVARCHAR(100),
    @in_vchTrailerType              NVARCHAR(50),
    @in_vchPriority                 NVARCHAR(3),
    @in_vchDockSchdMethod           NVARCHAR(50),
    @in_vchNotes                    NVARCHAR(250),
    @in_vchSCAC                     NVARCHAR(50),
    @in_vchTransportMode            NVARCHAR(30),
    @in_vchEffective                DATETIME,
    @in_vchStatus                   NVARCHAR(30),
    @in_chFreightFwdFlag            NCHAR(1),   
    @in_vchAddress1                 NVARCHAR(100),
    @in_vchAddress2                 NVARCHAR(100),
    @in_vchAddress3                 NVARCHAR(100),
    @in_vchAddress4                 NVARCHAR(100),
    @in_vchCity                     NVARCHAR(100),
    @in_vchCounty                   NVARCHAR(30),
    @in_vchState                    NVARCHAR(50),
    @in_vchZip                      NVARCHAR(12),
    @in_vchCountry                  NVARCHAR(50),
    @in_vchCountryCode              NVARCHAR(3),
    @in_vchPhone                    NVARCHAR(50),
    @in_vchExt                      NVARCHAR(6),
    @in_vchFax                      NVARCHAR(50),
    @in_vchEmail                    NVARCHAR(100),
    @in_chWebsite                   NVARCHAR(100),
    @in_vchManifestCarrierFlag      NVARCHAR(1),
    @in_vchServiceLevel	            NVARCHAR(100),
    @in_vchDescription	            NVARCHAR(100),
    @in_vchFlagshipCarrierCode      NVARCHAR(25),
    @in_vchFlagshipServiceCode      NVARCHAR(25),
    @in_vchShipCutOff               NVARCHAR(8)
AS
DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchLogMsg                NVARCHAR(500),
    @v_vchParam1                NVARCHAR(100),
    @v_nRaiseErrorNumber        INT,
    @v_nError                   INT,
    @v_nCustomError             INT,  
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @v_RecCount	                INT,
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_SelCAGFailed             INT,
    @e_SelTRTFailed             INT,
    -- Local Variables
    @v_nCarrierGroupID          INT,
    @v_nTrailerTypeID           INT
    -- Set Constants
    SET @c_nModuleNumber = 60     
    SET @c_nFileNumber = 3        -- This # must be unique per object.
    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SelCAGFailed = 2
    SET @e_SelTRTFailed = 3
   
    SET NOCOUNT ON
 IF @in_vchTranCode = 'U'
    GOTO UpdateCheck
 IF @in_vchTranCode = 'N'
    GOTO NewCheck
 IF @in_vchTranCode = 'D'
    GOTO DeleteCheck
 ELSE
    GOTO ExitLabel
    --If Tran Code = 'U' check for existence and update or insert accordingly
UpdateCheck:
    IF @in_vchTranCode = 'U'
	SELECT @v_RecCount = COUNT (*) FROM t_carrier 
		WHERE carrier_code = @in_vchCode
		SELECT @v_nError = @@ERROR
		IF @v_nError <> 0
		   BEGIN
			SET @v_nCustomError = @e_GenSqlError
			GOTO ErrorHandler
		   END
			  IF @v_RecCount > 0
			     GOTO UpdateLabel
		    	  ELSE
			     GOTO InsertLabel
			
    --If Tran Code = 'N' check for existence and update or insert accordingly
NewCheck:
    IF @in_vchTranCode = 'N'
        SELECT @v_RecCount = COUNT (*) FROM t_carrier 
		WHERE carrier_code = @in_vchCode
		SELECT @v_nError = @@ERROR
		IF @v_nError <> 0
		   BEGIN
			SET @v_nCustomError = @e_GenSqlError
			GOTO ErrorHandler
		   END
		   	IF @v_RecCount > 0
			   GOTO UpdateLabel
	    		ELSE
			   GOTO InsertLabel

    --If Tran Code = 'D' then delete record from t_carrier
DeleteCheck:
    IF @in_vchTranCode = 'D'
	BEGIN
	  DELETE t_manifest_carrier
          WHERE carrier_id IN (SELECT carrier_id FROM t_carrier WHERE carrier_code = @in_vchCode)
		SELECT @v_nError = @@ERROR
		IF @v_nError <> 0
		   BEGIN
			SET @v_nCustomError = @e_GenSqlError
			GOTO ErrorHandler
		   END
	  DELETE t_carrier where carrier_code = @in_vchCode
		SELECT @v_nError = @@ERROR
		IF @v_nError <> 0
		   BEGIN
			SET @v_nCustomError = @e_GenSqlError
			GOTO ErrorHandler
		   END
	END
     GOTO ExitLabel

UpdateLabel:  
    -- If status is not filled, use a default.
    IF @in_vchStatus IS NULL
        SET @in_vchStatus = 'A'  -- A status of "A" is used in WA.

    -- With the Group Name, grab the Carrier Group ID.  If the Group Name sent does not exist, log an
    -- informational message.
    IF @in_vchGroupName IS NOT NULL
    BEGIN
        -- Check to see if t_carrier_group exists.  If not, move on.
        IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('dbo.t_carrier_group'))
        BEGIN
            SELECT @v_nCarrierGroupID = carrier_group_id
                FROM t_carrier_group
                WHERE carrier_group_name = @in_vchGroupName
    
            -- Check for errors
            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nError <> 0 OR @v_nRowCount = 0 
            BEGIN
                IF @v_nError <> 0
                BEGIN
                    SET @v_nCustomError = @e_GenSqlError
                    GOTO ErrorHandler
                END
                ELSE
                BEGIN
                    -- Send a log message of level 3 (info).
                    SET @v_nCustomError = @e_SelCAGFailed
                    SET @v_vchLogMsg = 'The Carrier Group Name [' + @in_vchGroupName +
                        '] does not exist in the t_carrier_group table.'
                  --  EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 3, @v_vchLogMsg, 1
                END
            END
        END
    END

    -- With the Equipment Type, grab the Equipment ID.  If the Equipment Type sent does not exist, log an
    -- informational message.
    IF @in_vchTrailerType IS NOT NULL
    BEGIN
        SELECT @v_nTrailerTypeID = equipment_id
            FROM t_equipment
            WHERE equipment_name = @in_vchTrailerType

        -- Check for errors
        SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nError <> 0 OR @v_nRowCount = 0 
        BEGIN
            IF @v_nError <> 0
            BEGIN
                SET @v_nCustomError = @e_GenSqlError
                GOTO ErrorHandler
            END    
            ELSE
            BEGIN
                -- Send a log message of level 3 (info).
                SET @v_nCustomError = @e_SelTRTFailed
                SET @v_vchLogMsg = 'The Equipment Name [' + @in_vchTrailerType +
                    '] does not exist in the t_equipment table.'
              --  EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 3, @v_vchLogMsg, 1
            END
        END
    END


    -- Perform an update first with the Code sent.  If no records were updated, do an insert.
    UPDATE t_carrier
        SET carrier_group_id        = @v_nCarrierGroupID,
            transport_mode          = @in_vchTransportMode,
            cdl_verify              = @in_vchCDL,
            time_allowed_early      = @in_vchEarly,
            time_allowed_late       = @in_vchLate,
            disposition             = @in_vchDisposition,
            default_trailer_type_id = @v_nTrailerTypeID,
            default_priority        = @in_vchPriority,
            dock_schedule_method    = @in_vchDockSchdMethod,
            notes                   = @in_vchNotes,
            status                  = @in_vchStatus,
            freight_fwd_flag        = @in_chFreightFwdFlag,
            address1                = @in_vchAddress1,
            address2                = @in_vchAddress2,
            address3                = @in_vchAddress3,
            address4                = @in_vchAddress4,
            city                    = @in_vchCity,
            county                  = @in_vchCounty,
            state                   = @in_vchState,
            zip                     = @in_vchZip,
            country                 = @in_vchCountry,
            country_code            = @in_vchCountryCode,
            phone                   = @in_vchPhone,
            extension               = @in_vchExt,
            fax                     = @in_vchFax,
            email                   = @in_vchEmail,
            website                 = @in_chWebsite,
            manifest_carrier_flag   = ISNULL(@in_vchManifestCarrierFlag,'N'),
            flagship_carrier_code   = @in_vchFlagshipCarrierCode
        WHERE carrier_code = @in_vchCode

    -- Check for errors and grab the rowcount to check if a row was updated.
    SELECT @v_nError = @@ERROR

    IF @v_nError <> 0
    BEGIN
        SET @v_nCustomError = @e_GenSqlError
        GOTO ErrorHandler
    END

    UPDATE t_manifest_carrier
       SET description			= @in_vchDescription,
	   ship_cut_off			= @in_vchShipCutOff,
	   flagship_service_code	= @in_vchFlagshipServiceCode
     WHERE carrier_id IN (SELECT carrier_id FROM t_carrier WHERE carrier_code = @in_vchCode)
       AND service_level = @in_vchServiceLevel

    -- Check for errors and grab the rowcount to check if a row was updated.
    SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT

    IF @v_nError <> 0
    BEGIN
        SET @v_nCustomError = @e_GenSqlError
        GOTO ErrorHandler
    END

    IF @v_nRowCount = 0
    BEGIN
        IF @in_vchServiceLevel IS NOT NULL
            BEGIN
                DELETE FROM t_manifest_carrier
                    WHERE carrier_id IN (SELECT carrier_id 
                                           FROM t_carrier
                                          WHERE carrier_code = @in_vchCode)
                      AND flagship_service_code = @in_vchFlagshipServiceCode

		INSERT INTO t_manifest_carrier (
			carrier_id,
			service_level,
			description,
			ship_cut_off,
			flagship_service_code
			)
		SELECT carrier_id, 
			@in_vchServiceLevel,
			@in_vchDescription,
			@in_vchShipCutOff,
			@in_vchFlagshipServiceCode
		FROM t_carrier WHERE carrier_code = @in_vchCode

	    	SELECT @v_nError = @@ERROR
	    	IF @v_nError <> 0
	    	BEGIN
	        	SET @v_nCustomError = @e_GenSqlError
	        	GOTO ErrorHandler
	    	END
            END
    END
   GOTO ExitLabel

InsertLabel:
    -- If status is not filled, use a default.
    IF @in_vchStatus IS NULL
        SET @in_vchStatus = 'A'  -- A status of "A" is used in WA.

    -- With the Group Name, grab the Carrier Group ID.  If the Group Name sent does not exist, log an
    -- informational message.
    IF @in_vchGroupName IS NOT NULL
    BEGIN
        -- Check to see if t_carrier_group exists.  If not, move on.
        IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('dbo.t_carrier_group'))
        BEGIN
            SELECT @v_nCarrierGroupID = carrier_group_id
                FROM t_carrier_group
                WHERE carrier_group_name = @in_vchGroupName
    
            -- Check for errors
            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nError <> 0 OR @v_nRowCount = 0 
            BEGIN
                IF @v_nError <> 0
                BEGIN
                    SET @v_nCustomError = @e_GenSqlError
                    GOTO ErrorHandler
                END
                ELSE
                BEGIN
                    -- Send a log message of level 3 (info).
                    SET @v_nCustomError = @e_SelCAGFailed
                    SET @v_vchLogMsg = 'The Carrier Group Name [' + @in_vchGroupName +
                        '] does not exist in the t_carrier_group table.'
                 --   EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 3, @v_vchLogMsg, 1
                END
            END
        END
    END

    -- With the Equipment Type, grab the Equipment ID.  If the Equipment Type sent does not exist, log an
    -- informational message.
    IF @in_vchTrailerType IS NOT NULL
    BEGIN
        SELECT @v_nTrailerTypeID = equipment_id
            FROM t_equipment
            WHERE equipment_name = @in_vchTrailerType

        -- Check for errors
        SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nError <> 0 OR @v_nRowCount = 0 
        BEGIN
            IF @v_nError <> 0
            BEGIN
                SET @v_nCustomError = @e_GenSqlError
                GOTO ErrorHandler
            END    
            ELSE
            BEGIN
                -- Send a log message of level 3 (info).
                SET @v_nCustomError = @e_SelTRTFailed
                SET @v_vchLogMsg = 'The Equipment Name [' + @in_vchTrailerType +
                    '] does not exist in the t_equipment table.'
              --  EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 3, @v_vchLogMsg, 1
            END
        END
    END


        INSERT INTO t_carrier (
            carrier_code,
            carrier_name,
            carrier_group_id,
            cdl_verify,
            time_allowed_early,
            time_allowed_late,
            disposition,
            default_trailer_type_id,
            default_priority,
            dock_schedule_method,
            notes,
            scac_code,
            transport_mode,
       	    effective,
            status,
            freight_fwd_flag,
            address1,
            address2,
            address3,
            address4,
            city,
            county,
            state,
            zip,
            country,
            country_code,
            phone,
            extension,
            fax,
            email,
            website,
            manifest_carrier_flag,
            flagship_carrier_code
            )
        VALUES
            (
            @in_vchCode,
            @in_vchName,
            @v_nCarrierGroupID,
            @in_vchCDL,
            @in_vchEarly,
            @in_vchLate,
            @in_vchDisposition,
            @v_nTrailerTypeID,
            @in_vchPriority,
            @in_vchDockSchdMethod,
            @in_vchNotes,
            @in_vchSCAC,
            @in_vchTransportMode,
            @in_vchEffective,
            @in_vchStatus,
            @in_chFreightFwdFlag,
            @in_vchAddress1,
            @in_vchAddress2,
            @in_vchAddress3,
            @in_vchAddress4,
            @in_vchCity,
            @in_vchCounty,
            @in_vchState,
            @in_vchZip,
            @in_vchCountry,
            @in_vchCountryCode,
            @in_vchPhone,
            @in_vchExt,
            @in_vchFax,
            @in_vchEmail,
            @in_chWebsite,
            ISNULL(@in_vchManifestCarrierFlag,'N'),
            @in_vchFlagshipCarrierCode
            )
    
        -- Check for errors
        SELECT @v_nError = @@ERROR
        IF @v_nError <> 0
        BEGIN
            SET @v_nCustomError = @e_GenSqlError
            GOTO ErrorHandler			
        END
	IF @in_vchServiceLevel IS NOT NULL
            BEGIN
		INSERT INTO t_manifest_carrier (
			carrier_id,
			service_level,
			description,
			ship_cut_off,
			flagship_service_code
			)
		SELECT carrier_id, 
			@in_vchServiceLevel,
			@in_vchDescription,
			@in_vchShipCutOff,
			@in_vchFlagshipServiceCode
		FROM t_carrier WHERE carrier_code = @in_vchCode
	    END		

        -- Check for errors
        SELECT @v_nError = @@ERROR
        IF @v_nError <> 0
        BEGIN
            SET @v_nCustomError = @e_GenSqlError
            GOTO ErrorHandler			
        END

    GOTO ExitLabel

ErrorHandler:
    IF @v_nCustomError = @e_GenSqlError
    BEGIN -- SQL Server Error -- 1
       -- Log Error    
       SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
     --  EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1, @v_vchLogMsg, 1
       -- Raiserror
       SET @v_vchParam1 = @v_nError
       SET @v_nRaiseErrorNumber = 50001  -- General SQL Server Error
    END
  
    -- Raise the error with error #, severity, state, paramater
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)        

ExitLabel:

    -- Always leave the stored procedure from here.
    RETURN
