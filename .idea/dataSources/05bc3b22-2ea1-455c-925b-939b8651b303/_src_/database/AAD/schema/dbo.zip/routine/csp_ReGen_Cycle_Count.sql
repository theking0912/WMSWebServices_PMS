-- Procedure
CREATE PROCEDURE [dbo].[csp_ReGen_Cycle_Count]    
     @wh_id				    NVARCHAR(10)   
    ,@location_id		    NVARCHAR(50) 
	,@work_q_id             NVARCHAR(30) 
	,@user_id				NVARCHAR(30)
AS

DECLARE 
    @v_nErrorNumber	  INT,
    @v_nLogLevel	  TINYINT,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INT,

    @c_nModuleNumber      INT,
    @c_nFileNumber        INT,
    @v_nRaiseErrorNumber  INT,
    @v_nReturn            INT,
    @v_vchErrorMsg        NVARCHAR(200),
	--ADD BY David
	@v_datedue            DATETIME,

-- Error Types
    @e_GenSqlError   	  INT,
    @e_InsWKQFailed       INT,
    @e_SprocError         INT,

    @v_nLoopCount         INT,
    @v_vchDescription     NVARCHAR(30),
    @v_vchWorkqId         NVARCHAR(30),
    @v_vchWhId            NVARCHAR(10),    
    @v_vchLocationId      NVARCHAR(50),
	@loop_loc			  nvarchar(30)

    SET NOCOUNT ON

    SET @c_nModuleNumber = 63
    SET @c_nFileNumber = 8
	SET @v_datedue = GETDATE()
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_InsWKQFailed = 2
    SET @e_SprocError = 3
	
	--Get Original Cycle count history
	declare @cc_item nvarchar(30)
	declare @work_type nvarchar(30)

	SELECT @cc_item = item_number
	from t_work_q
	WHERE wh_id = @wh_id
	and work_q_id = @work_q_id

	IF @work_q_id ='LOSS' 
	RAISERROR('损耗不能重新生成盘点',11,1)

	IF EXISTS ( SELECT 1 FROM t_location
					where location_id = @location_id
					and wh_id = @wh_id
					and status = 'I')
	BEGIN
		GoTo ExitLabel
	END

	if isnull(@cc_item,'') =''
		begin
			set @work_type = 'Cycle Count'

			IF EXISTS ( SELECT 1 FROM t_work_q
						WHERE wh_id = @wh_id
						AND location_id = @location_id
						AND (work_status = 'U' or work_status = 'A'))
				BEGIN
					GoTo ExitLabel
				END
		end
	else
		begin
			set @work_type = 'Cycle Count Item'

			IF EXISTS ( SELECT 1 FROM t_work_q
						WHERE wh_id = @wh_id
						AND location_id = @location_id
						AND item_number =  @cc_item
						AND (work_status = 'U' or work_status = 'A'))
				BEGIN
					GoTo ExitLabel
				END
		end

    EXECUTE @v_nReturn = usp_get_next_value 'WORK_Q_ID', @v_vchWorkqId OUTPUT,
							@v_nErrorNumber OUTPUT, @v_vchErrorMsg OUTPUT
    
    -- Check for sproc error
    IF @v_nReturn <> 0 -- zero is success value
    BEGIN
        SET @v_nErrorNumber = @e_SprocError
        GOTO ErrorHandler
    END

    -- Insert WKQ
    INSERT INTO t_work_q (work_q_id, wh_id, location_id, work_type, work_status, 
        description, priority, workers_required, date_due, time_due,item_number)
            VALUES (@v_vchWorkqId, @wh_id, @location_id,
            '08', 'U', @work_type, '90', 1, @v_datedue, @v_datedue,@cc_item)

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_InsWKQFailed
        GOTO ErrorHandler			
    END

	UPDATE tbl_cyclecount_history
	SET close_by = @user_id
	,close_sign ='Y'
	,close_time = getdate()
	,close_type ='REGEN CC'
	WHERE wh_id = @wh_id
	AND work_q_id = @work_q_id

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_InsWKQFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An attempt to insert a cycle count task for location ' +
            ISNULL(@v_vchLocationId,'(NULL)') + ' into ' +
            ' the t_work_q table failed.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50002 -- Insert failed
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(varchar(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

ExitLabel:
    SET NOCOUNT OFF
    RETURN
