-- Procedure
CREATE  procedure [dbo].[csp_Upate_Package_status]
 (
   @wh_id nvarchar(10),
   @shipment_number nvarchar(30),
   @package_number nvarchar(10),
   @flag         nvarchar
  ) as
  BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	DECLARE		@status	NVARCHAR(1)

	BEGIN TRY

		BEGIN TRANSACTION


		IF @flag = 'R'
		BEGIN
			SELECT * 
			  FROM t_receipt
			 WHERE wh_id = @wh_id
			 AND   shipment_number = @shipment_number	

			IF @@ROWCOUNT > 0
				SET @status = 'R'
			ELSE
			    SET @status = 'N'
		END

		IF @flag = 'A'
		    SET @status = 'A'

		IF @flag = 'C'
		    SET @status = 'C'
		
		update tbl_rcpt_ship_package
		set status = @status,close_date = GETDATE()
		where shipment_number = @shipment_number
		and wh_id = @wh_id
		and package_number = @package_number

		COMMIT		
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        RETURN
    END CATCH
  
END
