
CREATE TRIGGER tr_arch_backup_control_insert ON dbo.t_arch_backup_control FOR INSERT
AS 
BEGIN

DECLARE	@strErrorMessage		varchar(200),
        @nErrorNumber			integer,
	@nLogLevel			tinyint,
        @strObjName			varchar(30),

	@count				integer,
	@rows				integer

  -- Set constant values.
  SET @strObjName = 'tr_arch_backup_control_insert'

  SET NOCOUNT ON

  -- Grab the Database Log Level from t_sca_control.  If it doesn't exist, insert it.
  -- 0 = Off, 1 = On
  SELECT @nLogLevel = next_value FROM t_sca_control WHERE control_type = 'DB OBJ LOG LEVEL'

  IF @@ROWCOUNT = 0
    BEGIN
      INSERT INTO t_sca_control (control_type, description, next_value, config_display, allow_edit)
        VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', '0', 'SHOW_VA', '1')
      SET @nLogLevel = 0
    END

  SELECT @count = COUNT(*) 
   FROM inserted 
   WHERE table_name IN(SELECT TABLE_NAME 
                        FROM INFORMATION_SCHEMA.TABLES 
                        WHERE TABLE_TYPE='BASE TABLE')

  IF @count <= 0
    BEGIN
      -- Rollback this query if not within a transaction.
      IF @@trancount = 1
        ROLLBACK TRANSACTION
        RAISERROR ('Trigger Error: Invalid Table Name.', 10, 1)
        RETURN
    END

END
