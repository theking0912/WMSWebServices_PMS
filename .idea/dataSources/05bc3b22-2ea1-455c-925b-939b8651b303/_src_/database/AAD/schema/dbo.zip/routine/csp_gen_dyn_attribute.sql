
-- ======================================= 
-- Modification: Sep29, 2014 HDL JERRY
-- Description: Gennerate the Dynamic attribute by the UOM
-- =======================================
CREATE PROCEDURE [dbo].[csp_gen_dyn_attribute] @v_item_number NVARCHAR(50)
	,@wh_id NVARCHAR(20)
	,@msg NVARCHAR(200) OUTPUT
AS
DECLARE @attribute_id NVARCHAR(20)
	,@v_count INT
	,@RowId INT
	,@attribute_type NVARCHAR(20)
	,@collection_id NVARCHAR(50)
	,@uom_prompt NVARCHAR(100)
	,@newid NVARCHAR(100)
	,@uom NVARCHAR(50)
	,@sto_id BIGINT
	,@al_collection_id NVARCHAR(50)
	,@attribute_collection_name NVARCHAR(100)
	,@v_item_name NVARCHAR(100)

BEGIN
   /**Delete by George 2016.06.28
   SELECT  @attribute_id = attribute_id 
	 from t_attribute_type 
	 WHERE CHARINDEX(@v_item_number, attribute_type)>0
  **/

	SELECT TOP 1 @collection_id = attribute_collection_id
	FROM dbo.t_attribute_collection_master WITH (NOLOCK)
	WHERE CHARINDEX(@v_item_number, attribute_collection_name) > 0

	SELECT TOP 1 @attribute_id = attribute_id
	FROM dbo.t_attribute_collection_detail WITH (NOLOCK)
	WHERE attribute_collection_id = @collection_id

	IF ISNULL(@attribute_id, '') <> ''
	BEGIN
		DELETE
		FROM t_attribute_values
		WHERE NOT EXISTS (
				SELECT 1
				FROM t_item_uom WITH (NOLOCK)
				WHERE item_number = @v_item_number 
					AND wh_id = @wh_id 
					AND uom_prompt = attribute_value
				)
			AND attribute_id = @attribute_id

		DELETE
		FROM dbo.t_sto_attrib_collection_detail
		WHERE NOT EXISTS (
				SELECT 1
				FROM t_attribute_values WITH (NOLOCK)
				WHERE attribute_id = t_sto_attrib_collection_detail.attribute_id
					AND attribute_value = t_sto_attrib_collection_detail.attribute_value
				)
			AND dbo.t_sto_attrib_collection_detail.attribute_id = @attribute_id
			AND EXISTS (
				SELECT 1
				FROM t_item_uom WITH (NOLOCK)
				WHERE item_number = @v_item_number 
					AND wh_id = @wh_id 
					AND uom_prompt = t_sto_attrib_collection_detail.attribute_value
				)
	END
 
	SELECT TOP 1 @v_item_number = item_number
		,@collection_id = attribute_collection_id
		,@v_item_name = description
	FROM dbo.t_item_master t WITH (NOLOCK)
	WHERE pack_flag = 'Y'
		AND item_number = @v_item_number
		AND wh_id = @wh_id
		AND EXISTS (
			SELECT 1
			FROM t_item_uom WITH (NOLOCK)
			WHERE conversion_factor > 1
				AND item_number = t.item_number
				AND uom NOT IN (
					'KG'
					,'L'
					,'JIN'
					)
			)

	SELECT @v_count = @@ROWCOUNT

	IF @v_count = 0
	BEGIN
		SET @msg = '没有需要生成的规格'

		RETURN
	END

	SELECT @attribute_type = '打包规格(' + @v_item_name + ')'

	SELECT TOP 1 @collection_id = attribute_collection_id
	FROM dbo.t_attribute_collection_master WITH (NOLOCK)
	WHERE CHARINDEX(@v_item_number, attribute_collection_name) > 0

	IF ISNULL(@collection_id, '') = ''
	BEGIN
		SET @attribute_collection_name = '打包规格(' + @v_item_number + ')'

		INSERT INTO t_attribute_type (
			attribute_type
			,description
			,import_validation
			,lookup_validation
			,create_date
			,modified_date
			,prompt_validation
			,allow_mix
			)
		VALUES (
			@attribute_type
			,@attribute_type
			,'N'
			,'Y'
			,GETDATE()
			,GETDATE()
			,'P'
			,'Y'
			)

		EXECUTE dbo.usp_attribute_collection_id @attribute_collection_name
			,@RowId OUTPUT

		/**Modified by Trevor 2016.06.28**/

		--SELECT @attribute_id = @@IDENTITY
		select @attribute_id =attribute_id from t_attribute_type where attribute_type = @attribute_type
		
		/**Modified by Trevor 2016.06.28**/

		INSERT INTO t_attribute_collection_detail (
			attribute_collection_id
			,attribute_id
			,sequence_id
			)
		SELECT @RowId
			,@attribute_id
			,(
				SELECT COALESCE(MAX(sequence_id) + 1, 1)
				FROM t_attribute_collection_detail WITH (NOLOCK)
				WHERE attribute_collection_id = @RowId
				)

		UPDATE dbo.t_item_master
		SET attribute_collection_id = @RowId
		WHERE item_number = @v_item_number 
			AND wh_id = @wh_id 
	END
	ELSE
	BEGIN
		SELECT TOP 1 @attribute_id = attribute_id
		FROM dbo.t_attribute_collection_detail WITH (NOLOCK)
		WHERE attribute_collection_id = @collection_id

		UPDATE dbo.t_item_master
		SET attribute_collection_id = @collection_id
		WHERE item_number = @v_item_number 
			AND wh_id = @wh_id 
	END

	SELECT @v_count = COUNT(1)
	FROM dbo.t_item_uom WITH (NOLOCK)
	WHERE item_number = @v_item_number 
		AND wh_id = @wh_id 
		AND conversion_factor > 1
		AND uom NOT IN (
			'KG'
			,'L'
			,'JIN'
			)
		AND NOT EXISTS (
			SELECT 1
			FROM t_sto_attrib_collection_detail WITH (NOLOCK)
			WHERE attribute_id = @attribute_id
				AND uom_prompt = attribute_value
			)

	IF @v_count = 0
	BEGIN
		SET @msg = '没有需要生成的规格'

		GOTO ExitLabel
	END
	ELSE
	BEGIN
		WHILE (1 = 1)
		BEGIN
			SELECT TOP 1 @uom_prompt = uom_prompt
				,@uom = uom
			FROM t_item_uom WITH (NOLOCK)
			WHERE item_number = @v_item_number 
				AND wh_id = @wh_id 
				AND conversion_factor > 1
				AND uom NOT IN (
					'KG'
					,'L'
					,'JIN'
					)
				AND NOT EXISTS (
					SELECT 1
					FROM dbo.t_sto_attrib_collection_detail WITH (NOLOCK)
					WHERE attribute_id = @attribute_id
						AND uom_prompt = attribute_value
					)

			SET @v_count = @@ROWCOUNT

			IF @v_count > 0
			BEGIN
				INSERT INTO t_attribute_values
				SELECT @attribute_id
					,uom_prompt
				FROM dbo.t_item_uom WITH (NOLOCK)
				WHERE item_number = @v_item_number
					AND uom = @uom
					AND wh_id = @wh_id
					AND NOT EXISTS (
						SELECT 1
						FROM t_attribute_values WITH (NOLOCK)
						WHERE attribute_id = @attribute_id
							AND attribute_value = t_item_uom.uom_prompt
						)

				SET @newid = newID()

				INSERT INTO t_user_entered_attributes (
					identifier
					,attribute_id
					,attribute_value
					)
				VALUES (
					@newid
					,@attribute_id
					,@uom_prompt
					)

				EXECUTE usp_dynamic_get_stored_attribute_id @wh_id
					,@v_item_number
					,'INTERFACE'
					,@newid
					,@sto_id OUTPUT
			END
			ELSE
			BEGIN
				BREAK
			END
		END
	END

	INSERT INTO t_attribute_values
	SELECT @attribute_id
		,uom_prompt
	FROM dbo.t_item_uom WITH (NOLOCK)
	WHERE item_number = @v_item_number 
		AND wh_id = @wh_id 
		AND conversion_factor >= 1
		AND NOT EXISTS (
			SELECT 1
			FROM t_attribute_values WITH (NOLOCK)
			WHERE attribute_id = @attribute_id
				AND uom_prompt = attribute_value
			)
		AND EXISTS (
			SELECT 1
			FROM dbo.t_sto_attrib_collection_detail WITH (NOLOCK)
			WHERE attribute_id = @attribute_id
				AND uom_prompt = attribute_value
			)
		AND ISNULL(@attribute_id, '') <> ''
		AND status = 'ACTIVE'

	ExitLabel:

	PRINT 'Transaction' + CAST(@@TRANCOUNT AS VARCHAR)

	RETURN
END
