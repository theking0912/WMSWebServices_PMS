CREATE PROCEDURE   csp_exp_updatedate_po
AS--
/*
UPDATE tbl_inf_exp_inoutbound 
SET  BUDAT=REPLACE(CONVERT(VARCHAR(10), b.receipt_date ,120),'-',''),
	 BLDAT=REPLACE(CONVERT(VARCHAR(10),isnull(date_posting,b.receipt_date),120),'-','')  

from tbl_inf_exp_inoutbound a,
     tbl_inf_exp_receipt b

	 WHERE a.DATA_DETAILID=b.id*/