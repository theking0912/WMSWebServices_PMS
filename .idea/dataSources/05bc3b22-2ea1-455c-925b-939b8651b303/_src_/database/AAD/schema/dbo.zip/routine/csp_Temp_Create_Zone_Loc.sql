-- =============================================
-- Author:		LAVER
-- Create date: 2014-10-15
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Create_Zone_Loc]
	@In_Nvch_Wh_ID			AS	NVARCHAR(10),
	@In_Nvch_Loc_ID			AS	NVARCHAR(50),
	@In_Nvch_Zone			AS	NVARCHAR(10),
	@In_Nvch_Pick_Seq		AS	NVARCHAR(30),
	@Out_Nvch_Msg_Code		AS	NVARCHAR(10)		OUTPUT,
	@Out_Nvch_Msg			AS	NVARCHAR(200)		OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    BEGIN TRY
		IF NOT EXISTS(SELECT zone 
						FROM t_zone_loca
						WHERE wh_id = @In_Nvch_Wh_ID
						AND location_id = @In_Nvch_Loc_ID)
		BEGIN
			INSERT INTO t_zone_loca
			            (wh_id,zone,location_id,pick_seq)
			      VALUES(@In_Nvch_Wh_ID,
				         @In_Nvch_Zone,
						 @In_Nvch_Loc_ID,
						 @In_Nvch_Pick_Seq)

			SET @Out_Nvch_Msg_Code = 'SUCCESS'
		END
		ELSE -- EXUSTS
		BEGIN
			SET @Out_Nvch_Msg_Code = 'FAILED'
		END
	    
		RETURN
	END TRY

	BEGIN CATCH
		SET @Out_Nvch_Msg_Code = 'FAILED'
		SET @Out_Nvch_Msg = ERROR_MESSAGE()
	END CATCH
END
