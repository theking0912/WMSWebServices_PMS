
CREATE PROCEDURE [dbo].[usp_xml_import_vendor]
	(
		 @v_vchHostGroupID		NVARCHAR(36)
		,@out_vchCode           uddt_output_code   OUTPUT
		,@out_vchMsg            uddt_output_msg    OUTPUT
	)
	
AS

-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                         HighJump Software
--                         Minneapolis, Minnesota, USA
-- ********************************************************************************
-- 
--    PURPOSE:
--          The purpose of this stored procedure is to populate GHI Tables for 
--              Vendor Import
--
--    DESCRIPTION:
--	
--    INPUT:
--      Host Group ID
--
--    OUTPUT:
--        out_vchCode - Contains 'SUCCESS' or Error Code.
--        out_vchMsg - Contains the error message or informational log message.:
--      
--  TARGET: SQL Server 
--
-- *********************************************************************************
	
DECLARE

----------------------------------------------------------------------------------------------------------------------------	
-- Procedure variables
----------------------------------------------------------------------------------------------------------------------------
		
	@v_dtRecordCreateDate		DATETIME
	
		
----------------------------------------------------------------------------------------------------------------------------	
-- Local Variables
----------------------------------------------------------------------------------------------------------------------------
	,@c_vchObjName               uddt_obj_name	 	
	,@v_nSysErrorNum			INT
	,@v_vchMsg					NVARCHAR(4000)
    ,@v_vchCode					NVARCHAR(10)
    ,@v_nRetryCount				INT
	,@v_nTranCount				INT	
	,@v_nXstate					INT			


SET NOCOUNT ON

----------------------------------------------------------------------------------------------------------------------------	
-- Set Constants
----------------------------------------------------------------------------------------------------------------------------

SET @c_vchObjName = N'usp_xml_import_vendor'
SET @v_vchCode = N'SUCCESS'
SET @v_vchMsg  = N'NONE'
SET @v_nSysErrorNum = 0
SET @v_nTranCount = 0



----------------------------------------------------------------------------------------------------------------------------	
-- Insert GHI Records
----------------------------------------------------------------------------------------------------------------------------

---- Insert Vendor Master ------------------------------

SET @v_dtRecordCreateDate = GETDATE()	
SET @v_nRetryCount = 3


INS_AL:

BEGIN TRY
	SET @v_nTranCount = @@TRANCOUNT 
	
	IF @v_nTranCount = 0 
        BEGIN TRANSACTION 
    ELSE 
        SAVE TRANSACTION SAVEPOINT
		
    SET XACT_ABORT ON
	
		INSERT INTO t_al_host_vendor_master(
			 host_group_id
			,record_create_date
			,processing_code
			,vendor_code
			,vendor_name				
			)
		SELECT
			 @v_vchHostGroupID
			,@v_dtRecordCreateDate
			,ven.TransactionCode 
			,ven.VendorCode
			,ven.VendorName			
		 FROM t_xml_imp_vendor ven WITH (NOLOCK)
		WHERE ven.hjs_parent_id = @v_vchHostGroupID
		ORDER BY ven.hjs_sequence    
		 
	COMMIT TRANSACTION
	
	SET XACT_ABORT OFF	
	
END TRY
 
BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
	SET @v_nTranCount = @@TRANCOUNT
	SET @v_nXstate = XACT_STATE() 
  
	IF @v_nXstate = -1 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount = 0 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount > 0 
        ROLLBACK TRANSACTION SAVEPOINT   

	

-- Check for Deadlock and Retry as long as the Retry Counter is greater than zero  
    IF (@v_nRetryCount > 0 AND @v_nSysErrorNum = 1205) 
	BEGIN
		SET @v_nRetryCount = @v_nRetryCount - 1
		SET XACT_ABORT OFF;	
		GOTO INS_AL
	END

	SET @v_vchCode = N'-20001'    
    SET @v_vchMsg = N'A SQL error occured while inserting t_xml_exp records for Vendor Import.'	
	SET @v_vchMsg = @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE()
	GOTO ERROR_HANDLER
END CATCH

GOTO EXIT_LABEL
	
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + N'Deadlock error: 40001 ' + @v_vchMsg
    ELSE    
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + @v_vchMsg 
		
    --Should only raise error in the parent sproc
    RAISERROR(@v_vchMsg, 11, 1)
    
    -- Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg
    
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

-- Always leave the stored procedure from here.
RETURN 
