
CREATE VIEW v_al_host_item_uom_orientation AS
SELECT
host_item_uom_orient_id,
host_item_uom_id,
host_group_id,
record_create_date,
processing_code,
item_number,
display_item_number,
wh_id,
client_code,
uom,
orientation_number,
length,
width,
height,
bottom_only,
top_only,
max_in_layer,
max_support_weight,
stack_index,
pattern
  FROM t_al_host_item_uom_orientation
