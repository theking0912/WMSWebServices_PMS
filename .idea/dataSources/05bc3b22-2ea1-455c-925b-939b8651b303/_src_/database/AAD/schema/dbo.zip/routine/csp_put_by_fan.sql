
--扇形上架location_id
CREATE PROCEDURE [dbo].[csp_put_by_fan]
	@in_zone_type 					NVARCHAR(10)
	,@in_vchWhID 					NVARCHAR(10)
	,@in_item_number 				NVARCHAR(30)
	,@in_lot_number 				NVARCHAR(30)
	,@in_qty 						INT
	,@out_put_location_id 			NVARCHAR(30) 		OUTPUT
	,@error_code 					NVARCHAR(10)		OUTPUT
	,@error_msg 					NVARCHAR(100) 		OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @nvch_location_id 			NVARCHAR(30)
	DECLARE @nvch_pick_seq 				NVARCHAR(30)
	DECLARE @cage_rate 					FLOAT
	DECLARE @full_pallet_qty 			FLOAT
	DECLARE @pallet_qty 				FLOAT

	SELECT @cage_rate = f1
	FROM t_control
	WHERE control_type = 'FULL_CAGE_PLATE_RATE'

	IF isnull(@cage_rate, '') = ''
		SET @cage_rate = 1

	SELECT @pallet_qty = f1
	FROM t_control
	WHERE control_type = 'RECEIPT_PLATE_RATE'

	IF isnull(@pallet_qty, '') = ''
		SET @pallet_qty = 1.1

	SELECT @full_pallet_qty = full_pallet_qty * @pallet_qty
	FROM t_item_master
	WHERE
		wh_id = @in_vchWhID
		AND item_number = @in_item_number

	--如果上架数量小于货笼储位的货位容量，则上架到绑定该商品货位上方的货位,对于LP储位，系统只能指示到空货位，因为存在另一个商品无法计算货位容量
	IF @in_qty <= @full_pallet_qty * @cage_rate
	BEGIN
		SELECT TOP 1 @nvch_location_id = loc.location_id
		FROM t_location loc WITH (NOLOCK)
		INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
		INNER JOIN 		 t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
		WHERE
			loc.wh_id = @in_vchWhID
			AND z.zone_type + z.zone_group = @in_zone_type
			AND loc.type IN ('L')
			AND loc.status NOT IN ('I','H')
			AND NOT EXISTS 
			(
				SELECT 1
				FROM t_stored_item sto
				WHERE
					sto.wh_id = loc.wh_id
					AND sto.location_id = loc.location_id
			)
			AND EXISTS
			(
				SELECT 1
				FROM tbl_loc_item li WITH (NOLOCK)
				WHERE
					loc.wh_id = li.wh_id
					AND li.item_number = @in_item_number
					AND left(loc.location_id, 7) = left(li.location_id, 7)
			)
		ORDER BY loc.location_id,zl.pick_seq

		IF isnull(@nvch_location_id, '') = ''
		BEGIN
			SELECT TOP 1 @nvch_location_id = loc.location_id
			FROM t_location loc WITH (NOLOCK)
			INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
			INNER JOIN       t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
			WHERE
				loc.wh_id = @in_vchWhID
				AND z.zone_type + z.zone_group = @in_zone_type
				AND loc.type IN ('L')
				AND loc.status NOT IN ('I','H')
				AND NOT EXISTS
				(
					SELECT 1
					FROM t_stored_item sto
					WHERE
						sto.wh_id = loc.wh_id
						AND sto.location_id = loc.location_id
				)
				AND EXISTS
				(
					SELECT 1
					FROM tbl_loc_item li WITH (NOLOCK)
					WHERE loc.wh_id = li.wh_id
						AND li.item_number = @in_item_number
						AND left(loc.location_id, 7) = left(li.location_id, 7)
						AND cast(right(loc.location_id, 1) AS INT) IN 
						(
							(cast(right(li.location_id, 1) AS INT) - 1)
							,cast(right(li.location_id, 1) AS INT) + 1
						)
				)
			ORDER BY loc.location_id,zl.pick_seq
		END
	END

	--如果上架数量小于托盘储位的货位容量，则上架到绑定该商品货位上方的货位
	IF isnull(@nvch_location_id, '') = ''
	BEGIN
		SELECT TOP 1 @nvch_location_id = loc.location_id
		FROM t_location loc WITH (NOLOCK)
		INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
		INNER JOIN       t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
		WHERE
			loc.wh_id = @in_vchWhID
			AND z.zone_type + z.zone_group = @in_zone_type
			AND loc.type IN ('P')
			AND loc.status NOT IN ('I','H')
			AND NOT EXISTS 
			(
				SELECT 1
				FROM t_stored_item sto
				WHERE
					sto.wh_id = loc.wh_id
					AND sto.location_id = loc.location_id
			)
			AND EXISTS 
			(
				SELECT 1
				FROM tbl_loc_item li WITH (NOLOCK)
				WHERE
					loc.wh_id = li.wh_id
					AND li.item_number = @in_item_number
					AND left(loc.location_id, 7) = left(li.location_id, 7)
			)
		ORDER BY loc.location_id,zl.pick_seq

		IF isnull(@nvch_location_id, '') = ''
		BEGIN
			SELECT TOP 1 @nvch_location_id = loc.location_id
			FROM t_location loc WITH (NOLOCK)
			INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
			INNER JOIN       t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
			WHERE
				loc.wh_id = @in_vchWhID
				AND z.zone_type + z.zone_group = @in_zone_type
				AND loc.type IN ('P')
				AND loc.status NOT IN ('I','H')
				AND NOT EXISTS
				(
					SELECT 1
					FROM t_stored_item sto
					WHERE
						sto.wh_id = loc.wh_id
						AND sto.location_id = loc.location_id
				)
				AND EXISTS 
				(
					SELECT 1
					FROM tbl_loc_item li WITH (NOLOCK)
					WHERE loc.wh_id = li.wh_id
						AND li.item_number = @in_item_number
						AND left(loc.location_id, 7) = left(li.location_id, 7)
						AND cast(right(loc.location_id, 1) AS INT) IN 
						(
							(cast(right(li.location_id, 1) AS INT) - 1)
							,cast(right(li.location_id, 1) AS INT) + 1
						)
				)
			ORDER BY loc.location_id,zl.pick_seq

			--如果上架数量小于后推式储位的货位容量，则上架到绑定该商品货位上方的没有该商品库存的货位
			IF isnull(@nvch_location_id, '') = ''
			BEGIN
				SELECT TOP 1 @nvch_location_id = loc.location_id
				FROM t_location loc WITH (NOLOCK)
				INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
				INNER JOIN       t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
				LEFT JOIN
				(
					SELECT wh_id,location_id,item_number,lot_number,actual_qty
					FROM t_stored_item WITH (NOLOCK)
					WHERE
						wh_id = @in_vchWhID
						AND status = 'A'
				) sto ON sto.wh_id = loc.wh_id AND sto.location_id = loc.location_id
				WHERE
					loc.wh_id = @in_vchWhID
					AND z.zone_type + z.zone_group = @in_zone_type
					AND loc.type IN ('H')
					AND loc.status NOT IN ('I','H')
					AND NOT EXISTS
					(
						SELECT 1
						FROM t_stored_item sto
						WHERE
							sto.wh_id = loc.wh_id
							AND sto.location_id = loc.location_id
							AND sto.item_number = @in_item_number
					)
					AND EXISTS
					(
						SELECT 1
						FROM t_item_master li
						WHERE sto.wh_id = li.wh_id
							AND sto.item_number = li.item_number
							AND isnull(sto.actual_qty, 0) + @in_qty <= isnull(li.full_pallet_qty, 0) * 
							(
								isnull(loc.storage_device_id, 1) - isnull
								(
									(
										SELECT sum(ceiling(total_actual_qty / isnull(im.full_pallet_qty, 1)))
										FROM (
											SELECT st.wh_id
												,st.item_number
												,sum(actual_qty) AS total_actual_qty
											FROM t_stored_item st
											WHERE st.wh_id = loc.wh_id
												AND st.location_id = loc.location_id
												AND st.item_number <> @in_item_number
												AND st.status = 'A'
											GROUP BY st.wh_id
												,st.location_id
												,st.item_number
											) sto
										INNER JOIN t_item_master im ON sto.wh_id = im.wh_id
											AND sto.item_number = im.item_number
									), 0
								)
							)
					)
					AND EXISTS
					(
						SELECT 1
						FROM tbl_loc_item li WITH (NOLOCK)
						WHERE
							loc.wh_id = li.wh_id
							AND li.item_number = @in_item_number
							AND left(loc.location_id, 7) = left(li.location_id, 7)
					)
				ORDER BY loc.location_id,zl.pick_seq

				IF isnull(@nvch_location_id, '') = ''
				BEGIN
					SELECT TOP 1 @nvch_location_id = loc.location_id
					FROM t_location loc WITH (NOLOCK)
					INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
					INNER JOIN       t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
					LEFT JOIN 
					(
						SELECT wh_id,location_id,item_number,lot_number,actual_qty
						FROM t_stored_item WITH (NOLOCK)
						WHERE
							wh_id = @in_vchWhID
							AND status = 'A'
					) sto ON sto.wh_id = loc.wh_id AND sto.location_id = loc.location_id
					WHERE loc.wh_id = @in_vchWhID
						AND z.zone_type + z.zone_group = @in_zone_type
						AND loc.type IN ('H')
						AND loc.status NOT IN ('I','H')
						AND NOT EXISTS 
						(
							SELECT 1
							FROM t_stored_item sto
							WHERE
								sto.wh_id = loc.wh_id
								AND sto.location_id = loc.location_id
								AND sto.item_number = @in_item_number
						)
						AND EXISTS 
						(
							SELECT 1
							FROM t_item_master li
							WHERE sto.wh_id = li.wh_id
								AND sto.item_number = li.item_number
								AND isnull(sto.actual_qty, 0) + @in_qty <= isnull(li.full_pallet_qty, 0) * 
								(
									isnull(loc.storage_device_id, 1) - isnull
									(
										(
											SELECT sum(ceiling(total_actual_qty / isnull(im.full_pallet_qty, 1)))
											FROM (
												SELECT st.wh_id
													,st.item_number
													,sum(actual_qty) AS total_actual_qty
												FROM t_stored_item st
												WHERE st.wh_id = loc.wh_id
													AND st.location_id = loc.location_id
													AND st.item_number <> @in_item_number
													AND st.status = 'A'
												GROUP BY st.wh_id
													,st.location_id
													,st.item_number
												) sto
											INNER JOIN t_item_master im ON sto.wh_id = im.wh_id
												AND sto.item_number = im.item_number
										), 0
									)
								)
						)
						AND EXISTS 
						(
							SELECT 1
							FROM tbl_loc_item li WITH (NOLOCK)
							WHERE loc.wh_id = li.wh_id
								AND li.item_number = @in_item_number
								AND left(loc.location_id, 7) = left(li.location_id, 7)
								AND cast(right(loc.location_id, 1) AS INT) IN 
								(
									(cast(right(li.location_id, 1) AS INT) - 1)
									,cast(right(li.location_id, 1) AS INT) + 1
								)
						)
					ORDER BY loc.location_id,zl.pick_seq
				END
			END
		END
	END

	SET @out_put_location_id = @nvch_location_id

	RETURN
END
