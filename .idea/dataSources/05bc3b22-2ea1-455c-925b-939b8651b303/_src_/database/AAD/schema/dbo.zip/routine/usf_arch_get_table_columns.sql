

CREATE  FUNCTION usf_arch_get_table_columns (@in_vchObject_Name  NVARCHAR(100))
RETURNS NVARCHAR(4000)
 AS   
BEGIN 
        DECLARE @Result         NVARCHAR(4000),
                @vCount         INTEGER,      
                @vObjectName    NVARCHAR(100),       
                @vObjectType    NVARCHAR(30),
                @vTableName     NVARCHAR(100),
                @vTableID       INTEGER,

          --Columns cursor variables
                @vCOLUMN_NAME               NVARCHAR(128), 
                @vDATA_TYPE                 NVARCHAR(128),
                @vCHARACTER_MAXIMUM_LENGTH  INTEGER,
                @vCHARACTER_OCTET_LENGTH   INTEGER,
                @vNUMERIC_PRECISION         INTEGER,
                @vNUMERIC_PRECISION_RADIX   INTEGER,
                @vNUMERIC_SCALE             INTEGER

          --Initialize variables   

           SET @vObjectName = @in_vchObject_Name
           SET @Result = ''


           DECLARE columns_cursor CURSOR FOR 
            SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
                   CHARACTER_OCTET_LENGTH, NUMERIC_PRECISION, NUMERIC_PRECISION_RADIX,
                   NUMERIC_SCALE
              FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_NAME =  @vObjectName 
          ORDER BY ORDINAL_POSITION




          OPEN columns_cursor

          FETCH NEXT FROM columns_cursor 
          INTO @vCOLUMN_NAME, @vDATA_TYPE, @vCHARACTER_MAXIMUM_LENGTH,
               @vCHARACTER_OCTET_LENGTH, @vNUMERIC_PRECISION, @vNUMERIC_PRECISION_RADIX,
               @vNUMERIC_SCALE

          WHILE @@FETCH_STATUS = 0
             BEGIN


                    SET @Result = @Result
                       + @vCOLUMN_NAME
                       + ' '
                       + @vDATA_TYPE
           
    
             
                IF @vDATA_TYPE IN ('uniqueidentifier', 'bigint', 'datetime', 'float', 
                                   'image', 'int', 'tinyint', 'smallint', 'text', 'ntext', 'bit')
                   BEGIN
                        SET @Result = @Result
                               + ','
                   END                   
                ELSE IF @vDATA_TYPE IN ('char', 'nchar', 'varchar', 'nvarchar')
                   BEGIN
                        SET @Result = @Result
                                    + '('
                                    + CAST(@vCHARACTER_MAXIMUM_LENGTH AS NVARCHAR(10))
                                    + '),'
                   END
                ELSE IF @vDATA_TYPE IN ('decimal', 'numeric')
                   BEGIN
                        SET @Result = @Result
                                    + '('
                                    + CAST(@vNUMERIC_PRECISION AS NVARCHAR(10))
                                    + ', '
                                    + CAST(@vNUMERIC_SCALE AS NVARCHAR(10))
                                    + '),'
                   END
   
               -- Get the next column.
               FETCH NEXT FROM columns_cursor 
               INTO @vCOLUMN_NAME, @vDATA_TYPE, @vCHARACTER_MAXIMUM_LENGTH,
                    @vCHARACTER_OCTET_LENGTH, @vNUMERIC_PRECISION, @vNUMERIC_PRECISION_RADIX,
                    @vNUMERIC_SCALE
           END

      CLOSE columns_cursor
      DEALLOCATE columns_cursor

      SET @Result = LEFT(@Result, LEN(@Result)-1)
ExitLabel:
    RETURN @Result

END


