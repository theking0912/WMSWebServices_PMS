 
 

CREATE  PROCEDURE [dbo].[csp_exp_so_outbound_OLD]
	  @DataID varchar(100)=null,
	  @process_status varchar(100)=null,
	  @wh_id varchar(100)='HDLSH',
	  @ZPOSITION varchar(100) ='SH' 
AS
BEGIN
	  insert INTO tbl_inf_exp_inoutbound
	  ( DATA_HEADID
			  ,DATA_DETAILID
			  ,ZPOSITION
			  ,ZBSART  --订单类型
			  ,BUDAT   --记账日期
			  ,BLDAT   --凭证日期
			  ,ZFLAG   --出入库标志
			  ,MATNR   --物料
			  ,WMS_ZMENGE  --免费接受数量
			  ,WMS_MENGE   --订单数量
			  ,WMS_MEINS   --订单数量
			  ,ZMENGE  --免费接受数量
			  ,MENGE   --订单数量
			  ,MEINS   --订单单位
			  ,EBELN   --凭证号（单号）
			  ,EBELP   --凭证行（行）
			  ,BWART	 --移动类型
			  ,SOBKZ	 --特殊库存标识
			  ,SAKTO   --总账科目
			  ,LIFNR	 --供应商
			  ,KOSTL   --成本中心
			  ,PRCTR   --利润中心
			  ,WERKS   --工厂(3199)
			  ,LGORT   --库存地(1007)
			  ,ZCOPRD  --联副产品标识
			  ,ZTIME   --时间
			  ,PROCESS_STATUS 
			  ,DATA_ID
			  ,PROCESS_MSG)

	  SELECT  b.id AS DATA_HEADID
			  ,a.id AS DATA_DETAILID
			  ,@ZPOSITION AS ZPOSITION
			  ,isnull(b.order_type,'') AS ZBSART  --订单类型
			  ,REPLACE(CONVERT(VARCHAR(10),a.inf_date,120),'-','') AS BUDAT   --记账日期
			  ,REPLACE(CONVERT(VARCHAR(10),ISNULL(b.shipped_date,a.inf_date),120),'-','') AS BLDAT   --凭证日期
			  ,'O' AS ZFLAG   --出入库标志
			  ,a.item_number AS MATNR   --物料
			  ,0 AS WMS_ZMENGE  --免费接受数量
			  ,a.quantity_shipped AS WMS_MENGE   --订单数量
              ,a.uom AS WMS_MEINS   --订单数量
			  ,0 AS ZMENGE  --免费接受数量
			  ,0 AS MENGE   --订单数量
			  ,'' AS MEINS   --订单单位
			  ,a.display_order_number AS EBELN   --凭证号（单号）
			  ,a.line_number AS EBELP   --凭证行（行）
			  ,b.sap_ordertype AS BWART	 --移动类型
			  ,isnull(b.stock_indicator_code,'')  AS SOBKZ	 --特殊库存标识
			  ,isnull(b.ledger_code,'')  AS SAKTO   --总账科目
			  ,'' AS LIFNR	 --供应商
			  ,isnull(b.cost_code,'') AS KOSTL   --成本中心
			  ,isnull(b.profit_code,'') AS PRCTR   --利润中心
			  ,ISNULL(a.factory,'')  AS WERKS   --工厂(3199)
			  ,isnull(a.storage_location,'') AS LGORT   --库存地(1007)
			  ,'' AS ZCOPRD  --联副产品标识
			  ,'000000' AS ZTIME   --时间
			  ,'NO' AS PROCESS_STATUS 
			  ,@DataID AS DATA_ID
			  ,'' AS PROCESS_MSG
	   FROM tbl_inf_exp_so_detail a,
	       tbl_inf_exp_so_master b
	 where  a.order_number=b.order_number
	        and lower(a.process_status)='ready'


	 update tbl_inf_exp_inoutbound
	  set   WMS_MEINS=b.uom
	  from  tbl_inf_exp_inoutbound a,t_item_uom b
	  where  a.MATNR=b.item_number and b.conversion_factor=1

	  update tbl_inf_exp_inoutbound
	  set   MEINS=b.order_uom
	  from  tbl_inf_exp_inoutbound a,t_po_detail b
	  where  a.EBELN=b.po_number and a.EBELP=b.line_number
	  
	 
	  update tbl_inf_exp_inoutbound
	  set   MENGE=WMS_MENGE/b.conversion_factor 
	  from  tbl_inf_exp_inoutbound a,t_item_uom b
	  where  a.MATNR=b.item_number  and a.MEINS=b.uom 
	   
	    
        
	--1.获取未处理的数据
	   create table #unoutbound
	   (
	      DATA_HEADID bigint ,
		  DATA_DETAILID bigint,
		  id bigint,
		  warehouse_id nvarchar(10) COLLATE database_default NULL,
		  shipped_date      datetime,
		  order_number   nvarchar(30) COLLATE database_default NULL,
		  line_number nvarchar(5) COLLATE database_default NULL,
		  item_number nvarchar(30) COLLATE database_default NULL,
		  quantity_shipped float,
		  parent_line_number nvarchar(5) COLLATE database_default NULL,
		  sap_ordertype  varchar(30) COLLATE database_default NULL,
		  storage_location nvarchar(30) COLLATE database_default NULL,
		  cost_code  nvarchar(30) COLLATE database_default NULL,
		  move_code nvarchar(30) COLLATE database_default NULL,
		  ledger_code nvarchar(30) COLLATE database_default NULL,
		  stock_indicator_code nvarchar(30) COLLATE database_default NULL,
		  profit_code nvarchar(30) COLLATE database_default NULL,
		  uom	nvarchar(30) COLLATE database_default NULL,
		  order_uom nvarchar(30) COLLATE database_default NULL,
		  sap_qty float,
		  factory nvarchar(30) COLLATE database_default NULL,
		  process_status varchar(50) COLLATE database_default NULL,
		  status int
	   )

     insert into #unoutbound
	 (
		[DATA_HEADID]
      ,[DATA_DETAILID]
      ,[id]
      ,[warehouse_id]
      ,[shipped_date]
      ,[order_number]
      ,[line_number]
      ,[item_number]
      ,[quantity_shipped]
      ,[parent_line_number]
      ,[sap_ordertype]
      ,[storage_location]
      ,[cost_code]
      ,[move_code]
      ,[ledger_code]
      ,[stock_indicator_code]
      ,[profit_code]
      ,[uom]
      ,[order_uom]
      ,[sap_qty]
      ,[factory]
      ,[process_status]
      ,[status]

	 )
	 SELECT  0
	        ,a.id
			,a.id 
			,a.warehouse_id
			,b.shipped_date 
			,a.display_order_number 
			,a.line_number 
			,a.item_number 
			,a.quantity_shipped
			,isnull(a.parent_line_number,'') 
			,b.sap_ordertype 
			,isnull(a.storage_location,'')
			,isnull(b.cost_code,'')
			,isnull(b.move_code,'')
			,isnull(b.ledger_code,'') 
			,isnull(b.stock_indicator_code,'') 
			,isnull(b.profit_code,'')
			,a.uom 
			,''
			,0
			,isnull(factory,'')
			,'NO'
			,0
     FROM  tbl_inf_exp_so_detail a,
	       tbl_inf_exp_so_master b
	 where  a.order_number=b.order_number
	        and lower(a.process_status)='ready'
			--AND a.order_number='4500000071'


	 update #unoutbound
	  set   uom=b.uom
	  from  #unoutbound a,t_item_uom b
	  where  a.item_number=b.item_number and b.conversion_factor=1

	  update #unoutbound
	  set   order_uom=b.order_uom
	  from  #unoutbound a,t_po_detail b
	  where  a.order_number=b.po_number and a.line_number=b.line_number
	  
	 
	  update #unoutbound
	  set   sap_qty=quantity_shipped/b.conversion_factor 
	  from  #unoutbound a,t_item_uom b
	  where  a.item_number=b.item_number  and a.order_uom=b.uom 
	    
  
	 INSERT INTO tbl_inf_exp_inoutbound(
			   [ZPOSITION]
			  ,[ZBSART]  --订单类型
			  ,[BUDAT]   --记账日期
			  ,[BLDAT]   --凭证日期
			  ,[ZFLAG]   --出入库标志
			  ,[MATNR]   --物料
			  ,[ZMENGE]  --免费接受数量
			  ,[MENGE]   --订单数量
			  ,[MEINS]   --订单单位
			  ,[EBELN]   --凭证号（单号）
			  ,[EBELP]   --凭证行（行）
			  ,[BWART]	 --移动类型
			  ,[SOBKZ]	 --特殊库存标识
			  ,[SAKTO]   --总账科目
			  ,[LIFNR]	 --供应商
			  ,[KOSTL]   --成本中心
			  ,[PRCTR]   --利润中心
			  ,[WERKS]   --工厂(3199)
			  ,[LGORT]   --库存地(1007)
			  ,[ZCOPRD]  --联副产品标识
			  ,[ZTIME]   --时间
			  ,[PROCESS_STATUS] 
			  ,[DATA_ID]
			  ,[PROCESS_MSG]
			  
			  )
		select @ZPOSITION
			  ,sap_ordertype
			  ,REPLACE(CONVERT(VARCHAR(10),shipped_date,120),'-','')
			  ,REPLACE(CONVERT(VARCHAR(10),shipped_date,120),'-','')
			  ,'O'
			  ,item_number
			  ,0
			  ,sap_qty
			  ,order_uom
			  ,order_number
			  ,line_number
			  ,move_code --[BWART]
			  ,stock_indicator_code --[SOBKZ]
			  ,ledger_code    --[SAKTO]
			  ,''    --[LIFNR]
			  ,cost_code --[KOSTL]
			  ,profit_code  --[PRCTR]
			  ,''    --[WERKS]
			  ,storage_location--[LGORT]
			  ,''    --[ZCOPRD]
			  ,'000000'
			  ,'NO'
			  ,@DataID
			  ,''
	 from #unoutbound

	 drop table #unoutbound

     insert into #returnresult values(1,'OK','Export OutBound Data successful.')
END



