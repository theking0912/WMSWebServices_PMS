
CREATE TRIGGER dbo.tr_load_master_action
ON t_load_master
FOR UPDATE
AS

BEGIN
    DECLARE
        @v_nTriggerAction       INT,
        @v_vchWhID              NVARCHAR(10),
        @v_vchLoadID            NVARCHAR(30),
        @v_vchOldStatus         NVARCHAR(30),
        @v_vchNewStatus         NVARCHAR(30),
        @v_vchCurrStatus        NVARCHAR(30),
        @v_dtCurrentDate        DATETIME,
        @v_vchEventData         NVARCHAR(500),
        @v_nUpdateStatus        INT,
        @v_nCarrierID           INT

	-- Error handling and logging variables.
    DECLARE
        @c_nModuleNumber        INT,
        @c_nFileNumber          INT,
        @v_vchLogMsg            NVARCHAR(250),
        @v_vchParam             NVARCHAR(100),
        @v_nRaiseErrorNumber    INT,
        @v_nError               INT,
        @v_nRowCount            INT,
        @v_nCustomError         INT

    -- Exceptions
    DECLARE
        @e_ClearTriggerSqlError             INT,
        @e_ClearTriggerZeroRows             INT,
        @e_TrackReqUpdateStopSqlError       INT,
        @e_TrackReqUpdateStopZeroRows       INT,
        @e_AddEventFailed                   INT,
        @e_TrackReqInsertHistorySqlError    INT,
        @e_TrackReqInsertHistoryZeroRows    INT,
        @e_TenderRespGetNewStatusSqlError   INT,
        @e_TenderRespGetNewStatusZeroRows   INT,
        @e_TenderRespUpdateLoadSqlError     INT,
        @e_TenderRespUpdateLoadZeroRows     INT,
        @e_TenderRespInsertHistorySqlError  INT,
        @e_TenderRespInsertHistoryZeroRows  INT,
        @e_GetInfoSqlError                  INT,
        @e_GetInfoZeroRows                  INT,
        @e_StatusUpdateLoadSqlError         INT,
        @e_StatusUpdateLoadZeroRows         INT,
        @e_StatusInsertHistorySqlError      INT,
        @e_StatusInsertHistoryZeroRows      INT,
        @e_TenderRespInvalidStatus          INT,
        @e_TrackReqInvalidStatus            INT,
        @e_TrackReqGetCurrStatusSqlError    INT,
        @e_TrackReqGetCurrStatusZeroRows    INT,
        @e_TenderRespGetCurrStatusSqlError  INT,
        @e_TenderRespGetCurrStatusZeroRows  INT,
        @e_StatusUpdateGetOldStatusSqlError INT,
        @e_StatusUpdateGetOldStatusZeroRows INT

    DECLARE @v_nNoCount INT
    SET @v_nNoCount = @@OPTIONS & 512
    SET NOCOUNT ON

    -- Set Log/Local Error Constants
    SET @e_ClearTriggerSqlError             = 1
    SET @e_ClearTriggerZeroRows             = 2
    SET @e_TrackReqUpdateStopSqlError       = 3
    SET @e_TrackReqUpdateStopZeroRows       = 4
    SET @e_AddEventFailed                   = 5
    SET @e_TrackReqInsertHistorySqlError    = 6
    SET @e_TrackReqInsertHistoryZeroRows    = 7
    SET @e_TenderRespGetNewStatusSqlError   = 8
    SET @e_TenderRespGetNewStatusZeroRows   = 9
    SET @e_TenderRespUpdateLoadSqlError     = 10
    SET @e_TenderRespUpdateLoadZeroRows     = 11
    SET @e_TenderRespInsertHistorySqlError  = 12
    SET @e_TenderRespInsertHistoryZeroRows  = 13
    SET @e_GetInfoSqlError                  = 14
    SET @e_GetInfoZeroRows                  = 15
    SET @e_StatusUpdateLoadSqlError         = 16
    SET @e_StatusUpdateLoadZeroRows         = 17
    SET @e_StatusInsertHistorySqlError      = 18
    SET @e_StatusInsertHistoryZeroRows      = 19
    SET @e_TenderRespInvalidStatus          = 20
    SET @e_TrackReqInvalidStatus            = 21
    SET @e_TrackReqGetCurrStatusSqlError    = 22
    SET @e_TrackReqGetCurrStatusZeroRows    = 23
    SET @e_TenderRespGetCurrStatusSqlError  = 24
    SET @e_TenderRespGetCurrStatusZeroRows  = 25
    SET @e_StatusUpdateGetOldStatusSqlError = 26
    SET @e_StatusUpdateGetOldStatusZeroRows = 27

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 301

    SET @v_nUpdateStatus = 0

    IF UPDATE (trigger_action)
    BEGIN
        SELECT
            @v_nTriggerAction = trigger_action,
            @v_vchWhID = wh_id,
            @v_vchLoadID = load_id
        FROM
            Inserted

        SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nRowCount = 0 OR @v_nError <> 0
        BEGIN
            IF @v_nError <> 0
                SET @v_nCustomError = @e_GetInfoSqlError
            ELSE
                SET @v_nCustomError = @e_GetInfoZeroRows
            GOTO ErrorHandler
        END

        -- Clear trigger_action column
        UPDATE
            l
        SET
            l.trigger_action = 0
        FROM
            t_load_master l
        INNER JOIN
            Inserted i
            ON
                l.wh_id = i.wh_id AND
                l.load_id = i.load_id

        SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nRowCount = 0 OR @v_nError <> 0
        BEGIN
            IF @v_nError <> 0
                SET @v_nCustomError = @e_ClearTriggerSqlError
            ELSE
                SET @v_nCustomError = @e_ClearTriggerZeroRows
            GOTO ErrorHandler
        END

        SET @v_dtCurrentDate = GETDATE()

        IF @v_nTriggerAction = 1 -- Tracking Request
        BEGIN

            -- Get current shipment status
            SELECT
                @v_vchCurrStatus = ISNULL(shipment_status, 'Pending')
            FROM
                Inserted

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_TrackReqGetCurrStatusSqlError
                ELSE
                    SET @v_nCustomError = @e_TrackReqGetCurrStatusZeroRows
                GOTO ErrorHandler
            END

            -- Check if current shipment status is valid.
            IF @v_vchCurrStatus <> 'In Transit' AND
                @v_vchCurrStatus <> 'Tender Accepted'
            BEGIN
                SET @v_nCustomError = @e_TrackReqInvalidStatus
                GOTO ErrorHandler
            END

            -- Set tracking request pending for non-delivered stops
            UPDATE
                s
            SET
                s.tracking_request_date = @v_dtCurrentDate,
                s.tracking_request_pending = 1,
                s.tracking_response_date = NULL,
                s.tracking_updated_by = NULL
            FROM
                t_stop s
            INNER JOIN
                Inserted i
                ON
                    s.wh_id = i.wh_id AND
                    s.load_id = i.load_id
            WHERE
                s.actual_delivery_date IS NULL

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_TrackReqUpdateStopSqlError
                ELSE
                    SET @v_nCustomError = @e_TrackReqUpdateStopZeroRows
                GOTO ErrorHandler
            END

            -- Raise event for Tracking Request
/*            SET @v_vchEventData = 'Warehouse ID|' + @v_vchWhID +
                '|Load ID|' + @v_vchLoadID + '|Message Type|Tracking Request'
            EXEC @v_nError =
                ADV_DB_NAME..usp_AdvAddEvent 6, 'AL.Process Requests From TA', @v_vchEventData, 50

            IF @v_nError <> 0
            BEGIN
                SET @v_nCustomError = @e_AddEventFailed
                GOTO ErrorHandler
            END

            -- Insert activity history rows
            INSERT INTO t_ta_load_activity_history (
                wh_id,
                load_id,
                stop_id,
                activity_date,
                activity,
                carrier_id,
                mode_id )
            SELECT
                s.wh_id,
                s.load_id,
                s.stop_id,
                s.tracking_request_date,
                'Tracking Request',
                l.carrier_id,
                l.mode_id
            FROM
                t_load_master l
            INNER JOIN
                Inserted i
                ON
                    l.wh_id = i.wh_id AND
                    l.load_id = i.load_id
            INNER JOIN
                t_stop s
                ON
                    i.wh_id = s.wh_id AND
                    i.load_id = s.load_id
            WHERE
                s.actual_delivery_date IS NULL
            ORDER BY
                s.stop_sequence

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_TrackReqInsertHistorySqlError
                ELSE
                    SET @v_nCustomError = @e_TrackReqInsertHistoryZeroRows
                GOTO ErrorHandler
            END

 */       END

        ELSE

        IF @v_nTriggerAction = 2 -- Tender Response
        BEGIN

            SET @v_nUpdateStatus = 1

            -- Determine new shipment status
            SELECT
                @v_vchNewStatus =
                    CASE
                        WHEN tender_accepted = 1
                        THEN 'Tender Accepted'
                        ELSE 'Tender Declined'
                    END
            FROM
                Inserted

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_TenderRespGetNewStatusSqlError
                ELSE
                    SET @v_nCustomError = @e_TenderRespGetNewStatusZeroRows
                GOTO ErrorHandler
            END

            SELECT
                @v_nCarrierID = d.carrier_id
            FROM
                Deleted d

        /*    IF @v_vchNewStatus = 'Tender Accepted'
            BEGIN
                INSERT INTO t_ta_tender_activity (load_master_id, carrier_id, tender_sequence, tender_status_id, request_date, response_date, tender_response_time, charge, processed)
                      SELECT TOP 1 load_master_id, carrier_id, tender_sequence+1, 2, request_date, GETDATE(), tender_response_time, charge, 'N' FROM t_ta_tender_activity 
                        WHERE load_master_id = (SELECT load_master_id FROM t_load_master WHERE load_id = @v_vchLoadID and wh_id = @v_vchWhID)
                              AND carrier_id = @v_nCarrierID ORDER BY activity_date DESC
            END
            ELSE IF @v_vchNewStatus = 'Tender Declined'
            BEGIN
                INSERT INTO t_ta_tender_activity (load_master_id, carrier_id, tender_sequence, tender_status_id, request_date, response_date, tender_response_time, charge, processed)
                      SELECT TOP 1 load_master_id, carrier_id, tender_sequence+1, 3, request_date, GETDATE(), tender_response_time, charge, 'N' FROM t_ta_tender_activity 
                        WHERE load_master_id = (SELECT load_master_id FROM t_load_master WHERE load_id = @v_vchLoadID and wh_id = @v_vchWhID)
                              AND carrier_id = @v_nCarrierID ORDER BY activity_date DESC
            END*/


            -- Get current shipment status
            SELECT
                @v_vchCurrStatus = ISNULL(shipment_status, 'Pending')
            FROM
                Inserted

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_TenderRespGetCurrStatusSqlError
                ELSE
                    SET @v_nCustomError = @e_TenderRespGetCurrStatusZeroRows
                GOTO ErrorHandler
            END

            -- Check if current shipment status is valid.
            IF @v_vchCurrStatus <> 'Tender Requested'
            BEGIN
                SET @v_nCustomError = @e_TenderRespInvalidStatus
                GOTO ErrorHandler
            END

            -- Set tender response date and shipment status in t_load_master.
            UPDATE
                l
            SET
                l.tender_response_date = @v_dtCurrentDate,
                l.shipment_status = @v_vchNewStatus
            FROM
                t_load_master l
            INNER JOIN
                Inserted i
                ON
                    l.wh_id = i.wh_id AND
                    l.load_id = i.load_id
            WHERE
                ISNULL(l.shipment_status, 'Pending') = 'Tender Requested'

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_TenderRespUpdateLoadSqlError
                ELSE
                    SET @v_nCustomError = @e_TenderRespUpdateLoadZeroRows
                GOTO ErrorHandler
            END

            -- Insert activity history row.
            /*INSERT INTO t_ta_load_activity_history (
                wh_id,
                load_id,
                activity_date,
                activity,
                carrier_id,
                mode_id,
                tender_accepted,
                tender_comments,
                tender_cost,
                updated_by )
            SELECT
                l.wh_id,
                l.load_id,
                l.tender_response_date,
                'Tender Response',
                l.carrier_id,
                l.mode_id,
                l.tender_accepted,
                l.tender_comments,
                l.tender_cost,
                l.tender_updated_by
            FROM
                t_load_master l
            INNER JOIN
                Inserted i
                ON
                    l.wh_id = i.wh_id AND
                    l.load_id = i.load_id

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_TenderRespInsertHistorySqlError
                ELSE
                    SET @v_nCustomError = @e_TenderRespInsertHistoryZeroRows
                GOTO ErrorHandler
            END*/

        END -- if tracking request or tender response
    END -- if update trigger_action

    IF (UPDATE (shipment_status)) OR (@v_nUpdateStatus = 1)
    BEGIN

        IF @v_nUpdateStatus = 1
        BEGIN
            SELECT
                @v_vchOldStatus = d.shipment_status
            FROM
                Deleted d
        END
        ELSE
        BEGIN
            SET @v_dtCurrentDate = GETDATE()
            SELECT
                @v_vchOldStatus = d.shipment_status,
                @v_vchNewStatus = i.shipment_status
            FROM
                Inserted i,
                Deleted d
        END

        SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nRowCount = 0 OR @v_nError <> 0
        BEGIN
            IF @v_nError <> 0
                SET @v_nCustomError = @e_StatusUpdateGetOldStatusSqlError
            ELSE
                SET @v_nCustomError = @e_StatusUpdateGetOldStatusZeroRows
            GOTO ErrorHandler
        END

        IF (@v_vchOldStatus <> @v_vchNewStatus) OR
            (@v_vchOldStatus IS NULL AND @v_vchNewStatus IS NOT NULL)
        BEGIN

            -- Update shipment_status_date
            UPDATE
                l
            SET
                l.shipment_status_date = @v_dtCurrentDate
            FROM
                Inserted i
            INNER JOIN
                t_load_master l
                ON
                i.wh_id = l.wh_id AND
                i.load_id = l.load_id

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_StatusUpdateLoadSqlError
                ELSE
                    SET @v_nCustomError = @e_StatusUpdateLoadZeroRows
                GOTO ErrorHandler
            END

            -- Insert status history row
            /*INSERT INTO t_ta_load_status_history (
                wh_id,
                load_id,
                shipment_status_date,
                shipment_status )
            SELECT
                wh_id,
                load_id,
                @v_dtCurrentDate,
                @v_vchNewStatus
            FROM
                Inserted

            SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0 OR @v_nError <> 0
            BEGIN
                IF @v_nError <> 0
                    SET @v_nCustomError = @e_StatusInsertHistorySqlError
                ELSE
                    SET @v_nCustomError = @e_StatusInsertHistoryZeroRows
                GOTO ErrorHandler
            END*/

        END -- if old status not equal new status
    END -- if shipment_status column updated

    GOTO ExitLabel

ErrorHandler:

    ROLLBACK TRAN

    IF @v_nCustomError = @e_ClearTriggerSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred resetting trigger field in t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_ClearTriggerZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to reset trigger field in t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50003 -- Update Error
    END

    ELSE IF @v_nCustomError = @e_TrackReqInvalidStatus
    BEGIN
        SET @v_vchLogMsg = 'Current status [' + @v_vchCurrStatus + '] not valid for Tracking' +
            ' Request. Status must be Tender Accepted or In Transit.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_TrackReqUpdateStopSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred updating Tracking information in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_TrackReqUpdateStopZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to update Tracking information in t_stop.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_stop'
        SET @v_nRaiseErrorNumber = 50003 -- Update Error
    END

    ELSE IF @v_nCustomError = @e_AddEventFailed
    BEGIN
        SET @v_vchLogMsg = 'Failed to add Tender Request event for wh_id [' +
            @v_vchWhID + '] and load_id [' + @v_vchLoadID + '].'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

    ELSE IF @v_nCustomError = @e_TrackReqInsertHistorySqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred inserting history row in t_ta_load_activity_history for' +
            ' Tracking Request.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_TrackReqInsertHistoryZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to insert history row in t_ta_load_activity_history' +
            ' for Tracking Request.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_ta_load_activity_history'
        SET @v_nRaiseErrorNumber = 50002 -- Insert Error
    END

    ELSE IF @v_nCustomError = @e_TrackReqGetCurrStatusSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred selecting current Tracking Request status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_TrackReqGetCurrStatusZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to select current Tracking Request status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_TenderRespGetCurrStatusSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred selecting current Tender Response status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_TenderRespGetCurrStatusZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to select current Tender Response status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_TenderRespGetNewStatusSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred selecting new Tender Response status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_TenderRespGetNewStatusZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to select new Tender Response status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_TenderRespInvalidStatus
    BEGIN
        SET @v_vchLogMsg = 'Current status [' + @v_vchCurrStatus + '] not valid for Tender' +
            ' Response. Status must be Tender Requested.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_TenderRespUpdateLoadSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred updating Tender information in t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_TenderRespUpdateLoadZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to update Tender information in t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50003 -- Update Error
    END

    ELSE IF @v_nCustomError = @e_TenderRespInsertHistorySqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred inserting history row in t_ta_load_activity_history for' +
            ' Tender Response.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_TenderRespInsertHistoryZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to insert history row in t_ta_load_activity_history' +
            ' for Tender Response.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_ta_load_activity_history'
        SET @v_nRaiseErrorNumber = 50002 -- Insert Error
    END

    ELSE IF @v_nCustomError = @e_GetInfoSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred selecting affected row information from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_GetInfoZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to select affected row information from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_StatusUpdateGetOldStatusSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred selecting old status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_StatusUpdateGetOldStatusZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to select old status from t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Error
    END

    ELSE IF @v_nCustomError = @e_StatusUpdateLoadSqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred updating status date information in t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_StatusUpdateLoadZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to update status date information in t_load_master.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_load_master'
        SET @v_nRaiseErrorNumber = 50003 -- Update Error
    END

    ELSE IF @v_nCustomError = @e_StatusInsertHistorySqlError
    BEGIN
        SET @v_vchLogMsg = 'SQL Server error [' + CONVERT(VARCHAR, @v_nError) +
            '] occurred inserting history row in t_ta_load_status_history.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = @v_nError
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END
    ELSE IF @v_nCustomError = @e_StatusInsertHistoryZeroRows
    BEGIN
        SET @v_vchLogMsg = 'Failed to insert history row in t_ta_load_status_history.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nCustomError, 1,
            @v_vchLogMsg, 1
        SET @v_vchParam = 't_ta_load_status_history'
        SET @v_nRaiseErrorNumber = 50002 -- Insert Error
    END

    -- Raise error message instead of number so informative message will show on WebWise screen
    RAISERROR (@v_vchLogMsg, 11, 1)

ExitLabel:
    IF @v_nNoCount = 0
        SET NOCOUNT OFF

    RETURN
END
