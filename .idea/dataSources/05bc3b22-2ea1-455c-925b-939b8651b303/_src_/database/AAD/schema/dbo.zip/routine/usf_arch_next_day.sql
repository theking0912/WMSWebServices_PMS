
CREATE FUNCTION usf_arch_next_day 
( 
    @Date 			DATETIME, 
    @WeekDay 			INTEGER
) 
RETURNS DATETIME 
BEGIN
    DECLARE @DayPart TINYINT

    SET @DayPart = @WeekDay
    RETURN DATEADD( DAY, @DayPart + 
                         CASE WHEN @DayPart <= DATEPART( WEEKDAY, @Date ) 
                              THEN 7 
                              ELSE 0 
                         END - 
                         DATEPART( WEEKDAY, @Date ), 
                         @Date ) 
END 



