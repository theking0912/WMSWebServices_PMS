

CREATE   PROCEDURE usp_before_pick_release

      @in_OrderNumber   AS NVARCHAR(20) = NULL,
      @in_LoadNumber    AS NVARCHAR(20) = NULL,
      @in_WaveNumber    AS NVARCHAR(20) = NULL,
      @in_ItemNumber    AS NVARCHAR(30) = NULL,
      @in_LotNumber     AS NVARCHAR(15) = NULL,
      @in_PickArea      AS NVARCHAR(10) = 'ALL',
      @in_vchType       AS NVARCHAR(2) = 'PP',  -- Either PP (Planned Pick) or RP (Replenishment)
      @in_vchWhID       AS NVARCHAR(10),
      @in_vchPKDStatus  AS NVARCHAR(8) = 'CREATED' -- Either RELEASED (for Refreshing Replens) or CREATED (Default)

AS

DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,

    -- Log Error numbers used for branching in the Error Handler.
    @e_nGenSqlError             INT,
    @e_nSprocError              INT,
    @e_nItemNotFound            INT,
    @e_nNoPickPutRules          INT,

    -- Local Variables
    @v_vchPickPutID             NVARCHAR(15),
    @v_vchRule                  NVARCHAR(30),
    @v_nProfileCntr             INT,
    @v_nNumOfProfiles           INT,
    @v_nNumOfRules              INT,
    @v_nRuleCntr                INT,
    @v_vchRuleType              NVARCHAR(4)

    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 5        -- This # must be unique per object.
    SET @c_vchObjName = 'usp_before_pick_release'

    -- Log/Local Error Constants
    SET @e_nGenSqlError = 1
    SET @e_nSprocError = 2
    SET @e_nItemNotFound = 3
    SET @e_nNoPickPutRules  = 4

    -- Set Rule Type baised on Type
    IF @in_vchType = 'RP'
        SET @v_vchRuleType = 'RPLN'
    ELSE
        SET @v_vchRuleType = 'PICK'

-- Temp table used to hold a unique list of pick put id's
-- across all items in the #ItemsToUpdate temp table.
CREATE TABLE #tmp_pick_put_list (
   sequence        SMALLINT IDENTITY,
   pick_put_id     NVARCHAR(15) COLLATE DATABASE_DEFAULT 
)

-- Temp table used to hold a list of pick put rules for a given Pick Put ID
CREATE TABLE #tmp_rule_set (
   sequence        SMALLINT ,   -- The sequencial order in which to execute the rule
   pick_put_rule   NVARCHAR(30) COLLATE DATABASE_DEFAULT -- Name of the rule stored procedure to execute
)


-- Temp table to hold the returned location id's and picking_flow values
-- for only the items which a specific rule found data for, these values
-- are matched with items in the #ItemsToUpdate temp table, and updated.
-- The updated rows in the #ItemsToUpdate temp table are then matched with
-- items in the t_pick_detail table and updated with the resulting location id's
-- and pick_flow values.
CREATE TABLE #tmp_locations_found (
   seq                    INT IDENTITY(1,1)  NOT NULL,
   pick_id                INT                NOT NULL,
   location_id            NVARCHAR(50)       COLLATE DATABASE_DEFAULT NOT NULL,
   picking_flow           NVARCHAR(3)        COLLATE DATABASE_DEFAULT NULL,
   lot_number             NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
   pick_area              NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   work_type              NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
   stored_attribute_id    BIGINT             NULL
)

    SET NOCOUNT ON

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
                ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_nSprocError
        GOTO ErrorHandler
    END


    -- Assign defaults to variables.
    SET @v_nProfileCntr = 1  -- Start the profile counter = 1.
    SET @v_nNumOfProfiles = 0  -- Clear the Number of profiles counter.

    -- Build a query to fill temp table to hold all of the lines to update
    INSERT INTO #tmp_pick_details_to_update
        (
        wh_id, pick_id, item_number, line_number,
        lot_number, serial_number, pick_quantity,
        uom, pick_put_id, order_number, type, load_id, wave_id, status,
        manifest_carrier_flag, stored_attribute_id)
    SELECT
        pkd.wh_id, pkd.pick_id, pkd.item_number, pkd.line_number,
        pkd.lot_number, pkd.serial_number, pkd.planned_quantity,
        pkd.uom, 
        ISNULL(dbo.usf_get_item_ppr_dia_ovrd(pkd.item_number, pkd.wh_id, pkd.uom, pkd.stored_attribute_id),
               itu.pick_put_id) as pick_put_id, 
        pkd.order_number, pkd.type, pkd.load_id, 
        pkd.wave_id, pkd.status, 
        dbo.usf_manifest_carrier_flag (pkd.wh_id, pkd.order_number, NULL),
        pkd.stored_attribute_id
    FROM t_pick_detail pkd,
	     t_item_uom itu 
    WHERE    pkd.item_number = itu.item_number
        AND  pkd.wh_id  = itu.wh_id
        AND  pkd.uom = itu.uom
        AND  pkd.status = @in_vchPKDStatus
        AND ((pkd.order_number = @in_OrderNumber) OR (@in_OrderNumber is NULL)
              OR (@in_OrderNumber = 'ALL'))
        AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL)
              OR (@in_LoadNumber = 'ALL'))
        AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL)
              OR (@in_WaveNumber = 'ALL'))
        AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL)
              OR (@in_ItemNumber = 'ALL'))
        AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL)
              OR (@in_LotNumber = 'ALL'))
        AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL)
              OR (@in_PickArea = 'ALL'))
        AND pkd.wh_id = @in_vchWhID
        AND pkd.type = @in_vchType

  -- Print a trace level message
  IF (@v_nLogLevel >= 5)
     BEGIN
       PRINT @c_vchObjName + ': The contents of #tmp_pick_details_to_update: '
       SELECT * FROM #tmp_pick_details_to_update
     END

  -- Temp table to retrieve the profiles on the load.
  INSERT INTO #tmp_pick_put_list (pick_put_id)
    SELECT DISTINCT pick_put_id
      FROM #tmp_pick_details_to_update

  SET @v_nNumOfProfiles = @@ROWCOUNT     -- Total profile count on the load.
  
  -- Print a trace level message
  IF (@v_nLogLevel >= 5)
     BEGIN

       PRINT @c_vchObjName + ': Here are the profiles for this execution:'
       SELECT * FROM #tmp_pick_put_list
     END

  -- Loop through the profiles.
  WHILE @v_nNumOfProfiles >= @v_nProfileCntr
    BEGIN
      -- Grab the next profile on the load based on the profile_cntr.
      SELECT @v_vchPickPutID = pick_put_id
        FROM #tmp_pick_put_list
        WHERE sequence = @v_nProfileCntr
      
      IF (@v_nLogLevel >= 5)
          PRINT @c_vchObjName + ': Now using profile: ' + @v_vchPickPutID

      -- Fill the temporary table with rules to execute for the profile.
      INSERT INTO #tmp_rule_set (sequence, pick_put_rule)
        SELECT ppd.sequence, ppr.before
          FROM t_pick_put_detail ppd
          INNER JOIN t_pick_put_rules ppr
            ON ppd.rule_id = ppr.rule_id
            AND ppd.type = ppr.type
          WHERE ppd.type = @v_vchRuleType
            AND ppd.pick_put_id = @v_vchPickPutID
            AND ppd.rule_id NOT LIKE '%_legacy'
          ORDER BY ppd.sequence

       -- Get and Set ErrorHandler Variables
       SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
       -- Check for any errors. If so, error number will not be equal to zero.
       IF @v_nErrorNumber <> 0
       BEGIN
           SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
               'the exact nature of the error.'
           SET @v_nLogErrorNum = @e_nGenSqlError
           GOTO ErrorHandler
       END

      IF @v_nRowCount = 0
      BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ': No Pick Put Rules were found for profile '+ @v_vchPickPutID + '. Check the pick_put_id ' +
              'in item master and pick put tables. Then retry.'
        SET @v_nLogErrorNum = @e_nNoPickPutRules
        GOTO ErrorHandler
      END

       IF (@v_nLogLevel >= 5)
         BEGIN
           PRINT @c_vchObjName + ': Here are the rules for profile ' + @v_vchPickPutID + ':'
           SELECT * FROM #tmp_rule_set
         END

      -- Set the @v_nRuleCntr = 1, the 1st number in the sequence.
      SET @v_nRuleCntr = 1  -- ?? what if sequence doesn't start from 1 !!!Segun
          SET @v_nNumOfRules = @v_nRowCount

      -- Cycle through the set of rules.
      WHILE @v_nNumOfRules >= @v_nRuleCntr
        BEGIN
          -- Find the rule.
          SELECT @v_vchRule = pick_put_rule
            FROM #tmp_rule_set
          WHERE sequence = @v_nRuleCntr

          IF (@v_nLogLevel >= 5)
            PRINT @c_vchObjName + ': About to execute rule #' + CONVERT(CHAR(2),@v_nRuleCntr) + ', rule: ' + @v_vchRule

          EXEC @v_vchRule @v_vchPickPutID -- Execute the rule!

          -- Get and Set ErrorHandler Variables
          SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
          -- Check for any errors. If so, error number will not be equal to zero.
          IF @v_nErrorNumber <> 0
          BEGIN
              SET @v_vchErrorMsg = 'Called stored procedure: ' + @v_vchRule + ' Failed!  Check SQL Server System Log for ' +
                  'the exact nature of the error.'
              SET @v_nLogErrorNum = @e_nSprocError
              GOTO ErrorHandler
          END

          -- Update the PKD with the #tmp_pick_details_to_update
          -- ** take out this update and just bulk update after all rule set have been applied
          -- !!! Segun
          /*UPDATE t_pick_detail
				SET pick_location = i.location_id,
					picking_flow = i.picking_flow
				FROM t_pick_detail pkd
				INNER JOIN #tmp_pick_details_to_update i
				   ON i.pick_id = pkd.pick_id
			  WHERE i.location_id IS NOT NULL
		  */

          -- Update the PKD with the pick put rule that was used.
          UPDATE #tmp_pick_details_to_update 
             SET before_pick_rule = @v_vchRule
           WHERE pick_location IS NOT NULL  
             AND before_pick_rule IS NULL            
          
          -- Get and Set ErrorHandler Variables
          SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
          -- Check for any errors. If so, error number will not be equal to zero.
          IF @v_nErrorNumber <> 0
          BEGIN
              SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +

                  'the exact nature of the error.'
              SET @v_nLogErrorNum = @e_nGenSqlError
              GOTO ErrorHandler
          END

          -- Clean up after ourselves
          -- Will leave it for now.
          DELETE #tmp_locations_found

          IF (SELECT COUNT(*)
                 FROM #tmp_pick_details_to_update
              WHERE pick_put_id = @v_vchPickPutID) = 0
             BREAK

          -- Increment the counter to evaluate the next rule.
          SET @v_nRuleCntr = @v_nRuleCntr + 1
        END --While Loop @v_nNumOfRules >= @v_nRuleCntr

      SET @v_vchRule = NULL -- Clear the @v_vchRule variable.
      DELETE #tmp_rule_set -- Clear out the temp table for the next round.
      SET @v_nProfileCntr = @v_nProfileCntr + 1

    END --While Loop @v_nNumOfProfiles >= @v_nProfileCntr


	-- *** Now, bulk update pkd with tmp table records by pick_id
    -- Please, make sure that all other parent sprocs to usp_before_pick_release
    -- has an update statement at least like this !!Segun
	/*UPDATE t_pick_detail
            SET pick_location = i.location_id,
                picking_flow = i.picking_flow,
                pick_area = i.pick_area,  -- just added
                work_type = i.work_type   -- just added
            FROM t_pick_detail pkd
            INNER JOIN #tmp_pick_details_to_update i
               ON i.pick_id = pkd.pick_id
          WHERE i.location_id IS NOT NULL*/
		  
    -- Get and Set ErrorHandler Variables
    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_nGenSqlError
        GOTO ErrorHandler
    END

  GOTO ExitLabel

ErrorHandler:

   -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)

ExitLabel:
  RETURN



