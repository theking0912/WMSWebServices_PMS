




-- =======================================    
-- Author: bruce   
-- Create Date: 20160330   
-- Description: 预留拣选更新状态
--  
    
-- =======================================    
   
CREATE  PROCEDURE [dbo].[csp_BookOrderPick_status]    
     @wh_id					NVARCHAR(10)  
    ,@fork_id               Nvarchar(30)		
AS    
BEGIN    
    DECLARE @pick_id INT
    DECLARE @cnt     INT
	DECLARE @shipment_number NVARCHAR(30)
	declare @qty float

	SELECT  @pick_id = 0
    WHILE (1 = 1)
	BEGIN
	  SELECT TOP 1
	         @pick_id = type,
			 @shipment_number = shipment_number
			 ,@qty = sum(actual_qty)--added by tony 20160408
		FROM t_stored_item
	   WHERE wh_id = @wh_id
	     AND location_id = @fork_id
		 AND type > @pick_id
		 group by type,shipment_number --added by tony 20160408
		 ORDER BY type

       IF @@ROWCOUNT = 0
	   BEGIN
	      BREAK
	   END
	   --20160428 updated by tony start
	  --UPDATE t_pick_detail
	  --   SET status = N'LOADED',
	  --       staged_quantity = picked_quantity,
		 --    loaded_quantity = picked_quantity
	  -- WHERE wh_id = @wh_id
		 --AND pick_id = @pick_id
		 --AND order_number = @shipment_number

		  UPDATE t_pick_detail
	     SET staged_quantity = staged_quantity + @qty,
		     loaded_quantity = loaded_quantity+ @qty
	   WHERE wh_id = @wh_id
		 AND pick_id = @pick_id
		 AND order_number = @shipment_number

		 UPDATE t_pick_detail
		 SET status = N'LOADED'
		  WHERE wh_id = @wh_id
		 AND pick_id = @pick_id
		 AND order_number = @shipment_number
		 AND loaded_quantity = planned_quantity
		--20160428 updated by tony end
	  --SELECT @cnt = COUNT(1)
	  --  FROM t_pick_detail
	  -- WHERE wh_id = @wh_id
		 --AND order_number = @shipment_number
		 --AND status != N'LOADED'

	  --IF (@cnt = 0)
	  --BEGIN
	  --   UPDATE t_order
		 --   SET status = N'LOADED'
	  --    WHERE wh_id = @wh_id
		 --   AND order_number = @shipment_number
	  --END
               If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') NOT IN('STAGED','LOADED') and a.order_number= @shipment_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
			      AND EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') ='STAGED' and a.order_number= @shipment_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
				  UPDATE t_order SET status = 'STAGED' where order_number= @shipment_number and wh_id=@wh_id
			   If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'')<>'LOADED' and a.order_number= @shipment_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
			      UPDATE t_order SET status = 'LOADED' where order_number= @shipment_number and wh_id=@wh_id
			   --------------- modified by Trevor on 20160408
     END
END



