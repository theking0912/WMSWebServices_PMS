


CREATE PROCEDURE [dbo].[csp_afo_add_all_order]
@in_vchWarehouseId        NVARCHAR(20),
@in_vchWaveId             NVARCHAR(60),
@in_vchViewId             NVARCHAR(50),
@in_vchUserId             NVARCHAR(50),  
@in_vchProfileType        NVARCHAR(10), 
@out_vchMessage           NVARCHAR(200) OUTPUT -- Contians "SUCCESS" or the message to be displayed.

AS

DECLARE
      @v_nRowCount          INTEGER,
      @v_nErrorNumber       INTEGER,
	  @v_vchSqlErrorNumber  INTEGER,
	  @v_vchLogMsg          NVARCHAR(250),
      @v_nTranCount         INTEGER,
	  @v_vchOrderNumber     NVARCHAR(30),
	  @v_nSysErrorNum       INTEGER,
	  @e_GenSqlError        INTEGER,
      @e_SprocError         INTEGER,
      @e_WaveMustBeHeld     INTEGER,
	  @e_SetWaveTypeError   INTEGER,
	  @v_nReturn            INTEGER,
      @e_InsWVDFailed       INTEGER,
      @e_InsWDLineFailed    INTEGER ,
	  @v_vchErrorMsg        NVARCHAR(500),
	  @v_nLogErrorNum       INTEGER,
	  @c_nModuleNumber      INTEGER,
	  @c_nFileNumber        INTEGER,
	  @v_vchParam1          NVARCHAR(100),
	  @v_nRaiseErrorNumber  INTEGER,
	  @out_vchWaveDetailId  NVARCHAR(50),
	  @v_vchWaveType        NVARCHAR(30)
	  SET NOCOUNT ON

	  SET @out_vchMessage = 'SUCCESS'
	  SET @e_GenSqlError = 1
	  SET @e_SprocError = 2
	  SET @e_WaveMustBeHeld = 3
      SET @e_InsWVDFailed = 4
	  SET @e_InsWDLineFailed = 5
	  SET @e_SetWaveTypeError = 6

	  SET @c_nModuleNumber = 76
	  SET @c_nFileNumber = 7


	  SET @v_nTranCount = @@TRANCOUNT
      IF @v_nTranCount = 0
        BEGIN TRANSACTION

		SELECT @v_nRowCount = COUNT(*)
		  FROM dbo.t_afo_wave_detail 
	     WHERE wave_id = @in_vchWaveId
		   AND wh_id   = @in_vchWarehouseId

		SELECT @v_vchWaveType = wave_type
		  FROM t_wave_master	
		 WHERE wave_id = @in_vchWaveId
		   AND wh_id   = @in_vchWarehouseId
		  IF @v_vchWaveType IS NULL OR @v_vchWaveType = '' OR @v_nRowCount = 0
		  BEGIN
			 UPDATE t_wave_master
				SET wave_type = @in_vchProfileType
			  WHERE wave_id = @in_vchWaveId
			   AND wh_id   = @in_vchWarehouseId
		  END
		  ELSE IF @v_vchWaveType != @in_vchProfileType
	      BEGIN
				SET @v_vchErrorMsg = '波次获取订单类型不一致'
        		SET @v_nErrorNumber = @e_SetWaveTypeError
        		GOTO ErrorHandler 
		  END
      
	  SET @v_vchOrderNumber = 0
	  WHILE(1=1)
	  BEGIN
			SELECT TOP 1
			       @v_vchOrderNumber = order_number
			  FROM t_afa_view_wave_order ta
			 WHERE wave_id = @in_vchWaveId
			   and wh_id   = @in_vchWarehouseId
			   and view_id = @in_vchViewId
			   and user_id = @in_vchUserId
			   and order_number > @v_vchOrderNumber
			   AND EXISTS(SELECT 1 FROM dbo.t_order_detail
			   WHERE order_number = ta.order_number AND qty>0 AND ISNULL(cancel_flag,'N')='N')
			 ORDER BY order_number
			SELECT @v_vchSqlErrorNumber = @@ERROR , @v_nRowCount = @@ROWCOUNT
			IF @v_vchSqlErrorNumber <> 0
			BEGIN
			   SET @v_nErrorNumber = @e_GenSqlError
			   --GOTO ErrorHandler
			END
			IF @v_nRowCount = 0
			BEGIN
			   BREAK
			END

			EXECUTE csp_afo_add_all_order_data
			        @v_vchOrderNumber
				  , @in_vchWarehouseId 
				  , @in_vchWaveId
				  , @out_vchMessage       OUTPUT
            SELECT @v_nSysErrorNum = @@ERROR
			IF @v_nSysErrorNum <> 0
			BEGIN
        		SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            		+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        		SET @v_nLogErrorNum = @e_GenSqlError
        		GOTO ErrorHandler
			END


		    DELETE t_afa_view_wave_order 
             WHERE order_number = @v_vchOrderNumber
               AND wh_id   = @in_vchWarehouseId
               AND view_id = @in_vchViewId     
               AND user_id = @in_vchUserId
               AND wave_id = @in_vchWaveId
            SELECT @v_vchSqlErrorNumber = @@ERROR , @v_nRowCount = @@ROWCOUNT  
			IF @v_vchSqlErrorNumber <> 0
			BEGIN
			   SET @v_nErrorNumber = @e_GenSqlError
			   GOTO ErrorHandler
			END


            UPDATE  t_order
            SET     status = 'WAVED'
            WHERE   wh_id = @in_vchWarehouseId
                    AND order_number = @v_vchOrderNumber
            SELECT  @v_vchSqlErrorNumber = @@ERROR ,@v_nRowCount = @@ROWCOUNT  
            IF @v_vchSqlErrorNumber <> 0
                BEGIN
                    SET @v_nErrorNumber = @e_GenSqlError
                    GOTO ErrorHandler
                END
	  END

	  IF @v_nTranCount = 0
        COMMIT TRANSACTION

	  GOTO ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    ELSE IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
            ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(NVARCHAR(30),@v_vchErrorMsg),'(NULL)') + '.'
       EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(NVARCHAR(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END
    ELSE IF @v_nErrorNumber = @e_WaveMustBeHeld
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Wave must be put on hold before adding orders.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_work_q'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
        -- Reset message after logged to return to optimizer
        SET @v_vchLogMsg = 'NOT ON HOLD'
    END
    ELSE IF @v_nErrorNumber = @e_InsWVDFailed
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Error occurred inserting a record in to the t_afo_wave_detail table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afo_wave_detail'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_InsWDLineFailed
    BEGIN
        -- Log Error
		        		
        SET @v_vchLogMsg = 'Error occurred inserting a record in to the t_afo_wave_detail_line table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afo_wave_detail_line'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END

	ELSE IF @v_nErrorNumber = @e_SetWaveTypeError
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = '波次获取订单类型不一致'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_wave_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END

    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    -- Raiserror parameters: Error #, Severity(11=ADO requirement), State(1), Parameter(to be used in error)
    --RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)


ExitLabel:
    RETURN
