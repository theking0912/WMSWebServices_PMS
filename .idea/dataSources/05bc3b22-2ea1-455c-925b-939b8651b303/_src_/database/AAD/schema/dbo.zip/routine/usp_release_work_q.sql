

CREATE  PROCEDURE usp_release_work_q

    @in_OrderNumber     AS NVARCHAR(20) = NULL,
    @in_LoadNumber      AS NVARCHAR(20) = NULL,
    @in_WaveNumber      AS NVARCHAR(20) = NULL,
    @in_ItemNumber      AS NVARCHAR(30) = NULL,
    @in_LotNumber       AS NVARCHAR(15) = NULL,
    @in_PickArea        AS NVARCHAR(10) = 'ALL',
    @in_vchType         AS NVARCHAR(2) = 'PP',
    @in_WHID            AS NVARCHAR(10) = '01',
    @in_nResultsFlag    AS INT = 0    -- 1 means return results;  0 means don't return results

AS

DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(2000),
    @v_vchOutMsg                NVARCHAR(2000),
    @v_nSysErrorNum             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @v_nTranCount               INT,

    -- Log Error numbers used for branching in the Error Handler.
    @e_GenSqlError          INT,
    @e_SprocError           INT,
    @e_MissingITMError      INT,
    @e_TControlError        INT,
    @e_BeforePickError      INT,
    @e_GetWKQRangeError     INT,
    @e_SetWKQTempError      INT,
    @e_SetWKQIDError        INT,
    @e_AddWKQError          INT,

    -- Local Variables
    @v_nCount               INT,
    @n_vchWorkType          NVARCHAR(10),
    @v_vchReleaseSprocName  NVARCHAR(100),
    @TempTableName          NVARCHAR(50),
    @v_nPreManCtl	    INT,

    --Control Type Constant
    @c_vchPreManCtl			NVARCHAR(30)

    SET NOCOUNT ON

   -- Temp table used to hold items from t_pick_detail.
   -- Items will be updated with a location_id and picking flow based on any specific
   -- rules which are executed.
   CREATE TABLE #tmp_pick_details_to_update (
      unique_id        INT IDENTITY(1,1) NOT NULL,
      wh_id            NVARCHAR(10)       COLLATE DATABASE_DEFAULT NOT NULL,
      pick_id          INT                NOT NULL,
      wave_id          NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
      load_id          NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
      work_q_id        NVARCHAR(30)       COLLATE DATABASE_DEFAULT null,
      item_number      NVARCHAR(30)       COLLATE DATABASE_DEFAULT NOT NULL,
      line_number      NVARCHAR(5)           COLLATE DATABASE_DEFAULT NULL,
      lot_number       NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
      serial_number    NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
      pick_quantity    FLOAT              NULL,
      planned_quantity FLOAT              NULL,
      uom              NVARCHAR(10)       COLLATE DATABASE_DEFAULT NULL,
      pick_put_id      NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
      location_id      NVARCHAR(50)       COLLATE DATABASE_DEFAULT NULL,
      pick_location    NVARCHAR(50)       COLLATE DATABASE_DEFAULT NULL,
      picking_flow     NVARCHAR(3)           COLLATE DATABASE_DEFAULT NULL,
      pick_area        NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
      work_type        NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
      order_number     NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
      cartonization_batch_id  NVARCHAR(150) COLLATE DATABASE_DEFAULT NULL,
      status           NVARCHAR(20)       COLLATE DATABASE_DEFAULT NULL,
      staging_location NVARCHAR(50)       COLLATE DATABASE_DEFAULT NULL,
      type             NVARCHAR(25)       COLLATE DATABASE_DEFAULT NULL,
      container_id     NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
      manifest_batch_id      NVARCHAR(50)  COLLATE DATABASE_DEFAULT NULL,
      manifest_carrier_flag  NCHAR(1)      COLLATE DATABASE_DEFAULT NULL,
      premanifest_flag       NCHAR(1)      COLLATE DATABASE_DEFAULT NULL,
      stored_attribute_id    BIGINT        NULL,
      before_pick_rule            NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,
      during_pick_rule            NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,
      pick_location_change_date   DATETIME                          NULL
    )
-- added two fields

    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 7        -- This # must be unique per object.

    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_MissingITMError = 3
    SET @e_TControlError = 4
    SET @e_BeforePickError = 5
    SET @e_GetWKQRangeError = 6
    SET @e_SetWKQTempError = 7
    SET @e_AddWKQError = 8

    SET @v_nReturn = 0

	SET @c_vchPreManCtl = 'USE_PREMANIFEST'

    -- Retrieve Database Log Level from t_control.  If it doesn't exist, insert it.
    -- 0 = Off, 1 = On
    SELECT @v_nLogLevel = next_value FROM t_control WHERE control_type = 'DB OBJ LOG LEVEL'

    IF @@ROWCOUNT = 0
        BEGIN
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit)
            VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', '0', 'SHOW_VA', '1')
        SET @v_nLogLevel = 0
    END


	SELECT @v_nPreManCtl = next_value FROM t_whse_control
	WHERE control_type = @c_vchPreManCtl
	AND wh_id = @in_WHID

    -- Print a trace level log message.
    IF @v_nLogLevel >= 5

        PRINT 'Paramters passed: Order Number: ' +  @in_OrderNumber  +
                                                 ' Load Number:' +  @in_LoadNumber +
                                                 ' Wave Number ' +  @in_WaveNumber  +
                                                 ' Pick Area ' +    @in_PickArea    +
                                                 ' Item Number ' +  @in_ItemNumber  +
                                                 ' Lot Number ' +   @in_LotNumber +                                                 ' Type ' +     @in_vchType +
                                                 ' Warehouse ID ' +    @in_WHID

    -- Check for DEFAULT_PICK_AREA in t_control
    IF NOT EXISTS (SELECT ctl.c1
                   FROM t_whse_control ctl , t_pick_area pka
                   WHERE ctl.c1 = pka.pick_area
                     AND ctl.wh_id = pka.wh_id
                     AND ctl.wh_id = @in_WHID
                     AND ctl.control_type = 'DEFAULT_PICK_AREA')
      BEGIN
          SET @v_vchErrorMsg = 'The t_control entry for DEFAULT_PICK_AREA is missing or invalid. '
          SET @v_nLogErrorNum = @e_TControlError
         -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 3, @v_vchErrorMsg, 1
       END

    -- Call usp_before_pick_release to set pick locations for all PKD's to be released
    -- Print a trace level log message.
    IF @v_nLogLevel >= 5
        PRINT 'About to Execute usp_before_pick_release. Paramters are' +
                                ' @in_OrderNumber = ' + @in_OrderNumber +
                                ' @in_LoadNumber = ' + @in_LoadNumber +
                                ' @in_WaveNumber = ' + @in_WaveNumber +
                                ' @in_ItemNumber = ' + @in_ItemNumber +
                                ' @in_LotNumber = ' + @in_LotNumber +
                                ' @in_PickArea = ' + @in_PickArea +
                                ' @in_vchType = ' + @in_vchType +
                                ' @in_vchWhID = ' + @in_WHID

    EXEC @v_nReturn = usp_before_pick_release
                @in_OrderNumber = @in_OrderNumber,
                @in_LoadNumber = @in_LoadNumber,
                @in_WaveNumber = @in_WaveNumber,
                @in_ItemNumber = @in_ItemNumber,
                @in_LotNumber = @in_LotNumber,
                @in_PickArea = @in_PickArea,
                @in_vchType = @in_vchType,
                @in_vchWhID = @in_WHID

    -- ERROR check the called sproc's results.
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in usp_before_pick_release with a return code of ' +
            ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_BeforePickError
        GOTO ErrorHandler
    END

    -- Print a trace level log message.
    IF @v_nLogLevel >= 5
    BEGIN
        PRINT 'Before Pick Area Updates: Contents of t_pick_detail for CREATED: '
        SELECT * FROM t_pick_detail WHERE status = 'CREATED'
    END


    -- The update of work_type, pick_area, etc. for PKD's based on locations found
    -- for picking is done in the final update from the temp table for performance.

    --  Update work_type, pick_area in PKD's where no pick location is found
    --  but a default pick area exists for the item/uom
    UPDATE #tmp_pick_details_to_update
        SET #tmp_pick_details_to_update.work_type = pka.work_type,
        #tmp_pick_details_to_update.pick_area = pka.pick_area
    FROM t_pick_area pka, t_item_uom uom, t_item_master itm
    WHERE #tmp_pick_details_to_update.item_number = itm.item_number
    AND #tmp_pick_details_to_update.wh_id = itm.wh_id 
    AND pka.pick_area = uom.default_pick_area
    AND pka.wh_id = uom.wh_id
    AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND itm.attribute_collection_id IS NULL AND itm.lot_control = N'N'))
    AND #tmp_pick_details_to_update.location_id IS NULL
    AND #tmp_pick_details_to_update.item_number = uom.item_number
    AND #tmp_pick_details_to_update.uom = uom.uom
    AND #tmp_pick_details_to_update.wh_id = uom.wh_id 
    AND uom.priority = 1
    AND (#tmp_pick_details_to_update.wh_id = @in_WHID OR @in_WHID = 'ALL')

    --  Update work_type, pick_area in PKD's set to global default where no
    --  previous pick area has been set
    UPDATE #tmp_pick_details_to_update
        SET #tmp_pick_details_to_update.work_type = pka.work_type,
        #tmp_pick_details_to_update.pick_area = wcl.c1
    FROM t_pick_area pka , t_whse_control wcl
    WHERE wcl.c1 = pka.pick_area
    AND wcl.wh_id = pka.wh_id
    ANd wcl.control_type = 'DEFAULT_PICK_AREA'
    AND #tmp_pick_details_to_update.pick_area IS NULL
    AND #tmp_pick_details_to_update.wh_id = wcl.wh_id
    AND (#tmp_pick_details_to_update.wh_id = @in_WHID OR @in_WHID = 'ALL') 

    SELECT @v_nSysErrorNum = @@ERROR
    IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        SET @v_nLogErrorNum = @e_GenSqlError
    --    SET @v_nErrorNumber = @e_BeforePickError
        GOTO ErrorHandler
    END

    -- Update the premanifest flag for pick areas in the #tmp_pick_details_to_update
    -- Used in later processing for parcel manifesting

    UPDATE #tmp_pick_details_to_update
	SET #tmp_pick_details_to_update.premanifest_flag = pka.premanifest_flag
	FROM #tmp_pick_details_to_update
             JOIN t_pick_area pka
             on (#tmp_pick_details_to_update.pick_area = pka.pick_area
                 AND #tmp_pick_details_to_update.wh_id = pka.wh_id)

    SELECT @v_nSysErrorNum = @@ERROR
    IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        SET @v_nLogErrorNum = @e_GenSqlError
    --    SET @v_nErrorNumber = @e_BeforePickError
        GOTO ErrorHandler
    END
   
    -- find and call release stored procedures for each work type
    -- !!Segun - added WHERE STATUS ='A' to eliminate running all sprocs
    -- so user can turn sprocs off by updating status in t_work_types instead of
    -- removing them
    SELECT TOP 1 @v_vchReleaseSprocName = wkt.release_sproc_name, @n_vchWorkType = wkt.work_type
        FROM t_work_types wkt, #tmp_pick_details_to_update pkd
        WHERE wkt.wh_id = pkd.wh_id
          AND wkt.work_type = pkd.work_type
          AND wkt.category = 'PICK'
          AND wkt.release_sproc_name IS NOT NULL
          AND wkt.status ='A' 
          AND wkt.wh_id = @in_WHID
        GROUP BY wkt.release_sproc_name, wkt.work_type
        ORDER BY wkt.work_type

    SET @v_nRowCount = @@ROWCOUNT
     WHILE @v_nRowCount > 0
        BEGIN --@v_nRowCount > 0

           EXEC @v_nReturn = @v_vchReleaseSprocName
                @in_OrderNumber = @in_OrderNumber,
                @in_LoadNumber = @in_LoadNumber,
                @in_WaveNumber = @in_WaveNumber,
                @in_ItemNumber = @in_ItemNumber,
                @in_LotNumber = @in_LotNumber,
                @in_PickArea = @in_PickArea,
                @in_vchType = @in_vchType,
                @in_WHID = @in_WHID,
                @in_nResultsFlag = @in_nResultsFlag

           IF @@ERROR <> 0 -- A zero means success.
	       BEGIN
	           SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
                             ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
               SET @v_nLogErrorNum = @e_SprocError
               GOTO ErrorHandler
	       END

           --new           IF @v_vchReleaseSprocName <> 'usp_release_work_q_label'
               BEGIN
                  IF @v_nReturn <> 0 -- A zero means success.
                      BEGIN
                          SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
                              ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
                          SET @v_nLogErrorNum = @e_SprocError
                          GOTO ErrorHandler
                      END
               END

            SELECT TOP 1 @v_vchReleaseSprocName = wkt.release_sproc_name, @n_vchWorkType = wkt.work_type
                FROM t_work_types wkt, #tmp_pick_details_to_update pkd
               WHERE wkt.wh_id = pkd.wh_id
                 AND wkt.work_type = pkd.work_type
                 AND wkt.category = 'PICK'
                 AND wkt.release_sproc_name IS NOT NULL
                 AND wkt.status ='A' 
                 AND wkt.wh_id = @in_WHID
                 AND wkt.work_type > @n_vchWorkType
                GROUP BY wkt.release_sproc_name, wkt.work_type
                ORDER BY wkt.work_type

            SET @v_nRowCount = @@ROWCOUNT
        
        END --@v_nRowCount > 0

    -- Select a count of the number of PKD's that have been released
    SELECT @v_nCount = COUNT(*)
    FROM #tmp_pick_details_to_update
    WHERE status = 'PRERLSE'
        OR status = 'CARTONIZE'

    SELECT @v_nSysErrorNum = @@ERROR
    IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    IF @v_nCount =  0
    -- No need to continue.
    GOTO Results

--Fix Defect D-08697
    --IF AFA is Installed and profile is not 4 for "Wave then Load"
    --Then create the WKQ's for load and shipments
    IF (SELECT count(0)
        FROM t_whse_control WITH (NOLOCK)
        WHERE wh_id = @in_WHID
          AND control_type = 'AFA_INSTALLED'
		  AND next_value = 4) = 0 
    BEGIN
		-- Create Work Queues for Load Audit, Loading and Shipping
		EXEC @v_nReturn = usp_release_work_q_shipping
					@in_OrderNumber = @in_OrderNumber,
					@in_LoadNumber = @in_LoadNumber,
					@in_WaveNumber = @in_WaveNumber,
					@in_ItemNumber = @in_ItemNumber,
					@in_LotNumber = @in_LotNumber,
					@in_PickArea = @in_PickArea,
					@in_vchType = @in_vchType,
					@in_WHID = @in_WHID,
					@in_nResultsFlag = @in_nResultsFlag

			-- ERROR check the called sproc's results.
			IF @v_nReturn <> 0 -- A zero means success.
			BEGIN
				SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
					ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
				SET @v_nLogErrorNum = @e_SprocError
				GOTO ErrorHandler
			END
    END
    ELSE
    BEGIN
        --Update PDK status to RELEASED if AFA = 4 
        UPDATE #tmp_pick_details_to_update --t_pick_detail
        SET status = 'RELEASED'
        WHERE status = 'PRERLSE'
            AND (work_q_id IS NOT NULL or work_type = '15')

        SELECT @v_nSysErrorNum = @@ERROR
            IF @v_nSysErrorNum <> 0
            BEGIN
                 SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
                     + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
                 SET @v_nLogErrorNum = @e_GenSqlError
              GOTO ErrorHandler
            END	
    END
--DONE Fix Defect D-08697
    -----------------------------------------------------------------------------------
    --      Final update back to t_pick_detail from temp table with results from
    --          before_pick_release and child release sprocs in loop above.
    -----------------------------------------------------------------------------------
    UPDATE pkd
	SET pkd.cartonization_batch_id = tmp.cartonization_batch_id,
            pkd.manifest_batch_id = tmp.manifest_batch_id,
	    pkd.status = tmp.status,
	    pkd.pick_location = tmp.pick_location,
	    pkd.picking_flow = tmp.picking_flow,
	    pkd.pick_area = tmp.pick_area,
	    pkd.work_type = tmp.work_type,
            pkd.work_q_id = tmp.work_q_id,
            pkd.container_id = tmp.container_id,
            pkd.before_pick_rule = tmp.before_pick_rule
	FROM t_pick_detail pkd, 
	    #tmp_pick_details_to_update tmp
	WHERE pkd.pick_id = tmp.pick_id
	
    SELECT @v_nSysErrorNum = @@ERROR
    IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END	

	IF @v_nPreManCtl = 1 
	BEGIN
		-- Insert mainfest batch id into que table for backgroud processing
		INSERT t_manifest_batch_queue (date_added, status, manifest_batch_id, wh_id )
		SELECT DISTINCT GETDATE(), 'NEW', manifest_batch_id, wh_id
		FROM #tmp_pick_details_to_update tmp
		WHERE manifest_batch_id IS NOT NULL	

	END

    -- drop temp table
    DROP TABLE #tmp_pick_details_to_update   

Results:
    -- Return message if called from WebWise

    IF @v_nCount =  0
        BEGIN
            IF @in_nResultsFlag = 1
            BEGIN    
                SELECT 'No Records to Release for Criteria Provided!' AS message
                SET @v_nReturn = 1000 --This will only be used in usp_resolve_orm_call_release
            END
            
            GOTO ExitLabel
        END
    ELSE
        IF @in_nResultsFlag = 1
        BEGIN
            SELECT 'Order Release Successful!' AS message
            SET @v_nReturn = 1001 --This will only be used in usp_resolve_orm_call_release
        END

    GoTo ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)

    SET @v_nReturn = @v_nLogErrorNum

    IF @v_nTranCount > 0
        ROLLBACK TRANSACTION

ExitLabel:
    -- Always leave the stored procedure from here.
    RETURN @v_nReturn



