-- Procedure
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Resend_Tote_To_PTL] 
	-- Add the parameters for the stored procedure here
	@In_Nvch_Guid					AS	NVARCHAR(50),
	@In_Nvch_Hu_Id					AS	NVARCHAR(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements. 
	SET NOCOUNT ON;
	BEGIN TRY

		BEGIN TRANSACTION
		UPDATE tbl_if_wcs_ptl_job_queue
			SET job_status = 'NEW'
			WHERE job_data = @In_Nvch_Guid

		UPDATE tbl_if_tote_wcs
			SET status = 'NEW'
			WHERE job_guid = @In_Nvch_Guid
			  AND tote = @In_Nvch_Hu_Id

		COMMIT

		RETURN 1
	END TRY
	BEGIN CATCH
		ROLLBACK
		RETURN 0
	END CATCH
END
