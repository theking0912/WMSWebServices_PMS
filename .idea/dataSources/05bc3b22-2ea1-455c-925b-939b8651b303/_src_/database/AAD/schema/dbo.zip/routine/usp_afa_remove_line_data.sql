
CREATE PROCEDURE usp_afa_remove_line_data
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchLoadDetailId   NVARCHAR(50),
@in_vchLoadId         NVARCHAR(60),
@in_vchItemNumber     NVARCHAR(60),
@in_vchLineNumber     NVARCHAR(10),
@in_vchLotNumber      NVARCHAR(20),
@in_nQuantity         INTEGER,
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contians "SUCCESS" or the message to be displayed.


AS

DECLARE 
    @v_nErrorNumber	  INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,

    @v_nReturn            INTEGER,
    
    @v_vchHuId            NVARCHAR(50),
    @v_chStatus           CHAR(1), 

    @e_GenSqlError   	  INTEGER,
    @e_UpdLDLFailed       INTEGER,
    @e_UpdOrdFailed       INTEGER,
    @e_FindLDFailed       INTEGER,
    @e_LoadMustBeHeld     INTEGER,

    @v_vchOrderNumber     NVARCHAR(60),
    @v_vchLotNumber       NVARCHAR(30),
    @v_nAvailQty          INTEGER,
    @v_nAFACtl            INTEGER,

    @v_nTranCount         INTEGER

    SET NOCOUNT ON

    SET @out_vchMessage = 'FAILURE' -- Initailize to fail

    SET @e_GenSqlError = 1 
    SET @e_UpdLDLFailed = 2
    SET @e_UpdOrdFailed = 3
    SET @e_FindLDFailed = 4
    SET @e_LoadMustBeHeld = 5
    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 2

    SELECT @v_nAFACtl = next_value
      FROM t_whse_control
     WHERE control_type = 'AFA_INSTALLED'
       AND wh_id = @in_vchWarehouseId

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WHETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    -- Update the record so it is locked
    UPDATE t_afa_load_detail_line
    SET line_number = line_number 
    WHERE load_detail_id =  @in_vchLoadDetailId
        AND item_number = @in_vchItemNumber
        AND line_number = @in_vchLineNumber
        AND wh_id = @in_vchWarehouseId

    -- Check for Errors. It is okay if nothing was deleted.  May be a partial.
    IF @@ERROR <> 0
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END

    -- Verify line has not been removed
    SELECT @v_nAvailQty = planned_qty
    FROM t_afa_load_detail_line
    WHERE load_detail_id =  @in_vchLoadDetailId
        AND item_number = @in_vchItemNumber
        AND line_number = @in_vchLineNumber
        AND wh_id = @in_vchWarehouseId

    IF @v_nAvailQty = 0
    BEGIN
        IF @v_nTranCount = 0
        BEGIN
            COMMIT TRANSACTION
            SET @out_vchMessage = 'SUCCESS'
            GOTO ExitLabel -- because it was probably removed by another user already
        END
        GOTO ExitLabel
    END

    -- Verify the load is on hold before manipulating data.
    SELECT @v_nRowCount = COUNT (*)
    FROM t_work_q
    WHERE wh_id = @in_vchWarehouseId                         
        AND work_q_id IN (SELECT work_q_id 
                         FROM t_pick_detail
                         WHERE wh_id = @in_vchWarehouseId
                             AND load_id = @in_vchLoadId)
        AND work_status <> 'H' 

    IF @v_nRowCount > 0 -- The the load is not on hold
    BEGIN
        SET @v_nErrorNumber = @e_LoadMustBeHeld
        GOTO ErrorHandler
    END

    -- Get the Order Number from t_ta_load_detail for the load_detail_id
    SELECT @v_vchOrderNumber = order_number 
    FROM t_afa_load_detail
    WHERE load_detail_id =  @in_vchLoadDetailId
        AND load_id = @in_vchLoadId

    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_FindLDFailed
        GOTO ErrorHandler
    END

    -- Get the real value of lot #.  VB will always pass in a "" or a value s    
    -- we need to check if NULL
    SELECT @v_vchLotNumber = lot_number
    FROM t_order_detail
    WHERE order_number = @v_vchOrderNumber
        AND item_number = @in_vchItemNumber
        AND line_number = @in_vchLineNumber
        AND wh_id = @in_vchWarehouseId

   -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_UpdLDLFailed
        GOTO ErrorHandler
    END

    IF @v_vchLotNumber IS NULL
    BEGIN
        UPDATE t_afa_load_detail_line
        SET planned_qty = (planned_qty - @in_nQuantity)
        WHERE load_detail_id = @in_vchLoadDetailId
            AND item_number = @in_vchItemNumber
            AND lot_number IS NULL
            AND line_number = @in_vchLineNumber
            AND wh_id = @in_vchWarehouseId

        -- Be sure a row was Inserted or updated
        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT

    END
    IF @v_vchLotNumber IS NOT NULL
    BEGIN
        UPDATE t_afa_load_detail_line
        SET planned_qty = (planned_qty - @in_nQuantity)
        WHERE load_detail_id = @in_vchLoadDetailId
            AND item_number = @in_vchItemNumber
            AND lot_number = @v_vchLotNumber
            AND line_number = @in_vchLineNumber
            AND wh_id = @in_vchWarehouseId
        -- Be sure a row was updated
        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    END

    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_UpdLDLFailed
        GOTO ErrorHandler
    END
    
    -- Delete t_afa_load_detail_line where no planned_qty
    -- This is done to accomodate partials and entire line item removal
    DELETE t_afa_load_detail_line
    WHERE load_detail_id = @in_vchLoadDetailId
        AND item_number = @in_vchItemNumber
        AND line_number = @in_vchLineNumber
        AND wh_id = @in_vchWarehouseId
        AND planned_qty = 0  

    -- Check for Errors. It is okay if nothing was deleted.  May be a partial.
    IF @@ERROR <> 0
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END

    -- Update the tran_plan quantity in t_order_detail for the line
    UPDATE t_order_detail SET tran_plan_qty = (tran_plan_qty + @in_nQuantity),
                              afo_plan_qty  = CASE WHEN (ISNULL(@v_nAFACtl,0) =  2 AND afo_plan_qty = tran_plan_qty) 
                                                   THEN (afo_plan_qty + @in_nQuantity) 
                                                   ELSE afo_plan_qty 
                                              END
    WHERE wh_id = @in_vchWarehouseId
        AND order_number = @v_vchOrderNumber
        AND item_number = @in_vchItemNumber
        AND line_number = @in_vchLineNumber

    -- Be sure a row was updated
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_UpdOrdFailed
        GOTO ErrorHandler
    END

    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    SET @out_vchMessage = 'SUCCESS'
  
    GOTO ExitLabel 

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    ELSE IF @v_nErrorNumber = @e_UpdLDLFailed 
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Failed to Update record into t_afa_load_detail_line for '+
            'load detail id ' + ISNULL(@in_vchLoadDetailId ,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afa_load_detail_line'
        SET @v_nRaiseErrorNumber = 50003 -- Insert Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_UpdOrdFailed
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Unable to update record for Order ' + ISNULL(@v_vchOrderNumber,'(NULL)')+
            ', Item ' + ISNULL(@in_vchItemNumber,'(NULL)')+ ' in the t_order_detail table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_order_detail'
        SET @v_nRaiseErrorNumber = 50003 -- Update Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_FindLDFailed
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Unable to find record for load detail Id ' + 
			ISNULL(@in_vchLoadDetailId,'(NULL)') + ' in the t_afa_load_detail table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afa_load_detail'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_LoadMustBeHeld
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Load must be put on hold before removing items.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_work_q'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
        -- Reset message after logged to return to optimizer
        SET @v_vchLogMsg = 'NOT ON HOLD'

    END

    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

    SET @out_vchMessage = @v_vchLogMsg
    -- Raise the error with error #, severity, state, paramater
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)        

ExitLabel:
    RETURN
