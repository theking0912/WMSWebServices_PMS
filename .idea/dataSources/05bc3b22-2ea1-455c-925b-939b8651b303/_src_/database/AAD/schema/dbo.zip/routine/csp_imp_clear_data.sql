CREATE PROCEDURE  [dbo].[csp_imp_clear_data]
AS 
/*DELETE FROM tbl_inf_imp_atporder
DELETE FROM tbl_inf_imp_soorder
DELETE FROM tbl_inf_imp_poorder
DELETE FROM tbl_inf_imp_pmorder
DELETE FROM tbl_inf_imp_customer
DELETE FROM tbl_inf_imp_cost
DELETE FROM tbl_inf_imp_item_master
DELETE FROM tbl_inf_imp_item_uom
DELETE FROM tbl_inf_imp_vendor
DELETE FROM tbl_inf_imp_vendor_bank
DELETE FROM tbl_inf_imp_ledger
DELETE FROM tbl_inf_imp_master
DELETE FROM tbl_inf_exp_inoutbound*/