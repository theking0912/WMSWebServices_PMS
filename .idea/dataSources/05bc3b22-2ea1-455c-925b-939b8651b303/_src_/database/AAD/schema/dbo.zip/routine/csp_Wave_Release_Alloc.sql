

-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Allocation Zone for put
--  
    
-- =======================================    
    
CREATE  PROCEDURE [dbo].[csp_Wave_Release_Alloc]    
     @wh_id				NVARCHAR(10)   
    ,@wave_id		    NVARCHAR(30) 
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    
	SET ANSI_NULLS OFF
		
		DECLARE @status	NVARCHAR(20)
		DECLARE @wave_type	NVARCHAR(20)
		DECLARE @detail_id			int
		DECLARE @order_number		NVARCHAR(30)
		DECLARE @cnt			int
		DECLARE @cnt_released	int
		DECLARE @cnt_noreleased	int
		DECLARE @cnt_part int
		DECLARE @pick_seq		BIGINT
		DECLARE @seq_id BIGINT
		DECLARE @error_code	    BIGINT
		DECLARE @error_msg NVARCHAR(300)

		select @status = status
		from t_wave_master
		where wh_id = @wh_id
		and   wave_id = @wave_id

		set @detail_id = 0
		set @pick_seq = 0

		IF @status not in ('N','P')
		BEGIN
			RETURN;
		END

        WHILE ( 1 = 1 )
        BEGIN
			
            SELECT TOP 1
                    @order_number = o.order_number ,
                    @detail_id = wd.wave_detail_id,
					@pick_seq = CAST(CAST(ISNULL(c.pick_seq,9999) as varchar(30))+CAST(wd.wave_detail_id as varchar(30)) as BIGINT)
            FROM    t_afo_wave_detail wd WITH(NOLOCK)
            INNER JOIN t_order o WITH(NOLOCK) ON wd.wh_id = o.wh_id
                    AND wd.order_number = o.order_number 
			LEFT JOIN t_customer c WITH(NOLOCK) ON o.wh_id = c.wh_id 
					AND o.customer_id = c.customer_id 
            WHERE   (o.status = 'WAVED' OR o.status = 'PART')
                    AND wd.wh_id = @wh_id
                    AND wd.wave_id = @wave_id
                    AND CAST(CAST(ISNULL(c.pick_seq,9999) as varchar(30))+CAST(wd.wave_detail_id as varchar(30)) as BIGINT) > @pick_seq
            ORDER BY CAST(CAST(ISNULL(c.pick_seq,9999) as varchar(30))+CAST(wd.wave_detail_id as varchar(30)) as BIGINT)

            IF @@ROWCOUNT = 0
                BEGIN
                    BREAK;
                END
				
            IF ( NOT EXISTS ( SELECT    1
                                FROM      t_pick_detail pkd WITH(NOLOCK)
                                WHERE     pkd.order_number = @order_number
                                        AND pkd.wh_id = @wh_id )
                )
                INSERT  INTO t_pick_detail
                        ( order_number ,
                            line_number ,
                            type ,
                            status ,
                            item_number ,
                            lot_number ,
                            unplanned_quantity ,
                            planned_quantity ,
                            picked_quantity ,
                            wave_id ,
                            wh_id ,
                            stored_attribute_id ,
                            pick_location
                        )
                        SELECT  @order_number AS order_number ,
                                wdl.line_number AS line_number ,
                              --  (case when isnull(pt.pick_type,'')='' then 'PP' else pt.pick_type end) AS type ,
			--------------------will modify 调拨单参与波次分配 20160813s-------------------
							   (case when isnull(pt.pick_type,'')='' then 'PP' 
							          when isnull(pt.order_type ,'')='TO' then 'PP' 
							   else pt.pick_type end) AS type ,
				--------------------will modify 调拨单参与波次分配 20160813e-------------------
                                'UNPLANNED' AS status ,
                                wdl.item_number AS item_number ,
                                ( CASE WHEN wdl.lot_number = '' THEN NULL
                                        ELSE wdl.lot_number
                                    END ) AS lot_number ,
                                0 AS unplanned_quantity ,
                                wdl.planned_qty AS planned_quantity ,
                                0 AS picked_quantity ,
                                wd.wave_id AS wave_id ,
                                @wh_id AS wh_id ,
                                ordl.stored_attribute_id AS stored_attribute_id ,
                                '' AS pick_location
                        FROM    t_afo_wave_detail_line wdl WITH(NOLOCK) 
                                inner join t_afo_wave_detail wd WITH(NOLOCK) on wdl.wh_id = wd.wh_id 
									AND wdl.wave_detail_id = wd.wave_detail_id
                                inner join dbo.t_order_detail ordl WITH(NOLOCK) on wd.wh_id = ordl.wh_id 
									AND wd.order_number = ordl.order_number 
									AND wdl.item_number = ordl.item_number
									AND wdl.line_number = ordl.line_number
								inner join t_order od WITH(NOLOCK) on wd.wh_id = od.wh_id 
									AND wd.order_number = od.order_number 
								left join tbl_pick_type pt WITH(NOLOCK) on od.wh_id = pt.wh_id 
									AND od.order_type = pt.order_type 
                        WHERE   wd.wh_id = @wh_id
                                AND wd.order_number = @order_number
                                AND NOT EXISTS ( SELECT 'X'
                                                    FROM   dbo.t_item_master item
                                                    WHERE  item.item_number = wdl.item_number
                                                        AND item.wh_id = wdl.wh_id
                                                        AND item.pick_type IN ('B', 'M' ) 
														AND od.order_type NOT IN ( 'RVO' ,'DO'))-----------------WILL ADD  20160802  退货出库和报废出库允许冬瓜牛肉按订单数量拣货

				--客户类型为BJMD-XPQ走预留拣选流程，移动类型为品控取样的走品控拣选流程
				IF Exists(select 1 from t_order od 
							left join t_customer ct 
							on od.wh_id=ct.wh_id and od.customer_id=ct.customer_id
							where od.order_number = @order_number 
								and od.wh_id = @wh_id 
								and ((ct.customer_type='BJMD-XPQ' and od.order_type='SO') or od.move_code='202'))
				----------------will  add  s  退货出库和报废出库不参与波次分配-----------------------------------
					OR 	 EXISTS (
				                 SELECT 1
				                  FROM t_order WITH (NOLOCK)
				                 WHERE order_number = @order_number
					             AND wh_id = @wh_id
					             AND order_type IN ( 'RVO' ,'DO')
								 )
			----------------will  add  e  退货出库和报废出库不参与波次分配-----------------------------------
				BEGIN
					UPDATE t_pick_detail 
					SET type='PO' 
					WHERE order_number = @order_number
                        AND wh_id = @wh_id
				END
            ELSE
                UPDATE  t_pick_detail
                SET     wave_id = @wave_id
                WHERE   order_number = @order_number
                        AND wh_id = @wh_id
                        AND wave_id <> @wave_id

            IF EXISTS(select 1 from t_pick_detail 
				 WHERE order_number = @order_number
					AND wh_id = @wh_id
					AND wave_id = @wave_id 
					AND type='PP'
					)
			BEGIN
				EXEC csp_Order_Allocation_Alloc_NBO @wh_id,@wave_id,@order_number,@error_code OUTPUT,@error_msg OUTPUT

				IF @error_code=1
				BEGIN
					SELECT @seq_id = @@IDENTITY

					INSERT INTO tbl_watch_bug (
						seq_id
						,exe_date
						,remark
						,wh_id
						,wave_id
						,pick_id
						)
					VALUES (
						@seq_id
						,GETDATE()
						,'Exception:'+ISNULL(@error_msg,'')
						,@wh_id
						,@wave_id
						,@order_number
						)

					DELETE wq FROM t_work_q wq 
					INNER JOIN tbl_allocation al on wq.wh_id=al.wh_id and wq.pick_ref_number=al.pick_id 
					WHERE al.wh_id=@wh_id 
						AND al.wave_id=@wave_id 
						AND al.order_number=@order_number 

					DELETE FROM tbl_allocation 
					WHERE wh_id=@wh_id 
						AND wave_id=@wave_id 
						AND order_number=@order_number 

					CONTINUE
				END
			END

			IF NOT EXISTS (					
					SELECT 1
					FROM dbo.t_order_detail ta WITH (NOLOCK) 
					inner join t_item_master itm on ta.wh_id=itm.wh_id and ta.item_number=itm.item_number 
					WHERE itm.pick_type IN ('S','O')
						AND ta.order_number = @order_number
						AND ta.wh_id = @wh_id 
						AND ISNULL(ta.cancel_flag,'N')='N'
					)
			BEGIN
				UPDATE t_order
				SET status = 'RELEASED'
				WHERE wh_id = @wh_id
					AND status NOT IN (
						'PICKED'
						,'STAGED'
						,'LOADED'
						,'SHIPPED'
						)
					AND order_number = @order_number
			END

        END

		BEGIN TRY
		
		BEGIN TRAN

        EXEC csp_Wave_PickList @wh_id, @wave_id		     			

	    SELECT  @cnt = COUNT(0) ,
                @cnt_noreleased = ISNULL(SUM(( CASE WHEN o.status = 'WAVED' THEN 1
                                             ELSE 0
                                        END )),0),
				@cnt_part = ISNULL(SUM((CASE WHEN o.status = 'PART' THEN 1
									ELSE 0
									END)),0)
        FROM    t_afo_wave_detail wd WITH(NOLOCK),
                t_order o WITH(NOLOCK)
        WHERE   wd.wh_id = o.wh_id
                AND wd.order_number = o.order_number 
                AND wd.wh_id = @wh_id
                AND wd.wave_id = @wave_id

		--if @cnt = @cnt_released
        IF @cnt_noreleased = 0
            UPDATE  t_wave_master
            SET     status = 'R' ,
                    released_date = GETDATE()
            WHERE   wh_id = @wh_id
                    AND wave_id = @wave_id

		IF @cnt_part > 0 
			UPDATE  t_wave_master
            SET     status = 'P' ,
                    released_date = GETDATE()
            WHERE   wh_id = @wh_id
                    AND wave_id = @wave_id

		--更新预留订单的订单和波次状态为已释放
		UPDATE t_pick_detail 
		SET status='RELEASED' 
		WHERE wh_id = @wh_id
            AND wave_id = @wave_id 
			AND status='UNPLANNED' 
			--AND type='PO' del by tony 20160329
			AND type in ('PO','PT') --  Added by tony 20160329
		
		UPDATE od SET od.status = 'RELEASED' 
		FROM t_order od 
		WHERE od.wh_id = @wh_id
			AND od.status NOT IN (
				'PICKED'
				,'STAGED'
				,'LOADED'
				,'SHIPPED'
				)
			AND Exists(select 1 from t_pick_detail pk 
						where od.wh_id=pk.wh_id 
						and od.order_number=pk.order_number 
						and wh_id = @wh_id 
						AND wave_id = @wave_id 
						--and type='PO'--del by tony 20160329
						AND type in ('PO','PT') --  Added by tony 20160329
						)			

		UPDATE t_wave_master 
		SET     status = 'R' ,
                    released_date = GETDATE()
        WHERE   wh_id = @wh_id
                AND wave_id = @wave_id 
				AND Not Exists(select 1 from t_pick_detail where wh_id = @wh_id AND wave_id = @wave_id 
					--and type='PO' --del by tony 20160329
					AND type in ('PP') --  Added by tony 20160329
					)

		COMMIT

        RETURN

    END TRY

    BEGIN CATCH
	    rollback
        RETURN
    END CATCH
  
END


