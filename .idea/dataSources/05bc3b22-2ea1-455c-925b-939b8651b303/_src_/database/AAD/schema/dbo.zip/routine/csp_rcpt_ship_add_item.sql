
CREATE PROCEDURE [dbo].[csp_rcpt_ship_add_item] 
@in_vchItemNumber       NVARCHAR(30),
@in_vchLineNumber       NVARCHAR(30),
--@in_nQuantity			INT,
@in_vchShipmentNumber   NVARCHAR(30),
@in_vchPo               NVARCHAR(30),
@in_vchWarehouseID      NVARCHAR(10),
@user_localeID          NVARCHAR(10),
@out_vchMessage         NVARCHAR(1000) OUTPUT
AS

DECLARE
     @v_vchSqlErrorNumber   NVARCHAR(50),
     @v_nRowCount           INTEGER,
     @v_vchErrorNumber      NVARCHAR(10)

     
     SET NOCOUNT ON
     BEGIN TRANSACTION

     SELECT @v_nRowCount = COUNT(*)
     FROM t_rcpt_ship_po
     WHERE   shipment_number = @in_vchShipmentNumber
         AND po_number       = @in_vchPo
         AND wh_id           = @in_vchWarehouseID
     
     IF @v_nRowCount = 0 
     BEGIN
         --Insert po into receipt shipment po
         INSERT INTO t_rcpt_ship_po
         (
             wh_id, 
             shipment_number, 
             po_number, 
             cases_received, 
             open_to_buy_date
         )
         SELECT 
             @in_vchWarehouseID, 
             @in_vchShipmentNumber, 
             po_number, 
             0, 
             GETDATE()
         FROM t_po_master
         WHERE   po_number = @in_vchPo
             AND wh_id     = @in_vchWarehouseID  
     
        -- Be sure a row was inserted
        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
        BEGIN
            IF @v_vchSqlErrorNumber <> 0
            BEGIN 
               SET @out_vchMessage = dbo.usf_get_locale_text('Execute_DB_Error','constant',@user_localeID,'CONSTANT')
            END
            ELSE
            BEGIN
               SET @out_vchMessage = dbo.usf_get_locale_text('Execute_Failure_WithOtherReasons','constant',@user_localeID,'CONSTANT')
            END
            GOTO ErrorHandler
        END
     END
     
     --Insert po detail into receipt shipment po detail
     INSERT INTO t_rcpt_ship_po_detail
         (
             wh_id, 
             shipment_number, 
             po_number, 
             line_number, 
             item_number, 
             schedule_number, 
             expected_qty, 
             reconciled_date, 
             status,
			 more_qty,
			 less_qty
         )
         SELECT 
             @in_vchWarehouseID, 
             @in_vchShipmentNumber, 
             po_number, 
             line_number, 
             pod.item_number,  
             schedule_number, 
            -- CAST((pod.qty*um.conversion_factor+ISNULL(ROUND(upper_percent * pod.qty*um.conversion_factor,0,1),0)) as float)
			CAST((pod.qty*um.conversion_factor+ISNULL(ceiling(upper_percent * pod.qty*um.conversion_factor),0)) as float)
			 -isnull((SELECT  SUM(received_qty) received_qty
                                FROM    dbo.t_rcpt_ship_po_detail WITH ( NOLOCK )
                                WHERE   shipment_number <> @in_vchShipmentNumber
								  AND po_number=@in_vchPo
								  and line_number=@in_vchLineNumber
								  and wh_id=@in_vchWarehouseID),0), 
             NULL, 
             'O',
			 0,
			 0
			 --pod.qty*um.conversion_factor
			 ---isnull((SELECT  SUM(less_qty) less_qty
    --                            FROM    t_rcpt_ship_po_detail WITH ( NOLOCK )
    --                            WHERE   shipment_number <> @in_vchShipmentNumber
				--				  AND po_number=@in_vchPo
				--				  and line_number=@in_vchLineNumber
				--				  and wh_id=@in_vchWarehouseID),0)
         FROM t_po_detail pod WITH ( NOLOCK ),dbo.t_item_uom um WITH ( NOLOCK )
         WHERE   po_number   = @in_vchPo
             AND pod.wh_id       = @in_vchWarehouseID 
             AND pod.item_number = @in_vchItemNumber
             AND line_number = @in_vchLineNumber
			 AND ISNULL(pod.cancel_flag,N'N')=N'N'
			 AND ISNULL(pod.complete_flag,'N') = 'N'
			 AND pod.item_number = um.item_number
			 AND pod.order_uom =um.uom
			 AND pod.wh_id =um.wh_id
			 -- AND pod.client_code =um.client_code
			 AND ((pod.qty+ISNULL(ROUND(upper_percent * pod.qty,0,1),0))*um.conversion_factor
			 -isnull((SELECT  SUM(received_qty) received_qty
                                FROM    t_rcpt_ship_po_detail WITH ( NOLOCK )
                                WHERE   shipment_number <> @in_vchShipmentNumber
								  AND po_number=@in_vchPo
								  and line_number=@in_vchLineNumber
								  and wh_id=@in_vchWarehouseID),0)) > 0
     
     -- Be sure a row was inserted
     SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
     IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
     BEGIN
         IF @v_vchSqlErrorNumber <> 0
         BEGIN 
            SET @out_vchMessage = dbo.usf_get_locale_text('Execute_DB_Error','constant',@user_localeID,'CONSTANT')
         END
         ELSE
         BEGIN
            SET @out_vchMessage = dbo.usf_get_locale_text('Execute_Failure_WithOtherReasons','constant',@user_localeID,'CONSTANT')
         END
         GOTO ErrorHandler
     END
     
     COMMIT TRANSACTION
     --SET @out_vchMessage = dbo.usf_get_locale_text('Execute_Success','constant',@user_localeID,'CONSTANT')
	 SET @out_vchMessage = 'SUCCESS'
     
     GOTO ExitLabel 

ErrorHandler:
    --SET @out_vchMessage = @out_vchMessage
    --ROLLBACK TRANSACTION      
	RAISERROR(@out_vchMessage,0,0)
    IF @@TRANCOUNT > 0   
	BEGIN
		ROLLBACK TRANSACTION   
		RETURN
	END

ExitLabel:
    RETURN

