





-- =============================================
-- Author:		<Author,,Name>
-- Create date:  1/14/2016
-- Description:	Add customer
-- =============================================
CREATE PROCEDURE [dbo].[csp_add_customer]
	-- Add the parameters for the stored procedure here
@user_id  nvarchar(10),     
@customer_id     int, 
@customer_code    nvarchar(30),   
@customer_name    nvarchar(30),   
@customer_addr1     nvarchar(100),  
@customer_addr2     nvarchar(30),  
@customer_addr3     nvarchar(30),   
@customer_city     nvarchar(30),   
@customer_state    nvarchar(6),   
@customer_zip       nvarchar(10),
@customer_country_code     nvarchar(5), 
@customer_country_name     nvarchar(30),  
@customer_phone      nvarchar(30),
@customer_email      nvarchar(30),
@customer_category    nvarchar(30), 
@customer_priority     nvarchar(2), 
@customer_ship_method     nvarchar(30), 
@customer_route      nvarchar(10),
@wh_id         nvarchar(10),
@customer_fax     nvarchar(30), 
@status       nvarchar(10),
@customercode_report nvarchar(10),       
@short_name       nvarchar(50),
@customer_type    nvarchar(20), 
@contact_first_name  nvarchar(35),    
@contact_last_name    nvarchar(35),   
@contact_phone       nvarchar(20),
@pick_seq    int,
@out_vchMsg             NVARCHAR(200) OUTPUT

AS
begin

		  
		
		INSERT INTO t_customer
				
     (	
	            customer_code,       customer_name,       customer_addr1,       customer_addr2,       customer_addr3 ,       
			customer_city,        customer_state ,      customer_zip ,      customer_country_code ,     customer_country_name ,      customer_phone,      
            customer_email,      customer_category ,    customer_priority ,     customer_ship_method,      customer_route ,     wh_id,         
            customer_fax,      status ,      customercode_report,        short_name,       customer_type ,    
            contact_first_name ,     contact_last_name,       contact_phone,      
			pick_seq
	 )
	  
	  values
	(
   
			@customer_code,      @customer_name,       @customer_addr1,       @customer_addr2,       @customer_addr3 ,       
			@customer_city,        @customer_state ,      @customer_zip ,      @customer_country_code ,     @customer_country_name ,      @customer_phone,      
			@customer_email,      @customer_category ,    @customer_priority ,     @customer_ship_method,      @customer_route ,     @wh_id,         
			@customer_fax,      @status ,      @customercode_report,        @short_name,       
			@customer_type ,    @contact_first_name ,     @contact_last_name,       @contact_phone,       
			@pick_seq
	)

		 INSERT INTO tbl_web_tran_log
		(
		   type_id,object_id,tran_date,employee_id,remark1,remark2
		)
		VALUES
		(
		'1','3',getdate(),@user_id ,'',''
		)	
			
			 INSERT INTO tbl_tran_customer
		
     (	
	        tran_log_id,is_new,customer_id ,     customer_code,       customer_name,       customer_addr1,       customer_addr2,       customer_addr3 ,       
			customer_city,        customer_state ,      customer_zip ,      customer_country_code ,     customer_country_name ,      customer_phone,      
            customer_email,      customer_category ,    customer_priority ,     customer_ship_method,      customer_route ,     wh_id,         
            customer_fax,      status ,      customercode_report,        short_name,       customer_type ,    
            contact_first_name ,     contact_last_name,       contact_phone,      
			 pick_seq
	 )
	select
           (select top 1 tran_log_id from tbl_web_tran_log order by tran_log_id desc), 'Y',customer_id , customer_code, customer_name, customer_addr1,customer_addr2,       
			customer_addr3 ,   customer_city,        customer_state ,      customer_zip ,      customer_country_code ,     customer_country_name ,  customer_phone,      
			customer_email,      customer_category ,    customer_priority ,     customer_ship_method,      customer_route ,     wh_id,         
			customer_fax,      status ,      customercode_report,        short_name,       customer_type ,    
			contact_first_name ,     contact_last_name,       contact_phone,       
			pick_seq    
			from t_customer  where customer_id=(select top 1 customer_id from t_customer order by customer_id desc )
		

           
if @@ROWCOUNT=0
  set @out_vchMsg='failed'
  else 
set @out_vchMsg='success'
return	
end



