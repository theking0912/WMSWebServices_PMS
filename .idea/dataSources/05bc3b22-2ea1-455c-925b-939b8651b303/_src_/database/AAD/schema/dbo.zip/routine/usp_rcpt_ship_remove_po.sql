

CREATE PROCEDURE [dbo].[usp_rcpt_ship_remove_po] 
@in_vchShipmentNumber   NVARCHAR(30),
@in_vchPo               NVARCHAR(30),
@in_vchWarehouseID      NVARCHAR(10),
@out_vchMessage         NVARCHAR(200) OUTPUT
AS

DECLARE

    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER,
    @v_vchErrorNumber       NVARCHAR(10)

    SET NOCOUNT ON


    SELECT @v_nRowCount = COUNT(*) FROM t_receipt
    WHERE po_number = @in_vchPo
       AND shipment_number = @in_vchShipmentNumber
       AND wh_id = @in_vchWarehouseID
       AND qty_received > 0;

    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR --, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
       BEGIN 
         SET @v_vchErrorNumber = '50001'
         SET @out_vchMessage   = 'A SQL error occured while count from t_receipt.'
       END

    IF @v_nRowCount > 0 
       BEGIN
         SET @out_vchMessage = 'PO BEING RECEIVED'
         GOTO ExitLabel
       END

    
    BEGIN TRANSACTION
    --Added by Tony
	--IF EXISTS ( SELECT 1 FROM tbl_rcpt_ship_package
	--			WHERE shipment_number   = @in_vchShipmentNumber   
	--			AND wh_id             = @in_vchWarehouseID)
	--	BEGIN
	--		 SET @out_vchMessage = 'Receiving'
	--		GOTO ExitLabel
	--	END
	--End


    --Delete all the receipt shipment po details
    DELETE 
    FROM t_rcpt_ship_po_detail 
    WHERE   shipment_number   = @in_vchShipmentNumber   
        AND wh_id             = @in_vchWarehouseID
        AND po_number         = @in_vchPo
        AND received_qty      = 0
		AND status			  = 'O'
    
    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN 
           SET @v_vchErrorNumber = '50001'
           SET @out_vchMessage = 'A SQL error occured while deleting from t_rcpt_ship_po_detail.'
        END
        GOTO ErrorHandler
    END
    
    DELETE 
    FROM t_rcpt_ship_po
    WHERE   po_number  = @in_vchPo 
        AND shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouseID
        AND NOT EXISTS 
        (
        SELECT 1 
        FROM t_rcpt_ship_po_detail 
        WHERE   shipment_number  = @in_vchShipmentNumber    
            AND wh_id            = @in_vchWarehouseID
            AND po_number        = @in_vchPo
			AND status			 = 'O'
        )
    
    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN 
            SET @v_vchErrorNumber = '50003'
            SET @out_vchMessage   = 'A SQL error occured while deleting from t_rcpt_ship_po.'
        END
        ELSE
        BEGIN
           SET @v_vchErrorNumber = '50004'
           SET @out_vchMessage   = 'Some items may already have been received.  Please refresh screen.'
        END
        GOTO ErrorHandler
    END
    
    COMMIT TRANSACTION
    SET @out_vchMessage = 'SUCCESS'
    
    GOTO ExitLabel 

ErrorHandler:
    SET @out_vchMessage = @v_vchErrorNumber + ' - ' + @out_vchMessage
	IF @@TRANCOUNT > 0
	BEGIN
    ROLLBACK TRANSACTION
	END
    --RAISERROR (@out_vchMessage, 16, 1)        

ExitLabel:
    RETURN
 

