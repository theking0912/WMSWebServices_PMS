
CREATE TRIGGER [dbo].[tr_attribute_type_insert] ON [dbo].[t_attribute_type] FOR INSERT 
AS 
DECLARE	@strErrorMessage             NVARCHAR(200),
        @nErrorNumber                INTEGER,
        @nLogLevel                   TINYINT,
        @strObjName                  NVARCHAR(30),
        @attribute_id                INTEGER,
        @attribute_action_id         INTEGER,
        @attribute_behavior_id       INTEGER,
        @attribute_behavior_type     NVARCHAR(20),

        @count                       INTEGER,
        @rows                        INTEGER

        DECLARE v_attrib_behavior_cur CURSOR
        OPTIMISTIC 
        FOR
           SELECT attribute_behavior_id, 
                  attribute_behavior_type
             FROM t_attribute_behavior
           ORDER BY attribute_behavior_id

  -- Set constant values.
  SET @strObjName = 'tr_attribute_type_inserte'

  SET NOCOUNT ON
 

  SELECT @attribute_id = attribute_id  FROM inserted

  -- Grab the Database Log Level from t_control.  If it doesn't exist, insert it.
  -- 0 = Off, 1 = On
  SELECT @nLogLevel = next_value FROM t_control WHERE control_type = 'DB OBJ LOG LEVEL'

  IF @@ROWCOUNT = 0
    BEGIN
      INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit)
        VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', '0', 'SHOW_VA', '1')
      SET @nLogLevel = 0
    END

    OPEN v_attrib_behavior_cur
    FETCH NEXT FROM v_attrib_behavior_cur INTO @attribute_behavior_id, @attribute_behavior_type
    WHILE @@FETCH_STATUS = 0
        BEGIN
	        INSERT INTO t_attribute_action 
	            (
	              attribute_id,
	              attribute_behavior_id,
	              process_before,
	              process_after,
	              process_during,
	              create_date,
	              modified_date
	            )
	        SELECT 
	             @attribute_id,
	             @attribute_behavior_id, 
	             def_process_before,
	             def_process_after,
	             def_process_during,
	             GETDATE(),
	             GETDATE()
	          FROM
	             t_attribute_behavior 
	         WHERE attribute_behavior_id = @attribute_behavior_id


             SELECT @attribute_action_id = SCOPE_IDENTITY()

             INSERT INTO t_attribute_action_prompt
	            (
	              attribute_action_id,
	              locale_id,
	              short_prompt,
	              long_prompt,
	              locale_attribute_type
	            )
	        VALUES
                ( 
	             @attribute_action_id,
	             '2052', 
	             N'请选择规格',
	             NULL,
	             NULL
	            )
        
            FETCH NEXT FROM v_attrib_behavior_cur INTO @attribute_behavior_id, @attribute_behavior_type
        END


    CLOSE v_attrib_behavior_cur
    DEALLOCATE v_attrib_behavior_cur

