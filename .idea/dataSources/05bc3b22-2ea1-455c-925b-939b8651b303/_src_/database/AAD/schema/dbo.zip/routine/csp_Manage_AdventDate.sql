






CREATE  PROCEDURE [dbo].[csp_Manage_AdventDate] 	
AS
BEGIN
	SET NOCOUNT ON

	----更新收货暂存区冻结商品所在托盘的状态为U不可用，上架会提示库存冻结，可做移库
	--UPDATE hu set hu.status='U' 
	--FROM t_hu_master hu 
	--	inner join dbo.t_stored_item sto on hu.wh_id=sto.wh_id and hu.hu_id=sto.hu_id 
	--	inner join t_item_master itm on sto.wh_id=itm.wh_id and sto.item_number=itm.item_number 
	--	inner join t_location loc on sto.wh_id=loc.wh_id and sto.location_id=loc.location_id 
	--	inner join t_zone_loca zl on sto.wh_id=zl.wh_id and sto.location_id=zl.location_id 
	--	inner join t_zone z on zl.wh_id=z.wh_id and zl.zone=z.zone 
	--WHERE sto.status in ('A','U') --U为盲收商品在收货暂存区的库存状态
	--	AND itm.expiration_date_control='Y'
	--	AND loc.type = 'S' 
	--	AND z.zone_type='N' 
	--	AND DATEADD(DAY, (itm.shelf_life - itm.advent_days), CAST(SUBSTRING(replace(lot_number,'/',''), 0, 9) AS DATETIME)) < DATEADD(DAY, -1, GETDATE()) 
	--	AND isnull(sto.lot_number,'')<>''
	--	AND isnull(sto.hu_id,'')<>''
	
	--更新收货暂存区临期商品库存的状态为H冻结不可用
	UPDATE sto set sto.status='H',sto.unavailable_qty=sto.actual_qty 
	FROM dbo.t_stored_item sto 
		inner join t_item_master itm on sto.wh_id=itm.wh_id and sto.item_number=itm.item_number 
		inner join t_location loc on sto.wh_id=loc.wh_id and sto.location_id=loc.location_id 
		inner join t_zone_loca zl on sto.wh_id=zl.wh_id and sto.location_id=zl.location_id 
		inner join t_zone z on zl.wh_id=z.wh_id and zl.zone=z.zone 
	WHERE sto.status in ('A','U') 
		AND itm.expiration_date_control='Y'
		AND loc.type = 'S' 
		AND z.zone_type='N' 
		AND DATEADD(DAY, (itm.shelf_life - itm.advent_days), CAST(SUBSTRING(replace(lot_number,'/',''), 0, 9) AS DATETIME)) < DATEADD(DAY, -1, GETDATE()) 
		AND isnull(sto.lot_number,'')<>''
		AND isnull(sto.hu_id,'')<>''

	--更新大库区和拣货区临期商品库存的状态为H冻结不可用，不可用数量为实际数量
	UPDATE sto set sto.status='H',sto.unavailable_qty=sto.actual_qty  
	FROM dbo.t_stored_item sto 
		inner join t_item_master itm on sto.wh_id=itm.wh_id and sto.item_number=itm.item_number 
		inner join t_location loc on sto.wh_id=loc.wh_id and sto.location_id=loc.location_id 
		inner join t_zone_loca zl on sto.wh_id=zl.wh_id and sto.location_id=zl.location_id 
		inner join t_zone z on zl.wh_id=z.wh_id and zl.zone=z.zone 
	WHERE sto.status = 'A' 
		AND itm.expiration_date_control='Y'
		AND loc.type not in ('X','D','T','F','S') --X播种暂存区，D发货道口，T播种货位，F叉车，S收货暂存区
		AND z.zone_type='N' 
		AND DATEADD(DAY, (itm.shelf_life - itm.advent_days), CAST(SUBSTRING(replace(lot_number,'/',''), 0, 9) AS DATETIME)) < DATEADD(DAY, -1, GETDATE()) 
		AND isnull(sto.lot_number,'')<>''
		AND NOT EXISTS(
			SELECT 1
				FROM tbl_allocation
			WHERE wh_id = sto.wh_id
				AND item_number = sto.item_number
				AND location_id = sto.location_id
				AND ISNULL(lot_number,'') = ISNULL(sto.lot_number,'')
				AND ISNULL(hu_id,'') = ISNULL(sto.hu_id,'')
				AND status != 'C'
				)

	----更新货损区库存和货损标识
	--UPDATE sto set sto.status='H',sto.unavailable_qty=sto.actual_qty,damage_flag='Y'
	--FROM dbo.t_stored_item sto 
	--	inner join t_location loc on sto.wh_id=loc.wh_id and sto.location_id=loc.location_id 
	--	inner join t_zone_loca zl on sto.wh_id=zl.wh_id and sto.location_id=zl.location_id 
	--	inner join t_zone z on zl.wh_id=z.wh_id and zl.zone=z.zone 
	--WHERE loc.type not in ('X','D','T','F','S') --X播种暂存区，D发货道口，T播种货位，F叉车，S收货暂存区
	--	AND z.zone_type='D' 
	--	AND sto.unavailable_qty<>sto.actual_qty
	--	AND isnull(ciq_number,'') =''    -----------------will  add 20160801
	
END







