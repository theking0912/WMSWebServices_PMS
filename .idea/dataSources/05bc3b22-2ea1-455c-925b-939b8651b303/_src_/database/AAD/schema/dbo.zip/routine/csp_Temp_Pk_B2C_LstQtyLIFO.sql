CREATE PROCEDURE [dbo].[csp_Pk_B2C_LstQtyLIFO]    
		@in_vchWhID NVARCHAR(10)
	,	@in_vchItemID nvarchar(30)
	,	@in_vchLot nvarchar(30)
	,	@in_fQuantiry float
	,	@in_vchClientCode nvarchar(30)
	,	@in_vchCaseFlag Nvarchar(1)
	,	@out_vchLocationID nvarchar(30) output
	,	@out_fAllocatedQty float output
AS    
BEGIN 
    DECLARE @Result			NVARCHAR(30)
	DECLARE @c_vchLocTypes	NVARCHAR(30)
	DECLARE @zone			NVARCHAR(30)
	DECLARE @vip_flag		NVARCHAR(30)

	BEGIN TRY

		set @out_vchLocationID = ''
		set @out_fAllocatedQty = 0
		set @zone = ''

		SET @Result = ''
		SET @c_vchLocTypes = 'AMI'

		select @vip_flag=vip_flag
		from t_client
		where wh_id = @in_vchWhID
		and client_code = @in_vchClientCode

		delete from #tmp_item_allocated

		insert into #tmp_item_allocated
		select  @in_vchWhID
			,	@in_vchItemID
			,	@in_vchLot
			,	z.zone
			,	ito.location_id
			,	loc.type
			,	ito.fifo_date
			,	ito.expiration_date
			,	zl.pick_seq
			,	ito.actual_qty - ito.unavailable_qty
			,	isnull(alloc.allocated_qty,0)
		from  t_stored_item ito inner join t_zone_loca zl on ito.wh_id = zl.wh_id and ito.location_id = zl.location_id
								inner join t_zone z on zl.wh_id = z.wh_id and zl.zone = z.zone
								inner join t_location loc on zl.wh_id = loc.wh_id and zl.location_id = loc.location_id
								left join (select location_id,item_number,wh_id,sum(isnull(allocated_qty,0) - isnull(picked_qty,0)) as allocated_qty,(case when @in_vchLot is null then @in_vchLot else lot_number end) as lot_number
											from tbl_allocation
											where item_number = @in_vchItemID
											and wh_id = @in_vchWhID
											and (@in_vchLot is null or lot_number = @in_vchLot)
											group by location_id,item_number,wh_id,(case when @in_vchLot is null then @in_vchLot else lot_number end)) alloc 
									on ito.wh_id = alloc.wh_id and ito.item_number = alloc.item_number
									and ito.location_id = alloc.location_id and (@in_vchLot is null or ito.lot_number = alloc.lot_number)
		where ito.item_number = @in_vchItemID
		and (@in_vchLot is null or ito.lot_number = @in_vchLot)
		and ito.wh_id = @in_vchWhID
		and ito.actual_qty - ito.unavailable_qty > 0
		and loc.status not in ('I','H')
		and ito.status = 'A'

		if @vip_flag = 'Y'or @vip_flag = 'V'
		begin
			select top 1 @out_vchLocationID = t.location_id
						,@out_fAllocatedQty=(case when t.stored_qty - t.allocated_qty >= @in_fQuantiry then @in_fQuantiry
												else t.stored_qty - t.allocated_qty end)
			from #tmp_item_allocated t inner join t_zone z on t.wh_id = z.wh_id and t.zone = z.zone and z.zone_type = 'CV'
										inner join tbl_client_zone cz on t.wh_id = cz.wh_id and cz.zone = t.zone and cz.client_code = @in_vchClientCode
										inner join (select wh_id, zone, sum(stored_qty - allocated_qty) as can_alloc_qty, sum(allocated_qty) as allocated_qty
													from #tmp_item_allocated
													where item_number = @in_vchItemID
													and wh_id = @in_vchWhID
													and (@in_vchLot is null or lot_number = @in_vchLot)
													group by wh_id,zone) zone_allo on t.zone = zone_allo.zone and t.wh_id = zone_allo.wh_id
			where t.stored_qty > t.allocated_qty
			order by (case when can_alloc_qty > @in_fQuantiry then 1 else 2 end),zone_allo.allocated_qty desc,zone_allo.can_alloc_qty desc, CHARINDEX( t.location_type, @c_vchLocTypes ), t.fifo_date desc, (t.stored_qty - t.allocated_qty), t.pick_flow, t.location_id
		end
		else
		begin
			select top 1 @out_vchLocationID = t.location_id
						,@out_fAllocatedQty=(case when t.stored_qty - t.allocated_qty >= @in_fQuantiry then @in_fQuantiry
												else t.stored_qty - t.allocated_qty end)
			from #tmp_item_allocated t inner join t_zone z on t.wh_id = z.wh_id and t.zone = z.zone and z.zone_type = 'CS'
										inner join (select wh_id, zone, sum(stored_qty - allocated_qty) as can_alloc_qty, sum(allocated_qty) as allocated_qty
													from #tmp_item_allocated
													where item_number = @in_vchItemID
													and wh_id = @in_vchWhID
													and (@in_vchLot is null or lot_number = @in_vchLot)
													group by wh_id,zone) zone_allo on t.zone = zone_allo.zone and t.wh_id = zone_allo.wh_id
			where t.stored_qty > t.allocated_qty
			order by (case when can_alloc_qty > @in_fQuantiry then 1 else 2 end),zone_allo.allocated_qty desc,zone_allo.can_alloc_qty desc, CHARINDEX( t.location_type, @c_vchLocTypes ), t.fifo_date desc, (t.stored_qty - t.allocated_qty), t.pick_flow, t.location_id
		end

		--drop table #tmp_item_allocated
		RETURN
	END TRY

    BEGIN CATCH
        SET @out_vchLocationID = ''
        SET @out_fAllocatedQty = 0
        RETURN
    END CATCH
END
