-- =======================================    
-- Author: Laver 
-- Create Date: 2014-08-04   
-- Description: Get Replenishment pick task
--  
    
-- =======================================    

CREATE PROCEDURE [dbo].[csp_Get_Task_ForRepPick]    
     @wh_id					NVARCHAR(10)
	,@user_id				NVARCHAR(30)
	,@zone					NVARCHAR(30)
	,@start_loc				NVARCHAR(50)
	,@pick_expiration_date	DATETIME		OUTPUT
	,@pick_loc				NVARCHAR(30)	OUTPUT
	,@pick_item_number		NVARCHAR(30)	OUTPUT
	,@pick_lot_number		NVARCHAR(30)	OUTPUT
	,@pick_sto_atrribute_id	NVARCHAR(30)	OUTPUT
	,@pick_qty				FLOAT			OUTPUT
	,@pick_hu_id			NVARCHAR(30)	OUTPUT
	--,@pick_zone				NVARCHAR(10)	OUTPUT
	--,@ref_number			NVARCHAR(30)	OUTPUT
	,@damage_flag			NVARCHAR(1)		OUTPUT
	,@passornot				NVARCHAR(1)		OUTPUT
	,@msg					NVARCHAR(200)	OUTPUT
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @pick_seq NVARCHAR(30)
		BEGIN TRY
			BEGIN TRANSACTION

			--Cancel the assgined information
			UPDATE tbl_allocation
			SET status ='U'
				,user_assign = NULL
			WHERE status ='A'
			AND wh_id = @wh_id
			AND user_assign = @user_id

			UPDATE dbo.tbl_pick_list
			SET status ='U'
			,user_assign = NULL
			WHERE status ='A'
			AND wh_id = @wh_id
			AND user_assign = @user_id

			COMMIT TRANSACTION
		END TRY

		BEGIN CATCH
			ROLLBACK
			SET @msg = ERROR_MESSAGE()
			SET @passornot = 1
			RETURN
		END CATCH

		
		--Get pick seq
		SELECT @pick_seq = pick_seq
			FROM t_zone_loca WITH(NOLOCK)
			WHERE wh_id = @wh_id
			AND location_id = @start_loc
			and zone = @zone

		SELECT TOP 1   @pick_loc = allo.location_id
					  ,@pick_item_number = allo.item_number
					  ,@pick_lot_number = allo.lot_number
					  ,@pick_sto_atrribute_id = allo.stored_attribute_id
					  ,@pick_hu_id = allo.hu_id
					  ,@pick_qty = sum(allo.allocated_qty - isnull(picked_qty,0))
					  ,@pick_expiration_date = allo.expiration_date
					  ,@damage_flag = allo.damage_flag
				FROM tbl_allocation allo with(nolock)
					INNER JOIN t_location loc with(nolock) on allo.wh_id = loc.wh_id and allo.location_id = loc.location_id
				WHERE allo.wh_id = @wh_id
				and (allo.status = 'U' OR (allo.status = 'A' and user_assign =@user_id))
				AND allo.zone = @zone
				AND allo.picking_flow >= @pick_seq
				and isnull(allo.ref_number ,'') <> ''
				AND allo.allo_type = 'R'
				AND loc.status not in ('H','I')
				AND allo.allocated_qty > isnull(allo.picked_qty,0)
				AND not exists ( select 1 from tbl_allocation a with(nolock)
								where a.wh_id = allo.wh_id
								 and a.location_id = allo.location_id
								 and a.[status] = 'A'
								 and a.user_assign <> @user_id)
				GROUP by allo.picking_flow,allo.location_id,allo.hu_id,allo.item_number,allo.lot_number,allo.expiration_date,allo.stored_attribute_id,allo.damage_flag
				ORDER BY allo.picking_flow,allo.location_id,allo.hu_id,allo.item_number,allo.lot_number,allo.expiration_date,allo.stored_attribute_id,allo.damage_flag

		IF @@ROWCOUNT = 0
			BEGIN
				SELECT TOP 1   @pick_loc = allo.location_id
					  ,@pick_item_number = allo.item_number
					  ,@pick_lot_number = allo.lot_number
					  ,@pick_sto_atrribute_id = allo.stored_attribute_id
					  ,@pick_hu_id = allo.hu_id
					  ,@pick_qty = sum(allo.allocated_qty - isnull(picked_qty,0))
					  ,@pick_expiration_date = allo.expiration_date
					  ,@damage_flag = allo.damage_flag
				FROM tbl_allocation allo with(nolock)
					INNER JOIN t_location loc with(nolock) on allo.wh_id = loc.wh_id and allo.location_id = loc.location_id
				WHERE allo.wh_id = @wh_id
				and (allo.status = 'U' OR (allo.status = 'A' and user_assign =@user_id))
				and isnull(allo.ref_number ,'') <> ''
				AND allo.allo_type = 'R'
				AND allo.zone = @zone
				AND loc.status not in ('H','I')
				AND allo.allocated_qty > isnull(allo.picked_qty,0)
				--The one loc can be allocated by one user
				AND not exists ( select 1 from tbl_allocation a with(nolock)
						where a.wh_id = allo.wh_id
							and a.location_id = allo.location_id
							and a.[status] = 'A'
							and a.user_assign <> @user_id)
				GROUP by allo.picking_flow,allo.location_id,allo.hu_id,allo.item_number,allo.lot_number,allo.expiration_date,allo.stored_attribute_id,allo.damage_flag
				ORDER BY allo.picking_flow,allo.location_id,allo.hu_id,allo.item_number,allo.lot_number,allo.expiration_date,allo.stored_attribute_id,allo.damage_flag
			END
		
		
		IF ISNULL(@pick_loc,'') <>''
			BEGIN TRY
				BEGIN TRANSACTION
				UPDATE tbl_allocation
				SET user_assign =@user_id
					,status ='A'
				WHERE wh_id = @wh_id
				and status = 'U'
				AND (hu_id = @pick_hu_id OR ISNULL(hu_id,'') = ISNULL(@pick_hu_id,''))
				--AND ref_number = @ref_number
				AND allo_type = 'R'
				AND location_id = @pick_loc
				AND item_number = @pick_item_number

				UPDATE dbo.tbl_pick_list
				SET user_assign = @user_id
					,status = 'A'
				WHERE wh_id = @wh_id
				AND status = 'U'
				AND (hu_id = @pick_hu_id OR ISNULL(hu_id,'') = ISNULL(@pick_hu_id,''))
				--AND ref_number = @ref_number
				AND type = 'R'
				AND location_id = @pick_loc
				AND item_number = @pick_item_number
				COMMIT TRANSACTION
			END TRY

			BEGIN CATCH
				ROLLBACK
				SET @msg = ERROR_MESSAGE()
				SET @passornot = 1
				RETURN
			END CATCH
-----------------------------------------------------------------------------------

		if not exists (select 1 from tbl_allocation
						where wh_id = @wh_id
						and user_assign =@user_id
						and status ='A') and isnull(@pick_loc,'') <> '' 
		begin
			SET @passornot = 1
			SET @msg = 'Miss assign task, pls try it again'
		end
		else
		begin
			SET @passornot = 0
			SET @msg = ''
		end

        RETURN

    END TRY

    BEGIN CATCH
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END
