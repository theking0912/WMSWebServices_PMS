
CREATE PROCEDURE [dbo].[usp_get_next_value]
@in_vchType           NVARCHAR(20),
@out_nUID             NVARCHAR(10) OUTPUT,
@out_nErrorNumber     integer OUTPUT,
@out_vchLogMsg        NVARCHAR(250) OUTPUT

AS

DECLARE 
	@v_nLogLevel			tinyint,
    @v_vchParam1          NVARCHAR(100),
    @v_vchSqlErrorNumber  NVARCHAR(50),

    @c_nModuleNumber      int,
    @c_nFileNumber        int,
    @v_nRaiseErrorNumber  int,

	@v_fMax				float,
    @v_nCount             int,
    @v_nReturn            int,

	@e_GenSqlError	int,
	@e_CtlError		int,
    @e_SprocError     int,

    @v_TranCount         int

    SET NOCOUNT ON

    -- Set constant values.
    SET @c_nModuleNumber = 60 -- Base
    SET @c_nFileNumber = 1 

    SET @e_GenSqlError = 1
    SET @e_CtlError = 2
    SET @e_SprocError = 3

    SET @v_TranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
  	IF @v_nReturn <> 0 -- zero is success value
    BEGIN
        SET @out_nErrorNumber = @e_SprocError
        GOTO ErrorHandler
    END

    --Lock the table until we get our unique id.
    -- @v_TranCount WILL REMAIN 0 EVEN WHEN THE TRANSACTION IS STARTED, IT CAN THEN BE CHECKED WHEN IT COMES TIME TO
    -- COMMIT OR ROLLBACK WHETHER THE TRANSACTION WAS CREATED HERE IN THE STORED PROCEDURE
    IF @v_TranCount = 0 

    BEGIN TRANSACTION
    GetNext:
    -- Update the next_value.
    UPDATE t_control
    SET next_value = next_value + 1
    WHERE control_type = @in_vchType

    -- If the record does not exist, create it and start with 1.
    IF @@ROWCOUNT = 0
    BEGIN
        IF @in_vchType = 'UID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'Unique Indentifier', 1, 'SHOW_VA', '0', 10000000)
        ELSE IF @in_vchType = 'SHIP_ID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'PSFT Ship ID', 1, 'SHOW_VA', '0', 10000000)
        ELSE IF @in_vchType = 'HU_ID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'Handling Unit ID', 10000001, 'SHOW_VA', '0', 100000000)
        ELSE IF @in_vchType = 'WORK_Q_ID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'Work Queue ID', 1, 'SHOW_VA', '0', 10000000)
    END

    -- Grab the Unique Identifier to use and the max UID.
    SELECT @out_nUID = next_value, @v_fMax = f1
    FROM t_control 
    WHERE control_type = @in_vchType

    -- Be sure a row was updated/found.
    IF @@ROWCOUNT = 0 OR @@ERROR <> 0
    BEGIN
        IF @@ERROR <> 0
            SET @out_nErrorNumber = @e_GenSqlError
        ELSE
            SET @out_nErrorNumber = @e_CtlError
        GOTO ErrorHandler
    END

    -- Verify the unique id is not already used.
    IF @in_vchType = 'HU_ID'
    BEGIN
        SELECT @v_nCount = COUNT (*)
        FROM t_hu_master
        WHERE hu_id = @out_nUID

            IF @v_nCount > 0  -- Unique Id already being used
                GOTO GetNext
    END
    ELSE IF @in_vchType = 'WORK_Q_ID'
    BEGIN
        SELECT @v_nCount = COUNT (*)
        FROM t_work_q
        WHERE work_q_id = @out_nUID

            IF @v_nCount > 0  -- Unique Id already being used
                GOTO GetNext
    END


    IF @out_nUID = @v_fMax
        -- The max was reached, start over for next time an ID is needed.  
	BEGIN
		IF @in_vchType = 'HU_ID'
		BEGIN
			UPDATE t_control
			SET next_value = 10000001
			WHERE control_type = @in_vchType
		END
		ELSE
		BEGIN
			UPDATE t_control
			SET next_value = 0
			WHERE control_type = @in_vchType
		END
	END      
		
    -- Release the lock now.
    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_TranCount = 0
        COMMIT TRANSACTION
  
    GOTO ExitLabel 


-- Error handling
ErrorHandler:
    IF @out_nErrorNumber = @e_GenSqlError -- 1
    BEGIN
        SET @out_vchLogMsg = 'An unknown SQL Server Error has occured while '+
        'attempting to access t_control.'
        EXEC usp_log_message @c_nModuleNumber, @c_nFileNumber, @out_nErrorNumber, 1,
        @out_vchLogMsg, 1
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- SQL Error
    END

    IF @out_nErrorNumber = @e_CtlError -- 2
    BEGIN
        SET @out_vchLogMsg = ': There is no ' + @in_vchType + ' record in the t_control table.'
        EXEC usp_log_message @c_nModuleNumber, @c_nFileNumber, @out_nErrorNumber, 1,
        @out_vchLogMsg, 1
        SET @v_vchParam1 = 't_control'  
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed
    END

    ELSE IF @out_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @out_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        CONVERT(varchar(30),@v_nReturn) + '.'
       -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @out_nErrorNumber, 1, @out_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_nReturn
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

    -- Raise the error with error #, severity, state, paramater
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)        

    
    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_TranCount = 0
        ROLLBACK TRANSACTION


ExitLabel:

RETURN
