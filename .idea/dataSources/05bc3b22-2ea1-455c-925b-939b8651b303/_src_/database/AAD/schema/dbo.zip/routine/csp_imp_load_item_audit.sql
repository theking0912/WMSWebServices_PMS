

-- =============================================
-- Author:		Peter
-- Create date: 2016-01-07
-- Description:	
-- =============================================

CREATE PROCEDURE [dbo].[csp_imp_load_item_audit]
  @DataID varchar(100),
  @process_status varchar(20)
AS
BEGIN
declare @data_idkey BIGINT 
declare @ZPOSITION nvarchar(30) 
declare @ITEMNUMBER nvarchar (30) 
declare @AUDIT_REQUIRED nvarchar (30) 
declare @REMARK nvarchar (30) 
declare @wh_id nvarchar(10)
declare @client_code nvarchar(100)
declare @id int 

BEGIN TRY
	IF  (isnull(object_id('tempdb..#returnresult'),0) =0 ) 
	begin
		create table #returnresult(outint1 int,outstr1 nvarchar(64),outstr2 nvarchar(256))
	END
		
	select top 1 @wh_id= wh_id , @data_idkey=data_idkey  
	from tbl_inf_imp_master WITH(NOLOCK)  where data_id=@DataID and interface_type='SRMWMSInterface_ItemAudit'
	
	update tbl_inf_imp_item_audit  set DATA_IDKEY=@data_idkey  where DATA_ID=@DataID and  isnull(DATA_IDKEY,0)=0
		 
    while exists(select top 1  DATA_ID from  tbl_inf_imp_item_audit  WITH(NOLOCK)  where DATA_ID=@DataID and PROCESS_STATUS=@process_status)
	begin
		select top 1  @id=ID,
					@ZPOSITION=ZPOSITION,					
					@ITEMNUMBER=ITEMNUMBER,
					@AUDIT_REQUIRED=AUDIT_REQUIRED,
					@REMARK=REMARK 									
		from  tbl_inf_imp_item_audit WITH(nolock) 
		where DATA_ID=@DataID and PROCESS_STATUS=@process_status
		  
		set @wh_id=(rtrim(left(@wh_id,3))+rtrim (@ZPOSITION))

		BEGIN transaction

	    IF EXISTS(select top 1 item_number FROM t_item_master with(nolock) WHERE wh_id=@wh_id and display_item_number=@ITEMNUMBER)
		begin
			update t_item_master set audit_required=(case when @AUDIT_REQUIRED='Y' or @AUDIT_REQUIRED='1' then 'Y' else 'N' end)
			where wh_id=@wh_id and display_item_number=@ITEMNUMBER

			update tbl_inf_imp_item_audit set PROCESS_STATUS='YES',SUCCESS_STATUS='YES'
			where ID=@id
		end
		else
		begin
			update tbl_inf_imp_item_audit
			set  SUCCESS_STATUS='NO', PROCESS_STATUS='YES',
					PROCESS_MSG=N'未找到对应物料编码'+@ITEMNUMBER
			where ID=@id
		end
	end

	declare  @target_rows int ,@retall INT
    
	select  @target_rows=COUNT(DATA_ID)  from tbl_inf_imp_item_audit WITH(nolock)
	where DATA_ID=@DataID and isnull(SUCCESS_STATUS,'NO')='YES'

	UPDATE tbl_inf_imp_master
		SET  target_rows=@target_rows,
			  process_status=case WHEN source_rows=@target_rows then 'YES' else 'NO' END,
			  process_msg=case WHEN source_rows=@target_rows THEN N'商品质检标记信息导入处理成功'
							   WHEN @target_rows>0 THEN N'商品质检标记信息部分处理成功,请检查错误日志' 
							   ELSE N'商品质检标记信息全部未处理，请检查错误日志'  end
		where  data_id=@DataID
 
	delete from #returnresult

	insert into #returnresult 
	select top 1  case when process_status='YES' then 101  else -101 end as outint1,
				cast(target_rows as varchar) as outstr1,
				process_msg as outstr2
	from tbl_inf_imp_master WITH(NOLOCK) 
	where data_id=@DataID

	IF (@@TRANCOUNT>0) 
		COMMIT  transaction

END TRY
BEGIN CATCH  -- Outer CATCH
   	if (@@TRANCOUNT>0) ROLLBACK TRANSACTION
	DECLARE @error NVARCHAR(100)
	SET @error='执行异常:'+substring(ERROR_MESSAGE(),1,90)
	insert into ILogs(DataId,InterfaceType,LogId,LogMsg,spid,LockTable)  
     
	SELECT @DataID,'SRMWMSInterface_ItemAudit',ERROR_NUMBER(),ERROR_MESSAGE(),
				request_session_id,OBJECT_NAME(resource_associated_entity_id)  
	FROM sys.dm_tran_locks	
	WHERE resource_type='OBJECT'

	declare  @succes_rows int
	select   @succes_rows=COUNT(DATA_ID)  from tbl_inf_imp_item_audit  WITH(nolock)
	where DATA_ID=@DataID and isnull(SUCCESS_STATUS,'NO')='YES'
 
	Update  tbl_inf_imp_master  
	set		process_msg=@error,
			target_rows=@succes_rows,
			process_status='NO'  
	where data_id=@DataID   and  interface_type='SRMWMSInterface_ItemAudit'

	delete from  #returnresult
	insert into #returnresult values(-101,'0',@error)
END CATCH   
   
END


GRANT EXEC ON csp_imp_load_item_audit TO AAD_USER,WA_USER