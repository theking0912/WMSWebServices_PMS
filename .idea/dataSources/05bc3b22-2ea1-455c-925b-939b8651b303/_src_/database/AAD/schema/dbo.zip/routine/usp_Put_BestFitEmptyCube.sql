
CREATE PROCEDURE usp_Put_BestFitEmptyCube
    @in_vchItem         NVARCHAR(30),
    @in_vchLot          NVARCHAR(30),
    @in_nQty            INT,
    @in_dtFIFODate      DATETIME,
    @in_vchForkZone     NVARCHAR(10),
    @in_vchWhID         NVARCHAR(10),
	@in_nStoAttID		BIGINT,
    @out_vchLoc         NVARCHAR(50) = NULL OUTPUT

AS
DECLARE @v_fNestedVolume FLOAT,
        @v_fUnitVolume   FLOAT

    -- Retreive the nested_volume, and unit_volume from t_item_uom.
    -- Only a single t_item_uom record may be used.  This is determined by taking the
    -- greatest conversion factor less than or equal to the quantity passed in.
    SELECT TOP 1 @v_fNestedVolume = itu.nested_volume,
                 @v_fUnitVolume = itu.unit_volume
    FROM t_item_uom itu
    WHERE itu.conversion_factor <= @in_nQty
        AND itu.item_number = @in_vchItem
        AND itu.wh_id = @in_vchWhID
    ORDER BY itu.conversion_factor DESC
    
    SELECT TOP 1 @out_vchLoc = loc.location_id
    FROM t_location loc
        INNER JOIN t_zone_loca zlc
            ON loc.location_id = zlc.location_id
            AND loc.wh_id = zlc.wh_id
        INNER JOIN t_pick_area pka
            ON pka.pick_area = loc.pick_area
            AND (pka.pick_area <> N'LABEL' OR (pka.pick_area = N'LABEL' AND @in_nStoAttID IS NULL AND @in_vchLot IS NULL) )
            AND pka.wh_id = loc.wh_id
            AND (pka.pick_area_type = 'R' OR (pka.pick_area_type = 'V' and @in_nStoAttID IS NULL))
    WHERE loc.status = 'E'
        AND (loc.type = 'M' 
            OR (loc.type = 'I' AND loc.capacity_volume = 0)
            OR (loc.type = 'I' AND @v_fUnitVolume = 0 AND @v_fNestedVolume = 0)
            OR (loc.type = 'I' 
                AND (loc.capacity_volume > 0 
                        AND loc.capacity_volume >= (@v_fUnitVolume + 
                                     CASE 
                                     WHEN @v_fNestedVolume = 0 THEN 
                                        @v_fUnitVolume 
                                     ELSE 
                                        @v_fNestedVolume 
                                     END * (@in_nQty - 1)))))
        AND loc.wh_id = @in_vchWhID
        AND zlc.zone = @in_vchForkZone
    -- capacity_volume is used here to allow fulfillment of a bulk like location 
    -- first then picking_flow.
    ORDER BY loc.type, loc.user_count, loc.capacity_volume, loc.picking_flow, loc.location_id 

ExitLabel:
  RETURN
