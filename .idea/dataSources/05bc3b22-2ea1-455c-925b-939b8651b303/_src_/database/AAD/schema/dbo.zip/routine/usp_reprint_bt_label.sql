
CREATE PROCEDURE usp_reprint_bt_label

    @in_ClientCode         AS NVARCHAR(20) = NULL,
    @in_DisplayOrderNumber AS NVARCHAR(20) = NULL,
    @in_OrderNumber     AS NVARCHAR(20) = NULL,
    @in_LoadNumber	AS NVARCHAR(20) = NULL,
    @in_WaveNumber	AS NVARCHAR(20) = NULL,
    @in_ItemNumber	AS NVARCHAR(30) = NULL, -- specific item, not supported
    @in_LotNumber	AS NVARCHAR(15) = NULL, -- specific lot, not supported
    @in_PickArea	AS NVARCHAR(10) = 'ALL',
    @in_WHID		AS NVARCHAR(10) = '01',
    @in_Batch_id	AS NVARCHAR(20) = NULL,
    @in_Label_id	AS NVARCHAR(12) = NULL,
    @in_ww_UserName	AS NVARCHAR(30) = '',
    @in_Call	        AS INT  = 1,               -- (1) Indicates the stored procedure is being called from webwise, (0) from other stored procedure
    @in_nResultsFlag    AS INT		        -- 1 if was not  printing the label;  0 if was printing the label

AS


 IF (@in_Call = 3)  -- If @inCall = 3 the stored procedure is being called from page 'Reprinted Labels' so the only task to do is return the previously printed labels
   BEGIN
	GOTO BeforeErrorHandler
   END


 DECLARE
       
    @str_SelectClause    NVARCHAR(1000),
    @str_WhereClause     NVARCHAR(1000),
    @str_UpdateClause    NVARCHAR(1000),
    @n_Count             INT,

    --generated file variables.
    @v_path     NVARCHAR (50),
    @v_folder   NVARCHAR (50),
    @v_str        NVARCHAR (1000),

    -- Error handling and logging variables.
    @c_nModuleNumber       INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber             INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum          INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg             NVARCHAR(500),
    @v_vchLogMsg              NVARCHAR(500),
    @v_nErrorNumber           INT,
    @v_nRowCount              INT,
    @v_nReturn                    INT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError             INT,
    @e_SprocError               INT,
    @e_InsITMFailed            INT,              
       
    -- Local Variables
    @v_vchItem                 NVARCHAR(30),
    @Number_of_labels_to_be_reprinted INT, -- els_in_ ##t_batch_label  INT
    @Number_of_labels_were_reprinted_before INT,
    @Number_of_repeated_labels INT
    
    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 1        -- This # must be unique per object.
    
    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_InsITMFailed = 3

    SET @v_nRowCount = 0
    SET @v_nReturn = 1
    
    SET NOCOUNT ON

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END
       
    -- Body of procedure.
    CREATE TABLE ##t_order_temp
    (
       order_number            NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       display_order_number    NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       client_code             NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       wh_id                   NVARCHAR(10)   COLLATE DATABASE_DEFAULT NOT NULL
    ) 

        INSERT INTO ##t_order_temp
        SELECT order_number,
               display_order_number,
               client_code,
               wh_id
          FROM t_order
         WHERE display_order_number LIKE @in_DisplayOrderNumber
           AND client_code          LIKE @in_ClientCode
           AND display_order_number LIKE @in_OrderNumber
           AND wh_id                = @in_WHID


     --if existing temp. table with the same name of the one we will create the table is dropped
    IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[tempdb].['+ USER  +'].[##t_batch_label]'))
        BEGIN
               DROP TABLE ##t_batch_label
        END

    --Checks for existing records (labels) in t_label matching the entered parameters to be reprinted
    SELECT @n_Count = COUNT(*)
      FROM t_label lbl, t_pick_detail pkd,t_printer prn, t_pick_area pka, 
           ##t_order_temp orm
    WHERE lbl.label_status <> 'NOT PRINTED' 
          --AND pkd.status = 'RELEASED'
          AND prn.status = 'A'
          AND prn.pick_area = pkd.pick_area  
          AND pka.pick_area = pkd.pick_area
          AND lbl.pick_id = pkd.pick_id
          AND pkd.order_number = orm.order_number
          AND pkd.wh_id        = orm.wh_id
          AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))

          AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
          AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
          AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
          AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                OR (@in_PickArea = 'ALL') OR (@in_LotNumber = ''))
          AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
          AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
          AND pkd.wh_id = @in_WHID 


  -- If no results were returned (@n_Count < 1) for the passed parameters the procedure jumps to ExitLabel 
  --as no rows will be affected by the rest of the statements in the body of the procedure..
   IF @n_Count < 1  
        BEGIN               
     	   
           DELETE t_labels_being_printed
       -- As there are not existing labels matching the passed parameters to be reprinted we jump to the end of sproc.
           GOTO BeforeErrorHandler 
        END


--Temp. table is created to be used when flat files are generated

    CREATE TABLE ##t_batch_label(
       batch 	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL, 	
       sequence        INT 	      NOT NULL,
       label_name      NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,
       field_01	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Header: label_id; Label: batch_id
       field_02	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Header: pick_area; Label: pkd.item_number
       field_03	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.lot_number
       field_04	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.serial_number
       field_05	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.planned_quantity
       field_06	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.uom
       field_07	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.order_number       
       field_08	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: pkd.pick_location       
       field_09	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Label: door_location       
       field_10	       NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,--Header and Label: quantity label will be printed
       path            NVARCHAR(50)   COLLATE DATABASE_DEFAULT NULL,
       separator       NCHAR(1)       COLLATE DATABASE_DEFAULT NULL
       ) 

       SET NOCOUNT OFF

	-- Print a trace level log message.
        IF @v_nLogLevel >= 4        
        BEGIN
            PRINT '##t_batch_label table created'
        END 


           
       --Inserts in temp. table the records containing information about the labels to be reprinted
       -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        INSERT INTO ##t_batch_label (batch,sequence,label_name,field_01,field_02,field_03,
                                                            field_04,field_05,field_06,field_07,field_08,field_09,field_10,path,separator)
        SELECT  lbl.batch_id,lbl.print_sequence,prn.name_label,lbl.label_id,itm.display_item_number,
                        pkd.lot_number,pkd.serial_number,pkd.planned_quantity,pkd.uom,
                        orm.display_order_number,pkd.pick_location,ldm.door_loc,1,prn.folder,prn.separator
        FROM t_label lbl
             JOIN t_pick_detail pkd 
                ON lbl.pick_id = pkd.pick_id
             JOIN t_printer prn
                ON prn.pick_area = pkd.pick_area 
             JOIN ##t_order_temp orm
                ON pkd.order_number = orm.order_number
               AND pkd.wh_id = orm.wh_id
             JOIN t_item_master itm
                ON pkd.item_number = itm.item_number
               AND pkd.wh_id = itm.wh_id
             LEFT OUTER JOIN t_load_master ldm
                ON pkd.load_id = ldm.load_id
        WHERE  lbl.label_status <> 'NOT PRINTED'
                       --AND pkd.status = 'RELEASED'
                       AND prn.status = 'A'
                       AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                                  OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                       AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                                OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                       AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                                 OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                       AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                                 OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                       AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                                 OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                       AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                                 OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
                       AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                                 OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                       AND pkd.wh_id = @in_WHID
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
        
      SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 

       -- Checks for any errors. If some, error number will be <> 0.
       -- Check for Number of rows affected.
       IF @v_nErrorNumber <> 0 OR @v_nRowCount = 0
           BEGIN
              SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	                                              'the exact nature of the error.'
       	      SET @v_nLogErrorNum = @e_GenSqlError
                   GOTO ErrorHandler
           END

    
        -- Print a trace level log message.
        IF @v_nLogLevel >= 4        
        BEGIN
            PRINT 'Labels added to temp table:' + CAST(@v_nRowCount AS NVARCHAR(10))
        END 




       -- Checks if the procedure call is being produced by the "Back" button on the web browser or the "Refresh. Data" button 
       -- If that's the case labels are not reprinted again
      IF (( @in_Call = 1 ) OR ( @in_Call = 3 ))
         BEGIN
		--return the labels in ##t_batch_label ready to be reprinted again.
		SELECT @Number_of_labels_to_be_reprinted = COUNT(field_01)
		FROM     ##t_batch_label
  		WHERE field_07 IS NOT NULL                

		SELECT @Number_of_labels_were_reprinted_before = COUNT(t_labels_being_printed.label_id)
		FROM t_labels_being_printed
		WHERE w_user_name = @in_ww_UserName
	
          	   
		SELECT  @Number_of_repeated_labels = COUNT(t_labels_being_printed.label_id)
		FROM  ##t_batch_label ,  t_labels_being_printed 
		WHERE (##t_batch_label.field_07 IS NOT NULL)  AND 
			  t_labels_being_printed.w_user_name = @in_ww_UserName AND
			   ##t_batch_label.field_01 = t_labels_being_printed.label_id  AND
			    ((DATEDIFF(MINUTE, t_labels_being_printed.date_time, GETDATE())) < 5 )
		
		IF (@Number_of_labels_to_be_reprinted = @Number_of_labels_were_reprinted_before) AND (@Number_of_labels_to_be_reprinted = @Number_of_repeated_labels)
		  
		   BEGIN
			--set @Number_of_labels = 1000
			--select  count(*) as number_of_reprinted_labels from ##t_batch_label where 
			SELECT @Number_of_repeated_labels AS number_of_reprinted_labels
			--'Same group of labels'
			GOTO BeforeErrorHandler
		   END


 	END


        
        ----------------------------------------------------------------------------------------------------------
        --This cursor is declared to support to several pick area to print
        ----------------------------------------------------------------------------------------------------------
        DECLARE Path_Cursor CURSOR FOR
        SELECT DISTINCT path  FROM ##t_batch_label

        OPEN Path_Cursor
              FETCH NEXT FROM Path_Cursor
              INTO @v_path

             WHILE @@FETCH_STATUS = 0
                  BEGIN
                          --Generate file for  label  picking
                          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                           SET @v_folder = @v_path + REPLACE(convert(varchar(10),getdate(),102),'.','')+REPLACE(convert(varchar(13),getdate(),114),':','') + '.bch' 
                           SET @v_str = 'SELECT separator+field_01+separator,separator+field_02+separator,separator+field_03+separator,separator+field_04+separator,separator+field_05+separator,separator+field_06+separator,separator+field_07+separator,separator+field_08+separator,separator+field_09+separator,field_10 FROM  ##t_batch_label WHERE path = '''+ @v_path + ''' ORDER BY batch,sequence'
                           SET @v_str ='bcp "' + @v_str + '" queryout '
                           SET @v_str = @v_str + @v_folder
                          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                           -- I M P O R T A N T
                          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                          --Serve role of the user HJS who is in Security --> Logins (Console SQL SERVER) 
                          --must have checked the option Administrator System to be able to use stored procedure master.dbo.xp_cmdshell with the command bcp 
                          SET @v_str = @v_str + ' -c -t, -S' + CONVERT(char(20), SERVERPROPERTY('servername')) + ' -UHJS -PHJSPASS#1 -q'                 

                          EXEC master.dbo.xp_cmdshell @v_str, no_output
		          --EXEC @v_nReturn = usp_execute_xpcmd @v_str	
        
                          -- Check for any errors. If so, error number will not be equal to zero.
                          IF @v_nReturn <> 0
                          BEGIN
			      CLOSE Path_Cursor
                              DEALLOCATE Path_Cursor
                              SET @v_vchErrorMsg = 'SQL Stored Procedure error occured!  Check SQL Server System Log for ' + 
                                                      'the exact nature of the error.'
	                      SET @v_nLogErrorNum = @e_SprocError 
                              GOTO ErrorHandler
                          END
                          -- Print a trace level log message.
                          IF @v_nLogLevel >= 4        
                          BEGIN
                               PRINT 'BCH File Created with command: ' + @v_str
                          END 
                          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                          FETCH NEXT FROM Path_Cursor
                          INTO @v_path
                   END --END While
          CLOSE Path_Cursor
          DEALLOCATE Path_Cursor
          -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        -- Temporary table is dropped
        DROP TABLE ##t_batch_label

        --If the stored procedure is being called from WebWise the affected rows must be returned so can be shown in the WebWise page as confirmation to the user.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        IF @in_Call	 = 1 -- called from webwise
        BEGIN
             DELETE t_labels_being_printed 
	     WHERE w_user_name = @in_ww_UserName 
          	
	     INSERT INTO t_labels_being_printed
	     SELECT lbl.batch_id, lbl.label_id, pkd.order_number, pkd.wave_id, pkd.load_id, pkd.item_number, pkd.uom, pkd.planned_quantity, 
                                     'REPRINTED' AS label_status, pkd.wh_id, prn.printer_name,@in_ww_UserName, getdate()
                      FROM t_label lbl, t_pick_detail pkd,t_printer prn, t_pick_area pka, ##t_order_temp orm
                      WHERE lbl.label_status <> 'NOT PRINTED' 
                                     --AND pkd.status = 'RELEASED'
                                     AND prn.status = 'A'
                                     AND prn.pick_area = pkd.pick_area  
                                     AND pka.pick_area = pkd.pick_area
                                     AND lbl.pick_id = pkd.pick_id
                                     AND pkd.order_number = orm.order_number 
                                     AND pkd.wh_id = orm.wh_id
                                     AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                                                OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                                     AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                                                OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                                     AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                                                OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                                     AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                                                OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                                     AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                                                OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                                     AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                                                OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
                                     AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                                                OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                                     AND pkd.wh_id = @in_WHID 
                       ORDER BY lbl.batch_id, lbl.print_sequence ASC
        	          -- Check for any errors. If so, error number will not be equal to zero.
       	     IF @v_nErrorNumber <> 0
           	          BEGIN
                   		SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                                                                  'the exact nature of the error.'
                  		SET @v_nLogErrorNum = @e_GenSqlError
                  		GOTO ErrorHandler
         	         END   
		
             SELECT COUNT(*) AS number_of_reprinted_labels FROM  t_labels_being_printed WHERE w_user_name = @in_ww_UserName
        END    --IF @in_Call	 = 1 -- called from webwise

        --The status of the labels affected by the stored procedure is changed to 'REPRINTED'
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        UPDATE t_label 
        SET label_status = 'REPRINTED'
        WHERE pick_id IN (SELECT pkd.pick_id
                                         FROM t_pick_detail pkd, t_label lbl, t_printer prn, t_pick_area pka, ##t_order_temp orm
                                         WHERE prn.status = 'A'
                                                        AND lbl.label_status <> 'NOT PRINTED'
                                                        --AND pkd.status = 'RELEASED'
                                                        AND prn.status = 'A'
                                                        AND prn.pick_area = pkd.pick_area  
                                                        AND pka.pick_area = pkd.pick_area
                                                        AND lbl.pick_id = pkd.pick_id
                                                        AND pkd.order_number = orm.order_number 
                                                        AND pkd.wh_id = orm.wh_id
                                                        AND ((pkd.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL) 
                                                                   OR (@in_LoadNumber = 'ALL') OR (@in_LoadNumber = ''))
                                                        AND ((pkd.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL) 
                                                                   OR (@in_WaveNumber = 'ALL') OR (@in_WaveNumber = ''))
                                                        AND ((pkd.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL) 
                                                                   OR (@in_ItemNumber = 'ALL') OR (@in_ItemNumber = ''))
                                                        AND ((pkd.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL) 
                                                                   OR (@in_LotNumber = 'ALL') OR (@in_LotNumber = ''))
                                                        AND ((pkd.pick_area = @in_PickArea) OR (@in_PickArea is NULL) 
                                                                   OR (@in_PickArea = 'ALL') OR (@in_PickArea = ''))
                                                        AND ((lbl.batch_id = @in_Batch_id) OR (@in_Batch_id is NULL) 
                                                                   OR (@in_Batch_id = 'ALL') OR (@in_Batch_id = ''))
                                                        AND ((lbl.label_id = @in_Label_id) OR (@in_Label_id is NULL) 
                                                                   OR (@in_Label_id = 'ALL') OR (@in_Label_id = ''))
                                                        AND pkd.wh_id = @in_WHID) 
      -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
      -- Check for any errors. If so, error number will not be equal to zero.
      IF @v_nErrorNumber <> 0
      BEGIN
          SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                                                  'the exact nature of the error.'
          SET @v_nLogErrorNum = @e_GenSqlError
          GOTO ErrorHandler
     END
    
    IF @v_nRowCount > 0    
         SET @v_nReturn = 0   
    GOTO ExitLabel

BeforeErrorHandler:

   IF (@in_Call = 1)  and (@n_Count < 1)
      BEGIN 
	SELECT '0' AS number_of_reprinted_labels
      END


   IF @in_Call = 3 
       BEGIN 

	    SELECT 
           lbp.batch_id AS out_batch_id, lbp.label_id AS out_label_id, orm.client_code, orm.display_order_number, 
           lbp.order_number AS out_order_number, lbp.wave_id AS out_wave_id, lbp.load_id AS out_load_id, 
           itm.display_item_number, lbp.item_number AS out_item_number, lbp.uom AS out_uom, lbp.planned_qty AS out_planned_qty, 
           lbp.status_label AS out_status_label, lbp.wh_id AS out_wh_id, lbp.printer_name AS out_printer_name
		 FROM t_labels_being_printed lbp
        INNER JOIN t_order orm
           ON lbp.order_number = orm.order_number
          AND lbp.wh_id = orm.wh_id
        INNER JOIN t_item_master itm
           ON lbp.item_number = itm.item_number
          AND lbp.wh_id = itm.wh_id
		 WHERE w_user_name = @in_ww_UserName
       END  
   
    GOTO ExitLabel

ErrorHandler:

        
   IF @v_nLogErrorNum = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error   
	SELECT @v_vchErrorMsg = description 
	  FROM master.dbo.sysmessages 
	 WHERE error = @v_nErrorNumber

        SET @v_vchLogMsg = 'An SQL Server Error has occurred with a return code of ' +
		ISNULL(CONVERT(VARCHAR(30),@v_nErrorNumber),'(NULL)') + '. Error Message: ' + 
		ISNULL(CONVERT(varchar(400),@v_vchErrorMsg),'(NULL)') + '.'
	EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, @v_nLogLevel, @v_vchErrorMsg, 1
        --Raiserror
    END

   IF @v_nLogErrorNum = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error
        SET @v_vchLogMsg = /*'An error occured in a stored procedure with a return code of ' +
                ISNULL(CONVERT(VARCHAR(30),@v_nErrorNumber),'(NULL)') + */'Error Message: ' +
                ISNULL(CONVERT(varchar(400),@v_vchErrorMsg),'(NULL)') 
       -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, @v_nLogLevel, @v_vchErrorMsg, 1
        --Raiserror
    END


    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = @v_vchLogMsg + ' ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        -- + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    

    /*-- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)   */ 


ExitLabel:
     IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[tempdb].['+ USER  +'].[##t_order_temp]'))
        BEGIN
               DROP TABLE ##t_order_temp
        END

	 DELETE t_labels_being_printed 
	 WHERE ((DATEDIFF(MINUTE, t_labels_being_printed.date_time, GETDATE())) > 60)
    -- Always leave the stored procedure from here.
    RETURN @v_nReturn

