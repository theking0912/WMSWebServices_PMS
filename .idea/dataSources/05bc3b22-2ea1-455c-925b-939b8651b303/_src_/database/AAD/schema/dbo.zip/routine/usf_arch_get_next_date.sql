
CREATE FUNCTION usf_arch_get_next_date 
(
	@p_schedid   	INTEGER, 
	@p_date  		DATETIME)
RETURNS DATETIME
AS

BEGIN
	DECLARE
		@vNextDate		DATETIME,
		@vToday			DATETIME,
		@vMonths		INTEGER
   
	SET @vToday =@p_date
	SET @vMonths = 0
--Will look for twelve more months if no date is found
--Will exit loop when @vNextDate is not null
	WHILE @vMonths <= 12
	BEGIN
		SELECT top 1
			@vNextDate = ev_date
		FROM
		(
		        SELECT top 100
		        	weekday_id, 
		            start_time,
		            sch_week, 
		            CAST((dbo.usf_arch_next_day(CAST(FLOOR(CAST(@vToday AS DECIMAL(12, 5))) - 
		               				(DAY(@vToday) - 1) AS DATETIME)-1, weekday_id
		                      )+ 7*(sch_week -1))+' '+start_time as datetime) ev_date	
		        FROM 
		           	v_arch_ord_schedule
		        WHERE 
		        	do_value = 'Y' 
		            AND schedule_id = @p_schedid 
				ORDER BY ev_date ASC
		) dates
		WHERE
			ev_date > @vToday
			AND ev_date < DATEADD(hh,-24,DATEADD(mm, DATEDIFF(m,0,@vToday  )+1, 0)) +1
		IF @@ROWCOUNT <= 0
		BEGIN
			set @vToday = (DATEADD(hh,-24,DATEADD(mm, DATEDIFF(m,0,@vToday  )+1, 0)) +1)
		 	--set @vToday = DATEADD(mm,1,@vToday) 
			SELECT 
				top 1
				@vNextDate = ev_date
			FROM
			(
			        SELECT top 100
			            weekday_id, 
			            start_time,
			            sch_week, 
			            CAST((dbo.usf_arch_next_day(CAST(FLOOR(CAST(@vToday AS DECIMAL(12, 5))) - 
			               				(DAY(@vToday) - 1) AS DATETIME)-1, weekday_id
			                      )+ 7*(sch_week -1))+' '+start_time as DATETIME) ev_date
			        FROM 
			        	v_arch_ord_schedule
			        WHERE 
			            do_value = 'Y' 
			            AND schedule_id = @p_schedid 
					ORDER BY ev_date ASC
			) dates
			WHERE
				 ev_date >= @vToday
				 and ev_date < DATEADD(hh,-24,DATEADD(mm, DATEDIFF(m,0,@vToday  )+1, 0)) +1
		END
		IF @@ROWCOUNT <= 0
			SET @vMonths = @vMonths +1	
    if @vNextDate is not null break
	END
    RETURN (@vNextDate);
    
END   

