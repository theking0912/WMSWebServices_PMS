
CREATE TRIGGER dbo.tr_wave_master_update ON t_wave_master FOR UPDATE AS
-- Fire the trigger only the po status changes
IF UPDATE(status)
BEGIN
DECLARE
    -- Used for logging to the t_log table.
    @c_nModuleNumber            INT,
    @c_nFileNumber              INT,
    @v_nLogErrorNum             INT, 
    @v_nLogLevel                INT,
    @v_vchErrorMsg              VARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,

    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_SprocError               INT,              
      
    -- Local Variables
	@vch_OldStatusID			NVARCHAR(10),
	@vch_NewStatusID			NVARCHAR(10),
    @vch_WaveID					NVARCHAR(20)

    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 17        -- This # must be unique per object.

    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2

	SET NOCOUNT ON
   
    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END

	-- Get the internal po id and it's old and new status
	SELECT
		@vch_WaveID = wave_id,
		@vch_OldStatusID = status
	FROM
		deleted

	SELECT
		@vch_NewStatusID = status
	FROM
		inserted

	-- We only do something if the new status is cancelled and the old status was not shipped or partial shipped
	IF @vch_NewStatusID = N'R'
	BEGIN
	    UPDATE t_wave_master
		SET released_date = GETDATE()
        WHERE wave_id = @vch_WaveID		
    END

    IF @vch_NewStatusID = N'H'
	BEGIN
	    UPDATE t_wave_master
		SET released_date = NULL
        WHERE wave_id = @vch_WaveID		
    END

    GOTO ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
    EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    

ExitLabel:
END -- Main
