




-- =======================================    
-- Author: Bruce.yuan   
-- Create Date: 20160608
-- Description: Short Pick Upd allocation qty
--  

-- =======================================    
    
create PROCEDURE [dbo].[csp_OrderPick_Allocate_Short_Pick_Total]    
     @wh_id					NVARCHAR(10)  
    ,@pick_key       		Nvarchar(30)
	,@pk_location           Nvarchar(30)  
	,@hu_id                 NVARCHAR(30)
	,@item_number			Nvarchar(30)
	,@lot_number			Nvarchar(30)
	,@stored_attribute_id	Nvarchar(30)
	,@total_qty		        float	
	,@fork_id               nvarchar(30)	
	,@put_hu_id				nvarchar(30)	
	,@user_id				nvarchar(30)
	,@tran_type				nvarchar(20)
	,@tran_description		nvarchar(50)
	,@damage_flag			NVARCHAR(1)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @pick_id		    bigint
		DECLARE @allocated_qty	    float
		DECLARE @picked_qty		    float
		DECLARE @seq_id			    bigint
		DECLARE @location_id        nvarchar(30)
		DECLARE @count              float
		DECLARE @remove_qty		    float
		DECLARE @qty                float
		DECLARE @FifoDate           DATETIME
		DECLARE @expiration_date    DATETIME
		DECLARE	@out_vchCode        uddt_output_code
		DECLARE @out_vchMsg         uddt_output_msg
		DECLARE @type			    NVARCHAR(2)
		DECLARE @zone_group		    NVARCHAR(10)
		DECLARE @zone			    NVARCHAR(30)
		DECLARE @shipping_label     NVARCHAR(30)
		DECLARE @order_number       NVARCHAR(30)





		SET @remove_qty = @total_qty * -1	
		SET @qty = @total_qty
		set @type = 'SO'

		SELECT @shipping_label = shipping_label
		FROM tbl_pick_list
		WHERE wh_id = @wh_id
		and (shipping_label = @pick_key or CONVERT(NVARCHAR(30),seq_id) = @pick_key )

		select @FifoDate=fifo_date ,@expiration_date=expiration_date 
		from t_stored_item  
		where wh_id=@wh_id and location_id =@pk_location 
		and item_number =@item_number
        and isnull(lot_number,'')=isnull(@lot_number,'')
	    and isnull(hu_id,'')=isnull(@hu_id,'')  


		BEGIN TRANSACTION
		--Get allocation information
		WHILE(@qty > 0)
		BEGIN
			SELECT top 1 @pick_id = allo.pick_id
					,@allocated_qty = allo.allocated_qty - allo.picked_qty
					,@seq_id = allo.seq_id
					,@location_id = allo.location_id
					,@order_number = allo.order_number
			FROM tbl_allocation allo,tbl_pick_list plt
			WHERE allo.wh_id = plt.wh_id
			and allo.seq_id = plt.seq_id
			and allo.user_assign = @user_id
			and allo.wh_id = @wh_id
			and plt.shipping_label = @pick_key
			and allo.status = 'A'
			AND allo.allo_type = 'O'
			and allo.item_number = @item_number
			and allo.location_id = @pk_location
			and isnull(allo.lot_number,'')=isnull(@lot_number,'') 
			and isnull(allo.hu_id,'')=isnull(@hu_id,'') 
			AND ISNULL(allo.stored_attribute_id, 0) = ISNULL(@stored_attribute_id, 0) 
			and  allo.allocated_qty - allo.picked_qty > 0
			order by allo.pick_id
		
			IF (@@ROWCOUNT = 0 or @qty<=0)
				BEGIN
					break
				END

			IF @qty <= @allocated_qty
				BEGIN
					SET @picked_qty= @qty
					SET @qty = 0
				END
			ELSE
				BEGIN
					SET @picked_qty= @allocated_qty
					SET @qty = @qty - @allocated_qty
				END


			--Updated t_pick_detail
			UPDATE t_pick_detail
			SET status = (CASE WHEN  picked_quantity + @picked_qty <= planned_quantity
								THEN 'PICKED'
							ELSE status END)
				,picked_quantity = picked_quantity + @picked_qty
			WHERE pick_id = @pick_id

			--Update allocation information
			UPDATE tbl_allocation
			SET status = (CASE WHEN  picked_qty + @picked_qty <= allocated_qty
								THEN 'C'
							ELSE 'U' END)
				,picked_qty = picked_qty + @picked_qty
			WHERE seq_id = @seq_id


			If NOT EXISTS (SELECT 1 FROM t_order_detail a
			            left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			            where isnull(b.status,'') NOT IN('PICKED','STAGED','LOADED') and a.order_number= @order_number and a.wh_id=@wh_id
						and isnull(b.work_type,'')='')
		    AND EXISTS (SELECT 1 FROM t_order_detail a
			            left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			            where isnull(b.status,'') ='PICKED' and a.order_number= @order_number and a.wh_id=@wh_id
						and isnull(b.work_type,'')='')
		    UPDATE t_order SET status = 'PICKED', date_picked = getdate() where order_number= @order_number and wh_id=@wh_id

		END
		


		--提总拣选，对于同一个任务号中同货位、同商品的任务全部更新为完成
		WHILE(1=1)
		BEGIN
			SELECT top 1 @pick_id = allo.pick_id
					,@allocated_qty = allo.allocated_qty - allo.picked_qty
					,@seq_id = allo.seq_id
					,@location_id = allo.location_id
					,@order_number = allo.order_number
			FROM tbl_allocation allo,tbl_pick_list plt
			WHERE allo.wh_id = plt.wh_id
			and allo.seq_id = plt.seq_id
			and allo.user_assign = @user_id
			and allo.wh_id = @wh_id
			and plt.shipping_label = @pick_key
			and allo.status = 'A'
			AND allo.allo_type = 'O'
			and allo.item_number = @item_number
			and allo.location_id = @pk_location
			and isnull(allo.lot_number,'')=isnull(@lot_number,'') 
			and isnull(allo.hu_id,'')=isnull(@hu_id,'') 
			AND ISNULL(allo.stored_attribute_id, 0) = ISNULL(@stored_attribute_id, 0) 
			and  allo.allocated_qty - allo.picked_qty > 0
			order by allo.pick_id
			IF (@@ROWCOUNT = 0)
			BEGIN
			     BREAK
			END

			UPDATE tbl_allocation
			   SET status = 'C'
			 WHERE wh_id = @wh_id
			   and seq_id = @seq_id

           IF NOT EXISTS( SELECT 1 FROM tbl_allocation
					   	WHERE  wh_id = @wh_id
						AND order_number=@order_number 
						and item_number =@item_number
						AND status <> 'C')
			BEGIN
				UPDATE t_pick_detail  
				SET status='LOADED' 
				WHERE order_number=@order_number 
				and wh_id=@wh_id and item_number =@item_number 
			
				UPDATE t_order
				SET status = 'LOADED' 
				WHERE order_number=@order_number and wh_id=@wh_id 
				AND NOT EXISTS( SELECT 1 FROM t_pick_detail pkd
								WHERE pkd.order_number=t_order.order_number
								and pkd.wh_id=t_order.wh_id
								and pkd.status <> 'LOADED')
			END

		END



		--提总拣选，对于同一个任务号中同货位、同商品的任务全部更新为完成


		--Remove the stock from pick location
		EXEC	[dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @wh_id,
				@in_vchItemNumber = @item_number,
				@in_vchLocationID = @location_id,
				@in_nType =0,
				@in_vchHUID = @hu_id,
				@in_vchLotNumber =@lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @remove_qty,
				@in_dtFifoDate =@FifoDate,
				@in_dtExpirationDate = @expiration_date,
				@in_vchHUType = N'IV',
				@in_vchShipmentNumber =NULL,
				@in_damage_flag = @damage_flag,
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT

		--Move the stock to fork
		EXEC	[dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @wh_id,
				@in_vchItemNumber = @item_number,
				@in_vchLocationID = @fork_id,
				@in_nType = 0,
				@in_vchHUID = @put_hu_id,
				@in_vchLotNumber =@lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @total_qty,
				@in_dtFifoDate =@FifoDate,
				@in_dtExpirationDate = @expiration_date,
				@in_vchHUType = @type,
				@in_vchShipmentNumber =@shipping_label,
				@in_damage_flag = @damage_flag,
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT


				--Create tran log
				--Insert t_tran_log_holding
				INSERT INTO t_tran_log_holding
					([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
					,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
					,wh_id_2,location_id_2,hu_id_2
					,generic_attribute_1,
					generic_attribute_2,
					generic_attribute_3,
					generic_attribute_4,
					generic_attribute_5,
					generic_attribute_6,
					generic_attribute_7,
					generic_attribute_8,
					generic_attribute_9,
					generic_attribute_10,
					generic_attribute_11)
				VALUES
					(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@user_id,@shipping_label,''
					,@wh_id,@location_id,@hu_id,@item_number,@lot_number,@total_qty
					,@wh_id,@fork_id,@put_hu_id
					,(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_1),    
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_2), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_3), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_4), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_5), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_6), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_7), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_8), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_9), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_10), 
    				(SELECT a.attribute_value 
    				FROM t_sto_attrib_collection_detail a,
						t_attribute_legacy_map alm
    				WHERE a.stored_attribute_id = @stored_attribute_id
    				AND a.attribute_id = alm.generic_attribute_11)
					)


				-- calculate zone
				SET @zone_group = dbo.fn_Get_StorageType_ByItem(@wh_id,@item_number,CASE ISNULL(@damage_flag,'N') WHEN 'Y' THEN 'D' ELSE 'N' END)
				SELECT TOP 1 @zone = zone 
					FROM t_zone 
				WHERE zone_type = CASE ISNULL(@damage_flag,'N') WHEN 'Y' THEN 'D' ELSE 'N' END 
				AND wh_id = @wh_id
				AND zone_group = @zone_group

				UPDATE t_hu_master SET zone = @zone ,subtype =  CASE ISNULL(@damage_flag,'N') WHEN 'Y' THEN 'D' ELSE 'N' END + @zone_group
				WHERE wh_id = @wh_id AND hu_id = @put_hu_id
			
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN


    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    








