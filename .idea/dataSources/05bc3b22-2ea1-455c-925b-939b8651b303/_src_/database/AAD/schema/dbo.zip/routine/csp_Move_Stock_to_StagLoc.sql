
    
CREATE PROCEDURE [dbo].[csp_Move_Stock_to_StagLoc]    
     @wh_id					NVARCHAR(10) 
    ,@pick_loc				Nvarchar(30)  	
	,@put_loc				nvarchar(30)			
	,@user_id				nvarchar(30)
	,@tran_type				nvarchar(20)
	,@tran_description		nvarchar(50)	
	,@order_number			NVARCHAR(30)
	,@passornot				int output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @hu_id			Nvarchar(30)
		,@item_number			Nvarchar(30)
		,@lot_number			Nvarchar(30)
		,@stored_attribute_id	Nvarchar(30)
		,@picked_qty			float
	
		BEGIN TRANSACTION														

		--Create tran log
		--Insert t_tran_log_holding
		IF EXISTS(select 1 from t_stored_item where wh_id=@wh_id and location_id=@pick_loc) 
		BEGIN	
			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
				,wh_id_2,location_id_2,hu_id_2
				,generic_attribute_1,
				generic_attribute_2,
				generic_attribute_3,
				generic_attribute_4,
				generic_attribute_5,
				generic_attribute_6,
				generic_attribute_7,
				generic_attribute_8,
				generic_attribute_9,
				generic_attribute_10,
				generic_attribute_11)
			SELECT
				@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@order_number
				,@wh_id,@pick_loc,hu_id,item_number,lot_number,actual_qty
				,@wh_id,@put_loc,hu_id
				,(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
			FROM t_stored_item 
			where wh_id=@wh_id and location_id=@pick_loc
				
		END

		--Move the stock to staging location
		update t_stored_item 
		set location_id=@put_loc 
		where wh_id=@wh_id 
		and location_id=@pick_loc 

		update t_hu_master 
		set location_id=@put_loc 
		where wh_id=@wh_id 
		and location_id=@pick_loc
		
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    

GRANT EXEC ON csp_Move_Stock_to_StagLoc TO AAD_USER,WA_USER

