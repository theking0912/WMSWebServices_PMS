CREATE PROCEDURE [dbo].[csp_Inventory_Adjust_MultiLoc]
    @in_vchWhID                NVARCHAR(10),
    @in_vchItemNumber          NVARCHAR(30),
    @in_vchStarLocID           NVARCHAR(50),
	@in_vchEndLocID		       NVARCHAR(50),
    @in_nType                  BIGINT, 
    @in_vchHUID                NVARCHAR(22),
    @in_vchLotNumber           NVARCHAR(15),
    @in_nStoredAttributeID     BIGINT, 
    @in_fQty                   FLOAT,
    @in_dtFifoDate             DATETIME,
    @in_dtExpirationDate       DATETIME,
    @in_vchHUType              NVARCHAR(10),
    @in_vchShipmentNumber      NVARCHAR(30),
    @out_vchCode               uddt_output_code   OUTPUT,
    @out_vchMsg                uddt_output_msg    OUTPUT

AS

DECLARE
    -- Error handling variables
    @c_vchObjName                   uddt_obj_name,  -- The name that uniquely tags this object.
    @v_vchCode                      uddt_output_code,
    @v_vchMsg                       uddt_output_msg,
    @v_nSysErrorNum                 INT,

    -- Local Variables
    @v_nExists                      BIT,
    @v_nRowCount                    INT,
    @v_fActualQty                   FLOAT,
    @v_fUnavailableQty              FLOAT, 
    @v_nSequence                    INT

    -- Set Constants
    SET @c_vchObjName = N'csp_Inventory_Adjust_MultiLoc'   
    SET @v_vchCode = N'SUCCESS'
    SET @v_vchMsg  = N'NONE'
    SET @v_nSysErrorNum = 0
    SET @v_nSequence = 0
	-- Handle NULLS and Implicit NULLS (01/01/1900)
	SET @in_dtFifoDate = CASE WHEN @in_dtFifoDate IS NULL OR @in_dtFifoDate = '01/01/1900' THEN GETDATE() ELSE @in_dtFifoDate END
	
	--Get Expiration Date
	IF @in_dtExpirationDate = '01/01/1900' OR @in_dtExpirationDate IS NULL
		BEGIN
			SELECT @in_dtExpirationDate= min(sto.expiration_date)
			FROM t_stored_item sto with(nolock)
			WHERE wh_id = @in_vchWhID
			AND item_number = @in_vchItemNumber
			AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'-1') = ISNULL(@in_vchLotNumber,'-1')))
		END

    SET @in_dtExpirationDate = CASE @in_dtExpirationDate WHEN '01/01/1900' THEN NULL ELSE @in_dtExpirationDate END 

    SET NOCOUNT ON

-----------------------------------------------------------------------------------
--                  Update STO Record
-----------------------------------------------------------------------------------  
BEGIN TRY  
    UPDATE t_stored_item
       SET @v_fActualQty  = actual_qty = actual_qty + @in_fQty
	  ,unavailable_qty = CASE WHEN status = N'H' THEN actual_qty + @in_fQty  ELSE unavailable_qty END 	  
          ,fifo_date       = CASE WHEN fifo_date < @in_dtFifoDate THEN fifo_date ELSE @in_dtFifoDate END
          ,expiration_date = CASE WHEN @in_dtExpirationDate IS NULL THEN expiration_date ELSE @in_dtExpirationDate END
          ,sequence        = @v_nSequence
     WHERE wh_id       = @in_vchWhID
       AND item_number = @in_vchItemNumber
       AND location_id = @in_vchStarLocID
       AND type        = @in_nType
       AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'-1') = ISNULL(@in_vchHUID,'-1')))
       AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'-1') = ISNULL(@in_vchLotNumber,'-1')))
       AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'-1') = ISNULL(@in_nStoredAttributeID,'-1')))
      
       SET @v_nRowCount = @@ROWCOUNT
	    
END TRY

BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
    SET @v_vchCode = N'-20001'
    SET @v_vchMsg = N'A SQL error occured while attempting to update STO records.'
    GOTO ERROR_HANDLER
END CATCH



IF @v_nRowCount > 0 SET @v_nExists = 1 ELSE SET @v_nExists = 0

IF @v_nExists = 0 
BEGIN --1
    IF @in_vchHUID IS NOT NULL 
    BEGIN--2
		
        -----------------------------------------------------------------------------------
        --                  Update HUM Record
        ----------------------------------------------------------------------------------- 
        BEGIN TRY
            UPDATE t_hu_master 
                SET location_id = @in_vchStarLocID, type = @in_vchHUType
            WHERE wh_id = @in_vchWhID
                AND hu_id = @in_vchHUID
                
            SET @v_nRowCount = @@ROWCOUNT
        END TRY

        BEGIN CATCH    
            SET @v_nSysErrorNum = ERROR_NUMBER()
            SET @v_vchCode = N'-20002'
            SET @v_vchMsg = N'A SQL error occured while attempting to update HUM record.'
            GOTO ERROR_HANDLER
        END CATCH
 
        IF @v_nRowCount <= 0 
        BEGIN--3 
            -----------------------------------------------------------------------------------
            --                  Insert HUM Record
            -----------------------------------------------------------------------------------        
            BEGIN TRY                
                INSERT INTO t_hu_master(wh_id, hu_id, location_id, type, status, control_number)
                    VALUES (@in_vchWhID, @in_vchHUID, @in_vchStarLocID, @in_vchHUType, 'A', @in_vchShipmentNumber) 
            END TRY
    
            BEGIN CATCH    
                SET @v_nSysErrorNum = ERROR_NUMBER()
                SET @v_vchCode = N'-20003'
                SET @v_vchMsg = N'A SQL error occured while attempting to insert HUM record.'
                GOTO ERROR_HANDLER
            END CATCH               
        END--3           
    END--2        
    -----------------------------------------------------------------------------------
    --                 Create STO Record
    ----------------------------------------------------------------------------------- 
    BEGIN TRY
		
        INSERT INTO t_stored_item(
            wh_id, item_number, location_id, type, hu_id, lot_number, stored_attribute_id, 
            actual_qty, unavailable_qty, status, fifo_date, expiration_date, sequence,
            shipment_number)
        VALUES(
            @in_vchWhID, @in_vchItemNumber, @in_vchStarLocID, @in_nType, @in_vchHUID, 
            @in_vchLotNumber, @in_nStoredAttributeID, @in_fQty, 0, N'A', @in_dtFifoDate, 
            @in_dtExpirationDate, @v_nSequence,
            @in_vchShipmentNumber)  
		
		IF ISNULL(@in_vchStarLocID,'0') <> ISNULL(@in_vchEndLocID,'0')
			BEGIN
				INSERT INTO tbl_stored_item_relation
					([wh_id],[location_id],[related_location])
				SELECT @in_vchWhID,@in_vchStarLocID,location_id
				FROM t_location  with(nolock)
				WHERE  wh_id = @in_vchWhID
				AND location_id BETWEEN @in_vchStarLocID AND @in_vchEndLocID

				UPDATE t_location SET status ='I'
				WHERE wh_id = @in_vchWhID
				AND location_id BETWEEN @in_vchStarLocID AND @in_vchEndLocID
				AND location_id <> @in_vchStarLocID
			END
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
		--print ERROR_message()
        SET @v_vchCode = N'-20004'
        SET @v_vchMsg = N'A SQL error occured while attempting to update STO record.'
        GOTO ERROR_HANDLER
    END CATCH 
END--1

-----------------------------------------------------------------------------------
--                Add Relation STO Record
----------------------------------------------------------------------------------- 
IF @v_nExists = 1 AND @v_fActualQty > 0 AND @in_fQty > 0
BEGIN
	IF ISNULL(@in_vchStarLocID,'0') <> ISNULL(@in_vchEndLocID,'0')
		BEGIN
			
			UPDATE t_location SET status ='I'
			WHERE wh_id = @in_vchWhID
			AND location_id BETWEEN @in_vchStarLocID AND @in_vchEndLocID
			AND location_id <> @in_vchStarLocID
			AND NOT EXISTS ( SELECT 1 FROM tbl_stored_item_relation sir  with(nolock)
								WHERE sir.wh_id = t_location.wh_id
								AND sir.location_id = @in_vchStarLocID
								AND sir.related_location = t_location.location_id)
			
			INSERT INTO tbl_stored_item_relation
				([wh_id],[location_id],[related_location])
			SELECT @in_vchWhID,@in_vchStarLocID,location_id
			FROM t_location  with(nolock)
			WHERE  wh_id = @in_vchWhID
			AND location_id BETWEEN @in_vchStarLocID AND @in_vchEndLocID
			AND NOT EXISTS ( SELECT 1 FROM tbl_stored_item_relation sir with(nolock)
								WHERE sir.wh_id = t_location.wh_id
								AND sir.location_id = @in_vchStarLocID
								AND sir.related_location = t_location.location_id)
		END
END


-----------------------------------------------------------------------------------
--                Delete STO Record
----------------------------------------------------------------------------------- 
IF @v_nExists = 1 AND @v_fActualQty = 0 
BEGIN--1
    BEGIN TRY
		
        DELETE t_stored_item
            WHERE wh_id       = @in_vchWhID
                AND item_number = @in_vchItemNumber
                AND location_id = @in_vchStarLocID
                AND type        = @in_nType
                AND ((hu_id = @in_vchHUID) OR (ISNULL(hu_id,'-1') = ISNULL(@in_vchHUID,'-1')))
                AND ((lot_number = @in_vchLotNumber) OR (ISNULL(lot_number,'-1') = ISNULL(@in_vchLotNumber,'-1')))
                AND ((stored_attribute_id = @in_nStoredAttributeID) OR (ISNULL(stored_attribute_id,'-1') = ISNULL(@in_nStoredAttributeID,'-1')))
                AND actual_qty = 0
                AND unavailable_qty = 0
		
		declare @current_end_loc nvarchar(30)
		select @current_end_loc = max(related_location)
		from tbl_stored_item_relation with(nolock)
		where wh_id = @in_vchWhID
		and location_id = @in_vchStarLocID
		/*
		insert into tbl_debug_loc_test
		(in_end_loc, get_end_loc,in_start_loc)
		values
		(@in_vchEndLocID, @current_end_loc,@in_vchStarLocID )
		*/

		DELETE FROM tbl_stored_item_relation
		WHERE NOT EXISTS(SELECT 1 FROM t_stored_item sto with(nolock)
						WHERE sto.wh_id = @in_vchWhID
						and sto.location_id = tbl_stored_item_relation.location_id )
		and wh_id = @in_vchWhID
		and location_id = @in_vchStarLocID

		IF @@ROWCOUNT > 0 
			BEGIN
				UPDATE t_location SET status ='E'
				WHERE wh_id = @in_vchWhID
				AND location_id BETWEEN @in_vchStarLocID AND @current_end_loc
				AND location_id <> @in_vchStarLocID
			END
    END TRY

    BEGIN CATCH    
        SET @v_nSysErrorNum = ERROR_NUMBER()
        SET @v_vchCode = N'-20005'
        SET @v_vchMsg = N'A SQL error occured while attempting to delete STO record.'
        GOTO ERROR_HANDLER
    END CATCH    

    -----------------------------------------------------------------------------------
    --                 Delete HUM Record
    ----------------------------------------------------------------------------------- 
    IF @in_vchHUID IS NOT NULL 
    BEGIN--2   
        IF NOT EXISTS (SELECT N'TRUE'
                         FROM t_stored_item
                        WHERE wh_id = @in_vchWhID
                          AND hu_id = @in_vchHUID) 
        BEGIN--3
            BEGIN TRY              
                DELETE FROM t_hu_master
                    WHERE wh_id = @in_vchWhID
                        AND hu_id = @in_vchHUID
            END TRY

            BEGIN CATCH    
                SET @v_nSysErrorNum = ERROR_NUMBER()
                SET @v_vchCode = N'-20006'
                SET @v_vchMsg = N'A SQL error occured while attempting to delete HUM record.'
                GOTO ERROR_HANDLER
            END CATCH    
        END--3
    END--2
END--1

GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + N'Deadlock error: 40001 ' 
                    + @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE() + N'.'
    ELSE    
        SET @v_vchMsg = @c_vchObjName + N': ' + @v_vchCode + ' ' + @v_vchMsg
                    + N' SQL Error = ' + ERROR_MESSAGE() + N'.'

    RAISERROR(@v_vchMsg, 11, 1)
   
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

	-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

    -- Always leave the stored procedure from here.
RETURN
