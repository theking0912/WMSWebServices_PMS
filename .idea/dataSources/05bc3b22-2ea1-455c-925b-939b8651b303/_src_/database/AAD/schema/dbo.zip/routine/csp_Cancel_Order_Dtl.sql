
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Cancel_Order_Dtl]
	-- Add the parameters for the stored procedure here
	@wh_id AS NVARCHAR(30)
	,@order_number AS NVARCHAR(30)
	,@user_id AS NVARCHAR(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @out_vchCode uddt_output_code
		,@out_vchMsg uddt_output_msg
	DECLARE @Rec_Cnt AS BIGINT
	DECLARE @hu_id AS NVARCHAR(30)
	DECLARE @out_nErrorNumber INTEGER
	DECLARE @out_vchLogMsg NVARCHAR(250)
	DECLARE @location_id NVARCHAR(50)
	DECLARE @pre_hu_id NVARCHAR(50)
	DECLARE @dock_stage NVARCHAR(50)
	DECLARE @storage_type NVARCHAR(50)
	DECLARE @original_storage_type NVARCHAR(50)
	DECLARE @damage_flag NVARCHAR(1)
	DECLARE @zone NVARCHAR(10)
	DECLARE @sub_type NVARCHAR(10)
	DECLARE @ori_hu_id NVARCHAR(50)
	DECLARE @item_number NVARCHAR(30)
	DECLARE @lot_number NVARCHAR(30)
	DECLARE @stored_attribute_id NVARCHAR(30)
	DECLARE @qty FLOAT
	DECLARE @expiration_date DATETIME
	DECLARE @type INT

	WHILE (1 = 1)
	BEGIN
		SELECT TOP 1 @item_number = sto.item_number
			,@storage_type = im.storage_type
			,@lot_number = lot_number
			,@expiration_date = expiration_date
			,@damage_flag = damage_flag
			,@dock_stage = location_id
			,@qty = actual_qty
			,@stored_attribute_id = stored_attribute_id
			,@type = type
			,@ori_hu_id = hu_id
			,@location_id = location_id
		FROM t_stored_item sto
		INNER JOIN t_item_master im ON sto.wh_id = im.wh_id
			AND sto.item_number = im.item_number
		WHERE sto.wh_id = @wh_id
			AND shipment_number = @order_number
			AND EXISTS (
				SELECT 1
				FROM t_pick_detail pd
				INNER JOIN t_order_detail od ON pd.wh_id = od.wh_id
					AND pd.order_number = od.order_number
					AND pd.item_number = od.item_number
					AND pd.line_number = od.line_number
				WHERE sto.wh_id = pd.wh_id
					AND sto.type = pd.pick_id
					AND pd.wh_id = @wh_id
					AND ISNULL(od.cancel_flag, 'N') = 'Y'
				)
		ORDER BY storage_type ASC

		IF @@rowcount = 0
		BEGIN
			BREAK
		END

		IF @damage_flag = 'N'
		BEGIN
			SET @zone = @storage_type + 'N'
			SET @sub_type = 'N' + @storage_type
		END
		ELSE
		BEGIN
			SET @zone = @storage_type + 'D'
			SET @sub_type = 'D' + @storage_type
		END

		SELECT @location_id = location_id
		FROM tbl_zone_staging
		WHERE type = 'A'
			AND wh_id = @wh_id
			AND zone = @zone

		IF ISNUMERIC(@ori_hu_id) = 0
			OR LEN(@ori_hu_id) <> 6
		BEGIN
			IF ISNULL(@original_storage_type,'')<>ISNULL(@storage_type,'')
			BEGIN
				EXEC usp_get_next_value 'HU_ID'
					,@hu_id OUTPUT
					,@out_nErrorNumber OUTPUT
					,@out_vchLogMsg OUTPUT
			END
			ELSE
			BEGIN
				SET @hu_id = @pre_hu_id
			END

			SET @pre_hu_id = @hu_id
		END
		ELSE
		BEGIN
			SET @hu_id = @ori_hu_id
		END

		SET @original_storage_type = @storage_type

		-- Create kit stock 
		EXEC [dbo].[csp_Inventory_Adjust] @in_vchWhID = @wh_id
			,@in_vchItemNumber = @item_number
			,@in_vchLocationID = @location_id
			,@in_nType = 0
			,@in_vchHUID = @hu_id
			,@in_vchLotNumber = @lot_number
			,@in_nStoredAttributeID = @stored_attribute_id
			,@in_fQty = @qty
			,@in_dtFifoDate = NULL
			,@in_dtExpirationDate = @expiration_date
			,@in_vchHUType = 'IV'
			,@in_vchShipmentNumber = 0
			,@in_damage_flag = @damage_flag
			,@out_vchCode = @out_vchCode OUTPUT
			,@out_vchMsg = @out_vchMsg OUTPUT

		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding (
			[tran_type]
			,[description]
			,[start_tran_date]
			,[start_tran_time]
			,[end_tran_date]
			,[end_tran_time]
			,[employee_id]
			,[control_number]
			,[control_number_2]
			,[wh_id]
			,[location_id]
			,[hu_id]
			,[item_number]
			,[lot_number]
			,[tran_qty]
			,wh_id_2
			,location_id_2
			,hu_id_2
			,generic_attribute_1
			,generic_attribute_2
			,generic_attribute_3
			,generic_attribute_4
			,generic_attribute_5
			,generic_attribute_6
			,generic_attribute_7
			,generic_attribute_8
			,generic_attribute_9
			,generic_attribute_10
			,generic_attribute_11
			)
		VALUES (
			'903'
			,'Cancel Order'
			,getdate()
			,getdate()
			,getdate()
			,getdate()
			,@user_id
			,@order_number
			,0
			,@wh_id
			,@dock_stage
			,@ori_hu_id
			,@item_number
			,@lot_number
			,@qty
			,@wh_id
			,@location_id
			,@hu_id
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_1
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_2
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_3
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_4
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_5
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_6
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_7
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_8
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_9
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_10
				)
			,(
				SELECT a.attribute_value
				FROM t_sto_attrib_collection_detail a
					,t_attribute_legacy_map alm
				WHERE a.stored_attribute_id = @stored_attribute_id
					AND a.attribute_id = alm.generic_attribute_11
				)
			)

		SET @qty = @qty * - 1

		-- remove original stock 
		EXEC [dbo].[csp_Inventory_Adjust] @in_vchWhID = @wh_id
			,@in_vchItemNumber = @item_number
			,@in_vchLocationID = @dock_stage
			,@in_nType = @type
			,@in_vchHUID = @ori_hu_id
			,@in_vchLotNumber = @lot_number
			,@in_nStoredAttributeID = @stored_attribute_id
			,@in_fQty = @qty
			,@in_dtFifoDate = NULL
			,@in_dtExpirationDate = @expiration_date
			,@in_vchHUType = 'IV'
			,@in_vchShipmentNumber = NULL
			,@in_damage_flag = @damage_flag
			,@out_vchCode = @out_vchCode OUTPUT
			,@out_vchMsg = @out_vchMsg OUTPUT

		UPDATE t_hu_master
		SET subtype = @sub_type
			,zone = @zone
			,control_number = NULL
		WHERE hu_id = @hu_id
			AND wh_id = @wh_id
	END
END
