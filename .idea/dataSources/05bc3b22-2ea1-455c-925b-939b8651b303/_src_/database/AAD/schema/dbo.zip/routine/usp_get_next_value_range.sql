
CREATE  PROCEDURE usp_get_next_value_range
     @in_vchType           NVARCHAR(20),
     @in_nIncrement        INT,
     @out_nUIDFirst        BIGINT       OUTPUT,  -- First reserved id
     @out_nUIDLast         NVARCHAR(10)  OUTPUT,  -- Last reserved id
     @out_nErrorNumber     INTEGER      OUTPUT,
     @out_vchLogMsg        NVARCHAR(250) OUTPUT
     
AS

DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber       INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber         INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum        INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel           TINYINT, -- Holds log level (1-5).
    @v_vchErrorMsg         NVARCHAR(500),
    @v_nErrorNumber        INT,
    @v_nRowCount           INT,
    @v_nReturn             INT,
    @v_Max_Work_Q_ID       BIGINT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError         INT,
    @e_HUIDCompareError    INT,
    @e_SprocError          INT,
    @e_CtlError            INT,
    @e_IncZeroError        INT,              
    @e_IncMaxExceededError INT,
    @e_IDResetFailed       INT,
    @e_IDDuplResetFailed   INT,
    
    -- Local Variables
    @v_vchItem             NVARCHAR(30),
    @v_fMax                FLOAT,
    @v_nTranCount          INT,
    @v_nUIDControl         BIGINT,
    @v_nReset              INT

    -- Set Constants
    SET @c_nModuleNumber = 60  -- Always #60 for WA.
    SET @c_nFileNumber   = 6   -- This # must be unique per object.
    
    -- Log/Local Error Constants
    SET @e_GenSqlError         = 1
    SET @e_SprocError          = 2
    SET @e_CtlError            = 3
    SET @e_IncZeroError        = 4
    SET @e_IncMaxExceededError = 5
    SET @e_IDResetFailed       = 6
    SET @e_IDDuplResetFailed   = 7
    SET @e_HUIDCompareError    = 8

    -- Lock the table until we get our unique id.
    -- Get the count of current transactions so we know whether or not to start our own.
    -- @v_nTranCount WILL REMAIN 0 EVEN WHEN THE TRANSACTION IS STARTED, IT CAN THEN BE CHECKED WHEN IT COMES TIME TO
    -- COMMIT OR ROLLBACK WHETHER THE TRANSACTION WAS CREATED HERE IN THE STORED PROCEDURE
    SET @v_nTranCount = @@TRANCOUNT   
    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    SET NOCOUNT ON

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
            ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler           
    END

    IF @in_nIncrement <= 0
    BEGIN
        SET @v_vchErrorMsg = 
            @in_vchType + ' increment value ' + CAST(@in_nIncrement AS NVARCHAR(30)) + 
            ' cannot be <= 0.'
        SET @v_nLogErrorNum = @e_IncZeroError
        GOTO ErrorHandler
    END

    GetNext:
    SELECT @v_nUIDControl = ISNULL(next_value,0), @v_fMax = f1
    FROM t_control 
    WHERE control_type = @in_vchType

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
    BEGIN
        -- If the record does not exist, create it and start with 1.   
        SET @v_nUIDControl = 0

        IF @in_vchType = 'UID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'Unique Indentifier', @v_nUIDControl, 'SHOW_VA', '0', 2147483647)
        ELSE IF @in_vchType = 'SHIP_ID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'PSFT Ship ID',       @v_nUIDControl, 'SHOW_VA', '0', 2147483647)
        ELSE IF @in_vchType = 'HU_ID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'Handling Unit ID',   @v_nUIDControl, 'SHOW_VA', '0', 2147483647)
        ELSE IF @in_vchType = 'WORK_Q_ID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'Work Queue ID',      @v_nUIDControl, 'SHOW_VA', '0', 2147483647)
        ELSE IF @in_vchType = 'MANIFEST_BATCH_ID'
            INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit, f1)
            VALUES (@in_vchType, 'Manifest Batch ID',      @v_nUIDControl, 'SHOW_VA', '0', 2147483647)
    END
    
    IF @in_nIncrement >= @v_fMax
    BEGIN
        SET @v_vchErrorMsg = 
            @in_vchType + ' increment value ' + 
            ISNULL(CAST(@in_nIncrement AS NVARCHAR(30)),'(NULL)') + 
            ' cannot be >= maximum allowed in t_control: ' + ISNULL(CAST(@v_fMax as NVARCHAR(30)) ,'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_IncMaxExceededError
        GOTO ErrorHandler
    END

    IF (@v_nUIDControl + @in_nIncrement) > @v_fMax
    BEGIN
        -- The max would be exceeded, reset next_value to 0.
        -- Check to see if the ID in t_control has already been reset.
        IF @v_nReset = 1 
        BEGIN
            SET @v_vchErrorMsg = 'ID in t_control has already been reset.  This is probably due to ' + 
                'duplicate IDs in destination table (i.e. WKQ, HUM, ...).  Type: ' + 
                ISNULL(@in_vchType,'(NULL)') + '  ID in t_control: ' + 
                ISNULL(CAST(@v_nUIDControl AS NVARCHAR(20)),'(NULL)') + '  UID First: ' +
                ISNULL(CAST(@out_nUIDFirst AS NVARCHAR(20)),'(NULL)') + '  UID Last: '  + 
                ISNULL(CAST(@out_nUIDLast AS NVARCHAR(20)),'(NULL)') 
            SET @v_nLogErrorNum = @e_IDDuplResetFailed
            GOTO ErrorHandler
        END
        
        SET @v_nUIDControl = 0

        UPDATE t_control
        SET next_value = @v_nUIDControl
        WHERE control_type = @in_vchType
        
        SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
        -- Check for any errors. If so, error number will not be equal to zero.
        IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
        -- Check for Number of rows affected.
        IF @v_nRowCount = 0
        BEGIN
            SET @v_vchErrorMsg = 'Failed to reset ID, ' +
                ISNULL(@in_vchType,'(NULL)') + ', to 0.'
            SET @v_nLogErrorNum = @e_IDResetFailed
            GOTO ErrorHandler
        END
        
        SET @v_nReset = 1  -- 1 indicates the ID in t_control has been reset.
        
    END

    SET @out_nUIDFirst = @v_nUIDControl + 1
    
    SET @out_nUIDLast  = @v_nUIDControl + @in_nIncrement


    -- Update the next_value.
    UPDATE t_control
    SET next_value = @out_nUIDLast 
    WHERE control_type = @in_vchType

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
    BEGIN
        SET @v_vchErrorMsg = 'Failed to find a record in t_control for the specified control value:' +
            ISNULL(@in_vchType,'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_CtlError
        GOTO ErrorHandler
    END
     
    -- Verify the unique id(s) are not already used.
    IF @in_vchType = 'HU_ID'
    BEGIN
        SELECT @v_nRowCount = COUNT(*)
        FROM t_hu_master
        WHERE 
            (
            (CASE  
                 WHEN (isnumeric(hu_id) = 1) THEN CAST(hu_id as BIGINT) 
                 ELSE '0' 
                END) >= @out_nUIDFirst
        AND (CASE  
                 WHEN (isnumeric(hu_id) = 1) THEN CAST(hu_id as BIGINT) 
                 ELSE '0' 
                END) <= @out_nUIDLast
            )
    
	SELECT @v_nErrorNumber = @@ERROR
	IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'HU ID verification failed.'
            SET @v_nLogErrorNum = @e_HUIDCompareError
            GOTO ErrorHandler
        END

        IF @v_nRowCount > 0  -- Unique Id already being used
            GOTO GetNext
    END     

    ELSE IF @in_vchType = 'WORK_Q_ID'
    BEGIN
        /*SELECT @v_nRowCount = COUNT (*)
        FROM t_work_q
        WHERE 
            (
            (CASE  
                 WHEN (isnumeric(work_q_id) = 1) THEN CAST(work_q_id as BIGINT) 
                 ELSE '0' 
                END) >= @out_nUIDFirst
        AND (CASE  
                 WHEN (isnumeric(work_q_id) = 1) THEN CAST(work_q_id as BIGINT) 
                 ELSE '0' 
                END) <= @out_nUIDLast
            )*/

    -- newly inserted code 
	SET @v_Max_Work_Q_ID = 0
        SELECT @v_Max_Work_Q_ID = MAX(CAST(work_q_id AS BIGINT)) FROM t_work_q
              where work_q_id between @out_nUIDFirst and @out_nUIDLast

        IF @v_Max_Work_Q_ID > 0 
           BEGIN
	       UPDATE t_control SET next_value = @v_Max_Work_Q_ID
	          WHERE control_type = @in_vchType
               GOTO GetNext
           END

    END

    -- Release the lock now.
    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION
    
    GOTO ExitLabel
    

ErrorHandler:
----------------------------------------------------------------------------------------------------
    -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    

    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

ExitLabel:

    -- Always leave the stored procedure from here.
    RETURN


GRANT EXECUTE ON usp_get_next_value_range TO WA_USER, AAD_USER
