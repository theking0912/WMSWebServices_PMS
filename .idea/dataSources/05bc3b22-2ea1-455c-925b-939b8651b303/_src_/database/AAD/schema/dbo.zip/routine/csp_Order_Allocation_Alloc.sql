
CREATE PROCEDURE [dbo].[csp_Order_Allocation_Alloc]    
     @wh_id				NVARCHAR(10)   
    ,@order_number	    NVARCHAR(30) 

AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @item_number			NVARCHAR(30)
		DECLARE @lot_number				NVARCHAR(30)
		DECLARE @line_number			NVARCHAR(5)
		DECLARE @planned_qty			float
		DECLARE @picked_qty				float
		DECLARE @leave_allocate_qty		float
		DECLARE @uom_qty				float
		DECLARE @alloc_qty				float
		DECLARE @allocated_qty			float
		DECLARE @pick_id				bigint
		DECLARE @pick_put_id			NVARCHAR(30)
		DECLARE @location_id			NVARCHAR(30)
		DECLARE @zone					NVARCHAR(30)
		DECLARE @pick_seq				NVARCHAR(30)
		DECLARE @carrier				NVARCHAR(30)
		DECLARE @event_data				NVARCHAR(2000)
		DECLARE @result                 INT
		DECLARE @alloc_lot_number       NVARCHAR(30)
		DECLARE @expiration_date        datetime
		DECLARE @re_release				NVARCHAR(30)
		DECLARE @is_rollback			NVARCHAR(30)
		DECLARE @stock_flag             NVARCHAR(1)
		DECLARE @v_nRowCount            INT
		DECLARE @v_nErrorNumber         INT
		DECLARE @v_nRuleCntr            INT
		DECLARE @v_nNumOfRules          INT
		DECLARE @gourd_flag             NVARCHAR(1)
		DECLARE @hu_id                  NVARCHAR(22)
		DECLARE @pick_type              NVARCHAR(1)
		DECLARE @damage_flag            NVARCHAR(1)
		DECLARE @pack_flag              NVARCHAR(1)
		DECLARE @pack_pos				NVARCHAR(2)
		DECLARE @stored_attribute_id    BIGINT
		DECLARE	@v_vchUOM               NVARCHAR(10)
		DECLARE @wave_type				NVARCHAR(10)
		DECLARE @seq_id					BIGINT
		DECLARE @sto_att				BIGINT
		DECLARE @order_uom				NVARCHAR(30)
		DECLARE @uom_convert_ord	    BIGINT
		set @re_release = 'N'

		set @is_rollback = 'N'
		
		BEGIN TRANSACTION

		set @pick_id = 0


		-- Temp table used to hold a list of pick put rules for a given Pick Put ID
		CREATE TABLE #tmp_rule_set (
		   sequence        SMALLINT ,   -- The sequencial order in which to execute the rule
		   pick_put_rule   NVARCHAR(30) COLLATE DATABASE_DEFAULT -- Name of the rule stored procedure to execute
		)

		IF EXISTS(SELECT 1
					FROM t_order WITH(NOLOCK)
				WHERE order_number = @order_number 
				AND wh_id = @wh_id 
				AND order_type IN ('RVO','DO'))
		BEGIN
			SET @damage_flag = 'Y'
		END
		ELSE
		BEGIN
			SET @damage_flag = 'N'
		END

		
		SELECT TOP 1 @wave_type = wave_type
			FROM t_pick_detail pd WITH(NOLOCK)
			INNER JOIN t_wave_master mst WITH(NOLOCK)
			ON pd.wh_id = mst.wh_id
			AND pd.wave_id = mst.wave_id
			WHERE pd.wh_id = @wh_id
			AND pd.order_number = @order_number

        WHILE ( 1 = 1 )
            BEGIN
			
                SELECT TOP 1
                        @item_number = pkd.item_number ,
                        @lot_number = pkd.lot_number ,
                        @line_number = pkd.line_number ,
                        @planned_qty = pkd.planned_quantity ,
                        @picked_qty = pkd.picked_quantity ,
                        @pick_id = pkd.pick_id ,
                        @stock_flag = itm.stock_flag ,
                        @pack_flag = itm.pack_flag ,
                        @stored_attribute_id = pkd.stored_attribute_id,
						@pack_pos = itm.pack_pos
                FROM    t_pick_detail pkd WITH(NOLOCK),
                        t_item_master itm WITH(NOLOCK)
                WHERE   pkd.wh_id = itm.wh_id
                        AND pkd.item_number = itm.item_number
                        AND pkd.order_number = @order_number
                        AND pkd.wh_id = @wh_id
                        AND pkd.pick_id > @pick_id
						AND pkd.type = 'PP'
                ORDER BY pkd.pick_id

                IF @@ROWCOUNT = 0
                    OR @is_rollback = 'Y'
                    BREAK;

               --牛肉和冬瓜类不需要分配
               IF EXISTS ( SELECT  'x'
                           FROM    t_item_master
                           WHERE   wh_id = @wh_id
                                   AND item_number = @item_number
                                   AND pick_type IN ( 'B', 'M' ) )
                   BEGIN
                       CONTINUE              
                   END

				IF @wave_type = 'ORDER_PICK'
			   BEGIN
					SET @pick_type = 'O'
			   END
			   ELSE
			   BEGIN
				   IF EXISTS ( SELECT  'x'
							   FROM    t_item_master WITH(NOLOCK)
							   WHERE   wh_id = @wh_id
									   AND item_number = @item_number
									   AND pick_type = 'S' )
					   AND EXISTS ( SELECT 'x'
									FROM   t_order o WITH(NOLOCK),
										v_type t
									WHERE  o.type_id = t.type_id
										   AND t.source = 't_order'
										   AND t.lookup_type = 'TYPE'
										   AND o.wh_id = @wh_id
										   AND o.order_number = @order_number
										   AND t.type = 'SO' )
					   BEGIN
						   SET @pick_type = 'S'
					   END
				   ELSE
					   BEGIN
						   SET @pick_type = 'O'
					   END
				END
				

				-- for re-allocation clear allocated qty
			if exists (select 1 from tbl_allocation WITH(NOLOCK)
						WHERE  order_number = @order_number
						and item_number = @item_number
						and (@lot_number is null or lot_number = @lot_number)
						and line_number = @line_number
						and pick_id = @pick_id  
						and status = 'E')
			BEGIN
                DELETE  FROM tbl_allocation
                WHERE   order_number = @order_number
                        AND item_number = @item_number
                        AND ( @lot_number IS NULL
                              OR lot_number = @lot_number
                            )
                        AND line_number = @line_number
                        AND pick_id = @pick_id
                        AND status = 'E'
                        AND picked_qty = 0


			-- for re-allocation clear allocated qty
                UPDATE  tbl_allocation
                SET     allocated_qty = picked_qty ,
                        status = 'C'
                WHERE   order_number = @order_number
                        AND item_number = @item_number
                        AND ( @lot_number IS NULL
                              OR lot_number = @lot_number
                            )
                        AND pick_id = @pick_id
                        AND status = 'E'
                        AND line_number = @line_number 
			END
            
                SELECT  @allocated_qty = SUM(ABS(allocated_qty) - picked_qty)
                FROM    tbl_allocation WITH(NOLOCK)
                WHERE   order_number = @order_number
                        AND item_number = @item_number
                        AND ( @lot_number IS NULL
                              OR lot_number = @lot_number
                            )
                        AND pick_id = @pick_id
                        AND line_number = @line_number 

			   
                SET @leave_allocate_qty = @planned_qty - @picked_qty - ISNULL(@allocated_qty,0)
                SET @uom_qty = 9999999



                WHILE @leave_allocate_qty > 0
                    BEGIN
                        SELECT TOP 1
                                @v_vchUOM = itu.uom ,
                                @uom_qty = itu.conversion_factor
                        FROM    t_item_uom itu WITH(NOLOCK)
                        WHERE   wh_id = @wh_id
                                AND item_number = @item_number
                                AND status = N'ACTIVE'
                                AND conversion_factor <= @leave_allocate_qty
                                AND conversion_factor < @uom_qty
                        ORDER BY conversion_factor DESC

                        SELECT  @v_nErrorNumber = @@ERROR ,
                                @v_nRowCount = @@ROWCOUNT
                        IF @v_nErrorNumber <> 0
                            OR @v_nRowCount = 0
                            BEGIN
                                BREAK;
                            END


						---判断摘果订单，打包库存不足，分配原料库存 ADD BY Jerry 0405
						IF  @pick_type = 'O' 
						BEGIN 
						  SELECT TOP 1  @order_uom =order_uom ,@uom_convert_ord=tb.conversion_factor
						    FROM dbo.t_order_detail ta WITH(NOLOCK),t_item_uom tb WITH(NOLOCK)
						   WHERE order_number = @order_number
						     AND line_number = @line_number
							 AND ta.item_number = tb.item_number
							 AND ta.order_uom = tb.uom
							 AND ta.item_number =@item_number


						  IF EXISTS(SELECT 1 
										  FROM dbo.t_stored_item WITH(NOLOCK)
										 WHERE item_number = @item_number 
										   AND stored_attribute_id = @stored_attribute_id
										   AND ISNULL(@stored_attribute_id,'')<>''
										   AND ISNULL(dbo.csf_stored_qty(@wh_id,@item_number,@stored_attribute_id,1),0)>=@uom_convert_ord
		
									)
							 BEGIN
							   SET @sto_att=@stored_attribute_id  
							   SET @leave_allocate_qty = FLOOR(@leave_allocate_qty/@uom_convert_ord)*@uom_convert_ord
							 END 
						  ELSE
						    begin   
							 SET @sto_att =NULL

							 --IF  ISNULL(@stored_attribute_id,'')<>''
							 --BEGIN
							 --  SET @leave_allocate_qty = FLOOR(@leave_allocate_qty/@uom_convert_ord)*@uom_convert_ord
							 --END
							END
						END

						ELSE
						  BEGIN 
						    SET @sto_att=@stored_attribute_id  
						  END


                        INSERT  INTO #tmp_rule_set
                                ( sequence ,
                                  pick_put_rule
                                )
                                SELECT  ppd.sequence ,
                                        ppr.before
                                FROM    t_item_uom itu WITH(NOLOCK),
                                        t_pick_put_master ppm ,
                                        t_pick_put_detail ppd ,
                                        t_pick_put_rules ppr
                                WHERE   itu.pick_put_id = ppm.pick_put_id
                                        AND ppm.pick_put_id = ppd.pick_put_id
                                        AND ppd.rule_id = ppr.rule_id
                                        AND ppd.type = ppr.type
                                        AND ppd.type = 'PICK'
                                        AND itu.wh_id = @wh_id
                                        AND itu.item_number = @item_number
                                        AND itu.uom = @v_vchUOM

                        SELECT  @v_nErrorNumber = @@ERROR ,
                                @v_nRowCount = @@ROWCOUNT
                        IF @v_nErrorNumber <> 0
                            OR @v_nRowCount = 0
                            BEGIN
                                BREAK;
                            END
                        SET @v_nRuleCntr = 1 
                        SET @v_nNumOfRules = @v_nRowCount
                        WHILE @v_nRuleCntr <= @v_nNumOfRules
                            BEGIN
                                SELECT  @pick_put_id = pick_put_rule
                                FROM    #tmp_rule_set
                                WHERE   sequence = @v_nRuleCntr

                                EXEC @pick_put_id 
								@wh_id, 
								@item_number,
                                @lot_number, 
								@leave_allocate_qty,
								@pack_flag,
                                @sto_att,
								@damage_flag,
                                @alloc_lot_number OUTPUT,
								@expiration_date OUTPUT,
                                @location_id OUTPUT, 
								@hu_id OUTPUT,
                                @alloc_qty OUTPUT
								--@damage_flag OUTPUT
                                IF @location_id IS NULL OR @alloc_qty = 0
                                    BEGIN
                                        SET @v_nRuleCntr = @v_nRuleCntr + 1
                                        CONTINUE
                                    END
                                								
								SET @zone = NULL
								IF ISNULL(@zone,'') = ''
								BEGIN
									SELECT TOP 1 @zone = tz.zone FROM t_item_master tim WITH(NOLOCK)
												INNER JOIN t_zone tz WITH(NOLOCK)
												ON tim.wh_id = tz.wh_id
													AND tim.storage_type = tz.zone_group
												WHERE tim.item_number = @item_number
													AND tim.wh_id = @wh_id
													AND tz.zone_type = CASE ISNULL(@damage_flag,'N') WHEN 'N' THEN 'N' ELSE 'D' END									
								END

								SELECT TOP 1 
                                        @pick_seq = pick_seq
                                FROM    t_zone_loca
                                WHERE   location_id = @location_id

                                SET @leave_allocate_qty = @leave_allocate_qty - @alloc_qty


                                INSERT  INTO tbl_allocation
                                        ( wave_id ,
                                          order_number ,
                                          pick_id ,
                                          item_number ,
										  expiration_date ,
                                          lot_number ,
                                          stored_attribute_id ,
                                          location_id ,
                                          hu_id ,
                                          allocated_qty ,
                                          picked_qty ,
                                          status ,
                                          released_date ,
                                          ref_number ,
                                          pick_wall_loc ,
                                          pick_wall_slot ,
                                          pick_conveyor_node ,
                                          zone ,
                                          wh_id ,
                                          line_number ,
                                          picking_flow ,
                                          allo_type ,
                                          damage_flag
                                        )
                                        SELECT  pkd.wave_id AS wave_id ,
                                                @order_number AS order_number ,
                                                pkd.pick_id AS pick_id ,
                                                pkd.item_number AS item_number ,
												@expiration_date AS expiration_date,
                                                @alloc_lot_number AS lot_number ,
                                                --pkd.stored_attribute_id AS stored_attribute_id ,
												--CASE WHEN @pick_type = 'O' THEN  @stored_attribute_id ELSE  pkd.stored_attribute_id  END  AS stored_attribute_id ,
                                                @sto_att,
												@location_id AS location_id ,
                                                @hu_id AS hu_id ,
                                                @alloc_qty AS allocated_qty ,
                                                0 AS picked_qty ,
                                                'U' AS status ,
                                                GETDATE() AS released_date ,
                                                @order_number AS ref_number ,
                                                NULL AS pick_wall_loc ,
                                                NULL AS pick_wall_slot ,
                                                NULL AS pick_conveyor_node ,
                                                @zone AS zone ,
                                                @wh_id AS wh_id ,
                                                @line_number AS line_number ,
                                                @pick_seq AS picking_flow ,
                                                @pick_type AS allo_type ,
                                                @damage_flag AS damage_flag
                                        FROM    t_pick_detail pkd WITH(NOLOCK)
                                        WHERE   pkd.pick_id = @pick_id
									
									SELECT @seq_id = @@IDENTITY
									INSERT INTO tbl_watch_bug
										(seq_id,exe_date,remark)
										VALUES(@seq_id,GETDATE(),'Release Wave')
                            END
                    END 

				--只有播种的订单对应的可以负库存分配的商品才能进行负库存分配 
                IF @leave_allocate_qty > 0 AND @stock_flag = 'Y' AND @pick_type = 'S'
                    BEGIN
						SELECT TOP 1 @zone = tz.zone FROM t_item_master tim WITH(NOLOCK)
												INNER JOIN t_zone tz WITH(NOLOCK)
												ON tim.wh_id = tz.wh_id
													AND tim.storage_type = tz.zone_group
												WHERE tim.item_number = @item_number
													AND tim.wh_id = @wh_id
													AND tz.zone_type = CASE ISNULL(@damage_flag,'N') WHEN 'N' THEN 'N' ELSE 'D' END
						
						IF ISNULL(@pack_pos,'') <> '' AND ISNULL(@zone,'') <> ''
						BEGIN
							SELECT TOP 1 @location_id = location_id
							FROM tbl_zone_staging
								WHERE zone = @zone
									AND wh_id = @wh_id
									--AND type = @pack_pos
									AND type IN ('RI','RO')
						END

                        INSERT  INTO tbl_allocation
                                ( wave_id ,
                                  order_number ,
                                  pick_id ,
                                  item_number ,
								  expiration_date,
                                  lot_number ,
                                  stored_attribute_id ,
                                  location_id ,
                                  hu_id ,
                                  allocated_qty ,
                                  picked_qty ,
                                  status ,
                                  released_date ,
                                  ref_number ,
                                  pick_wall_loc ,
                                  pick_wall_slot ,
                                  pick_conveyor_node ,
                                  zone ,
                                  wh_id ,
                                  line_number ,
                                  picking_flow ,
                                  allo_type ,
                                  damage_flag
                                )
                                SELECT  pkd.wave_id AS wave_id ,
                                        @order_number AS order_number ,
                                        pkd.pick_id AS pick_id ,
                                        pkd.item_number AS item_number ,
										@expiration_date AS expiration_date,
                                       -- @alloc_lot_number AS lot_number ,
									   NULL AS lot_number,
                                        --pkd.stored_attribute_id AS stored_attribute_id ,
										--CASE WHEN @pick_type = 'O' THEN  @stored_attribute_id ELSE  pkd.stored_attribute_id  END  AS stored_attribute_id ,
                                        @sto_att,
										@location_id AS location_id ,
                                        NULL AS hu_id ,
                                        -1 * @leave_allocate_qty AS allocated_qty ,
                                        0 AS picked_qty ,
                                        'U' AS status ,
                                        GETDATE() AS released_date ,
                                        @order_number AS ref_number ,
                                        NULL AS pick_wall_loc ,
                                        NULL AS pick_wall_slot ,
                                        NULL AS pick_conveyor_node ,
            --                            (SELECT TOP 1 tz.zone FROM t_item_master tim
												--INNER JOIN t_zone tz
												--ON tim.wh_id = tz.wh_id
												--	AND tim.storage_type = tz.zone_group
												--WHERE tim.item_number = @item_number
												--	AND tim.wh_id = @wh_id
												--	AND tz.zone_type = CASE ISNULL(@damage_flag,'N') WHEN 'N' THEN 'N' ELSE 'D' END),
										@zone,
                                        @wh_id AS wh_id ,
                                        @line_number AS line_number ,
                                       -- @pick_seq AS picking_flow ,
									    NULL AS picking_flow,
                                        @pick_type AS allo_type ,
                                        @damage_flag AS damage_flag
                                FROM    t_pick_detail pkd WITH(NOLOCK)
                                WHERE   pkd.pick_id = @pick_id

								SELECT @seq_id = @@IDENTITY
									INSERT INTO tbl_watch_bug
										(seq_id,exe_date,remark)
										VALUES(@seq_id,GETDATE(),'Release Wave')
                    END
 

            END

        IF @is_rollback = 'Y'
            BEGIN
                ROLLBACK;
            END
        ELSE
            BEGIN
				
                IF EXISTS ( /*SELECT  1
                            FROM    tbl_allocation alloc
                            WHERE   wh_id = @wh_id
                                    AND order_number = @order_number
                                    AND ABS(alloc.allocated_qty) - alloc.picked_qty > 0 
						    UNION*/
                            SELECT  1
                            FROM    dbo.t_order_detail ta WITH(NOLOCK)
                            WHERE  ( NOT EXISTS ( SELECT 1
                                                 FROM   dbo.t_item_master WITH(NOLOCK)
                                                 WHERE  item_number = ta.item_number
                                                        AND wh_id = ta.wh_id 
														AND pick_type NOT IN('B','M'))
							   OR EXISTS(SELECT  1
											   FROM    tbl_allocation alloc WITH(NOLOCK)
											  WHERE   wh_id = @wh_id
												AND order_number = @order_number
												AND ABS(alloc.allocated_qty) - alloc.picked_qty > 0 ))
							  AND ta.order_number=@order_number
							  AND ta.wh_id=@wh_id
							)
                    BEGIN
                        UPDATE  t_order
                        SET     status = 'RELEASED'
                        WHERE   wh_id = @wh_id
								AND status NOT IN ('PICKED','STAGED','LOADED','SHIPPED')
                                AND order_number = @order_number
								

                        UPDATE  t_pick_detail
                        SET     status = 'RELEASED'
                        WHERE   wh_id = @wh_id
                                AND order_number = @order_number
								AND status NOT IN ('PICKED','STAGED','LOADED','SHIPPED')
								AND type = 'PP'

                    END
                ELSE
                    BEGIN
                        UPDATE  t_order 
                        SET     status = 'WAVED'
                        WHERE   wh_id = @wh_id
								AND status NOT IN ('PICKED','STAGED','LOADED','SHIPPED')
                                AND order_number = @order_number
                    END					

			
                DECLARE @sum_alloc_qty FLOAT
                DECLARE @sum_planned_qty FLOAT

                SELECT  @sum_alloc_qty = ISNULL(SUM(ABS(allocated_qty)), 0)
                FROM    tbl_allocation WITH(NOLOCK)
                WHERE   wh_id = @wh_id
                        AND order_number = @order_number

                SELECT  @sum_planned_qty = ISNULL(SUM(pkd.planned_quantity), 0)
                FROM    t_pick_detail pkd WITH(NOLOCK)
                WHERE   pkd.order_number = @order_number
                        AND pkd.wh_id = @wh_id
						AND pkd.type = 'PP'
				--IF NOT EXISTS ( SELECT 1
    --                            FROM   t_order o ,
    --                                v_type t
    --                            WHERE  o.type_id = t.type_id
    --                                   AND t.source = 't_order'
    --                                   AND t.lookup_type = 'TYPE'
    --                                   AND o.wh_id = @wh_id
    --                                   AND o.order_number = @order_number)
    --                                   AND t.type = 'SO' )
				--	AND @sum_alloc_qty < @sum_planned_qty
				IF @sum_alloc_qty < @sum_planned_qty --AND @sum_alloc_qty > 0
				BEGIN
					 UPDATE  t_order
                        --SET     status = 'WAVED'
						SET     status = 'PART'
                        WHERE   wh_id = @wh_id
								AND status NOT IN ('PICKED','STAGED','LOADED','SHIPPED')
                                AND order_number = @order_number
				END

                IF @sum_alloc_qty <= @sum_planned_qty
                    COMMIT;

                IF @sum_alloc_qty > @sum_planned_qty
                    ROLLBACK;
            END
				
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        RETURN
    END CATCH
	
  
END
