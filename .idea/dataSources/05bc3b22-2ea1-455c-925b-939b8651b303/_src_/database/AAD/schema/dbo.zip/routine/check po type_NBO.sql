






-- =======================================    
-- Author: will.xu
-- Create Date: 02 15 2016       
-- =======================================    
    
CREATE PROCEDURE [dbo].[check po type_NBO]    
     @wh_id					NVARCHAR(10)
	,@po_number             NVARCHAR(30)
	,@passornot				NVARCHAR(1)		output
AS
BEGIN
	DECLARE @sap_ordertype	NVARCHAR(30)

	set @passornot=0

	select @sap_ordertype=sap_ordertype from t_po_master 
	where wh_id = @wh_id 
		and po_number = @po_number
		and sap_ordertype in ('TT','UB','WXDL','XH','YFGJ','ZJ','THDL','JH')

	if isnull(@sap_ordertype,'') <> ''
	begin
		set @passornot=1
	end

	RETURN
END


    










