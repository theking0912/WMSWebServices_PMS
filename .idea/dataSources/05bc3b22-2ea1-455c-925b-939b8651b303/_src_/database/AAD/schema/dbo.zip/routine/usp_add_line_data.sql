
CREATE PROCEDURE usp_add_line_data
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchWaveDetailId   NVARCHAR(50),
@in_vchWaveId         NVARCHAR(60),
@in_vchItemNumber     NVARCHAR(60),
@in_vchLineNumber     NVARCHAR(20),
@in_vchLotNumber      NVARCHAR(30),
@in_nQuantity         BIGINT,
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contians "SUCCESS" or the message to be displayed.


AS

DECLARE 
    @v_nErrorNumber		  INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,
    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,
    @v_nReturn            INTEGER,
	@e_GenSqlError   	  INTEGER,
    @e_InsWDLFailed       INTEGER,
    @e_UpdWDLFailed       INTEGER,
    @e_UpdOrdFailed       INTEGER,
    @e_FindWVDFailed      INTEGER,
    @e_WaveMustBeHeld     INTEGER,

    @v_vchOrderNumber     NVARCHAR(60),
    @v_vchHuId            NVARCHAR(50),
    @v_chStatus           CHAR (1),
    @v_vchLotNumber       NVARCHAR(30),
    @v_nAvailQty          BIGINT,
    @v_nAFACtl            INTEGER,

    @v_nTranCount         INTEGER

    -- Set Constants
    SET @c_nModuleNumber = 63
    SET @c_nFileNumber = 3   

    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_InsWDLFailed = 2
    SET @e_UpdOrdFailed = 3
    SET @e_FindWVDFailed  = 4
    SET @e_UpdWDLFailed = 5
    SET @e_WaveMustBeHeld = 6

    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'

    SELECT @v_nAFACtl = next_value
      FROM t_whse_control
     WHERE control_type = 'AFA_INSTALLED'
       AND wh_id = @in_vchWarehouseId 

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN
    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    -- Verify the load is on hold before manipulating data.
    SELECT @v_chStatus = status
    FROM t_wave_master
    WHERE wh_id = @in_vchWarehouseId
        AND wave_id = @in_vchWaveId

    IF @v_chStatus = 'R'  
    BEGIN
        SET @v_nErrorNumber = @e_WaveMustBeHeld
        GOTO ErrorHandler
    END

    -- Get the Order Number from t_afo_wave_detail
    SELECT @v_vchOrderNumber = order_number 
    FROM t_afo_wave_detail
    WHERE wave_detail_id =  @in_vchWaveDetailId

    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_FindWVDFailed
        GOTO ErrorHandler
    END
    -- Get the real value of lot #.  VB will always pass in a "" or a value s    
    -- we need to check if NULL
    SELECT @v_vchLotNumber = lot_number,
           @v_nAvailQty = afo_plan_qty
    FROM t_order_detail
    WHERE wh_id = @in_vchWarehouseId
        AND order_number = @v_vchOrderNumber
        AND line_number = @in_vchLineNumber
        AND item_number = @in_vchItemNumber
    
    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_UpdWDLFailed
        GOTO ErrorHandler
    END

    IF @v_nAvailQty < @in_nQuantity 
    BEGIN
        SET @out_vchMessage = 'ZERO QTY'
        GOTO ExitLabel
    END

    IF @v_vchLotNumber IS NULL
    BEGIN
        -- Count to see if record for the item/line exists
        SELECT @v_nRowCount = COUNT(*)
        FROM t_afo_wave_detail_line
        WHERE wave_detail_id = @in_vchWaveDetailId 
            AND item_number = @in_vchItemNumber 
            AND lot_number IS NULL
            AND line_number = @in_vchLineNumber
            AND wh_id = @in_vchWarehouseId

        SELECT @v_vchSqlErrorNumber = @@ERROR
    END
    
    IF @v_vchLotNumber IS NOT NULL
    BEGIN
        -- Count to see if record for the item/line exists
        SELECT @v_nRowCount = COUNT(*)
        FROM t_afo_wave_detail_line
        WHERE wave_detail_id = @in_vchWaveDetailId 
            AND item_number = @in_vchItemNumber 
            AND lot_number = @v_vchLotNumber
            AND line_number = @in_vchLineNumber
            AND wh_id = @in_vchWarehouseId

        SELECT @v_vchSqlErrorNumber = @@ERROR
    END
    -- Check for SQL Error
    IF  @@ERROR <> 0
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END

    
    -- Begin Insert Update
    IF  @v_nRowCount = 0 
        BEGIN -- Begin Insert
            --Then insert a new wave detail line (WDL) record
            INSERT INTO t_afo_wave_detail_line (wave_detail_id, wh_id, line_number, item_number, lot_number, planned_qty)
                VALUES (@in_vchWaveDetailId , @in_vchWarehouseId, @in_vchLineNumber, 
                         @in_vchItemNumber, @v_vchLotNumber, @in_nQuantity)
        
            SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
            BEGIN
                IF @v_vchSqlErrorNumber <> 0
                    SET @v_nErrorNumber = @e_GenSqlError
                ELSE
                    SET @v_nErrorNumber = @e_InsWDLFailed
                GOTO ErrorHandler			
            END
    
        END -- End Insert

    ELSE
        BEGIN -- Begin Update
            --Update planned quantity of an existing record
            UPDATE t_afo_wave_detail_line SET planned_qty = planned_qty + @in_nQuantity
                WHERE wave_detail_id = @in_vchWaveDetailId 
                    AND item_number = @in_vchItemNumber
                    AND (lot_number = @in_vchLotNumber OR lot_number IS NULL)
                    AND line_number = @in_vchLineNumber 
                    AND wh_id = @in_vchWarehouseId
            
            -- Be sure a row was updated
            SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
            BEGIN
                IF @v_vchSqlErrorNumber <> 0
                    SET @v_nErrorNumber = @e_GenSqlError
                ELSE
                    SET @v_nErrorNumber = @e_UpdWDLFailed
                GOTO ErrorHandler
            END
        END -- End Update

    -- Update the remaining Quantites in t_order for the line
    UPDATE t_order_detail 
    SET afo_plan_qty = (afo_plan_qty - @in_nQuantity),
        tran_plan_qty = CASE WHEN (ISNULL(@v_nAFACtl,0) = 2 AND tran_plan_qty = afo_plan_qty) 
                                             THEN (tran_plan_qty - @in_nQuantity) 
                                             ELSE tran_plan_qty 
                                        END
    WHERE wh_id = @in_vchWarehouseId
        AND order_number = @v_vchOrderNumber
        AND line_number = @in_vchLineNumber
        AND item_number = @in_vchItemNumber


    -- Be sure a row was updated
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_UpdOrdFailed
        GOTO ErrorHandler
    END

    IF @v_nTranCount = 0
        COMMIT TRANSACTION
  
    GOTO ExitLabel 

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    ELSE IF @v_nErrorNumber = @e_InsWDLFailed 
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Failed to Insert record into t_afo_wave_detail for '+
            'wave detail id ' + ISNULL(@in_vchWaveDetailId ,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afo_wave_detail'
        SET @v_nRaiseErrorNumber = 50002 -- Insert Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_UpdWDLFailed 
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Failed to Update a record in t_afo_wave_detail_line for '+
            'wave detail id ' + ISNULL(@in_vchWaveDetailId ,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afo_wave_detail_line'
        SET @v_nRaiseErrorNumber = 50002 -- Insert Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_UpdOrdFailed
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Unable to update record for Order ' + ISNULL(@v_vchOrderNumber,'(NULL)')+
            ', Item ' + ISNULL(@in_vchItemNumber,'(NULL)')+ ' in the t_order_detail table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_order_detail'
        SET @v_nRaiseErrorNumber = 50003 -- Update Failed Error
    END
    ELSE IF @v_nErrorNumber = @e_FindWVDFailed
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Unable to find record for Wave detail Id ' + 
			ISNULL(@in_vchWaveDetailId,'(NULL)') + ' in the t_afo_wave_detail table.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_afo_wave_detail'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
    END
    IF @v_nErrorNumber = @e_WaveMustBeHeld
    BEGIN
        -- Log Error    
        SET @v_vchLogMsg = 'Wave must be put on hold before adding items.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_wave_master'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
        -- Reset message after logged to return to optimizer
        SET @v_vchLogMsg = 'NOT ON HOLD'
    END


    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    -- Raiserror parameters: Error #, Severity(11=ADO requirement), State(1), Parameter(to be used in error)
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)        

ExitLabel:
    RETURN

