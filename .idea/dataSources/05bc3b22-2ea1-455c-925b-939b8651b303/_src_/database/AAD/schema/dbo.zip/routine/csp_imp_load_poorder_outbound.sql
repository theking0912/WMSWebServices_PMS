


CREATE  PROCEDURE [dbo].[csp_imp_load_poorder_outbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id varchar(100),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG varchar(100)
AS
BEGIN TRY
      --declare @client_no varchar(100)
	 /*//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //EKKO-EBELN	订单号
        //EKKO-BSART	订单类型
        //EKKO-LIFNR	供应商编码
        //EKKO-BEDAT	订单日期
        //EKET-EINDT    交货日期
        //T024-EKNAM	采购组
        //TCURT-KTEXT	货币
        //EKKO-INCO2	国际贸易条件
        //TVZBT-VTEXT	支付条件的描述
        //ZFLAG	        出入库标识
        //第二级
        //EKPO-EBELP	行号
        //EKPO-MATNR	物料号
        //EKPO-MENGE	订单数量
        //EKPO-MEINS	订单单位
        //EKPO-NETPR	净价
        //EKPO-PEINH	价格单位
        //T006A-MSEHT   价格单位描述
        //EKKO-RESWK	发货工厂
        //EKPO-RESLO	发货库存地点
        //EKPO-WERKS	收货工厂
        //EKPO-LGORT	收货库存地点
        //T001W-KUNNR   工厂的客户号
        //EKPO-UEBTO	过量交货
        //EKPO-UNTTO	交货不足
        //EKPO-LOEKZ	删除标识
        //EKPO-EKLIZ	交货已完成
        //EKPO-MWSKZ	税码
        //KONP-KBETR	税率	
        //第三级（委外）
        //MATNR	组件物料
        //ERFMG	需求数量
        //ERFME	单位
        //BDTER	需求日期*/
      declare @order_typeid int
	  declare @order_type varchar(100)
	  declare @ZPOSITION varchar(100)
      declare @EBELN varchar(100)
      declare @BSART varchar(100)
      declare @LIFNR varchar(100)
      declare @BEDAT varchar(100)
	  declare @EINDT varchar(100)
      --declare @ZFLAG varchar(100)

      declare @EBELP varchar(100)
      declare @MATNR varchar(100)
      declare @qty   varchar(100)
      declare @MEINS varchar(100)
      declare @NETPR varchar(100)
      declare @PEINH varchar(100)
      declare @RESWK varchar(100)
      declare @RESLO varchar(100)
      declare @WERKS varchar(100)
      declare @LGORT varchar(100)
	  declare @KUNNR varchar(100)
      declare @UEBTO varchar(100)
      declare @UNTTO varchar(100)
      declare @LOEKZ varchar(100)
      declare @EKLIZ varchar(100)
      declare @MWSKZ varchar(100)
      declare @MATNR2 varchar(100)
      declare @ERFMG varchar(100)
      declare @ERFME varchar(100)
      declare @BDTER varchar(100)
	  declare @customer_id varchar(100)
	  declare @customer_name varchar(100)
	  declare @customer_phone varchar(100)
	  declare @customer_fax varchar(100)
	  declare @customer_email varchar(100)
	  declare @cancel_flag varchar(100)

	  declare @EKNAM varchar(100)
	  declare @KTEXT varchar(100)
	  declare @INCO2 varchar(100)
	  declare @KBETR varchar(100)

	select top 1    @ZFLAG = ZFLAG 
						,@ZPOSITION= ZPOSITION
						,@BSART  = BSART
						,@LIFNR  = LIFNR
						,@BEDAT  = BEDAT
						,@EINDT  = isnull(EINDT,'')
						,@ZFLAG  = ZFLAG 
						,@MATNR  = MATNR
						,@qty  = MENGE
						,@MEINS  = MEINS
						,@NETPR  = NETPR
						,@PEINH  = PEINH
						,@RESWK  = RESWK
						,@RESLO  = RESLO
						,@WERKS  = WERKS
						,@LGORT  = LGORT
						,@KUNNR  = KUNNR
						,@UEBTO  = UEBTO
						,@UNTTO  = UNTTO
						,@LOEKZ  = LOEKZ
						,@EKLIZ  = EKLIZ
						,@MWSKZ  = MWSKZ
						,@MATNR2 = isnull(MATNR2,'')
						,@ERFMG  = ERFMG
						,@ERFME  = isnull(ERFME,'')
						,@BDTER  = isnull(BDTER,'')
						,@EKNAM  = EKNAM
						,@KTEXT  = KTEXT
	                   , @INCO2  = INCO2
					   , @KBETR  = KBETR
		  from  tbl_inf_imp_poorder   WITH(NOLOCK) 
		  where DATA_ID=@DataID and PROCESS_STATUS=@process_status
		         and EBELN=@order_no and EBELP=@line_no and ZFLAG=@ZFLAG

		  if  (@EINDT='' or @EINDT='00000000') set @EINDT=null 

		  if @EINDT=null
		  BEGIN
				if exists(select top 1 order_number  from  t_order_detail with(nolock)
								where order_number=@order_no  and date_expected >'1901-01-0100:00:00')
				BEGIN
					 select @EINDT=CONVERT(VARCHAR(10),MIN(date_expected),112)  
					 from t_order_detail with(nolock)
					 where order_number=@order_no  and date_expected >'1901-01-0100:00:00'
                end
		  end 	    
         
		  select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype   WITH(NOLOCK) 
		 where sap_ordertype=@BSART    and flag_inoutbound=@ZFLAG   

		 if (@LOEKZ='X') 
		 begin
		      set @cancel_flag='Y'
		 end
		 else 
		      set @cancel_flag='N'

		if (@KUNNR<>'')
		begin
				select top 1 @customer_id=customer_id ,
						     @customer_name=customer_name,
							 @customer_phone=customer_phone,
							 @customer_email=customer_email,
							 @customer_fax=customer_fax
				from t_customer   WITH(NOLOCK) 
				where rtrim(customer_code)=@KUNNR 
				and wh_id=@wh_id 

				if  (@KUNNR='300243')
				begin
					set  @order_typeid=5265
					set  @order_type='AO'  --员工申购
				end
		END 


		 /* 
		 if (@BSART='MD')
		begin
			select top 1 @customer_id=customer_id ,
						 @customer_name=customer_name,
						 @customer_phone=customer_phone,
					     @customer_email=customer_email,
						 @customer_fax=customer_fax
			from t_customer   WITH(NOLOCK) 
			where rtrim(customer_code)=@WERKS
 
		END
		else
		begin
		   if (@KUNNR<>'')
		   begin
				select top 1 @customer_id=customer_id ,
						     @customer_name=customer_name,
							 @customer_phone=customer_phone,
							 @customer_email=customer_email,
							 @customer_fax=customer_fax
				from t_customer   WITH(NOLOCK) 
				where rtrim(customer_code)=@KUNNR
			END 
		end 
		*/
	/*text	description
		CANCELLED	已取消
		LOADED	已装载
		NEW	新建
		PACKED	已包装
		PICKED	已拣货
		RELEASED	波次释放
		SHIPPED	已发货
		STAGED	准备包装
		WAVED	已建波次*/

    IF rtrim(@LIFNR)='' set @LIFNR=null
	--print @EINDT
    if not exists(select top 1 order_number from t_order with(nolock) where order_number=@order_no)
	    insert into t_order(  [wh_id]
							  ,[order_number]
							  ,[type_id]
							  ,[order_type]
							  ,[display_order_number]
							  ,[order_date]
							 ,[customer_id]
							 ,[customer_name]
							  ,[client_code]
							  ,[status]
							  ,[lock_flag]
							  ,sap_ordertype
							  ,vendor_code
							  ,earliest_ship_date
							  )
					values (     @wh_id
					            ,@order_no
					            ,@order_typeid
								,@order_type
								,@order_no
								,cast(@BEDAT as date)
								 , @customer_id 
								 , @customer_name 
								,@client_code
								,'NEW'
								,'N'
								,@BSART
								,@LIFNR
								,cast(@EINDT as date)
					         )
	else
		   update t_order 
		   set       type_id=@order_typeid,
		             order_type=@order_type,
					 order_date=cast(@BEDAT as date)
					 ,customer_id=@customer_id 
					 ,customer_name=@customer_name
					 ,client_code=@client_code
					 ,sap_ordertype=@BSART
					 ,vendor_code=@LIFNR
					 ,earliest_ship_date= cast(@EINDT as date) 
		   from  t_order with(nolock)
		   where  order_number=@order_no  and isnull(@LOEKZ,'')<>'X'


		declare @stored_attribute_id bigint
		declare @uom nvarchar(30)
		set @uom=@MEINS
		if exists( select top 1 item_number from t_item_master  WITH(NOLOCK) where item_number=@client_code+'-'+@MATNR  and wh_id=@wh_id and pack_flag='Y')
		begin
			SELECT @stored_attribute_id=CONVERT(INT,tscd.stored_attribute_id)
			FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
			INNER JOIN 
			(SELECT TOP 1 tacd.attribute_id,tiu.uom_prompt, tacd.attribute_collection_id  FROM t_item_master tim WITH(NOLOCK) 
			INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK) 
			ON tim.attribute_collection_id = tacd.attribute_collection_id
			INNER JOIN t_item_uom tiu WITH(NOLOCK)
			ON tim.wh_id = tiu.wh_id
			AND tim.item_number = tiu.item_number
			WHERE tim.item_number = @client_code+'-'+@MATNR
			AND tim.wh_id = @wh_id
			AND tiu.uom = @uom) a
			ON tscd.attribute_id = a.attribute_id
			AND tscd.attribute_value = a.uom_prompt
			 INNER JOIN t_sto_attrib_collection_master tscm
       on tscd.stored_attribute_id=tscm.stored_attribute_id and tscm.attribute_collection_id=a.attribute_collection_id
		end 


	--DEAL WITH SEND/RECEIVE FACTORY
	declare @storage_location1 nvarchar(30)  --SEND FACTORY     (1.RESWK/2.WERKS)
	declare @storage_location2 nvarchar(30)  --RECEIVE FACTORY  (1.WERKS/2.LGORT)
	IF(@RESWK<>'')  select @storage_location1=@WERKS, @storage_location2=@RESWK
	IF(@RESWK='')   select @storage_location1=@LGORT, @storage_location2=@WERKS

 
	if not exists(select top 1  order_number  from t_order_detail  WITH(NOLOCK)  where  order_number=@order_no and line_number=@line_no)
	BEGIN   
		IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
		WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
		BEGIN
			insert into #returnresult values(-202,N'fail',N'订单已经加入波次，不允许新增行明细') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
			return 
		END
		ELSE
		BEGIN
			insert into  t_order_detail([wh_id]
								,[order_number]
								,[line_number]
								,[item_number]
								,[qty]
								,[order_uom]
								,stored_attribute_id
							--  ,[tax_rate]
								,[storage_location]
								-- ,[price]
							--  ,[price_uom]
								--,[parent_line_number]
								,factory
								,cancel_flag
								,date_expected
								)
							values(@wh_id,
									@order_no,
									@line_no,
									@client_code+'-'+@MATNR,
									cast(@qty as float),
									@MEINS,
									@stored_attribute_id,
								-- @MWSKZ,
									@storage_location1, -- @RESLO, /*2015.01.09 @RESLO replace with @RESWK */
								-- @NETPR,
								--	 @PEINH,
								-- 0,
									@storage_location2,
									@cancel_flag
									,CAST(@EINDT  as DATE)
									)
		END
	END
	else 
	BEGIN
		IF @cancel_flag = 'Y'
		BEGIN
			update t_order_detail
			set  cancel_flag=@cancel_flag
			where  order_number=@order_no and line_number=@line_no
		END
		ELSE
		BEGIN
			IF EXISTS(SELECT 1 FROM t_order WITH(NOLOCK)
			WHERE order_number=@order_no and status <> 'NEW')--Modify by George 2016/3/30,Add order_number condition	
			BEGIN
				insert into #returnresult values(-202,N'fail',N'已加入波次，未打删除标记，不允许修改') --Modify by George 2016/3/30,Check order status if status is not NEW then return fail to SAP		
				return 
			END
			ELSE
			BEGIN
				update t_order_detail
				set  [wh_id]=@wh_id
					,[item_number]=@client_code+'-'+@MATNR
					,[qty]=@qty
					,[order_uom]=@MEINS
					,stored_attribute_id=@stored_attribute_id
					--,[tax_rate]=@MWSKZ
					,[storage_location]= @storage_location1
					--,[price]=@NETPR
					--,[price_uom]=@PEINH
					--,[parent_line_number]
					,factory=@storage_location2
					,cancel_flag=@cancel_flag
						,date_expected= @EINDT 
				where  order_number=@order_no and line_number=@line_no
			END
		END	
	END		
	insert into #returnresult values(1,N'OK',N'PO Outbound成功.')

END TRY
BEGIN CATCH
	--ROLLBACK TRANSACTION
	DECLARE @error NVARCHAR(100)
    SET @error=N'执行异常(ROW):'+substring(ERROR_MESSAGE(),1,90)
	delete from #returnresult
	insert into #returnresult values(-101,N'fAILE',@error)
END CATCH



