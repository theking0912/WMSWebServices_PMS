



CREATE PROCEDURE [dbo].[csp_OST_DestLoc_Check] 
     @wh_id NVARCHAR(10) 
	,@location_id nvarchar(30)
	,@item_number NVARCHAR(30) 
	,@lot_number nvarchar(30) 
	,@passornot bigint OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from    
	SET NOCOUNT ON;	

	IF NOT EXISTS ( SELECT 1 FROM t_location loc inner join t_zone_loca loca on loca.wh_id=loc.wh_id and  loc.location_id = loca.location_id--------------------will  add  20160804
		                                         inner join t_zone zon on zon.wh_id=loca.wh_id and zon.zone=loca.zone--------------------will  add  20160804
					where loc.wh_id = @wh_id
				AND loc.location_id = @location_id
				AND zon.zone_type='N'---------------will  add 20160804
				and loc.type IN ('P','L','H','C','B','Z'))
	BEGIN
		set @passornot = 1
		RETURN
	END

	IF EXISTS(SELECT 1 FROM tbl_allocation 
				where wh_id = @wh_id
				AND location_id = @location_id
				AND item_number=@item_number------------------will  add  20160804
				and status<>'C')
	BEGIN
		set @passornot = 1
		return
	END
	---------------WILL  add  20160809  s------------------------------
	IF EXISTS (SELECT 1 FROM t_location with (nolock) where wh_id = @wh_id AND location_id = @location_id and type in ('C','B','Z'))
	BEGIN
	IF NOT EXISTS(SELECT 1 FROM tbl_loc_item 
				where wh_id = @wh_id
				AND location_id = @location_id
				and item_number = @item_number )
	BEGIN
		set @passornot = 1
		return
	END
	END
 ---------------WILL  add  20160809  e------------------------------
	IF EXISTS( SELECT 1 FROM t_stored_item sto
				inner join t_location loc on sto.wh_id = loc.wh_id
								and sto.location_id = loc.location_id
				WHERE sto.wh_id = @wh_id
				and sto.location_id = @location_id
				and loc.type in ('P','L','H')
				AND item_number=@item_number------------------will  add  20160804
				and isnull(sto.lot_number,'') <> isnull(@lot_number,''))
	begin
		set @passornot = 1
		return 
	end

	IF EXISTS( SELECT 1 FROM t_stored_item sto
				WHERE sto.wh_id = @wh_id
				and sto.location_id = @location_id
				and sto.status <>'A'
				and sto.damage_flag='N'---------------will  add   20160804
				and sto.item_number  =@item_number)
	begin
		set @passornot = 1
		return 
	end

	SET @passornot = 0
	RETURN	
END





