CREATE PROCEDURE [dbo].[usp_create_topoff_replens]
@in_vchBeginLoc      NVARCHAR(50),
@in_vchEndLoc        NVARCHAR(50),
@in_vchWhID          NVARCHAR(10),
@in_nLocaleID        INT
AS

DECLARE
-- Error handling and logging variables.
@c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
@c_nFileNumber              INT, -- The # that uniquely tags this object.
@c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
@v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
@v_nLogLevel                INT, -- Holds log level (1-5).
@v_vchErrorMsg              NVARCHAR(500),
@v_nSysErrorNum             INT,
@v_nSysRowCount             INT,
@v_nReturn                  INT,
@v_nCount                   INT,
@v_nTranCount               INT,

-- Log Error numbers used for branching in the Error Handler.
@e_GenSqlError              INTEGER,
@e_SprocError               INTEGER,
@e_InsPKDFailed             INTEGER,
@e_GetNextFailed            INTEGER,
@e_InvalidItem              INTEGER,
@e_InvalidItemUoM           INTEGER,
@e_InvalidLocation          INTEGER,
@e_InvalidType              INTEGER,

-- Local Variables
@v_nSequence                INTEGER,
@v_nNumRecords              INTEGER,
@v_vchItemNumber            NVARCHAR(30),
@v_vchDestLocation          NVARCHAR(50),
@v_nReplenQty               INTEGER,
@v_vchWhID                  NVARCHAR(10),
@v_vchType                  NVARCHAR(10),
@v_vchUOM                   NVARCHAR(10),
@v_vchCalcFlag              NVARCHAR(3),
@v_nQty                     INTEGER,
@v_nMaxQty                  INTEGER,
@v_nStoredAttributeID       BIGINT,
@v_chWorkType               NVARCHAR(2)

SET NOCOUNT ON
-- Set constant values.
SET @c_vchObjName = 'usp_create_topoff_replens'
SET @e_GenSqlError = 1
SET @e_SprocError = 2
SET @e_InsPKDFailed = 3
SET @e_GetNextFailed = 4
SET @e_InvalidItem = 5
SET @e_InvalidItemUoM = 6
SET @e_InvalidLocation = 7
SET @e_InvalidType = 8

-- Set local constant value
SET @v_vchType = 'TOPOFF'

-----------------------------------------------------------------------------------
--                     Build Temp Table for Top Off Candidates
-----------------------------------------------------------------------------------

CREATE TABLE #t_topoff_replenishments
(
   sequence        INTEGER IDENTITY,     
   item_number     NVARCHAR(30) COLLATE DATABASE_DEFAULT ,
   dest_location   NVARCHAR(30) COLLATE DATABASE_DEFAULT ,
   uom             NVARCHAR(10) COLLATE DATABASE_DEFAULT ,
   stored_attribute_id   BIGINT NULL
)
-----------------------------------------------------------------------------------
--                     Find and Insert Top Off Candidates                  
-----------------------------------------------------------------------------------


INSERT INTO #t_topoff_replenishments  (item_number, dest_location, uom, stored_attribute_id)

SELECT
    fwd.item_number,  
    fwd.location_id, 
    fwd.uom,
    fwd.stored_attribute_id
FROM t_fwd_pick fwd
        LEFT OUTER JOIN t_stored_item sto
        ON fwd.location_id = sto.location_id
            AND fwd.item_number = sto.item_number
            AND fwd.stored_attribute_id = sto.stored_attribute_id
WHERE 
    fwd.location_id BETWEEN @in_vchBeginLoc AND @in_vchEndLoc
    AND fwd.wh_id = @in_vchWhID
    AND (fwd.maximum_replenishment_qty >= ISNULL(sto.actual_qty,0))
ORDER BY fwd.location_id

-----------------------------------------------------------------------------------
--                     Cycle through Temp Table
-----------------------------------------------------------------------------------

SELECT @v_nNumRecords = COUNT(*)
  FROM #t_topoff_replenishments

SET @v_nSequence = 1
WHILE @v_nSequence <= @v_nNumRecords
BEGIN

    SELECT TOP 1
        @v_vchItemNumber = item_number,
        @v_vchDestLocation = dest_location,
        @v_vchUOM = uom,
        @v_nStoredAttributeID = stored_attribute_id
    FROM
        #t_topoff_replenishments
    WHERE
        sequence = @v_nSequence
    ORDER BY
        item_number

    SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
    IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
    END

    EXECUTE @v_nReturn = usp_generate_replen  
                @v_vchItemNumber,
                @v_nStoredAttributeID,
                @v_vchUOM, 
                @v_vchDestLocation, 
                @in_vchWhID, 
                @v_vchType,
				@in_nLocaleID
            IF @v_nReturn <> 0 -- A zero means success.
            BEGIN
                SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
                    ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
                SET @v_nLogErrorNum = @e_SprocError
                GOTO ERROR_HANDLER
            END
        
    -- Print a trace level log message.
    IF @v_nLogLevel >= 5
    BEGIN
        PRINT 'TopOff replenishment request created in t_pick_detail.'
        SELECT * FROM t_pick_detail WHERE status = 'CREATED'
    END

    SET @v_nSequence = @v_nSequence + 1

END -- WHILE @nSequence <= @nNumRecords

DROP TABLE #t_topoff_replenishments

GOTO EXIT_LABEL
-----------------------------------------------------------------------------------
--                            Error Handling Code
-----------------------------------------------------------------------------------
ERROR_HANDLER:
-- Log the error message in ADV.t_log
EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

-- Raise the error with error message, severity, state
SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
    + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
    + ' ERROR [' + @v_vchErrorMsg + ']'
RAISERROR(@v_vchErrorMsg, 11, 1)

SET @v_nReturn = @v_nLogErrorNum

IF @v_nTranCount > 0
    ROLLBACK TRANSACTION

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:
RETURN

