
CREATE PROCEDURE usp_PkLstQtyFIFO
	@in_vchPickPutID	NVARCHAR(15)

AS
-- *******************************************************************************
-- Stored Procedure: usp_PkLstQtyFIFO
-- *******************************************************************************
-- Database Name: AAD
-- Database User Name: dbo
-- *******************************************************************************
--
--  The purpose of this stored procedure is to Pick to Clean then FIFO
--
--  Notes:
--  In short, when each sproc called, a list of rules are built in a temporary RuleSet table
--  for each item, based on the itu.pick_put_id field.  Each rule, executes another
--  sproc which finds a location (and sometimes additional information) and returns to the parent
--  sproc which updates the appropriate field.
--
--  If the location is to be returned to the application, the t_employee.sp_return field is
--  updated, thus allowing the application to select this result immediately following.
--  
--  Output:
--	
--  Target:
--	    SQL Server
--
-- ********************************************************************************
--                          Copyright ⌐ 2003-2013.
--                           All Rights Reserved.
--                            HighJump Software
--                         Minneapolis, Minnesota, USA
-- ********************************************************************************
DECLARE 
	@c_vchLocTypes	NVARCHAR(30),
	@c_nStorageType	INT

-- Set Constants
SET @c_nStorageType = 0

SET NOCOUNT ON

-- Check the type of PKD. Either it's a 'PP'(Planned Pick), then include X and P type locations,
-- otherwise assume, for now, it's an 'RP' (Replenishments), where X and P shouldn't be considered
-- locations to pick from. (X = Crossdock and P = Forward Pick)
IF (SELECT TOP 1 type
    FROM  #tmp_pick_details_to_update) = 'PP'
    SET @c_vchLocTypes = 'XPASMI'
ELSE SET @c_vchLocTypes = 'ASMI'

/* Load all qualifying locations into the temporary table in optimal order */
INSERT INTO #tmp_locations_found ( pick_id, location_id, picking_flow, pick_area, work_type, stored_attribute_id )
  SELECT dtu.pick_id, loc.location_id, RIGHT( '000' + RTRIM(ISNULL(loc.picking_flow,'0')), 3 ),
         loc.pick_area, pka.work_type, dtu.stored_attribute_id
    FROM #tmp_pick_details_to_update dtu
    INNER JOIN t_stored_item sto WITH (NOLOCK)
       ON sto.wh_id = dtu.wh_id
      AND sto.item_number = dtu.item_number
    INNER JOIN t_location loc WITH (NOLOCK)
       ON loc.wh_id = sto.wh_id
      AND loc.location_id = sto.location_id
    INNER JOIN t_pick_area pka WITH (NOLOCK)
       ON pka.wh_id = loc.wh_id
      AND pka.pick_area = loc.pick_area
    WHERE dtu.pick_put_id = @in_vchPickPutID
      AND (dtu.lot_number IS NULL OR dtu.lot_number = sto.lot_number)
      AND CHARINDEX(loc.type,@c_vchLocTypes) > 0
      AND loc.status <> 'I'
      AND (sto.actual_qty - sto.unavailable_qty) <= dtu.pick_quantity
      AND (sto.actual_qty - sto.unavailable_qty) > 0
      AND sto.type = @c_nStorageType
      AND sto.status = 'A'
      AND (sto.stored_attribute_id = dtu.stored_attribute_id
           OR dtu.stored_attribute_id IS NULL
           OR EXISTS (SELECT fnc.stored_attribute_id
                          FROM usf_get_pick_attribute_id(dtu.item_number, dtu.stored_attribute_id) fnc
                          WHERE fnc.stored_attribute_id = sto.stored_attribute_id)
          )
      AND dtu.location_id is NULL
    ORDER BY CHARINDEX( loc.type, 'XPASMI'), loc.user_count, sto.actual_qty, sto.fifo_date, loc.picking_flow, loc.location_id 

/* Skim off the optimal locations (the ones with the lowest seq) */
SELECT pick_id, MIN(seq) as seq
  INTO #tmp_best_locations
  FROM #tmp_locations_found
  GROUP BY pick_id

/* Update the the temp table with the results */
UPDATE #tmp_pick_details_to_update
  SET location_id = locf.location_id,
      picking_flow = locf.picking_flow,
      pick_location = locf.location_id,
      pick_area = locf.pick_area, 
      work_type = locf.work_type,
      stored_attribute_id = locf.stored_attribute_id
  FROM #tmp_pick_details_to_update dtu
  INNER JOIN #tmp_locations_found locf
     ON locf.pick_id = dtu.pick_id
  INNER JOIN #tmp_best_locations bloc
     ON bloc.pick_id = locf.pick_id
    AND bloc.seq = locf.seq
WHERE dtu.pick_put_id = @in_vchPickPutID

--Exit
RETURN
