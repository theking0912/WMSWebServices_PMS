
CREATE PROCEDURE usp_PkOneLotLIFO
	@in_vchPickPutID	NVARCHAR(15)
AS

-- *******************************************************************************
--                          Copyright ⌐ 2003-2013.
--                           All Rights Reserved.
--                            HighJump Software
--                        Minneapolis, Minnesota, USA
-- ********************************************************************************
--
--  The purpose of this stored procedure is to select one lot that can complete 
--      the entire pick.
--
--  Notes:
--	In short, when each sproc called, a list of rules are built in a temporary RuleSet table
--  for each item, based on the itu.pick_put_id field.  Each rule, executes another
--  sproc which finds a location (and sometimes additional information) and returns to the parent
--  sproc which updates the appropriate field.
--
--  If the location is to be returned to the application, the t_employee.sp_return field is
--  updated, thus allowing the application to select this result immediately following.
--	
--  Target:
--	    SQL Server
--
-- ********************************************************************************
DECLARE 
    @c_vchLocTypes	    NVARCHAR(30),
    @c_nStorageType	    INT,
    @n_RowCount         INT
	
-- Set Constants
SET @c_nStorageType = 0

-- Check the type of PKD. Either it's a 'PP'(Planned Pick), then include X and P type locations,
-- otherwise assume, for now, it's an 'RP' (Replenishments), where X and P shouldn't be considered
-- locations to pick from. (X = Crossdock and P = Forward Pick)
IF (SELECT TOP 1 type
    FROM #tmp_pick_details_to_update) = 'PP'
    SET @c_vchLocTypes = 'XPASMI'
ELSE SET @c_vchLocTypes = 'ASMI'

SELECT @n_RowCount = COUNT(*)
  FROM #tmp_pick_details_to_update dtu
  WHERE dtu.lot_number IS NULL

IF @n_RowCount > 0 
BEGIN
	/* Load all qualifying locations into the temporary table in optimal order */
	INSERT INTO #tmp_locations_found ( pick_id, location_id, picking_flow, pick_area, work_type, 
        stored_attribute_id, lot_number )
    SELECT dtu.pick_id, loc.location_id, RIGHT( '000' + RTRIM(ISNULL(loc.picking_flow,'0')), 3 ),
         loc.pick_area, pka.work_type, dtu.stored_attribute_id, sto.lot_number
	FROM #tmp_pick_details_to_update dtu
	INNER JOIN t_stored_item sto WITH (NOLOCK)
		ON sto.wh_id = dtu.wh_id
		AND sto.item_number = dtu.item_number
	INNER JOIN t_location loc WITH (NOLOCK)
		ON loc.wh_id = sto.wh_id
		AND loc.location_id = sto.location_id
    INNER JOIN t_pick_area pka WITH (NOLOCK)
        ON pka.wh_id = loc.wh_id
        AND pka.pick_area = loc.pick_area
	INNER JOIN 
		(SELECT sto2.item_number, sto2.wh_id, sto2.location_id,
			  sto2.stored_attribute_id, sto2.lot_number,
			  SUM(sto2.actual_qty - sto2.unavailable_qty) AS available_qty
           FROM t_stored_item sto2 WITH (NOLOCK)
           INNER JOIN t_location loc2 WITH (NOLOCK)
              ON loc2.location_id = sto2.location_id
             AND loc2.wh_id = sto2.wh_id
           WHERE CHARINDEX(loc2.type,@c_vchLocTypes) > 0
             AND loc2.status <> 'I'
             AND (sto2.actual_qty - sto2.unavailable_qty) > 0
             AND sto2.type = @c_nStorageType
             AND sto2.status = 'A'
		   GROUP BY sto2.item_number, sto2.wh_id, sto2.location_id,
			  sto2.stored_attribute_id, sto2.lot_number) tmp
        ON tmp.wh_id = sto.wh_id
        AND tmp.item_number = sto.item_number
        AND tmp.lot_number = sto.lot_number
        AND tmp.location_id = sto.location_id
        AND ISNULL(tmp.stored_attribute_id, -1) = ISNULL(sto.stored_attribute_id, -1)
        AND dtu.pick_quantity <= tmp.available_qty
	WHERE dtu.pick_put_id = @in_vchPickPutID
		AND CHARINDEX(loc.type, @c_vchLocTypes) > 0
		AND loc.status <> 'I'
		AND (sto.actual_qty - sto.unavailable_qty) > 0
		AND sto.type = @c_nStorageType
		AND sto.status = 'A'
        AND (sto.stored_attribute_id = dtu.stored_attribute_id
            OR dtu.stored_attribute_id IS NULL
            OR EXISTS (SELECT fnc.stored_attribute_id
                  FROM usf_get_pick_attribute_id(dtu.item_number, dtu.stored_attribute_id) fnc
                  WHERE fnc.stored_attribute_id = sto.stored_attribute_id)
            )
		AND dtu.lot_number IS NULL
        AND dtu.location_id IS NUll
	ORDER BY sto.fifo_date DESC, loc.picking_flow, loc.location_id 
   
   /* Skim off the optimal locations (the ones with the lowest seq) */
   SELECT pick_id, MIN(seq) as seq
     INTO #tmp_best_locations
     FROM #tmp_locations_found
     GROUP BY pick_id
         
   /* Update the the temp table with the results */
    UPDATE #tmp_pick_details_to_update
        SET location_id = locf.location_id,
          picking_flow = locf.picking_flow,
          pick_location = locf.location_id,
          pick_area = locf.pick_area, 
          work_type = locf.work_type,
          stored_attribute_id = locf.stored_attribute_id,
          lot_number = locf.lot_number
    FROM #tmp_pick_details_to_update dtu
    INNER JOIN #tmp_locations_found locf
        ON locf.pick_id = dtu.pick_id
    INNER JOIN #tmp_best_locations bloc
        ON bloc.pick_id = locf.pick_id
        AND bloc.seq = locf.seq
    WHERE dtu.pick_put_id = @in_vchPickPutID
    
    /* Update the PKD Lot number with the choice */
    UPDATE pkd
        SET lot_number = dtu.lot_number
    FROM t_pick_detail pkd 
    INNER JOIN #tmp_match_update upd
        ON upd.original_id = pkd.pick_id
    INNER JOIN #tmp_pick_details_to_update dtu
        ON dtu.pick_id = upd.new_id
END

--Exit
RETURN
