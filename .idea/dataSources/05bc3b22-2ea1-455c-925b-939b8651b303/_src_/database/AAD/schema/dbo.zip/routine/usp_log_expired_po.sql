
CREATE PROCEDURE usp_log_expired_po
    @in_vchType         NVARCHAR(5),
    @in_vchWhID         NVARCHAR(10),
    @out_vchMessage     NVARCHAR(200) OUTPUT, -- Contains "SUCCESS" or the message to be displayed.
    @out_vchLogMessage  NVARCHAR(100) OUTPUT

AS
DECLARE
    -- Error handling variables
    @c_vchObjName               NVARCHAR(30),  -- The name that uniquely tags this object.
    @v_nLogLevel                INTEGER,      -- Holds log level (1-5).
    @v_vchSqlErrorNumber        NVARCHAR(50),
    @v_nRowCount                INTEGER,
    @v_vchMessage               NVARCHAR(500), -- Used to bubble up messages from child sprocs.
    @v_nReturn                  INTEGER,

    -- Local Variables
    @v_nCount                   INTEGER,
    @v_nExpirationDays          INTEGER,
    @v_nReminderDays            INTEGER

    -- Tables
    DECLARE @tblExpiredPOs TABLE
        (
        wh_id         NVARCHAR(10),
        po_number     NVARCHAR(30),
        description   NVARCHAR(50)
        UNIQUE (wh_id, po_number)
        )

    -- Set Constants
    SET @c_vchObjName = 'usp_log_expired_po'

    -- Intialize Variables
    SET @v_nReturn = 0
    SET @out_vchMessage = 'SUCCESS'
    SET @out_vchLogMessage = 'NONE'
    
    SET NOCOUNT ON

    -- If this logging feature is not used, remove the following paragraph.
    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @out_vchMessage = '-20001'
        SET @out_vchLogMessage = '(1)An SQL error occurred in a stored procedure with a return code of [' +
    	    ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '].'
        GOTO ERROR_HANDLER
    END

-----------------------------------------------------------------------------------
--                    Grab days of expiration from t_control.
-----------------------------------------------------------------------------------

SELECT
    @v_nExpirationDays = next_value,
    @v_nReminderDays = f1
FROM
    t_control
WHERE
    control_type = 'EXPIRED_PO_DAYS';

SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
IF @v_vchSqlErrorNumber <> 0
BEGIN
    SET @out_vchMessage = '-20002'
    SET @out_vchLogMessage = '(2) A SQL error occured while retrieving t_control record.'
    GOTO ERROR_HANDLER
END

IF @v_nRowCount = 0
BEGIN
    SET @out_vchMessage = '-20003'
    SET @out_vchLogMessage = '(3) Missing control_type = "EXPIRED_PO_DAYS" in t_control. '
                              + 'Add it and run again.'
    GOTO ERROR_HANDLER
END

IF @v_nLogLevel >= 5
BEGIN
    SELECT 'Expiration Days from t_control.next_value: ' + CONVERT(VARCHAR(10),@v_nExpirationDays)
    SELECT 'Reminder Days from t_control.f1: ' + CONVERT(VARCHAR(10),@v_nReminderDays)
END
-----------------------------------------------------------------------------------
--                     Determine all purchase orders not closed.
-----------------------------------------------------------------------------------

INSERT INTO
    @tblExpiredPOs
SELECT DISTINCT
    pom.wh_id,
    pom.po_number,
    'Purchase order not closed.'
FROM
    t_po_master pom
WHERE
    pom.status <> 'C' -- C = "closed"
    AND (pom.create_date + @v_nExpirationDays) < GETDATE()
    AND pom.wh_id = ISNULL(@in_vchWhID, pom.wh_id)
    AND NOT EXISTS
        (SELECT 1 FROM @tblExpiredPOs
            WHERE po_number = pom.po_number
                AND wh_id = pom.wh_id)
    
SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
IF @v_vchSqlErrorNumber <> 0
BEGIN
    SET @out_vchMessage = '-20004'
    SET @out_vchLogMessage = '(4) A SQL error occured while retrieving t_po_master records that have '
                          + 'not been closed.'
    GOTO ERROR_HANDLER
END   

-----------------------------------------------------------------------------------
--                              Log Exceptions
-----------------------------------------------------------------------------------

INSERT INTO t_exception_log
    (
    tran_type, wh_id, description, control_number,
    exception_date, exception_time
    )
SELECT
    @in_vchType, tbl.wh_id, tbl.description, tbl.po_number,
    GETDATE(), GETDATE()
FROM
    @tblExpiredPOs tbl
WHERE NOT EXISTS
    (SELECT 1 FROM t_exception_log xlg
        WHERE xlg.tran_type = @in_vchType
            AND xlg.exception_date + @v_nReminderDays > GETDATE()
            AND xlg.control_number = tbl.po_number
            AND xlg.wh_id = tbl.wh_id)

SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
IF @v_vchSqlErrorNumber <> 0
BEGIN
    SET @out_vchMessage = '-20005'
    SET @out_vchLogMessage = '(5) A SQL error occured while inserting t_exception records.'
    GOTO ERROR_HANDLER
END

IF @v_nRowCount > 0
    SET @out_vchLogMessage = 'Generated exception log records for [' + CONVERT(VARCHAR(10), @v_nRowCount)
                              + '] PO(s) past the expected close date.'

SET @out_vchMessage = 'SUCCESS'
    
GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:

    SET @out_vchLogMessage = @c_vchObjName + ': ' + @out_vchLogMessage + ' SQL Error = '
                          + @v_vchSqlErrorNumber

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

    -- Always leave the stored procedure from here.
    RETURN
