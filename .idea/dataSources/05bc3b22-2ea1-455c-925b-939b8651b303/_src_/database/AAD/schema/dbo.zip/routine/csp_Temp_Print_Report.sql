CREATE PROCEDURE  [dbo].[csp_Print_Report]
    @in_WarehouseID     nvarchar(20),
    @in_ParameKey       nvarchar(255),	
    @in_Station         nvarchar(100),
	@in_PrintType       nvarchar(50),
    @in_Carrier         nvarchar(100),
	@in_Client         nvarchar(100),
	@in_User            nvarchar(50),
	@out_Result         int out,
	@out_ErrMess        nvarchar(150) out
AS
 DECLARE      
        @v_nError               INT,      
        @v_nRowCount            INT
	
	SET @out_Result=0
	set @out_ErrMess='Success' 
    update tbl_print_history set status='Complete'
	where wh_id=@in_WarehouseID and  paramekey=@in_ParameKey
	and station=@in_Station and printtype=@in_PrintType
      
    SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT

    IF @v_nRowCount = 0 OR @v_nError <> 0
    BEGIN
	   set @out_Result=-1
	   set  @out_ErrMess='Failed'
      RETURN 
    END
  
RETURN
