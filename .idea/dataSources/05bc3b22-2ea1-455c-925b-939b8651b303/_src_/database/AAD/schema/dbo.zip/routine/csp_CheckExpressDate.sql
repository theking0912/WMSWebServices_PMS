


    
CREATE  PROCEDURE [dbo].[csp_CheckExpressDate] 
	@lot_number NVARCHAR(50) = '', 
	@expiration_date NVARCHAR(50),
	@item_number NVARCHAR(50),
	@out_passornot NVARCHAR(1) OUTPUT, --0:Pass 1: Fail
    @out_msg NVARCHAR(200) OUTPUT
AS
	BEGIN
		SET  NOCOUNT ON;

		--定义局部变量
		DECLARE @result AS INT = 0
		DECLARE @num1_date	AS INT = 0
		DECLARE @num2_date	AS INT = 0
		DECLARE @num3_date	AS INT = 0
		DECLARE @lot_number_min NVARCHAR(50) -------------------will  add 20160805
		SET @out_passornot = 0
	    BEGIN TRY
			BEGIN TRAN
        
            BEGIN
				IF(ISNULL(@lot_number, '') = '')
				BEGIN
					SET @lot_number = CONVERT(NVARCHAR(60), CONVERT(DATETIME,@expiration_date), 112);
                END
				--查询出有效日期总天数
				SELECT TOP 1 @result = ISNULL(shelf_life, 0) FROM dbo.t_item_master WITH(NOLOCK) WHERE item_number = @item_number AND expiration_date_control = 'Y'; 
				IF(@result > 0)
				BEGIN
					--2/3过期天数 = 总天数 * 三分之二
					--SELECT @num1_date = (ROUND(@result * 2 / 3 - 1,0));
					SELECT @num1_date = (ceiling(@result * 2.0 / 3.0 - 1));
					--1/2过期天数 = 总天数 * 二分之一
					--SELECT @num3_date = (ROUND(@result * 1 / 2 - 1,0));
					SELECT @num3_date = (ceiling(@result * 1.0 / 2.0 - 1));
					--SELECT @num1_date = (ROUND(@result,0));  ----will add
					--已过期天数 = 今天日期 - 生产日期
					SELECT @num2_date = DATEDIFF(DAY,CONVERT(DATETIME, @expiration_date), GETDATE());
					--如果已过期天数大于等于0，则不进入判断

					

					IF(@num2_date < 0)
					BEGIN
						ROLLBACK
						SET @out_msg = '生产日期不能大于今天！';
						SET @out_passornot = 1;
						RETURN
					END

					IF(@num2_date >= @result - 1)
					BEGIN
					    ROLLBACK 
						SET @out_msg = '已超保质期！';----will add 
						SET @out_passornot = 1;
						RETURN
					END
	-------------------------MODIFY WILL 20160805 S-------------------------------------				
					--IF EXISTS(SELECT 1 FROM t_stored_item WITH(NOLOCK)
					--				WHERE item_number = @item_number
					--					AND SUBSTRING(lot_number,1,8) > SUBSTRING(@lot_number,1,8))
					--BEGIN
					--	ROLLBACK
					--	SET @out_msg = '小于最老批次！';
					--	SET @out_passornot = 4;
					--	RETURN
					--END

					SELECT top 1 @lot_number_min= SUBSTRING(item.lot_number,1,8) FROM t_stored_item item WITH(NOLOCK) inner join t_location loc WITH(NOLOCK) 
                                             on loc.wh_id=item.wh_id and loc.location_id=item.location_id 									
									        WHERE item.item_number = @item_number
											and item.type=0
											--and item.status ='A'
											and item.damage_flag ='N'
											and loc.type in ('P','L','H','B','Z','C')
									        ORDER BY SUBSTRING(item.lot_number,1,8)
					IF (@lot_number_min>SUBSTRING(@lot_number,1,8))
					BEGIN
						ROLLBACK
						SET @out_msg = '小于最老批次！';
						SET @out_passornot = 4;
						RETURN
					END
             -------------------------MODIFY WILL 20160805 E-------------------------------------	


					--如果已过期天数大于等于2/3过期天数，则该商品已经过期了2/3
                    IF(@num2_date >= @num1_date)
					BEGIN
					    ROLLBACK
						--SET @out_msg = '商品过期2/3！';
						SET @out_msg = '有效期已过2/3！';----will add 
						SET @out_passornot = 2;
						RETURN
					END

					IF(@num2_date >= @num3_date)
					BEGIN
					    ROLLBACK
						--SET @out_msg = '商品过期1/2！';
						SET @out_msg = '有效期已过1/2！';----will add 
						SET @out_passornot = 3;
						RETURN
					END
														
				END



				/*
				--总天数
				SELECT @result = (CONVERT(FLOAT,CONVERT(VARCHAR(50), DATEDIFF(DAY,CONVERT(varchar(50), CONVERT(DATETIME, @lot_number),23),CONVERT(VARCHAR(50), @expiration_date, 23)))));
				--2/3的过期天数
				SELECT @num1_date = (ROUND(CONVERT(FLOAT,CONVERT(VARCHAR(50), DATEDIFF(DAY,CONVERT(varchar(50), CONVERT(DATETIME, @lot_number),23),CONVERT(VARCHAR(50), @expiration_date, 23)))) * 2 / 3,0));
				--未过期天数
				SELECT @num2_date = CONVERT(VARCHAR(50), DATEDIFF(DAY,CONVERT(varchar(50), CONVERT(DATETIME, GETDATE()),23),CONVERT(VARCHAR(50), @expiration_date, 23)));
				--如果未过期天数小于0，证明该商品已过期！
				IF (@num2_date < 0)
				BEGIN
					ROLLBACK
					SET @out_msg = '商品已过期！';
					SET @out_passornot = 1;
					RETURN
				END
				IF (@num2_date <= (@result - @num1_date))
				BEGIN
					ROLLBACK
					SET @out_msg = '商品过期2/3！';
					SET @out_passornot = 1;
					RETURN
				END
				--已过期天数
				SELECT @num2_date = CONVERT(VARCHAR(50), DATEDIFF(DAY,CONVERT(varchar(50), CONVERT(DATETIME, @lot_number),23),CONVERT(VARCHAR(50), GETDATE(), 23)));
				--未过期天数是否小于等于总天数-2/3的过期天数，如果小于等于，则该商品已过期2/3
				IF (@num2_date >= @num1_date)
				BEGIN
					ROLLBACK
					SET @out_msg = '商品过期2/3！';
					SET @out_passornot = 1;
					RETURN
				END
				*/

            END
			SET @out_passornot = 0
            SET @out_msg = ''
            COMMIT		
            RETURN	
        END TRY
		


        BEGIN CATCH
            SET NOCOUNT OFF
            ROLLBACK
            SET @out_msg = ERROR_MESSAGE()
			SET @out_passornot = 1;
            RETURN
        END CATCH

	END



