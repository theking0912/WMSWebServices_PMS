CREATE FUNCTION [dbo].[fn_Get_StorageType_ByItem]
(
    @in_wh_id		  NVARCHAR(50),
    @in_item_number   NVARCHAR(50),
    @in_type		  NVARCHAR(10) --D:Damage; B:Blind; N:Normal
)
RETURNS NVARCHAR(10)
AS
BEGIN
    DECLARE
    -- Local Variables
    @v_zone_type             NVARCHAR(10),
	@v_client_type           NVARCHAR(10),
	@v_vip_flag				 NVARCHAR(10),
	@v_storage_type			 NVARCHAR(10)

	SELECT @v_zone_type = storage_type 
		FROM t_item_master itm
	  WHERE  itm.wh_id = @in_wh_id
		AND itm.item_number = @in_item_number

	--IF @in_type = 'N' 
	--	BEGIN
	--		SET @v_zone_type = @in_type + @v_storage_type
	--	END
	--ELSE
	--	BEGIN
	--		SET @v_zone_type = @in_type + @v_storage_type
	--	END

----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

    -- Always leave from here.
    RETURN @v_zone_type 
END
