
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Special_Assign_Store_Report]
	-- Add the parameters for the stored procedure here
	 @in_WaveID             AS  NVARCHAR(20)
	,@in_CustomerCode	    AS	NVARCHAR(30)
	,@in_item_number		AS	NVARCHAR(30)
	,@in_wh_id				AS	NVARCHAR(10)
	,@in_location_id		AS	NVARCHAR(50)
	,@in_hu_id				AS	NVARCHAR(30)
	,@in_qty				AS	FLOAT
	,@user_id				AS	NVARCHAR(20)
	,@passornot				nvarchar(1)   OUTPUT
	,@msg					nvarchar(200) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @i_cnt                      AS  INT
	DECLARE @lot_number					AS	Nvarchar(30)
	DECLARE @stored_attribute_id		AS	Nvarchar(30)
	DECLARE @expiration_date			AS	DATETIME
	DECLARE @damage_flag				AS	NVARCHAR(1)
	DECLARE @pick_id					AS	INT 
	DECLARE @id                         AS  INT
	DECLARE @remove_qty					AS	FLOAT
	DECLARE @order_qty                  AS  FLOAT
	DECLARE @tmp_fqty                   AS  FLOAT
	DECLARE @put_hu_id					AS  NVARCHAR(30)
	DECLARE @wave_id					AS	NVARCHAR(30)
	DECLARE @line_number	            AS  NVARCHAR(5)
	DECLARE @order_number               AS  NVARCHAR(30)
	DECLARE	@out_vchCode uddt_output_code,
			@out_vchMsg uddt_output_msg
	DECLARE @dest_loc nvarchar(30)

    SET @dest_loc= @in_location_id

	CREATE TABLE #tmp_order_detial
	(
		id                    INT IDENTITY(1,1) NOT NULL,
		wh_id                 NVARCHAR(10)  COLLATE DATABASE_DEFAULT NULL ,
		order_number          NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
		line_number           NVARCHAR(5)   COLLATE DATABASE_DEFAULT NULL ,
		item_number			  NVARCHAR(30)  COLLATE DATABASE_DEFAULT NULL ,
		qty                   FLOAT  NULL  DEFAULT (0)
	)

	INSERT INTO #tmp_order_detial
	(
	   wh_id,
	   order_number,
	   line_number,
	   item_number,
	   qty
	)
	SELECT od.wh_id,
	       od.order_number,
	       odl.line_number,
		   odl.item_number,
		   dbo.csf_uom_convert(odl.wh_id, odl.item_number, odl.order_uom,NULL, odl.qty) - isnull(allo.picked_qty,0)
	FROM t_order od WITH(NOLOCK) 
	INNER JOIN t_order_detail odl WITH(NOLOCK)
	ON od.wh_id = odl.wh_id
	AND od.order_number = odl.order_number
	INNER JOIN t_afo_wave_detail awdl WITH(NOLOCK)
	ON od.wh_id = awdl.wh_id
	AND od.order_number = awdl.order_number
	INNER JOIN t_item_master itm WITH(NOLOCK)
	ON odl.wh_id = itm.wh_id
	AND odl.item_number = itm.item_number
	INNER JOIN t_customer ct with(nolock)
	on od.customer_id = ct.customer_id
	LEFT JOIN(SELECT  order_number,
	                  line_number,
                      item_number ,
                      wh_id ,
                      SUM(ISNULL(picked_qty, 0)) AS picked_qty
                FROM  tbl_allocation WITH(NOLOCK)
               WHERE  item_number = @in_item_number
                 AND  wh_id = @in_wh_id
				 AND  wave_id = @in_WaveID
				 AND  allocated_qty > 0
             GROUP BY order_number,
	                  line_number,
                      item_number ,
                      wh_id
	         )allo
	ON odl.wh_id = allo.wh_id
	AND odl.order_number = allo.order_number
	AND odl.line_number = allo.line_number
	AND odl.item_number = allo.item_number
	WHERE ct.customer_code = @in_CustomerCode
	AND od.wh_id = @in_wh_id
	AND odl.item_number = @in_item_number
	AND awdl.wave_id = @in_WaveID
	AND od.status NOT IN ('SHIPPED','NEW')
	AND itm.pick_type in ('B','M','S')
	AND ISNULL(odl.cancel_flag,'N') = 'N'
	AND dbo.csf_uom_convert(odl.wh_id, odl.item_number, odl.order_uom,NULL, odl.qty) - isnull(allo.picked_qty,0) > 0
	ORDER BY od.order_number,odl.line_number

    IF @@ROWCOUNT = 0
	BEGIN
		INSERT INTO #tmp_order_detial
		(
		   wh_id,
		   order_number,
		   line_number,
		   item_number,
		   qty
		)
		SELECT TOP 1
		       od.wh_id,
			   od.order_number,
			   odl.line_number,
			   odl.item_number,
			   dbo.csf_uom_convert(odl.wh_id, odl.item_number, odl.order_uom,NULL, odl.qty) - isnull(allo.picked_qty,0)
		FROM t_order od WITH(NOLOCK) 
		INNER JOIN t_order_detail odl WITH(NOLOCK)
		ON od.wh_id = odl.wh_id
		AND od.order_number = odl.order_number
		INNER JOIN t_afo_wave_detail awdl WITH(NOLOCK)
		ON od.wh_id = awdl.wh_id
		AND od.order_number = awdl.order_number
		INNER JOIN t_item_master itm WITH(NOLOCK)
		ON odl.wh_id = itm.wh_id
		AND odl.item_number = itm.item_number
		INNER JOIN t_customer ct with(nolock)
		ON od.customer_id = ct.customer_id
		LEFT JOIN(SELECT  order_number,
						  line_number,
						  item_number ,
						  wh_id ,
						  SUM(ISNULL(picked_qty, 0)) AS picked_qty
					FROM  tbl_allocation WITH(NOLOCK)
				   WHERE  item_number = @in_item_number
					 AND  wh_id = @in_wh_id
					 AND  wave_id = @in_WaveID
					 AND  allocated_qty > 0
				 GROUP BY order_number,
						  line_number,
						  item_number ,
						  wh_id
				 )allo
		ON odl.wh_id = allo.wh_id
		AND odl.order_number = allo.order_number
		AND odl.line_number = allo.line_number
		AND odl.item_number = allo.item_number
		WHERE ct.customer_code = @in_CustomerCode
		AND od.wh_id = @in_wh_id
		AND odl.item_number = @in_item_number
		AND awdl.wave_id = @in_WaveID
		AND od.status NOT IN ('SHIPPED','NEW')
		AND itm.pick_type in ('B','M','S')
		AND ISNULL(odl.cancel_flag,'N') = 'N'
		--AND dbo.csf_uom_convert(odl.wh_id, odl.item_number, odl.order_uom,NULL, odl.qty) - isnull(allo.picked_qty,0) > 0
		ORDER BY od.order_number,odl.line_number
	END

	
	
	BEGIN TRY

	SELECT TOP 1 
	     @expiration_date = expiration_date
		,@lot_number = lot_number
		,@stored_attribute_id = stored_attribute_id
		,@damage_flag = damage_flag
	 FROM dbo.t_stored_item
	WHERE wh_id = @in_wh_id
	AND location_id = @in_location_id
	AND hu_id = @in_hu_id
	AND item_number = @in_item_number
	AND actual_qty >= @in_qty
	AND actual_qty > 0 
	AND type = 0

	IF @@ROWCOUNT = 0
	BEGIN
		SET @msg = N'未分配的播种数量不够'
		SET @passornot = 1
		RETURN
	END

	BEGIN TRANSACTION

	SET @id = 0
	WHILE(@in_qty > 0)
	BEGIN
	   SELECT TOP 1
	          @id = id,
	          @order_number = order_number,
			  @line_number = line_number,
			  @order_qty = qty
	     FROM #tmp_order_detial
		WHERE id > @id
	    ORDER BY id
		IF @@ROWCOUNT = 0
		BEGIN
		  BREAK
		END

		--最后一行明细时，将数量全部进行分配
		SELECT @i_cnt = COUNT(1)
		  FROM #tmp_order_detial
		 WHERE id > @id

		IF (@order_qty < @in_qty AND @i_cnt > 0)
		BEGIN
		   SET @tmp_fqty = @order_qty
		   SET @in_qty = @in_qty - @order_qty
		END
		ELSE
		BEGIN
		   SET @tmp_fqty = @in_qty
		   SET @in_qty = 0
		END
		
		SET @remove_qty = -1 * @tmp_fqty
		SET @put_hu_id = @in_location_id + '-' + @order_number


		SELECT TOP 1 @wave_id = wave_id 
		FROM t_afo_wave_detail WITH(NOLOCK) 
	    WHERE order_number = @order_number
		AND wh_id = @in_wh_id

		SELECT @pick_id = pick_id 
		FROM dbo.t_pick_detail WITH(NOLOCK)
	    WHERE wh_id = @in_wh_id
		AND order_number = @order_number
		AND item_number = @in_item_number
		AND line_number = @line_number
		AND type = 'PP'

		SELECT @i_cnt = @@ROWCOUNT

		IF(@i_cnt = 0)
		BEGIN
			  EXEC csp_Create_Pick_Dtl 
			  @order_number,
			  @line_number,
			  NULL,
			  NULL,
			  'LOADED',
			  @in_item_number,
			  0,
			  @tmp_fqty,
			  @tmp_fqty,
			  @tmp_fqty,
			  @tmp_fqty,
			  @in_location_id,
			  @in_wh_id,
			  'PP',
			  @wave_id,
			  @pick_id OUTPUT


			  INSERT INTO tbl_allocation
			  (
			      [wave_id]
      	         ,[order_number]
                 ,[pick_id]
                 ,[item_number]
                 ,[lot_number]
                 ,[stored_attribute_id]
                 ,[location_id]
                 ,[hu_id]
                 ,[allocated_qty]
                 ,[picked_qty]
                 ,[expected_qty]
                 ,[status]
                 ,[released_date]
                 ,[ref_number]
                 ,[pick_wall_loc]
                 ,[pick_wall_slot]
                 ,[pick_conveyor_node]
                 ,[zone]
                 ,[wh_id]
                 ,[user_assign]
                 ,[line_number]
                 ,[shipping_label]
                 ,[picking_flow]
                 ,[allo_type]
                 ,[damage_flag]
                 ,[expiration_date]
			  )
			  VALUES( @wave_id
					 ,@order_number
				     ,@pick_id
					 ,@in_item_number
					 ,@lot_number
					 ,@stored_attribute_id
					 ,@in_location_id
					 ,@put_hu_id
					 ,@tmp_fqty
					 ,@tmp_fqty
					 ,0
					 ,'C'
					 ,GETDATE()
					 ,NULL
					 ,NULL
					 ,NULL
					 ,NULL
					 ,NULL
					 ,@in_wh_id
					 ,@user_id
					 ,@line_number
					 ,NULL
					 ,NULL
					 ,NULL
					 ,@damage_flag
					 ,@expiration_date
					)


		      If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                where isnull(b.status,'') NOT IN('STAGED','LOADED') and a.order_number= @order_number and a.wh_id=@in_wh_id
							and isnull(b.work_type,'')='')
			     AND EXISTS (SELECT 1 FROM t_order_detail a
			                left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                where isnull(b.status,'') ='STAGED' and a.order_number= @order_number and a.wh_id=@in_wh_id
							and isnull(b.work_type,'')='')
				            UPDATE t_order SET status = 'STAGED' where order_number= @order_number and wh_id=@in_wh_id
			  ELSE
		      BEGIN 
				     If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'')<>'LOADED' and a.order_number= @order_number and a.wh_id=@in_wh_id
								   and isnull(b.work_type,'')='')
			         UPDATE t_order SET status = 'LOADED' where order_number= @order_number and wh_id=@in_wh_id
			  END
		END
	    ELSE
		BEGIN
		      UPDATE t_pick_detail 
			     SET planned_quantity = planned_quantity + @tmp_fqty
				    ,picked_quantity = picked_quantity + @tmp_fqty
			 	    ,staged_quantity = staged_quantity + @tmp_fqty
				    ,loaded_quantity = loaded_quantity + @tmp_fqty
			   WHERE pick_id  = @pick_id


			 UPDATE t_pick_detail
		        SET status = CASE WHEN staged_quantity = planned_quantity THEN 'LOADED' ELSE status END 
		      WHERE pick_id  = @pick_id


		   If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') NOT IN('STAGED','LOADED') and a.order_number= @order_number and a.wh_id=@in_wh_id
								   and isnull(b.work_type,'')='')
			      AND EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') ='STAGED' and a.order_number= @order_number and a.wh_id=@in_wh_id
								   and isnull(b.work_type,'')='')
				    UPDATE t_order SET status = 'STAGED' where order_number= @order_number and wh_id=@in_wh_id
			    ELSE
				  BEGIN 
				    If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'')<>'LOADED' and a.order_number= @order_number and a.wh_id=@in_wh_id
								   and isnull(b.work_type,'')='')
			        UPDATE t_order SET status = 'LOADED' where order_number= @order_number and wh_id=@in_wh_id
			      end


			UPDATE tbl_allocation
				SET allocated_qty = allocated_qty + @tmp_fqty
					,picked_qty = picked_qty + @tmp_fqty
				WHERE pick_id = @pick_id
				AND	wh_id = @in_wh_id
				AND order_number = @order_number
				AND item_number = @in_item_number
				AND line_number = @line_number
				AND ISNULL(lot_number,'') = ISNULL(@lot_number,'')
				AND damage_flag = @damage_flag
			IF @@ROWCOUNT = 0
			BEGIN
				INSERT INTO tbl_allocation 
					([wave_id]
					,[order_number]
					,[pick_id]
					,[item_number]
					,[lot_number]
					,[stored_attribute_id]
					,[location_id]
					,[hu_id]
					,[allocated_qty]
					,[picked_qty]
					,[expected_qty]
					,[status]
					,[released_date]
					,[ref_number]
					,[pick_wall_loc]
					,[pick_wall_slot]
					,[pick_conveyor_node]
					,[zone]
					,[wh_id]
					,[user_assign]
					,[line_number]
					,[shipping_label]
					,[picking_flow]
					,[allo_type]
					,[damage_flag]
					,[expiration_date])
				VALUES(@wave_id
					  ,@order_number
					  ,@pick_id
					  ,@in_item_number
					  ,@lot_number
					  ,@stored_attribute_id
					  ,@in_location_id
				      ,@put_hu_id
				      ,@tmp_fqty
					  ,@tmp_fqty
					  ,0
					  ,N'C'
					  ,GETDATE()
					  ,NULL
					  ,NULL
				      ,NULL
					  ,NULL
				      ,NULL
					  ,@in_wh_id
					  ,@user_id
					  ,@line_number
					  ,NULL
					  ,NULL
					  ,NULL
					  ,@damage_flag
					  ,@expiration_date
					  )
			END
		  
		END
	
		EXEC	[dbo].[csp_Inventory_Adjust]
					@in_vchWhID = @in_wh_id,
					@in_vchItemNumber = @in_item_number,
					@in_vchLocationID = @dest_loc,
					@in_nType = @pick_id,
					@in_vchHUID = @put_hu_id,
					@in_vchLotNumber =@lot_number,
					@in_nStoredAttributeID = @stored_attribute_id,
					@in_fQty = @tmp_fqty,
					@in_dtFifoDate = NULL,
					@in_dtExpirationDate = @expiration_date,
					@in_vchHUType = N'SO',
					@in_vchShipmentNumber = @order_number,
					@in_damage_flag = @damage_flag,
					@out_vchCode = @out_vchCode OUTPUT,
					@out_vchMsg = @out_vchMsg OUTPUT

		EXEC	[dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @in_wh_id,
				@in_vchItemNumber = @in_item_number,
				@in_vchLocationID = @in_location_id,
				@in_nType =0,
				@in_vchHUID = @in_hu_id,
				@in_vchLotNumber =@lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty =@remove_qty,
				@in_dtFifoDate = NULL,
				@in_dtExpirationDate = @expiration_date,
				@in_vchHUType = N'IV',
				@in_vchShipmentNumber =NULL,
				@in_damage_flag = @damage_flag,
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT

			--Create tran log
		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
			,wh_id_2,location_id_2,hu_id_2
			,generic_attribute_1,
			generic_attribute_2,
			generic_attribute_3,
			generic_attribute_4,
			generic_attribute_5,
			generic_attribute_6,
			generic_attribute_7,
			generic_attribute_8,
			generic_attribute_9,
			generic_attribute_10,
			generic_attribute_11)
		VALUES
			('702',N'RF播种',getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@pick_id
			,@in_wh_id,@in_location_id,@in_hu_id,@in_item_number,@lot_number,@tmp_fqty
			,@in_wh_id,@in_location_id,@put_hu_id
			,(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_1),    
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_2), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_3), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_4), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_5), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_6), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_7), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_8), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_9), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_10), 
			(SELECT a.attribute_value 
			FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
			WHERE a.stored_attribute_id = @stored_attribute_id
			AND a.attribute_id = alm.generic_attribute_11)
			)
    END

		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
	END CATCH
END

