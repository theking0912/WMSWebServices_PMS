
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Move_Stock_For_Dps_Ma] 
	-- Add the parameters for the stored procedure here
	@dpsPickId					AS  BIGINT,
	@in_wh_id					AS	NVARCHAR(30),
	@in_order_number			AS	NVARCHAR(30),
	@in_hu_id					AS	NVARCHAR(30),
	@in_put_location			AS	NVARCHAR(30),
	@in_item_number				AS	NVARCHAR(30),
	@in_uom						AS	NVARCHAR(20),
	@in_qty						AS	FLOAT
	--,
	--@out_msg					AS	NVARCHAR(200) output,
	--@out_passornot				AS	INT output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--SET XACT_ABORT ON
	DECLARE @out_msg					NVARCHAR(200)
	DECLARE @out_passornot  INT
	DECLARE @pick_id				BIGINT
	DECLARE @lot_number				NVARCHAR(30)
	DECLARE @stored_attribute_id	NVARCHAR(30)
	DECLARE @expiration_date		DATETIME
	DECLARE @type					BIGINT
	DECLARE @source_location		NVARCHAR(30)
	DECLARE @picked_qty				FLOAT
	DECLARE @remove__qty			FLOAT
	DECLARE @damage_flag			NVARCHAR(1)
	DECLARE @put_hu_id				NVARCHAR(30)
	DECLARE @wall_location			NVARCHAR(30)
	DECLARE @sto_qty				FLOAT
	DECLARE @excpect_qty			FLOAT
	DECLARE @short_qty				FLOAT
	DECLARE @vir_hu					NVARCHAR(30)

	DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg

	BEGIN TRY

		 SET @out_passornot = 1
		SET @out_msg = N'执行失败'
		--BEGIN TRANSACTION

		
		
		SELECT TOP 1 @lot_number = si.lot_number,
			   @stored_attribute_id = si.stored_attribute_id,
			   @expiration_date = expiration_date,
			   @type = si.type,
			   @source_location = location_id,
			   @damage_flag = damage_flag,
			   @sto_qty = actual_qty
			FROM t_stored_item si
			INNER JOIN t_pick_detail pd
			ON si.type = pd.pick_id
			AND si.wh_id = pd.wh_id
			WHERE si.wh_id = @in_wh_id
			 AND hu_id = @in_hu_id
			 AND si.item_number = @in_item_number
			 AND pd.order_number = @in_order_number
			 AND si.type <> 0
			
			IF @@rowcount = 0
			BEGIN
				 SET @out_msg = N'执行失败! 没有可执行的库存 huid= ' + @in_hu_id + ' item_number=' + @in_item_number + ' order=' + @in_order_number + ' wh_id = ' + @in_wh_id
				--rollback
				  
				update work_pointer set PointerId=@dpsPickId where PointerName='DpsPick' and PointerId<@dpsPickId 
				return
			END

			SELECT @excpect_qty = conversion_factor * @in_qty
						FROM t_item_uom WITH(NOLOCK)
					WHERE wh_id = @in_wh_id
						AND item_number = @in_item_number
						AND uom = @in_uom
		WHILE(1=1)
		BEGIN
			IF @excpect_qty > 0 
			BEGIN

			SELECT TOP 1 @lot_number = si.lot_number,
			   @stored_attribute_id = si.stored_attribute_id,
			   @expiration_date = expiration_date,
			   @type = si.type,
			   @source_location = location_id,
			   @damage_flag = damage_flag,
			   @sto_qty = actual_qty
			FROM t_stored_item si
			INNER JOIN t_pick_detail pd
			ON si.type = pd.pick_id
			AND si.wh_id = pd.wh_id
			WHERE si.wh_id = @in_wh_id
			 AND hu_id = @in_hu_id
			 AND si.item_number = @in_item_number
			 AND pd.order_number = @in_order_number
			 AND si.type <> 0

			IF @@ROWCOUNT = 0
			BEGIN
				BREAK;
			END
			
			
			IF @excpect_qty <= @sto_qty
			BEGIN
				SET @Picked_qty = @excpect_qty
				SET @excpect_qty = 0
			END
			ELSE
			BEGIN
				SET @Picked_qty = @sto_qty
				SET @excpect_qty = @excpect_qty - @sto_qty
			END

				UPDATE t_pick_detail
				SET loaded_quantity = loaded_quantity + @picked_qty
					,status = CASE WHEN planned_quantity = loaded_quantity + @picked_qty+packed_quantity THEN 'LOADED'
								ELSE status END
					WHERE pick_id = @type

				SET @put_hu_id = @in_order_number + '-' + @in_put_location
	
				SELECT @wall_location = location_id 
				FROM tbl_pick_wall pw WITH(NOLOCK)
					INNER JOIN tbl_pick_wall_slot pwl WITH(NOLOCK)
						ON pw.wh_id = pwl.wh_id
						AND pw.wall_id = pwl.wall_id
					WHERE pwl.slot = @in_put_location

				--Move the stock to fork
				EXEC [dbo].[csp_Inventory_Adjust]
					@in_vchWhID = @in_wh_id,
					@in_vchItemNumber = @in_item_number,
					@in_vchLocationID = @wall_location,
					@in_nType = @type,
					@in_vchHUID = @put_hu_id,
					@in_vchLotNumber = @lot_number,
					@in_nStoredAttributeID = @stored_attribute_id,
					@in_fQty = @picked_qty,
					@in_dtFifoDate = NULL,
					@in_dtExpirationDate = @expiration_date,
					@in_vchHUType = 'SO',
					@in_vchShipmentNumber = @in_order_number,
					@in_damage_flag = @damage_flag,
					@out_vchCode = @out_vchCode OUTPUT,
					@out_vchMsg = @out_vchMsg OUTPUT

				SET @remove__qty = @picked_qty * -1

				--ReMove the stock to fork
				EXEC [dbo].[csp_Inventory_Adjust]
					@in_vchWhID = @in_wh_id,
					@in_vchItemNumber = @in_item_number,
					@in_vchLocationID = @source_location,
					@in_nType = @type,
					@in_vchHUID = @in_hu_id,
					@in_vchLotNumber = @lot_number,
					@in_nStoredAttributeID = @stored_attribute_id,
					@in_fQty = @remove__qty,
					@in_dtFifoDate = NULL,
					@in_dtExpirationDate = @expiration_date,
					@in_vchHUType = 'SO',
					@in_vchShipmentNumber = NULL,
					@in_damage_flag = @damage_flag,
					@out_vchCode = @out_vchCode OUTPUT,
					@out_vchMsg = @out_vchMsg OUTPUT

				INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],location_id,[location_id_2],[hu_id],[item_number],[lot_number],[tran_qty])
				values('201','Move(Pick)',getdate(),getdate(),getdate(),getdate(),'PTW',@in_order_number,null,
				@in_wh_id,@source_location,null,@in_hu_id,@in_item_number,@lot_number,@picked_qty)

				INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],location_id,[location_id_2],[hu_id],[item_number],[lot_number],[tran_qty])
			values('202','Move(Put)',getdate(),getdate(),getdate(),getdate(),'PTW',@in_order_number,null,
			@in_wh_id,@in_put_location,NULL,@put_hu_id,@in_item_number,@lot_number,@picked_qty) 
			END

			IF @excpect_qty = 0
			BEGIN
				SELECT TOP 1 
					@lot_number = si.lot_number,
					@stored_attribute_id = si.stored_attribute_id,
					@expiration_date = expiration_date,
					@type = si.type,
					@source_location = location_id,
					@damage_flag = damage_flag,
					@short_qty = actual_qty
				FROM t_stored_item si
				INNER JOIN t_pick_detail pd
				ON si.type = pd.pick_id
				AND si.wh_id = pd.wh_id
				WHERE si.wh_id = @in_wh_id
					AND hu_id = @in_hu_id
					AND si.item_number = @in_item_number
					AND pd.order_number = @in_order_number
					AND si.type <> 0

				IF @@ROWCOUNT > 0
				BEGIN
					SET @vir_hu = @in_order_number + '-' + @in_hu_id

					INSERT INTO [dbo].[t_exception_log]
							   ([tran_type]
							   ,[description]
							   ,[exception_date]
							   ,[exception_time]
							   ,[employee_id]
							   ,[wh_id]
							   ,[suggested_value]
							   ,[entered_value]
							   ,[location_id]
							   ,[item_number]
							   ,[lot_number]
							   ,[quantity]
							   ,[hu_id]
							   ,[load_id]
							   ,[control_number]
							   ,[line_number]
							   ,[tracking_number]
							   ,[error_code]
							   ,[error_message]
							   ,[status]
							   ,[uom])
						 VALUES
							   ('257'
							   ,'Slot Move'
							   ,GETDATE()
							   ,GETDATE()
							   ,'DPS'
							   ,@in_wh_id
							   ,@stored_attribute_id
							   ,NULL
							   ,'EXC001'
							   ,@in_item_number
							   ,@lot_number
							   ,@short_qty / (SELECT conversion_factor FROM t_item_uom WITH(NOLOCK)
																	WHERE wh_id = @in_wh_id
																		AND item_number = @in_item_number
																		AND uom = @in_uom)
							   ,@vir_hu
							   ,NULL
							   ,@in_order_number
							   ,NULL
							   ,@in_hu_id
							   ,'257'
							   ,'播种短拣'
							   ,'NEW'
							   ,@in_uom)
						
						--Move the stock to fork
						EXEC [dbo].[csp_Inventory_Adjust]
								@in_vchWhID = @in_wh_id,
								@in_vchItemNumber = @in_item_number,
								@in_vchLocationID = 'EXC001',
								@in_nType = 0,
								@in_vchHUID = @vir_hu,
								@in_vchLotNumber = @lot_number,
								@in_nStoredAttributeID = @stored_attribute_id,
								@in_fQty = @short_qty,
								@in_dtFifoDate = NULL,
								@in_dtExpirationDate = @expiration_date,
								@in_vchHUType = 'IV',
								@in_vchShipmentNumber = '',
								@in_damage_flag = @damage_flag,
								@out_vchCode = @out_vchCode OUTPUT,
								@out_vchMsg = @out_vchMsg OUTPUT
						
						
						UPDATE t_stored_item SET status = 'U'
						WHERE ISNULL(lot_number,'') = ISNULL(@lot_number,'')
							AND ISNULL(stored_attribute_id,'') = ISNULL(@stored_attribute_id,'')
							AND type = 0
							AND location_id = 'EXC001'					
							AND hu_id = @vir_hu 
							AND damage_flag = @damage_flag
							AND item_number = @in_item_number
							AND wh_id = @in_wh_id

						UPDATE t_pick_detail
							SET staged_quantity = staged_quantity - @short_qty
								--,planned_quantity = planned_quantity - @short_qty
								--,picked_quantity = picked_quantity - @short_qty
								,packed_quantity = ISNULL(packed_quantity,0) + @short_qty
								,status = CASE WHEN loaded_quantity + @short_qty = planned_quantity
												THEN 'LOADED' ELSE status END
						WHERE pick_id = @type

						SET @short_qty = @short_qty * -1

						--ReMove the stock to fork
						EXEC [dbo].[csp_Inventory_Adjust]
							@in_vchWhID = @in_wh_id,
							@in_vchItemNumber = @in_item_number,
							@in_vchLocationID = @source_location,
							@in_nType = @type,
							@in_vchHUID = @in_hu_id,
							@in_vchLotNumber = @lot_number,
							@in_nStoredAttributeID = @stored_attribute_id,
							@in_fQty = @short_qty,
							@in_dtFifoDate = NULL,
							@in_dtExpirationDate = @expiration_date,
							@in_vchHUType = 'SO',
							@in_vchShipmentNumber = NULL,
							@in_damage_flag = @damage_flag,
							@out_vchCode = @out_vchCode OUTPUT,
							@out_vchMsg = @out_vchMsg OUTPUT		
				END

				BREAK
			END
		END

		update work_pointer set PointerId=@dpsPickId where PointerName='DpsPick' and PointerId<@dpsPickId 

		update tbl_inf_dps_lp_pick set status = -1 where id=@dpsPickId and status=-2
		--update tbl_inf_dps_lp_pick set status = 1 where id=@dpsPickId 
		SET @out_passornot = 0
		set @out_msg = N'执行成功'
		--COMMIT
		RETURN
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION
		END
		update tbl_inf_dps_lp_pick set status=-2 where id=@dpsPickId

		SET @out_passornot = 1
		SET @out_msg = N'执行失败:' + ERROR_MESSAGE()
		RETURN
	END CATCH
END
