
CREATE PROCEDURE [dbo].[csp_dynamic_query_builder] (
    @in_nInformation_Collection_ID    INT,
    @in_nChecksum                   INT,
    @in_vchIdentifier               VARCHAR(36),
    @out_nStored_Information_ID       BIGINT OUTPUT
)
AS

DECLARE
-- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nSysErrorNum             INT,
    @v_nSysRowCount             INT,
    @v_nReturn                  INT,
    @v_nCount                   INT,


  -- Log Error numbers used for branching in the Error Handler.
    @e_GenSqlError              INT,
    @e_SprocError               INT,

-- Local variables	
    @v_nOrigNoCountState         INT		
--    @v_vchSQLPivotTable        NVARCHAR(4000),
--    @v_nCounter                INT,
--    @v_nMaxSeqCollection       INT


--  Created table variables to handle the processing instead of dynamic sql as SQL Server 
--  has limitation of handling dynamic queries only upto 4000 characters long.  With 11 DIA attributes it was exceeding that limit by a big margin.
--  use of table variables will also make the processing more efficient as compared to extensive dynamic sql.

DECLARE @v_tblStoredInforIdValues TABLE
(
			stored_information_id	BIGINT,
			sequence_id			INT,
			information_value		NVARCHAR(250)
)

DECLARE @v_tblStoredInforIdValuesHorz TABLE
(
			stored_information_id	BIGINT,
			val1		NVARCHAR(250),
			val2		NVARCHAR(250),
			val3		NVARCHAR(250),
			val4		NVARCHAR(250),
			val5		NVARCHAR(250),
			val6		NVARCHAR(250),
			val7		NVARCHAR(250),
			val8		NVARCHAR(250),
			val9		NVARCHAR(250),
			val10		NVARCHAR(250),
			val11		NVARCHAR(250)
)


DECLARE @v_tblStoredInformationId TABLE
( stored_information_id	BIGINT )


-- Set Constants
SET @c_nModuleNumber = 60     -- Always #60 for WA.
SET @c_nFileNumber = 15        -- This # must be unique per object.
SET @c_vchObjName = 'usp_dynamic_query_builder'



-- Log/Local Error Constants
SET @e_GenSqlError = 1
SET @e_SprocError = 2

-- SET NOCOUNT to ON to no longer display the count message.
-- Save the current state so we can restore it at the end of
-- this procedure.
SET @v_nOrigNoCountState = @@OPTIONS & 512
-- 0 if NOCOUNT is off, 512 if on
IF @v_nOrigNoCountState = 0
	SET NOCOUNT ON


-- Set Local Variables
--SET @v_nCounter = 1
--SET @v_vchSQLPivotTable = ''


-- Get the quantity of attributes of a collection
--SELECT  @v_nMaxSeqCollection = MAX(sequence_id) FROM t_attribute_collection_detail
--WHERE  attribute_collection_id = @in_nAtrribute_Collection_ID

insert into @v_tblStoredInforIdValues
SELECT distinct tsacm.stored_information_id, tacd.sequence_id, tsacd.information_value
FROM tbl_sto_information_collection_master tsacm,
	 tbl_sto_information_collection_detail tsacd, 
	 tbl_information_collection_detail tacd
WHERE tsacd.stored_information_id = tsacm.stored_information_id 
  AND tsacd.information_id = tacd.information_id 
  AND tacd.information_collection_id = tsacm.information_collection_id 
  AND tsacm.information_collection_id = @in_nInformation_Collection_ID
  AND tsacm.detail_checksum = @in_nChecksum


SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
    END



insert into @v_tblStoredInforIdValuesHorz
SELECT tbl.stored_information_id,
(SELECT tbl1.information_value FROM @v_tblStoredInforIdValues tbl1 WHERE tbl1.stored_information_id = tbl.stored_information_id and tbl1.sequence_id = 1) as val1,
(SELECT tbl2.information_value FROM @v_tblStoredInforIdValues tbl2 WHERE tbl2.stored_information_id = tbl.stored_information_id and tbl2.sequence_id = 2) as val2,
(SELECT tbl3.information_value FROM @v_tblStoredInforIdValues tbl3 WHERE tbl3.stored_information_id = tbl.stored_information_id and tbl3.sequence_id = 3) as val3,
(SELECT tbl4.information_value FROM @v_tblStoredInforIdValues tbl4 WHERE tbl4.stored_information_id = tbl.stored_information_id and tbl4.sequence_id = 4) as val4,
(SELECT tbl5.information_value FROM @v_tblStoredInforIdValues tbl5 WHERE tbl5.stored_information_id = tbl.stored_information_id and tbl5.sequence_id = 5) as val5,
(SELECT tbl6.information_value FROM @v_tblStoredInforIdValues tbl6 WHERE tbl6.stored_information_id = tbl.stored_information_id and tbl6.sequence_id = 6) as val6,
(SELECT tbl7.information_value FROM @v_tblStoredInforIdValues tbl7 WHERE tbl7.stored_information_id = tbl.stored_information_id and tbl7.sequence_id = 7) as val7,
(SELECT tbl8.information_value FROM @v_tblStoredInforIdValues tbl8 WHERE tbl8.stored_information_id = tbl.stored_information_id and tbl8.sequence_id = 8) as val8,
(SELECT tbl9.information_value FROM @v_tblStoredInforIdValues tbl9 WHERE tbl9.stored_information_id = tbl.stored_information_id and tbl9.sequence_id = 9) as val9,
(SELECT tbl10.information_value FROM @v_tblStoredInforIdValues tbl10 WHERE tbl10.stored_information_id = tbl.stored_information_id and tbl10.sequence_id = 10) as val10,
(SELECT tbl11.information_value FROM @v_tblStoredInforIdValues tbl11 WHERE tbl11.stored_information_id = tbl.stored_information_id and tbl11.sequence_id = 11) as val11
FROM @v_tblStoredInforIdValues tbl
group by tbl.stored_information_id

SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
    END


/*
-- Create a temporary table to store the result of the dynamic query
CREATE TABLE #tmp_stored_attribute_id
( stored_attribute_id BIGINT )

SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
    END
*/

INSERT INTO @v_tblStoredInformationId --#tmp_stored_attribute_id (stored_attribute_id)
SELECT stored.stored_information_id 
FROM @v_tblStoredInforIdValuesHorz stored
WHERE ISNULL(stored.val1,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 1 ),ISNULL(stored.val1,'NULL')) 
AND ISNULL(stored.val2,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 2 ),ISNULL(stored.val2,'NULL')) 
AND ISNULL(stored.val3,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 3 ),ISNULL(stored.val3,'NULL')) 
AND ISNULL(stored.val4,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 4 ),ISNULL(stored.val4,'NULL')) 
AND ISNULL(stored.val5,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 5 ),ISNULL(stored.val5,'NULL'))  
AND ISNULL(stored.val6,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 6 ),ISNULL(stored.val6,'NULL'))  
AND ISNULL(stored.val7,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 7 ),ISNULL(stored.val7,'NULL'))  
AND ISNULL(stored.val8,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 8 ),ISNULL(stored.val8,'NULL'))  
AND ISNULL(stored.val9,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 9 ),ISNULL(stored.val9,'NULL'))  
AND ISNULL(stored.val10,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 10 ),ISNULL(stored.val10,'NULL'))  
AND ISNULL(stored.val11,'NULL') = ISNULL(dbo.csf_getUserValuesToTmpTable(@in_vchIdentifier,@in_nInformation_Collection_ID, 11 ),ISNULL(stored.val11,'NULL'))  


SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
				+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
    END


/*
SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'INSERT INTO #tmp_stored_attribute_id (stored_attribute_id)'
-- Build a virtual table with all the values for stored collection
--  stored_attribute_id , atribute_collection_id, val1, val2, val3 .. etc, this values are genarated dynamicly 
SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'SELECT t1.stored_attribute_id FROM ( '
SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' SELECT DISTINCT tsacm.stored_attribute_id, tsacm.attribute_collection_id, '
    WHILE  @v_nCounter <= @v_nMaxSeqCollection
		BEGIN
			IF @v_nCounter = @v_nMaxSeqCollection   
				BEGIN
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' (SELECT attribute_value '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'FROM t_sto_attrib_collection_detail tsacd, '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N't_attribute_collection_detail tacd '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'AND tsacd.attribute_id = tacd.attribute_id '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'AND tacd.attribute_collection_id = tsacm.attribute_collection_id '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'AND tacd.sequence_id = ' + CONVERT(NVARCHAR(15),@v_nCounter) + ') as val' + CONVERT(NVARCHAR(15),@v_nCounter)
				END  
			ELSE
				BEGIN
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' (SELECT attribute_value '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'FROM t_sto_attrib_collection_detail tsacd, '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N't_attribute_collection_detail tacd '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'AND tsacd.attribute_id = tacd.attribute_id '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'AND tacd.attribute_collection_id = tsacm.attribute_collection_id '
					SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N'AND tacd.sequence_id = ' + CONVERT(NVARCHAR(15),@v_nCounter) + ') as val' + CONVERT(NVARCHAR(15),@v_nCounter) + ', '
				END  
            SET @v_nCounter = @v_nCounter + 1
		END
    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' FROM t_sto_attrib_collection_master tsacm '
    -- SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' INNER JOIN t_sto_attrib_collection_detail tsacd2 ON tsacm.stored_attribute_id = tsacd2.stored_attribute_id '
  	SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' WHERE tsacm.attribute_collection_id = ' + CONVERT(NVARCHAR(15),@in_nAtrribute_Collection_ID)
  	SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND tsacm.detail_checksum = ' + CONVERT(NVARCHAR(11),@in_nChecksum) 
    -- SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND tsacd2.attribute_value IN ( SELECT attribute_value FROM t_user_entered_attributes WHERE identifier = ''' + @in_vchIdentifier + ''')'
    -- SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND ( SELECT COUNT(*) FROM t_user_entered_attributes WHERE identifier = ''' + @in_vchIdentifier + ''' AND attribute_value IS NOT NULL) = ( SELECT COUNT(*) FROM t_sto_attrib_collection_detail WHERE stored_attribute_id = tsacm.stored_attribute_id )'
    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' ) AS t1 WHERE '

 
   -- Build the condition to search if there match between user entered values and stored collections
   SET @v_nCounter = 1
   WHILE  @v_nCounter <= @v_nMaxSeqCollection
		BEGIN
			IF @v_nCounter = 1   
				BEGIN
				    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' ISNULL(val' + CONVERT(NVARCHAR(15),@v_nCounter) + ','''') = '
				    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' ISNULL((SELECT attribute_value '
				    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' FROM t_user_entered_attributes tmp, t_attribute_collection_detail attd  '
				    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' WHERE attd.attribute_id = tmp.attribute_id'
				    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND tmp.identifier = ''' + @in_vchIdentifier + ''''
				    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND attd.attribute_collection_id = ' + CONVERT(NVARCHAR(15),@in_nAtrribute_Collection_ID)
				    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND attd.sequence_id = ' + CONVERT(NVARCHAR(15),@v_nCounter) + ' ),'''')  '
				END  
			ELSE
				BEGIN
                    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND ISNULL(val' + CONVERT(NVARCHAR(15),@v_nCounter) + ','''') = '
                    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' ISNULL((SELECT attribute_value '
                    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' FROM t_user_entered_attributes tmp, t_attribute_collection_detail attd  '
                    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' WHERE attd.attribute_id = tmp.attribute_id'
                    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND tmp.identifier = ''' + @in_vchIdentifier + ''''
                    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND attd.attribute_collection_id = ' + CONVERT(NVARCHAR(15),@in_nAtrribute_Collection_ID)
                    SET @v_vchSQLPivotTable = @v_vchSQLPivotTable + N' AND attd.sequence_id = ' + CONVERT(NVARCHAR(15),@v_nCounter) + ' ),'''') '
				END  
            SET @v_nCounter = @v_nCounter + 1
		END

    EXECUTE ( @v_vchSQLPivotTable ) 
    SELECT @v_nSysErrorNum = @@ERROR
	IF @v_nSysErrorNum <> 0
		BEGIN
			SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
					+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
			SET @v_nLogErrorNum = @e_GenSqlError
			GOTO ERROR_HANDLER
	    END
*/
    -- Getting the result of the query from #tmp_stored_attribute_id
    SELECT @v_nSysRowCount = COUNT(*) FROM @v_tblStoredInformationId  -- #tmp_stored_attribute_id
    IF @v_nSysRowCount = 0
       SET @out_nStored_Information_ID = NULL
    ELSE
       SELECT @out_nStored_Information_ID = stored_information_id FROM @v_tblStoredInformationId  -- #tmp_stored_attribute_id

/*    
    -- Drop the temporary table.
    DROP TABLE #tmp_stored_attribute_id
    IF @v_nSysErrorNum <> 0
		BEGIN
			SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
					+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
			SET @v_nLogErrorNum = @e_GenSqlError
			GOTO ERROR_HANDLER
	    END
*/

GOTO EXIT_LABEL
-----------------------------------------------------------------------------------
--                            Error Handling Code
-----------------------------------------------------------------------------------
ERROR_HANDLER:

----------------------------------------------------------------------------------------------------
-- Delete these comments, they are only reminders...
-- Add each log message to the ...\RequiredData\InsertLogMap.sql script.
----------------------------------------------------------------------------------------------------
    --Roll back transaction if some error occurred    
    IF @@TRANCOUNT > 0
       ROLLBACK TRANSACTION

    -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)


-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

IF @@TRANCOUNT > 0
	COMMIT TRANSACTION

-- Reset NOCOUNT
IF @v_nOrigNoCountState = 0
    SET NOCOUNT OFF

-- Always leave the stored procedure from here.
RETURN
