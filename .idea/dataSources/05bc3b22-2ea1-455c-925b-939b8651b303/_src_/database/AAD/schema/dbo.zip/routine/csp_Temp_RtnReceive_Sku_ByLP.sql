-- =======================================    
-- Author: Tony.chen    
-- Create Date: 08 Nov 2013    
-- Description: Return Receiving by LP   
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_RtnReceive_Sku_ByLP]    
     @wh_id					NVARCHAR(10)    
    ,@control_number		NVARCHAR(30)   
	,@control_number_2		NVARCHAR(30)   
	,@item_number			Nvarchar(30)
	,@lot_number			Nvarchar(30)
	,@stored_attribute_id	Nvarchar(30)
	,@qty					float
	,@hu_id					Nvarchar(30)
	,@location_id			Nvarchar(30)
	,@type					Nvarchar(30) --D:Damage; B:Blind; N:Normal
	,@user_id				nvarchar(30)
	,@tran_type				nvarchar(30)
	,@tran_description		nvarchar(50)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @zone_type			NVARCHAR(30)
		DECLARE @schedule_number	INT
		DECLARE @line_number		NVARCHAR(5)

		BEGIN TRANSACTION
			--Create LP information
			IF NOT EXISTS(SELECT 1 FROM t_hu_master
					   WHERE wh_id = @wh_id
					   and hu_id = @hu_id)
				BEGIN
					SET @zone_type = dbo.fn_Get_ZoneType_ByItem(@wh_id,@item_number,@type)

					INSERT INTO t_hu_master
					(wh_id,hu_id,type,control_number,location_id,subtype
					,status, fifo_date,zone)
					VALUES
					(@wh_id,@hu_id,'IV',@control_number,@location_id,@zone_type
					,'A',GETDATE(),NULL)
				END
				
			--Insert into t_stored_item
			IF EXISTS (SELECT 1 FROM t_stored_item
						WHERE wh_id = @wh_id
						AND location_id = @location_id
						AND item_number = @item_number
						and isnull(lot_number,'') =isnull( @lot_number,'')
						and isnull(stored_attribute_id,0) = isnull(@stored_attribute_id,0)
						AND hu_id = @hu_id)
				BEGIN
					UPDATE t_stored_item
					SET [actual_qty] = [actual_qty] + @qty
					WHERE wh_id = @wh_id
					AND location_id = @location_id
					AND item_number = @item_number
					and isnull(lot_number,'') =isnull( @lot_number,'')
					and isnull(stored_attribute_id,0) = isnull(@stored_attribute_id,0)
					AND hu_id = @hu_id
				END
			ELSE
				BEGIN
					INSERT INTO t_stored_item
					([item_number],lot_number,[wh_id],[location_id],[actual_qty],[status],[fifo_date],[type],[stored_attribute_id],[hu_id])
					VALUES
					(@item_number,@lot_number,@wh_id,@location_id,@qty,'A',GETDATE(),'0',@stored_attribute_id,@hu_id)
				END
			
			-- get line no and schedule no
			SELECT @line_number = line_number
			      ,@schedule_number = schedule_number
			  FROM t_po_detail
			 WHERE po_number = @control_number_2
			   AND item_number = @item_number

			--Insert into t_receipt
			INSERT INTO t_receipt
				([receipt_id],[vendor_code],po_number,line_number,schedule_number,[receipt_date]
				,[item_number],[lot_number],[qty_received],[qty_damaged]
				,[hu_id],[fork_id],[wh_id],[stored_attribute_id])
			SELECT
				@control_number,vendor_code,@control_number_2,@line_number,@schedule_number,getdate()
				,@item_number,@lot_number,@qty, case @type when 'D' then @qty else 0 end
				,@hu_id,@location_id,@wh_id,@stored_attribute_id 
			FROM t_po_master
			WHERE wh_id = @wh_id
			AND po_number = @control_number_2

			--Insert into [dbo].[int_upd_receipt]
			Insert into [dbo].[tbl_inf_exp_receipt]
				(receipt_id,vendor_code,po_number,display_po_number,receipt_date
				,scac_code,status,item_number,display_item_number,lot_number
				,line_number,schedule_number,qty_received,qty_damaged,hu_id
				,packing_slip,fork_id,uom,shipment_number,warehouse_id,client_code
				,generic_attribute1	,generic_attribute2	,generic_attribute3
				,generic_attribute4	,generic_attribute5	,generic_attribute6
				,generic_attribute7	,generic_attribute8	,generic_attribute9
				,generic_attribute10,generic_attribute11,process_status)
			SELECT
				@control_number,vendor_code,@control_number_2,display_po_number,getdate()
				,NULL,'N',@item_number,NULL,@lot_number
				,@line_number,@schedule_number,@qty, case @type when 'D' then @qty else 0 end,@hu_id
				,NULL,@location_id,NULL,NULL,@wh_id,client_code
				,(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
				,'Ready'
			FROM t_po_master
			WHERE wh_id = @wh_id
			AND po_number = @control_number_2	


			--Insert t_tran_log_holding
			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
				,generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11)
			VALUES
				(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@user_id,@control_number,@control_number_2
				,@wh_id,@location_id,@hu_id,@item_number,@lot_number,@qty,
				(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
				)

				--Interface 
				--INSERT INTO [dbo].[int_upd_receipt]



			 SET @passornot = 0
			 SET @msg = ''
		COMMIT		
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END
