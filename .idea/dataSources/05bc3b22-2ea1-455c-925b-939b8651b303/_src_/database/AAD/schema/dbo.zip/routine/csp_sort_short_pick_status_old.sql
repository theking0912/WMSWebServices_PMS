




-- =======================================    
-- Author: will    
-- Create Date:03172016   
-- Description: update sort pick short status   
--  
    
-- =======================================    

CREATE PROCEDURE [dbo].[csp_sort_short_pick_status_old]    
     @wh_id					NVARCHAR(10)  
	--,@location_id           Nvarchar(30) 
	,@hu_id					Nvarchar(30)
   -- ,@pick_key               Nvarchar(30)
	,@passornot				nvarchar(1) output
	--,@ABC    Nvarchar(30)output
AS    
    
    -- SET NOCOUNT ON added to prevent extra result sets from      
BEGIN
    DECLARE @item_number  Nvarchar(30)
	DECLARE @wave_id      Nvarchar(30)
	DECLARE @order_number Nvarchar(30)
	DECLARE @qty          INT
	DECLARE @type         INT

	SET @wave_id=''
	SET @item_number=''
	SET @passornot=1
	SET @order_number=''
	SET @type=0


	-----------------------找出波次--------------------
	while (1=1)
	BEGIN
	select top 1 @type=type from t_stored_item where wh_id=@wh_id
	-- and hu_id=@hu_id 
	and isnull(hu_id,'')=isnull(@hu_id,'')  ---- Modified by Trevor on 20160412 
	and type>@type order by type

	 if @@ROWCOUNT =0
	 break

	select @wave_id=wave_id ,@order_number=order_number,@item_number=item_number 
	                                                         from tbl_pick_list 
									                         where wh_id=@wh_id and pick_id=@type
     
	 if not exists (select 1 from tbl_allocation allo where allo.wave_id =@wave_id
	                                               and  allo.item_number =@item_number
												   and  allo.order_number=@order_number
												   and  allo.wh_id=@wh_id
												   and  allo.status in ('A','U')
												   and  allo.allo_type='S')
	    begin
		   UPDATE t_pick_detail SET status = 'STAGED' 
		   where order_number=@order_number and wh_id=@wh_id and item_number =@item_number 

---Modified by Trevor on 20160328
		   --IF NOT EXISTS (select 1 from tbl_allocation where
					--	  wave_id=@wave_id and order_number =@order_number and status<>'C' and  wh_id =@wh_id )
		   IF NOT EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') not in ('STAGED','LOADED') and  a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
		      and EXISTS (select 1 from t_order_detail a
		                           left join t_pick_detail b
									on a.order_number=b.order_number and a.line_number=b.line_number and a.item_number=b.item_number and a.wh_id=b.wh_id
								  where a.order_number =@order_number and isnull(b.status,'') in ('STAGED') and a.wh_id =@wh_id
								  and isnull(b.work_type,'')='')
								  						  
			begin

			   UPDATE t_order SET status = 'STAGED' where wh_id=@wh_id and order_number=@order_number


               end
 
		end

	END
END
  
  
    








