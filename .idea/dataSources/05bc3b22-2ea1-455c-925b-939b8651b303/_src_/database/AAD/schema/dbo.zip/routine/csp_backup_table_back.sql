




--created by leroy lee 2017.221 17:00
CREATE PROCEDURE [dbo].[csp_backup_table_back]
 
AS
--获取当前日期是否为第一天
DECLARE @FirstDay		date
DECLARE @Now			date
DECLARE @BEGIN_DATE		datetime
DECLARE @END_DATE		datetime
DECLARE @BUDAT_POINT	varchar(100)
DECLARE @MONTH_DAYS		INT
DECLARE @BACKUP_COUNT		INT
DECLARE @DELETE_COUNT	decimal

select @FirstDay = convert(date,dateadd(d,-day(getdate())+1,getdate()),120) 
select @MONTH_DAYS = day(dateadd(month,1,getdate()) - day(getdate()))
select @BUDAT_POINT = convert(varchar(100),@FirstDay,112)
select @Now = convert(date,getdate(),120)

----------------------------------------------------------------------------------1、清理回传接口表----------------------------------------------------------------------------------
begin
	BEGIN TRAN
			--开始时间
			select @BEGIN_DATE = getdate()
		 
			--备份到历史表中
			insert into tbl_inf_exp_inoutbound_back
			select * 
			from tbl_inf_exp_inoutbound with(nolock)
			where BUDAT < @BUDAT_POINT
		 
			--查询备份的记录数
			select @BACKUP_COUNT = @@ROWCOUNT
		 
			--删除已备份的数据
			delete 
			from  tbl_inf_exp_inoutbound
			where BUDAT < @BUDAT_POINT

			--查询删除掉的条数
			select @DELETE_COUNT = @@ROWCOUNT
		 
			--结束时间
			select @END_DATE = getdate()

			--插入日志
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'tbl_inf_exp_inoutbound',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------2、清理tbl_inf_exp_inoutbound_log表---------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()
		--备份到历史表中
		insert into tbl_inf_exp_inoutbound_log_back
		select * 
		from tbl_inf_exp_inoutbound_log 
		where BUDAT < @BUDAT_POINT
		--删除已备份的数据
		delete
		from tbl_inf_exp_inoutbound_log 
		where BUDAT < @BUDAT_POINT
		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT
		--结束时间
		select @END_DATE = getdate()
		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end

--
EXECUTE [dbo].[pr_Dept_Bak] 
--
----------------------------------------------------------------------------------3、清理订单明细表----------------------------------------------------------------------------------
DECLARE @BEGIN_DELETE_DATE datetime
select @BEGIN_DELETE_DATE = dateadd(m,-1,getdate())
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()

		--备份到历史表中
		insert into t_order_detail_back_for_qc 
		select * 
		from t_order_detail 
		where order_number in (select order_number 
								from t_pick_detail 
								where create_date < @BEGIN_DELETE_DATE)

		--删除已备份的数据
		delete 
		from t_order_detail 
		where order_number in (select order_number 
								from t_pick_detail 
								where create_date < @BEGIN_DELETE_DATE)

		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT

		--结束时间
		select @END_DATE = getdate()

		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'t_order_detail',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------4、清理预约明细表----------------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()

		--备份到历史表中
		insert into tbl_allocation_back_for_qc 
		select * 
		from tbl_allocation 
		where order_number in (select order_number 
								from t_pick_detail 
								where create_date < @BEGIN_DELETE_DATE)
		--删除已备份的数据
		delete 
		from tbl_allocation 
		where order_number in (select order_number 
								from t_pick_detail 
								where create_date < @BEGIN_DELETE_DATE)

		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT

		--结束时间
		select @END_DATE = getdate()

		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'tbl_allocation',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------5、清理拣货明细表----------------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()

		--备份到历史表中
		insert into t_pick_detail_back_for_qc 
		select * 
		from t_pick_detail 
		where create_date < @BEGIN_DELETE_DATE

		--删除已备份的数据
		delete 
		from t_pick_detail 
		where create_date < @BEGIN_DELETE_DATE

		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT

		--结束时间
		select @END_DATE = getdate()

		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'t_pick_detail',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------6、清理ILogs表----------------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()

		--备份到历史表中
		insert into ILogs_back 
		select * 
		from ILogs 
		where LogDate < @BEGIN_DELETE_DATE
		--删除已备份的数据
		delete 
		from ILogs 
		where LogDate < @BEGIN_DELETE_DATE
		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT
		--结束时间
		select @END_DATE = getdate()
		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'ILogs',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------7、清理tbl_inf_exp_so_detail表--------------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()
		--备份到历史表中
		insert into tbl_inf_exp_so_detail_back
		select * 
		from tbl_inf_exp_so_detail 
		where inf_date < @BEGIN_DELETE_DATE
		--删除已备份的数据
		delete
		from tbl_inf_exp_so_detail 
		where inf_date < @BEGIN_DELETE_DATE
		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT
		--结束时间
		select @END_DATE = getdate()
		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'tbl_inf_exp_so_detail',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------8、清理tbl_inf_imp_poorder_log表------------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()
		--备份到历史表中
		insert into tbl_inf_imp_poorder_log_back
		select * 
		from tbl_inf_imp_poorder_log 
		where RECEIVE_DATE < @BEGIN_DELETE_DATE
		--删除已备份的数据
		delete
		from tbl_inf_imp_poorder_log 
		where RECEIVE_DATE < @BEGIN_DELETE_DATE
		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT
		--结束时间
		select @END_DATE = getdate()
		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'tbl_inf_imp_poorder_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------9、清理t_tran_log表----------------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()
		--备份到历史表中
		insert into t_tran_log_back
		select * 
		from t_tran_log 
		where start_tran_date < @BEGIN_DELETE_DATE
		--删除已备份的数据
		delete
		from t_tran_log 
		where start_tran_date < @BEGIN_DELETE_DATE
		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT
		--结束时间
		select @END_DATE = getdate()
		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'t_tran_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end
----------------------------------------------------------------------------------10、清理tbl_pick_list表----------------------------------------------------------------------------------
begin
	BEGIN TRAN
		--开始时间
		select @BEGIN_DATE = getdate()
		--备份到历史表中
		insert into tbl_pick_list_back
		select * 
		from tbl_pick_list 
		where released_date < @BEGIN_DELETE_DATE
		--删除已备份的数据
		delete
		from tbl_pick_list 
		where released_date < @BEGIN_DELETE_DATE
		--查询删除掉的条数
		select @DELETE_COUNT = @@ROWCOUNT
		--结束时间
		select @END_DATE = getdate()
		--插入日志
		insert into tbl_job_log 
		values(@FirstDay,@MONTH_DAYS,'tbl_pick_list',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
	IF @BACKUP_COUNT <> @DELETE_COUNT
		BEGIN
			ROLLBACK TRAN
			insert into tbl_job_log 
			values(@FirstDay,@MONTH_DAYS,'ROLLBACK_tbl_inf_exp_inoutbound_log',@DELETE_COUNT,@BEGIN_DATE,@END_DATE)
		END
	ELSE
		BEGIN
			COMMIT TRAN
		END
end


