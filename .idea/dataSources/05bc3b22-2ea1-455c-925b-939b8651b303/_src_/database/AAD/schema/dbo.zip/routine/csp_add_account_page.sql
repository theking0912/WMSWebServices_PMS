-- ======================================    
-- Author: JERRY.Ming   
-- Create Date: 3.2015   
-- Description: add account page
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_add_account_page]
    @wh_id NVARCHAR(20) ,
    @item_number NVARCHAR(50) ,
    @lot_number NVARCHAR(50) ,
	@line_number NVARCHAR(20),
    @qty FLOAT ,
    @uom NVARCHAR(50) ,
    @order_number NVARCHAR(50) ,
    @customer_id NVARCHAR(50) ,
    @order_type NVARCHAR(50) ,
    @type NVARCHAR(20) ,			----IN /OUT /INV  帐页类型
    @msg NVARCHAR(1000) OUTPUT
AS
    DECLARE @inv_qty INT ,
        @discrepancy_flag NVARCHAR(1) , --0 same|1 diffient
        @sysdate DATETIME ,
        @local_id NVARCHAR(50) ,
        @SQL1 NVARCHAR(1000) ,
        @SQL2 NVARCHAR(1000) ,
        @work_q_id NVARCHAR(30) ,
        @v_nReturn INT ,
        @v_nErrorNumber INT ,
        @v_vchErrorMsg NVARCHAR(1000) ,
        @expiration_date DATE ,
        @shelf_life INT ,
        @v_expir_date DATE ,
        @v_ncount INT ,
        @po_type NVARCHAR(20) ,
        @date_shipped DATE ,
        @date_expected DATE ,
        @out_vchMsg NVARCHAR(50) ,
        @i_cnt INT ,
        @passornot NVARCHAR(2) ,
        @outmsg NVARCHAR(200) ,
        @current_date NVARCHAR(50) ,
        @shipment_number NVARCHAR(100) ,
        @seq_id INT ,
        @qty_stored FLOAT ,
        @conversion_factor INT

    SET @discrepancy_flag = N'0'   
    SET @sysdate = GETDATE()
    SET @inv_qty = 0

    BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
        SET NOCOUNT ON;    
        BEGIN TRANSACTION
        BEGIN TRY

            

            IF @type = 'INV'
                BEGIN

                    SELECT  @qty_stored = ISNULL(SUM(actual_qty),0)
                    FROM    dbo.t_stored_item
                    WHERE   item_number = @item_number
                            AND wh_id = @wh_id
	   
                    SELECT  @conversion_factor = conversion_factor
                    FROM    dbo.t_item_uom
                    WHERE   item_number = @item_number
                            AND wh_id = @wh_id
                            AND uom = @uom

                    INSERT  INTO tbl_account_page
                            ( account_time ,
                              wh_id ,
                              item_number ,
                              lot_number ,
                              qty ,
                              uom ,
                              conversion_factor ,
                              order_number ,
                              customer_id ,
                              order_type ,
                              qty_stored ,
                              type
		                    )
                    VALUES  ( GETDATE() ,
                              @wh_id ,
                              @item_number ,
                              @lot_number ,
                              @qty ,
                              @uom ,
                              @conversion_factor ,
                              @order_number ,
                              @customer_id ,
                              @order_type ,
                              @qty_stored ,
                              @type
		                    )
                END

            IF @type = 'OUT'
                BEGIN
                    INSERT  INTO tbl_account_page
                            ( account_time ,
                              wh_id ,
                              item_number ,
                              lot_number ,
                              qty ,
                              uom ,
                              conversion_factor ,
                              order_number ,
                              customer_id ,
                              order_type ,
                              qty_stored ,
                              type
                            )
                            SELECT  date_order ,
                                    wh_id ,
                                    item_number ,
                                    lot_number ,
                                    qty ,
                                    order_uom ,
                                    conversion_factor ,
                                    order_number ,
                                    customer_id ,
                                    order_type ,
                                    ( SELECT    ISNULL(SUM(actual_qty),0)
                                      FROM      dbo.t_stored_item
                                      WHERE     item_number = m.item_number
                                                AND wh_id = m.wh_id
                                    ) AS qty_stored ,
                                    m.type_1
                            FROM    ( SELECT    GETDATE() AS date_order ,
                                                @wh_id AS wh_id ,
                                                ta.item_number ,
                                                lot_number ,
                                                SUM(-1 * ta.qty_shipped) AS qty ,
                                                order_uom ,
                                                tb.conversion_factor ,
                                                ta.order_number ,
                                                tc.customer_id ,
                                                tc.order_type ,
                                   -- @qty_stored,
                                                @type AS type_1
                                      FROM      dbo.t_order_detail ta
                                                LEFT OUTER JOIN dbo.t_item_uom tb ON ta.item_number = tb.item_number
                                                              AND ta.wh_id = tb.wh_id
                                                              AND ta.order_uom = tb.uom
                                                INNER JOIN dbo.t_order tc ON ta.order_number = tc.order_number
                                                              AND ta.wh_id = tc.wh_id
                                      WHERE     ta.order_number = @order_number
                                                AND ta.wh_id = @wh_id
                                                AND qty > 0
                                      GROUP BY  ta.item_number ,
                                                lot_number ,
                                                order_uom ,
                                                tb.conversion_factor ,
                                                ta.order_number ,
                                                tc.customer_id ,
                                                tc.order_type
                                    ) m


		 
                END


            IF @type = 'IN'
                BEGIN
                    INSERT  INTO tbl_account_page
                            ( account_time ,
                              wh_id ,
                              item_number ,
                              lot_number ,
                              qty ,
                              uom ,
                              conversion_factor ,
                              order_number ,
                              customer_id ,
                              order_type ,
                              qty_stored ,
                              type
                            )
                            SELECT top 1  date_order ,
                                    wh_id ,
                                    item_number ,
                                    lot_number ,
                                    @qty as qty ,
                                    uom ,
                                    conversion_factor ,
                                    order_number ,
                                    vendor_code ,
                                    order_type ,
                                    ( SELECT    ISNULL(SUM(actual_qty),0)
                                      FROM      dbo.t_stored_item
                                      WHERE     item_number = m.item_number
                                                AND wh_id = m.wh_id
                                    )+@qty AS qty_stored ,
                                    m.type_1
                            FROM    ( SELECT    GETDATE() AS date_order ,
                                                @wh_id AS wh_id ,
                                                ta.item_number ,
                                                ta.lot_number ,
                                                SUM(qty_received + qty_damaged
                                                    + qty_discount) AS qty ,
                                                tb.uom ,
                                                tb.conversion_factor ,
                                                ta.receipt_id AS order_number ,
                                                ta.vendor_code ,
                                                td.text as order_type ,
                                                @type AS type_1
                                      FROM      dbo.t_receipt ta ,
                                                t_item_uom tb,
												dbo.t_po_master tc
												left join  t_lookup td on
												tc.type_id = td.lookup_id
                                      WHERE     receipt_id = @order_number
                                                AND ta.wh_id = @wh_id
                                                AND ta.wh_id = tb.wh_id
                                                AND ta.item_number = tb.item_number
												AND ta.line_number = @line_number
												and ta.item_number=@item_number
                                                AND tb.conversion_factor = 1
												AND ta.po_number = tc.po_number
												AND ta.wh_id = tc.wh_id
                                      GROUP BY  ta.item_number ,
                                                ta.lot_number ,
                                                tb.uom ,
                                                tb.conversion_factor ,
                                                ta.receipt_id ,
                                                ta.vendor_code,
												td.text
                                    ) m
                END



            SET @msg = @msg + @out_vchMsg

            IF @msg IS NOT NULL
                BEGIN
                    ROLLBACK TRANSACTION
                    RAISERROR(@msg, 11, 1)
                END
            COMMIT
            RETURN
        END TRY

        BEGIN CATCH
            ROLLBACK TRANSACTION
            SET NOCOUNT OFF
            SET @msg = ERROR_MESSAGE() + @msg
            RAISERROR (@msg, -- Message text.
                11,
                1)
            RETURN
        END CATCH
  
    END
