
-- =======================================    
-- Author: Tony.chen    
-- Create Date: 20 Nov 2013    
-- Description: Yard Receipt    
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Shipping]    
     @wh_id				NVARCHAR(10)    
    ,@shipping_label    NVARCHAR(30)  
	,@user_id			NVARCHAR(10)
	,@passornot			nvarchar(1) output --0:Pass 1: Fail
	,@msg				nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @order_number NVARCHAR(30)
		DECLARE @display_order_number NVARCHAR(30)
		DECLARE @client_code NVARCHAR(30)

		if exists(select 1
					from tbl_shipping_label
					where ship_label_barcode = @shipping_label
					and wh_id = @wh_id
					and status = 'SHIPPED')
		begin
			SET @passornot = 1
			SET @msg = '已发运的面单.'
			return
		end

		if exists(select 1
					from tbl_shipping_label
					where ship_label_barcode = @shipping_label
					and wh_id = @wh_id
					and kit_sign = 'Y')
		begin
			update tbl_shipping_label
			set status = 'SHIPPED'
			where ship_label_barcode = @shipping_label
			and wh_id = @wh_id
			and kit_sign = 'Y'

			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
				,generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11)
			values(
				'341','Shipping',getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@shipping_label
				,@wh_id,null,@shipping_label,null,null,0,
				null,
				null,
				null,
				null,
				null,
				null,
				null,
				null,
				null,
				null,
				null)

			insert into tbl_inf_exp_so_shipping_label
						(order_number
					   ,wh_id
					   ,shipping_label
					   ,weight
					   ,client_code
					   ,comment
					   ,kit_sign
					   ,parent_label
					   ,process_status)
				select order_number
					   ,wh_id
					   ,ship_label_barcode
					   ,weight
					   ,@client_code
					   ,NULL
					   ,kit_sign
					   ,parent_label
					   ,'Ready'
				from tbl_shipping_label
				where wh_id = @wh_id
					AND order_number = @order_number
					and ship_label_barcode = @shipping_label

			update a
			set status = '1' -- Used
			from tbl_carrier_shipping_label a, tbl_shipping_label b
			where a.shipping_label = b.ship_label_barcode
			and   b.wh_id = @wh_id
			AND   b.order_number = @order_number
			and   b.ship_label_barcode = @shipping_label

			return
		end

		BEGIN TRANSACTION
			--Get Order
			SELECT @order_number = sl.order_number
				,@client_code = o.client_code
				,@display_order_number = display_order_number
			FROM tbl_shipping_label sl
				inner join t_order o on sl.wh_id = o.wh_id and sl.order_number = o.order_number 
			WHERE sl.ship_label_barcode = @shipping_label
			AND sl.wh_id = @wh_id;
			
			--Update PKD
			UPDATE pkd
			SET status = (case when (pkd.shipped_quantity + ( SELECT SUM(quantity) 
																FROM tbl_shipping_label_detail sld
																WHERE sld.wh_id = pkd.wh_id
																and sld.item_number = pkd.item_number
																and sld.ship_label_barcode = @shipping_label) = planned_quantity)
								then 'SHIPPED'
								ELSE status end)
			
				,pkd.shipped_quantity = pkd.shipped_quantity + ( SELECT SUM(quantity) 
																FROM tbl_shipping_label_detail sld
																WHERE sld.wh_id = pkd.wh_id
																and sld.item_number = pkd.item_number
																and sld.ship_label_barcode = @shipping_label)
			FROM t_pick_detail pkd
			WHERE pkd.wh_id = @wh_id
			and pkd.order_number = @order_number
			AND EXISTS ( SELECT 1
							FROM tbl_shipping_label_detail sld
							WHERE sld.wh_id = pkd.wh_id
							and sld.item_number = pkd.item_number
							and sld.ship_label_barcode = @shipping_label)

			

			--update order line
			UPDATE od
			SET od.qty_shipped = od.qty_shipped + ( SELECT SUM(quantity) 
													FROM tbl_shipping_label_detail sld
													WHERE sld.wh_id = od.wh_id
													and sld.item_number = od.item_number
													and sld.ship_label_barcode = @shipping_label)
			FROM t_order_detail od
			WHERE od.wh_id = @wh_id
			and od.order_number = @order_number
			AND EXISTS ( SELECT 1
						FROM tbl_shipping_label_detail sld
						WHERE sld.wh_id = od.wh_id
						and sld.item_number = od.item_number
						and sld.ship_label_barcode = @shipping_label)

			--Update Shipping status
			UPDATE tbl_shipping_label
			SET status ='SHIPPED'
			WHERE wh_id = @wh_id
			AND ship_label_barcode = @shipping_label
			
			--UPDATE order status 
			UPDATE t_order
			SET status = 'SHIPPED'
			    ,actual_ship_date = getdate()
			WHERE wh_id = @wh_id
			AND order_number = @order_number
			AND NOT EXISTS ( SELECT 1 FROM t_order_detail od
							WHERE od.wh_id =  @wh_id
							AND order_number = @order_number
							AND qty <>  qty_shipped)
			--Create Log
			--Insert t_tran_log_holding
			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
				,generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11)
			SELECT
				'341','Shipping',getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@shipping_label
				,@wh_id,sto.location_id,sto.hu_id,sto.item_number,sto.lot_number,sto.actual_qty,
				(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sto.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
			FROM t_stored_item sto
			WHERE wh_id = @wh_id
			and hu_id = @shipping_label

			--Create interface for shipping
			INSERT INTO tbl_inf_exp_so_master
				([order_number],[user_id],[warehouse_id],[client_code],[process_status],carrier_code)
			SELECT order_number,@user_id, wh_id,client_code,'Ready',carrier_scac
			FROM t_order
			WHERE wh_id = @wh_id
			and order_number = @order_number

			INSERT INTO tbl_inf_exp_so_detail
				([line_number],[item_number],[lot_number],[quantity_shipped],[hu_id],[user_id],[warehouse_id]
				 ,client_code,uom,order_number,display_order_number
				 ,generic_attribute1,generic_attribute2,generic_attribute3,
               generic_attribute4,generic_attribute5,generic_attribute6,
                generic_attribute7,generic_attribute8,generic_attribute9,
                generic_attribute10,generic_attribute11	,[process_status]
				)
			SELECT sld.line_number,sld.item_number,sld.lot_number,sld.quantity,sld.ship_label_barcode,@user_id,@wh_id
				,@client_code,'EA',@order_number,@display_order_number,
				(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = sld.stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
				,'Ready'
			FROM tbl_shipping_label_detail sld 
				inner join tbl_shipping_label sl on sld.wh_id = sl.wh_id
												and sld.ship_label_barcode = sl.ship_label_barcode
			WHERE sl.wh_id = @wh_id
			and sl.ship_label_barcode = @shipping_label

			-- set line_number when line_number is null
			update tbl_inf_exp_so_detail
			set line_number = (select max(line_number) 
								from t_order_detail od 
								where tbl_inf_exp_so_detail.warehouse_id = od.wh_id
								and tbl_inf_exp_so_detail.item_number = od.item_number
								and tbl_inf_exp_so_detail.order_number = od.order_number
								and (tbl_inf_exp_so_detail.lot_number is null or tbl_inf_exp_so_detail.lot_number = od.lot_number)
								and od.order_number = @order_number)
			where warehouse_id = @wh_id
			and order_number = @order_number
			and (line_number is null or line_number = '')

			INSERT INTO tbl_inf_exp_so_sn
					   (order_number
					   ,wh_id
					   ,serial_number
					   ,item_number
					   ,client_code
					   ,comment
					   ,process_status)
				SELECT order_number,wh_id,serial_number,item_number,@client_code,NULL,'Ready' 
				  FROM tbl_sn_master
				  WHERE hu_id = @shipping_label
					AND wh_id = @wh_id
					AND order_number = @order_number

			insert into tbl_inf_exp_so_shipping_label
						(order_number
					   ,wh_id
					   ,shipping_label
					   ,weight
					   ,client_code
					   ,comment
					   ,process_status)
				select order_number
					   ,wh_id
					   ,ship_label_barcode
					   ,weight
					   ,@client_code
					   ,NULL
					   ,'Ready'
				from tbl_shipping_label
				where wh_id = @wh_id
					AND order_number = @order_number
					and ship_label_barcode = @shipping_label

			update a
			set status = '1' -- Used
			from tbl_carrier_shipping_label a, tbl_shipping_label b
			where a.shipping_label = b.ship_label_barcode
			and   b.wh_id = @wh_id
			AND   b.order_number = @order_number
			and   b.ship_label_barcode = @shipping_label

			--Delete STO
			DELETE FROM t_stored_item
			WHERE wh_id = @wh_id
			AND hu_id = @shipping_label

			--Delete HU
			DELETE FROM t_hu_master
			WHERE wh_id = @wh_id
			AND hu_id = @shipping_label

			--UPDATE tbl_sn_master
			DELETE FROM  tbl_sn_master
			WHERE hu_id = @shipping_label
			AND wh_id = @wh_id
			AND order_number = @order_number

			--CREATE SN Interface
			 SET @passornot = 0
			 SET @msg = ''
		COMMIT		
        RETURN

    END TRY

    BEGIN CATCH
        ROLLBACK
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END

