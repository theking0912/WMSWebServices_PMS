-- ======================================    
-- Author: JERRY.Ming   
-- Create Date: 11.2014   
-- Description: add po to print
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_add_po_to_print]    
     @wh_id				    NVARCHAR(10)   
	,@user_id               NVARCHAR(30)
	,@status				NVARCHAR(10)
	,@comments				NVARCHAR(100)
	,@po_number				nvarchar(50)
	,@locale_id				NVARCHAR(50)
	,@item_number			NVARCHAR(50)
    ,@line_number			NVARCHAR(50)
	,@print_num				NVARCHAR(20)
--	,@qty					FLOAT
    ,@msg					nvarchar(1000) output

AS    
 DECLARE      
    @inv_qty               INT,
	@discrepancy_flag      NVARCHAR(1), --0 same|1 diffient
	@sysdate               DATETIME,
	@local_id              NVARCHAR(50),
	@SQL1                  NVARCHAR(1000),
	@SQL2                  NVARCHAR(1000),
	@work_q_id             NVARCHAR(30),
	@v_nReturn			   INT,
	@v_nErrorNumber		   INT,
	@v_vchErrorMsg		   NVARCHAR(1000),
	@expiration_date       DATE,
	@shelf_life			   int,
	@v_expir_date		   date,
	@v_ncount				int,
	@po_type			   nvarchar(20)
    ,@date_shipped			DATE
	,@date_expected			Date
	,@out_vchMsg			NVARCHAR(50)
	,@i_cnt					int
	,@passornot				nvarchar(2)
	,@outmsg					nvarchar(200)
	,@current_date			nvarchar(50)
	,@shipment_number		NVARCHAR(100)
	,@seq_id		int


	SET @discrepancy_flag = N'0'   
	SET @sysdate =getdate()
	SET @inv_qty = 0

BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    
	begin TRANSACTION
	BEGIN TRY
	  if @wh_id is null 	
	    begin
		  set @msg='仓库不能为空'
		  RAISERROR(@msg, 11, 1)
		end		
		
	  

	  ----生成shipment_number

	  SELECT TOP 1 @shipment_number = t1.shipment_number
	    from dbo.t_rcpt_ship_po t1 
	   WHERE print_num =@print_num
	     AND po_number =@po_number

	  IF ISNULL(@shipment_number,'')='' 
	    BEGIN
		  
		  SELECT @current_date = CONVERT(NVARCHAR(10), GETDATE(),112)

		  EXEC csp_Get_AutoSeqNo_ByWH  @wh_id,'VirtualPOSeqNo',@current_date,@seq_id output, @passornot output, @outmsg output
		  
		  select @shipment_number=@current_date + CONVERT(NVARCHAR(10),@seq_id)
		END 

	  
	  if ISNULL(@shipment_number,'') =''	
	    begin
		  set @msg='运单号不能为空'
		  RAISERROR(@msg, 11, 1)
		end		

	  select @v_ncount=count(*) 
	  from t_rcpt_ship where wh_id=@wh_id and shipment_number=@shipment_number 

	  select @po_type = type_id,
			 @date_shipped = create_date ,
			 @date_expected= create_date
	   from t_po_master where po_number=@po_number and wh_id=@wh_id
 
	  
	  if @status is null 	
	    begin
		  set @msg='status 不能为空'
		  RAISERROR(@msg, 11, 1)
		end	
	  
	  if @po_number is null 	
	    begin
		  set @msg='shipment_type 不能为空'
		  RAISERROR(@msg, 11, 1)
		end	
	  	
				  		
	  IF @msg is null and @v_ncount=0 
	  begin
	    
	    INSERT INTO t_rcpt_ship
					(
					wh_id,
					shipment_number,
					carrier_id,
					trailer_number,
					date_shipped,
					date_expected,
					date_received,
					date_posting,
					status,
					comments,
					shipment_type,
					create_by,
					create_date
					)

					VALUES(
					@wh_id,
					@shipment_number,
					(select top 1 carrier_id from t_carrier),
					'NO.',
					@date_shipped			
					,@date_expected			
					,GETDATE()	
					,GETDATE()			
					,@status				
					,@comments				
					,@po_type			
				    ,@user_id
					,getdate()
					)
				--	INSERT INTO t_aaa values('1',10,1000)
				--select * from t_aaa
	   
	  end

	  EXECUTE csp_rcpt_ship_add_item
		@item_number,
		@line_number,
		--@qty,
		@shipment_number,
		@po_number,
		@wh_id,
		@locale_id,
		@out_vchMsg OUTPUT
      
	  UPDATE dbo.t_rcpt_ship_po SET print_num=@print_num,asn_time =GETDATE()
	  WHERE shipment_number =@shipment_number
	   AND wh_id = @wh_id
	   

	   SET @msg= @msg + @out_vchMsg

	   IF @msg IS not NULL 
	     
	     BEGIN
		   ROLLBACK TRANSACTION
		   RAISERROR(@msg, 11, 1)
		 END
	   commit
	   RETURN
    END TRY

    BEGIN CATCH
	    ROLLBACK TRANSACTION
        SET NOCOUNT OFF
        SET @msg = ERROR_MESSAGE()+@msg
		RAISERROR (@msg, -- Message text.
                11,
                1)
        RETURN
    END CATCH
  
END
