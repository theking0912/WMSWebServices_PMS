-- Procedure
CREATE PROCEDURE  [dbo].[csp_Get_PTL_Slot]   
	@wh_id				nvarchar(20),
	@order_number		nvarchar(30),
	@zone				NVARCHAR(30),
	@customer_code		NVARCHAR(30),
	@wave_id			NVARCHAR(20),
	@out_wall_id		NVARCHAR(30) OUTPUT,
	@out_slot			NVARCHAR(30) OUTPUT
AS

BEGIN TRY

	DECLARE @qty			FLOAT
	DECLARE @client_code	NVARCHAR(30)
	DECLARE @rtn			NVARCHAR(30)
	DECLARE	@zone_group		NVARCHAR(20)

	set @out_wall_id = null
	set @out_slot = null

	-- find the wall base vip wall. if the client has vip wall, using vip wall prority.
	--select @client_code = client_code 
	--from t_order
	--where order_number = @order_number
	--and wh_id = @wh_id
	----print 'fn_Check_For_BigOrder' + @order_number +  @wh_id
	--execute @rtn = fn_Check_For_BigOrder @wh_id,@order_number
	----print '@rtn' + isnull(@rtn , 'NULL')
	---- add big order rule
	--if @rtn = '1'
	--begin
	--	select top 1 @out_wall_id = pws.wall_id
	--	from tbl_pick_wall_slot pws inner join tbl_pick_wall pw on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
	--	where pws.wh_id = @wh_id
	--	and pws.status = 'U'
	--	and pw.status = 'A'
	--	and pw.big_order = 'Y'
	--	and pw.client_code = @client_code
	--	and pws.slot like '%-4-%'
	--	order by pws.slot

	--	select top 1 @out_slot = slot
	--	from tbl_pick_wall_slot
	--	where wh_id = @wh_id
	--	and wall_id = @out_wall_id
	--	and slot like '%-4-%'
	--	and status = 'U'
	--	order by slot

	--	return
	--end

	--SELECT TOP 1 @zone_group = zone_group FROM t_zone WITH(NOLOCK) WHERE wh_id = @wh_id AND zone = @zone

	--IF NOT EXISTS(select 1
	--					from tbl_pick_wall_slot pws inner join tbl_pick_wall pw 
	--					on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
	--					inner join tbl_pick_wall_slot_detail pwsd WITH(NOLOCK)
	--					on pws.wh_id = pwsd.wh_id
	--					and pws.slot = pwsd.slot
	--					WHERE pwsd.order_number = @order_number
	--						AND pws.wh_id = @wh_id
	--						AND pw.zone_group = @zone_group)
	IF NOT EXISTS(select 1
						from tbl_pick_wall_slot pws inner join tbl_pick_wall pw 
						on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
						inner join tbl_pick_wall_slot_detail pwsd WITH(NOLOCK)
						on pws.wh_id = pwsd.wh_id
						and pws.slot = pwsd.slot
						WHERE pwsd.order_number = @order_number
							AND pws.wh_id = @wh_id
							AND EXISTS(SELECT 1 FROM tbl_pick_wall_zone pwz WITH(NOLOCK)
												WHERE pwz.wh_id = pw.wh_id
													  AND pwz.wall_id = pw.wall_id
													  AND pwz.zone = @zone))
	BEGIN
		select top 1 @out_wall_id = pws.wall_id, @qty = count(0)
		from tbl_pick_wall_slot pws inner join tbl_pick_wall pw on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
		where pws.wh_id = @wh_id
		--and pws.status = 'U'
		and pw.status = 'A'
		--and pw.zone_group = @zone_group
		AND EXISTS(SELECT 1 FROM tbl_pick_wall_zone pwz WITH(NOLOCK)
												WHERE pwz.wh_id = pw.wh_id
													  AND pwz.wall_id = pw.wall_id
													  AND pwz.zone = @zone)
		group by pws.wall_id
		order by count(0),pws.wall_id

		SELECT  @out_slot = slot
			 FROM tbl_pick_wall_slot
			WHERE customer_code = @customer_code
				AND wh_id = @wh_id
				AND wall_id = @out_wall_id
				AND wave_id = @wave_id
				ORDER BY picking_flow ASC,slot DESC

		IF @@ROWCOUNT = 0
		BEGIN
			select top 1 @out_slot = slot
			from tbl_pick_wall_slot
			where wh_id = @wh_id
			and wall_id = @out_wall_id
			and status = 'U'
			ORDER BY picking_flow ASC,slot DESC
		END

		IF ISNULL(@out_slot,'') <> ''
		BEGIN
			INSERT INTO [dbo].[tbl_pick_wall_slot_detail]
			   ([wh_id]
			   ,[wall_id]
			   ,[slot]
			   ,[order_number]
			   ,[type]
			   ,[send_time]
			   ,[remark])
			 VALUES
				   (@wh_id
				   ,@out_wall_id
				   ,@out_slot
				   ,@order_number
				   ,NULL
				   ,GETDATE()
				   ,NULL)
		
		END
	END

	

	--if EXISTS (select 1 from tbl_pick_wall where client_code = @client_code)
	--begin
	--	select top 1 @out_wall_id = pws.wall_id, @qty = isnull(sum(allo.allocated_qty - allo.picked_qty),0)
	--	from tbl_pick_wall_slot pws inner join tbl_pick_wall pw on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
	--								inner join tbl_allocation allo on pws.wh_id = allo.wh_id and pws.order_number = allo.order_number and allo.allocated_qty > allo.picked_qty
	--																and exists (select 1 from tbl_allocation allo1
	--																			where allo.wh_id = allo1.wh_id
	--																			and allo.zone = allo1.zone
	--																			and allo1.wh_id = @wh_id
	--																			and allo1.order_number = @order_number)
	--	where pws.wh_id = @wh_id
	--	and pw.status = 'A'
	--	and pw.client_code = @client_code
	--	and isnull(pw.big_order,'N') <> 'Y'
	--	and exists (select 1 from tbl_pick_wall_slot pws1
	--				where pws.wh_id = pws1.wh_id
	--				and pws.wall_id = pws1.wall_id
	--				and pws1.status = 'U')
	--	group by pws.wall_id
	--	order by isnull(sum(allo.allocated_qty - allo.picked_qty),0) desc

	--	if @out_wall_id is null
	--	select top 1 @out_wall_id = pws.wall_id, @qty = count(0)
	--	from tbl_pick_wall_slot pws inner join tbl_pick_wall pw on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
	--	where pws.wh_id = @wh_id
	--	and pws.status = 'U'
	--	and pw.status = 'A'
	--	and isnull(pw.big_order,'N') <> 'Y'
	--	and pw.client_code = @client_code
	--	group by pws.wall_id
	--	order by count(0),pws.wall_id
	--end

	---- find the wall by summary task of picking, if there are same zone
	--if @out_wall_id is null
	--select top 1 @out_wall_id = pws.wall_id, @qty = isnull(sum(allo.allocated_qty - allo.picked_qty),0)
	--from tbl_pick_wall_slot pws inner join tbl_pick_wall pw on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
	--							inner join tbl_allocation allo on pws.wh_id = allo.wh_id and pws.order_number = allo.order_number and allo.allocated_qty > allo.picked_qty
	--															and exists (select 1 from tbl_allocation allo1
	--																		where allo.wh_id = allo1.wh_id
	--																		and allo.zone = allo1.zone
	--																		and allo1.wh_id = @wh_id
	--																		and allo1.order_number = @order_number)
	--where pws.wh_id = @wh_id
	--and pw.status = 'A'
	----and isnull(pw.big_order,'N') <> 'Y'
	----and (pw.client_code is null or pw.client_code <> @client_code)
	--and exists (select 1 from tbl_pick_wall_slot pws1
	--			where pws.wh_id = pws1.wh_id
	--			and pws.wall_id = pws1.wall_id
	--			and pws1.status = 'U')
	--group by pws.wall_id
	--order by isnull(sum(allo.allocated_qty - allo.picked_qty),0) desc
	 
	---- find the wall if there is not same zone
	--if @out_wall_id is null
	--select top 1 @out_wall_id = pws.wall_id, @qty = count(0)
	--from tbl_pick_wall_slot pws inner join tbl_pick_wall pw on pw.wh_id = pws.wh_id and pw.wall_id = pws.wall_id
	--where pws.wh_id = @wh_id
	--and (pw.client_code is null or pw.client_code <> @client_code)
	--and pws.status = 'U'
	--and pw.status = 'A'
	--and isnull(pw.big_order,'N') <> 'Y'
	--group by pws.wall_id
	--order by count(0),pws.wall_id

	--select top 1 @out_slot = slot
	--from tbl_pick_wall_slot
	--where wh_id = @wh_id
	--and wall_id = @out_wall_id
	--and status = 'U'
	--order by slot

	RETURN
END TRY

BEGIN CATCH
    set @out_wall_id = null
	set @out_slot = null
    RETURN
END CATCH
