-- =======================================    
--      
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Check_Item_ForPutaway]    
     @wh_id					NVARCHAR(10)    
    ,@item_number			NVARCHAR(30) 
	,@source_hu_id			NVARCHAR(30)
	,@putaway_hu_id			NVARCHAR(30) 
	,@putaway_loc			NVARCHAR(50)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @lot_number				NVARCHAR(30)
		DECLARE @stored_attribute_id	BIGINT
		DECLARE	@expiration_date		DATETIME
		DECLARE @damage_flag			NVARCHAR(1)
		
		SELECT TOP 1 @lot_number = lot_number,
						@stored_attribute_id = stored_attribute_id,
						@expiration_date = expiration_date,
						@damage_flag = damage_flag
				FROM t_stored_item 
			WHERE hu_id = @source_hu_id
			AND item_number = @item_number
			AND wh_id = @wh_id

		IF EXISTS( SELECT 1 FROM t_stored_item
					WHERE wh_id = @wh_id
					AND location_id = @putaway_loc
					AND (hu_id = @putaway_hu_id OR ISNULL(hu_id,'') = ISNULL(@putaway_hu_id,''))
					AND item_number = @item_number
					AND (ISNULL(lot_number,'') <> ISNULL(@lot_number,'')
						OR ISNULL(stored_attribute_id,'') <> ISNULL(@stored_attribute_id,'')
						OR ISNULL(damage_flag,'N') <> ISNULL(@damage_flag,'N'))
					)
			BEGIN
				SET @passornot = 2
				RETURN
			END

		SET @passornot = 0
        RETURN

    END TRY

    BEGIN CATCH
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END
