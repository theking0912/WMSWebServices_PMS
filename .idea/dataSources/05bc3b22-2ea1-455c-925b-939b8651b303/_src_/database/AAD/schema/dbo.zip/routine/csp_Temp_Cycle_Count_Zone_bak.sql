CREATE PROCEDURE [dbo].[csp_Cycle_Count_Zone_bak]
-- Passing in warehouse ID, Location Type and Status from www page for starting and ending location
-- which to create cycle counts for

@in_vchWhId		NVARCHAR(30),
@in_vchZone		NVARCHAR(10)

AS

DECLARE 
    @v_nErrorNumber       INT,
    @v_nLogLevel          TINYINT,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INT,

    @c_nModuleNumber      INT,
    @c_nFileNumber        INT,
    @v_nRaiseErrorNumber  INT,
    @v_nReturn            INT,
    @v_vchErrorMsg        NVARCHAR(200),
    --ADD BY David
	@v_datedue            DATETIME,

-- Error Types
    @e_GenSqlError   	  INT,
    @e_InsWKQFailed       INT,
    @e_SprocError         INT,

    @v_nLoopCount         INT,
    @v_nTranCount         INT,
    @v_vchDescription     NVARCHAR(30),
    @v_vchWorkqId         NVARCHAR(30),

    @v_vchWhid            NVARCHAR(10),    
    @v_vchLocationId      NVARCHAR(50)

    SET NOCOUNT ON

    SET @c_nModuleNumber = 63
    SET @c_nFileNumber = 8
	SET @v_datedue = GETDATE()
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_InsWKQFailed = 2
    SET @e_SprocError = 3

    SELECT TOP 1 @v_vchWhid = wh_id, @v_vchLocationId = location_id
      FROM t_zone_loca
      WHERE wh_id = @in_vchWhId
        AND zone = @in_vchZone
        AND NOT EXISTS (SELECT * FROM t_work_q WHERE work_type = '08' 
		AND (work_status = 'U' OR work_status = 'A')
 		AND wh_id = t_zone_loca.wh_id AND location_id = t_zone_loca.location_id)

    WHILE @@ROWCOUNT = 1

            BEGIN  -- begin ins

                SET @v_nLoopCount = @v_nLoopCount + 1

                -- Execute to get unique work q id
                EXECUTE @v_nReturn = usp_get_next_value 'WORK_Q_ID', @v_vchWorkqId OUTPUT,
                @v_nErrorNumber OUTPUT, @v_vchErrorMsg OUTPUT
    
    	        -- Check for sproc error
          	    IF @v_nReturn <> 0 -- zero is success value
                BEGIN
                       SET @v_nErrorNumber = @e_SprocError
                    GOTO ErrorHandler
                END

                -- Insert WKQ
                INSERT INTO t_work_q (work_q_id, wh_id, location_id, work_type, work_status, 
                    description, priority, workers_required, date_due, time_due)
                     VALUES (@v_vchWorkqId, @v_vchWhid, @v_vchLocationId,
                     '08', 'U', 'Cycle Count', '90', 1, @v_datedue, @v_datedue)

                SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
                IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
                BEGIN
                    IF @v_vchSqlErrorNumber <> 0
                        SET @v_nErrorNumber = @e_GenSqlError
                    ELSE
                        SET @v_nErrorNumber = @e_InsWKQFailed
                    GOTO ErrorHandler			
                END

		SELECT TOP 1 @v_vchWhid = wh_id, @v_vchLocationId = location_id
		  FROM t_zone_loca
		  WHERE wh_id = @in_vchWhId
		    AND zone = @in_vchZone
		    AND NOT EXISTS (SELECT * FROM t_work_q WHERE work_type = '08' 
			AND (work_status = 'U' OR work_status = 'A')
			AND wh_id = t_zone_loca.wh_id AND location_id = t_zone_loca.location_id)

            END -- end ins

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_InsWKQFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An attempt to insert a cycle count task for location ' +
            ISNULL(@v_vchLocationId,'(NULL)') + ' into ' +
            ' the t_work_q table failed.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50002 -- Insert failed
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(varchar(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

ExitLabel:
    SET NOCOUNT OFF
    RETURN
