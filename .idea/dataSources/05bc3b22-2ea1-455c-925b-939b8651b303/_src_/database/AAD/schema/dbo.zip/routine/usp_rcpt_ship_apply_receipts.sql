
CREATE PROCEDURE usp_rcpt_ship_apply_receipts
@in_vchWarehouseId    NVARCHAR(20),
@in_vchShipmentNumber NVARCHAR(60),
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contians "SUCCESS" or the message to be displayed.

AS

DECLARE
    @v_vchErrorNumber       NVARCHAR(10),
    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER,

    @v_nTranCount           INTEGER,
    @v_vchStatus            NVARCHAR(1),
    @v_vchNoMoreReceipts    NVARCHAR(1),
    @v_nSeq                 INTEGER,
    @v_vchItemNumber        NVARCHAR(60),
    @v_fltReceivedQty       FLOAT,
    @v_fltExpectedQty       FLOAT,
    @v_vchPONumber          NVARCHAR(60),
    @v_vchPOLineNumber      NVARCHAR(5),
    @v_nScheduleNumber      INTEGER,
    @v_vchPrevPONumber      NVARCHAR(60),
    @v_vchPrevPOLineNumber  NVARCHAR(5),
    @v_nPrevScheduleNumber  INTEGER,
    @v_nCount               INTEGER


    DECLARE @tblItems TABLE
    (
        seq INTEGER IDENTITY(1,1),
        item_number NVARCHAR(60),
        received_qty FLOAT,
        PRIMARY KEY CLUSTERED (seq)
    )

    SET NOCOUNT ON
    SET @out_vchMessage = 'SUCCESS'

    SET @v_vchNoMoreReceipts = 'N'

    SELECT
        @v_vchStatus = status
    FROM t_rcpt_ship
    WHERE   shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouseId

    -- Be sure a row was found
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorNumber = '50001'
            SET @out_vchMessage   = 'A SQL error occured while retrieving the Shipment from t_rcpt_ship'
        END
        ELSE
        BEGIN
            SET @v_vchErrorNumber = '50002'
            SET @out_vchMessage   = 'Shipment: ' + @in_vchShipmentNumber + ' does not exist.'
        END
        GOTO ErrorHandler
    END

    -- Check Shipment status
    IF @v_vchStatus  <> 'C'
    BEGIN
       --SET @v_vchErrorNumber = '50003'
       --SET @out_vchMessage   = 'Shipment: ' + @in_vchShipmentNumber + ' not completed or has been reconciled.'
       SET @out_vchMessage = 'SUCCESS'
       GOTO ExitLabel --GOTO ErrorHandler
    END

    -- Retrieve all the received items and their quantities which have not been reconciled for the Shipment
    INSERT INTO @tblItems
    (
        item_number, 
        received_qty
    )
    SELECT
        item_number,
        qty_received
    FROM t_receipt rcp
    WHERE   wh_id = @in_vchWarehouseId
        AND shipment_number = @in_vchShipmentNumber
        AND NOT EXISTS
        (
        SELECT 1
        FROM t_rcpt_ship_po_detail rpd
        WHERE   rpd.item_number     = rcp.item_number
            AND rpd.wh_id           = @in_vchWarehouseId
            AND rpd.status          = 'R'
            AND rpd.shipment_number = rcp.shipment_number
        )

    -- Check if a SQL error occured
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
       SET @v_vchErrorNumber = '50004'
       SET @out_vchMessage   = 'A SQL Error occured while retrieving the received qty from t_rcpt_ship_details for Shipment: ' + @in_vchShipmentNumber
       GOTO ErrorHandler
    END


    SET @v_vchPrevPONumber     = '0'
    SET @v_vchPrevPOLineNumber = '0'
    SET @v_nPrevScheduleNumber = 0

    -- Initialize all the received quantities for the items that have not been reconciled
    UPDATE t_rcpt_ship_po_detail
    SET received_qty = 0
    FROM @tblItems a
    WHERE t_rcpt_ship_po_detail.item_number = a.item_number
        AND wh_id = @in_vchWarehouseId
        AND shipment_number = @in_vchShipmentNumber

     -- Check if a SQL error occured
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
       SET @v_vchErrorNumber = '50005'
       SET @out_vchMessage   = 'A SQL Error occured while initializing the received quantities for Shipment: ' + @in_vchShipmentNumber
       GOTO ErrorHandler
    END

    -- Set the Count to be used in the loop.
    SELECT @v_nCount = COUNT(*) FROM @tblItems
    SET @v_nSeq = 1

    BEGIN TRANSACTION --Begin Loop through Items
    WHILE @v_nSeq <= @v_nCount

    BEGIN
        -- Retrieve the next item and quantity to be applied to the Shipment
        SELECT
            @v_vchItemNumber = item_number,
            @v_fltReceivedQty = received_qty
        FROM @tblItems
        WHERE seq = @v_nSeq

        -- Check if a SQL error occured
        SELECT @v_vchSqlErrorNumber = @@ERROR--, @v_nRowCount = @@ROWCOUNT
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
           SET @v_vchErrorNumber = '50006'
           SET @out_vchMessage   = 'A SQL Error occured while retrieving from table variable.'
           ROLLBACK TRANSACTION
           GOTO ErrorHandler
        END

        -- Retrieve the next receipt shipment po details against which the items received quantity will be applied
        SELECT TOP 1
            @v_vchPONumber = po_number,
            @v_vchPOLineNumber = line_number,
            @v_nScheduleNumber = schedule_number,
            @v_fltExpectedQty = expected_qty
        FROM t_rcpt_ship_po_detail
        WHERE   wh_id            = @in_vchWarehouseId
            AND shipment_number  = @in_vchShipmentNumber
            AND item_number      = @v_vchItemNumber
            AND
            (
                po_number  > @v_vchPrevPONumber
                OR
                (
                        po_number   = @v_vchPrevPONumber
                    AND line_number > @v_vchPrevPOLineNumber
                )
                OR
                (
                        po_number       = @v_vchPrevPONumber
                    AND line_number     = @v_vchPrevPOLineNumber
                    AND schedule_number > @v_nPrevScheduleNumber
                )
            )
        ORDER BY
            po_number,
            line_number,
            schedule_number

        -- Check if a SQL error occured
        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
           SET @v_vchErrorNumber = '50007'
           SET @out_vchMessage   = 'A SQL Error occured while retrieving the next receipt shipment po details for Shipment: ' + @in_vchShipmentNumber
           ROLLBACK TRANSACTION
           GOTO ErrorHandler
        END

        -- If there are no more receipt shipment po details then apply the balance of the received quantity to the last po detail
        IF @v_nRowCount = 0
        BEGIN
            UPDATE t_rcpt_ship_po_detail
            SET received_qty = received_qty + @v_fltReceivedQty
            WHERE   po_number       = @v_vchPrevPONumber
                AND line_number     = @v_vchPrevPOLineNumber
                AND schedule_number = @v_nPrevScheduleNumber
                AND item_number     = @v_vchItemNumber
                AND shipment_number = @in_vchShipmentNumber
                AND wh_id           = @in_vchWarehouseId

            -- Check if a SQL error occured
            SELECT @v_vchSqlErrorNumber = @@ERROR
            IF @v_vchSqlErrorNumber <> 0
            BEGIN
               SET @v_vchErrorNumber = '50008'
               SET @out_vchMessage   = 'A SQL Error occured while updating the last receipt shipment po detail for Shipment: ' + @in_vchShipmentNumber
               ROLLBACK TRANSACTION
               GOTO ErrorHandler
            END

            SET @v_vchPrevPONumber     = '0'
            SET @v_vchPrevPOLineNumber = '0'
            SET @v_nPrevScheduleNumber = 0
            SET @v_nSeq                = @v_nSeq + 1
        END

        ELSE
        -- set the previous values to the current values
        BEGIN
            SET @v_vchPrevPONumber        = @v_vchPONumber
            SET @v_vchPrevPOLineNumber    = @v_vchPOLineNumber
            SET @v_nPrevScheduleNumber    = @v_nScheduleNumber
        END

        IF @v_nRowCount > 0
        BEGIN
            -- Update the receipt shipment po detail setting the received quantity appropriately
            UPDATE t_rcpt_ship_po_detail
            SET received_qty =
            (
                CASE WHEN expected_qty <= @v_fltReceivedQty
                     THEN expected_qty
                     ELSE @v_fltReceivedQty
                END
            )
            WHERE   po_number       = @v_vchPrevPONumber
                AND line_number     = @v_vchPrevPOLineNumber
                AND schedule_number = @v_nScheduleNumber
                AND item_number     = @v_vchItemNumber
                AND shipment_number = @in_vchShipmentNumber
                AND wh_id           = @in_vchWarehouseId

            -- Check if a SQL error occured
            SELECT @v_vchSqlErrorNumber = @@ERROR
            IF @v_vchSqlErrorNumber <> 0
            BEGIN
                SET @v_vchErrorNumber = '50009'
                SET @out_vchMessage   = 'A SQL Error occured while update the receipt shipment po detail for Shipment: ' + @in_vchShipmentNumber
                ROLLBACK TRANSACTION
                GOTO ErrorHandler
            END

            -- deduct the quantity applied to the receipt shipment po detail from the received quantity
            IF  @v_fltExpectedQty < @v_fltReceivedQty
                SET @v_fltReceivedQty = @v_fltReceivedQty - @v_fltExpectedQty
            ELSE
               SET @v_fltReceivedQty = 0

            -- if the received quantity has been depleted, then move on to the next item
            IF @v_fltReceivedQty = 0
            BEGIN
               SET @v_vchPrevPONumber      = '0'
               SET @v_vchPrevPOLineNumber  = '0'
               SET @v_nPrevScheduleNumber  = 0
               SET @v_nSeq                 = @v_nSeq + 1
            END
            ELSE

            -- if the received quantity has not been depleted then update the table variable with the balance of the received quantity
            BEGIN
                UPDATE @tblItems
                    SET received_qty = @v_fltReceivedQty
                    WHERE item_number = @v_vchItemNumber

                -- Check if a SQL error occured
                SELECT @v_vchSqlErrorNumber = @@ERROR
                IF @v_vchSqlErrorNumber <> 0
                BEGIN
                    SET @v_vchErrorNumber = '50010'
                    SET @out_vchMessage = 'A SQL Error occured while update the table variable with the balance of the received quantities for item: ' + @v_vchItemNumber
                    ROLLBACK TRANSACTION
                    GOTO ErrorHandler
                END
            END
        END -- IF v_nRowCount > 0
    END --End Loop through Items

    COMMIT Transaction

    GOTO ExitLabel

ErrorHandler:
    SET @out_vchMessage = @v_vchErrorNumber + ' - ' + @out_vchMessage
    RAISERROR (@out_vchMessage, 16, 1)

ExitLabel:
    RETURN
