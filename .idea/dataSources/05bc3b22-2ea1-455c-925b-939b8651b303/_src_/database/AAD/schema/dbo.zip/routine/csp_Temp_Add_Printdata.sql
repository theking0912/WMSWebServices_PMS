CREATE PROCEDURE  [dbo].[csp_Add_Printdata]
    @in_WarehouseID     nvarchar(20),
    @in_ParameKey       nvarchar(255),	
	@in_PrintNum        int,
    @in_Station         nvarchar(100),
	@in_PrintType       nvarchar(50),
    @in_Carrier         nvarchar(100),
	@in_Client          nvarchar(100),
	@in_User            nvarchar(50),
	@in_printstatus     nvarchar(50),
	@out_Result         int out,
	@out_ErrMess        nvarchar(150) out
AS
 DECLARE      
        @v_nError               INT,      
        @v_nRowCount            INT

		set @out_Result=0
		set @out_ErrMess='Success' 
     UPDATE tbl_print_history SET printdate= getdate(),printuser=@in_User
	 where wh_id=@in_WarehouseID 
	 and  paramekey=@in_ParameKey
	 and  station=@in_Station
	 and printtype=@in_PrintType

	SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT
	if @v_nError <> 0
	 BEGIN
	    set @out_Result=-1
		set @out_ErrMess='FAILED' 
	   RETURN 
	 END 

    IF @v_nRowCount = 0 
	 BEGIN
		---将打印信息添加进add表
		INSERT INTO tbl_print_history
			(wh_id, paramekey,station,printtype,status,printdate,printuser,carrier_code)
		VALUES
			(@in_WarehouseID, @in_ParameKey,@in_Station,@in_PrintType,
				@in_printstatus, (select getdate()),@in_User,@in_Carrier)
			SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT

		IF @v_nRowCount = 0 OR @v_nError <> 0
			BEGIN
				set @out_ErrMess='The Insert tbl_print_history failed'
				set @out_Result=-1	    
				RETURN
			END
				
    END 

	if @in_PrintType='B' 
	 Begin
		update tbl_print_client set printnum=printnum+@in_PrintNum,
		printdate=(select getdate()),printuser=@in_User
		where client_code in (select client_code from t_item_master where item_master_id=@in_ParameKey)
		and item_number in (select item_number from t_item_master where item_master_id=@in_ParameKey)
		 
 
		SELECT @v_nRowCount = @@ROWCOUNT

		IF @v_nRowCount = 0 
		Begin
				----将打印信息加入客户打印信息表
			INSERT INTO tbl_print_client
				(wh_id,client_code,item_number,printnum,printdate,printuser)
				select @in_WarehouseID,client_code, item_number,@in_PrintNum,(select getdate()),@in_User
				from t_item_master where item_master_id=@in_ParameKey

				SELECT @v_nError = @@ERROR, @v_nRowCount = @@ROWCOUNT

				IF @v_nRowCount = 0 OR @v_nError <> 0
				BEGIN
					set @out_ErrMess='The Insert tbl_print_client failed'
					set @out_Result=-1	
					RETURN
				END
			End
		End

RETURN
