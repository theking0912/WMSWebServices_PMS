
CREATE PROCEDURE usp_afa_hold_shipment
@in_vchWarehouseId    NVARCHAR(20),
@in_vchLoadId         NVARCHAR(60),
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contains "SUCCESS" or the message to be displayed.

AS

DECLARE
    @v_nLogErrorNum       INTEGER,
    @v_vchErrorMsg        NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,

    @e_GenSqlError   	   INTEGER,
    @e_NotHoldable         INTEGER,
    @e_UpdLDMFailed        INTEGER,
    @e_DelWKQDepFailed     INTEGER,
    @e_DelWKQShipReqFailed INTEGER,
    @e_DelWKQPickReqFailed INTEGER,
    @e_DelPKDFailed        INTEGER,

    @c_chHoldStatus       CHAR(1),
    @v_vchOrderNumber     NVARCHAR(60),
    @v_nTranCount         INTEGER,
    @v_nValue             INTEGER,
    @vchOrderNum          NVARCHAR(60),
    @vchWHID              NVARCHAR(20),
    @v_nContAdvFlag       INTEGER


    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @c_chHoldStatus = 'H'

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 6

    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_NotHoldable = 2
    SET @e_UpdLDMFailed = 3
    SET @e_DelWKQDepFailed = 4
    SET @e_DelWKQShipReqFailed = 5
    SET @e_DelWKQPickReqFailed = 6
    SET @e_DelPKDFailed = 7

    -- create local temp tables
    CREATE TABLE #t_carton_batch (
	   cartonization_batch_id  NVARCHAR(60) COLLATE DATABASE_DEFAULT NOT NULL
       )


    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0
        BEGIN TRANSACTION


    -- Check to see if picking has begun for any fo the orders in the set of loads
    -- to be put on hold.
    SELECT @v_nRowCount = COUNT (*)
    FROM t_pick_detail
    WHERE wh_id = @in_vchWarehouseId
        AND load_id = @in_vchLoadId
        AND(
            (picked_quantity > 0) 
	     OR (staged_quantity > 0) 
	     OR (loaded_quantity > 0)
            )

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount > 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        END
        ELSE
        BEGIN
             SET @v_vchErrorMsg = 'Load cannot be held.  Picking has started.'
             SET @v_nLogErrorNum = @e_NotHoldable
        END
    GOTO ErrorHandler
    END


    -- Check to see if labels have been printed for any of the orders on the wave
    -- to be put on hold.
    SELECT @v_nRowCount = COUNT (*)
    FROM t_pick_detail pkd, t_label lbl
    WHERE pkd.pick_id = lbl.pick_id
        AND lbl.label_status in ( 'PRINTED' , 'REPRINTED' )
        AND pkd.wh_id = @in_vchWarehouseId
        AND pkd.load_id = @in_vchLoadId

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount > 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        END
        ELSE
        BEGIN
             SET @v_vchErrorMsg = 'Wave cannot be held.  Picking has started (labels printed).'
             SET @v_nLogErrorNum = @e_NotHoldable
        END
    GOTO ErrorHandler
    END

    -- Get all the containerization batch id's on the wave for lines sent to cartonization
    INSERT INTO #t_carton_batch (cartonization_batch_id) 
        (SELECT cartonization_batch_id
        FROM t_pick_detail
        WHERE wh_id = @in_vchWarehouseId
            AND load_id = @in_vchLoadId
            AND cartonization_batch_id IS NOT NULL) -- Was sent to cartonizaiton


    -- Checkk for errors
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        SET @v_vchErrorMsg = 'temp fill SQL Server System error occured!  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
    -- Check rows affected
    IF @v_nRowCount = 0
    BEGIN
        -- nothing cartonized
        GOTO HoldShipment
    END 

    -- If there are rows then delete anything in the pick container table
    -- Delete all container data on the wave
    DELETE t_pick_container
    WHERE cartonization_batch_id IN 
           (SELECT cartonization_batch_id
            FROM #t_carton_batch)
        AND wh_id = @in_vchWarehouseId

    -- Check for errors 
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        SET @v_vchErrorMsg = 'bbb SQL Server System error occured!  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    -- Check if Container Advantage is being used. If it is then more data clean up.
    SELECT @v_nContAdvFlag = ISNULL(next_value, 0)
    FROM t_control 
    WHERE control_type = 'CONTAINER-OPTIMIZE'


    IF @v_nContAdvFlag = 1 -- CTA is being used
    BEGIN -- Begin Cartonization clean up
        -- Delete the cartonization results data results data
        DELETE t_container_optimize_block
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM #t_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'wwwSQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


        DELETE t_container_optimize_status
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM #t_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


        DELETE t_container_optimize_xml
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM #t_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END


        -- delete carton prep data
        DELETE t_pick_task_uom
        WHERE cartonization_batch_id IN 
               (SELECT cartonization_batch_id
                FROM #t_carton_batch)
            AND wh_id = @in_vchWarehouseId

        -- Check for errors 
        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END

    END -- End Cartonization cleanup



HoldShipment:
    -- Update t_load_master to a hold status
    UPDATE t_load_master
    SET status = @c_chHoldStatus
    WHERE load_id = @in_vchLoadId
        AND wh_id = @in_vchWarehouseId

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        END
        ELSE
        BEGIN
             SET @v_vchErrorMsg = 'Falied to update t_load_master record to status of H.'
             SET @v_nLogErrorNum = @e_UpdLDMFailed
        END
    GOTO ErrorHandler
    END


    -- Delete the pick details and any work requests related to the load
    --First delete dependency records
    DELETE t_work_q_dependency
    WHERE wh_id = @in_vchWarehouseId
        AND parent_work_q_id IN (SELECT work_q_id
                               FROM t_work_q
                               WHERE wh_id = @in_vchWarehouseId
                                   AND pick_ref_number = @in_vchLoadId)
        OR dependent_work_q_id IN (SELECT work_q_id
                               FROM t_work_q
                               WHERE wh_id = @in_vchWarehouseId
                                   AND pick_ref_number = @in_vchLoadId)

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

    
    -- Delete any related ship, load, or load_audit requests
    DELETE t_work_q
    WHERE wh_id = @in_vchWarehouseId
        AND pick_ref_number = @in_vchLoadId
        AND work_type IN ('10', '11', '12')

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 --OR @v_nRowCount = 0
    BEGIN
        --IF @v_vchSqlErrorNumber <> 0
        --BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        --END
        --ELSE
        --BEGIN
        --    SET @v_vchErrorMsg = 'Falied to delete ship request records from the t_work_q table.'
        --     SET @v_nLogErrorNum = @e_DelWKQShipReqFailed
        --END
    GOTO ErrorHandler
    END


   -- Delete the pick request work_q's
   DELETE t_work_q
   WHERE wh_id = @in_vchWarehouseId
       AND work_q_id IN (SELECT work_q_id
                         FROM t_pick_detail
                         WHERE wh_id = @in_vchWarehouseId
                             AND load_id = @in_vchLoadId)

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 --OR @v_nRowCount = 0
    BEGIN
        --IF @v_vchSqlErrorNumber <> 0
        --BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        --END
        --ELSE
        --BEGIN
        --     SET @v_vchErrorMsg = 'Falied to delete pick request records from the t_work_q table.'
        --     SET @v_nLogErrorNum = @e_DelWKQPickReqFailed
        --END
    GOTO ErrorHandler
    END

   -- delete the label records
   DELETE lbl
   FROM t_label lbl , t_pick_detail pkd  
    WHERE lbl.pick_id = pkd.pick_id
        AND pkd.wh_id = @in_vchWarehouseId
        AND pkd.load_id = @in_vchLoadId

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
        'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
    	GOTO ErrorHandler
    END


   -- delete the pick detail records
   DELETE t_pick_detail
   WHERE wh_id = @in_vchWarehouseId
       AND load_id = @in_vchLoadId

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 --OR @v_nRowCount = 0
    BEGIN
        --IF @v_vchSqlErrorNumber <> 0
        --BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
        --END
        --ELSE
        --BEGIN
        --     SET @v_vchErrorMsg = 'Falied to detlete record from the t_pick_detail table.'
        --     SET @v_nLogErrorNum = @e_DelPKDFailed
        --END
    GOTO ErrorHandler
    END

	-- START CSA ORDER STATUS HISTORY LOGIC
	-- Add Code here to loop through all the orders on a shipment and write an order status history record for CSA.
	
    --If CSA is installed and the order history sproc exists then insert order status history records.
    --First check to see if CSA is installed and the usp_ta_order_status_history sproc are installed.
    --SELECT @v_nValue = next_value FROM t_control WHERE control_type = 'CSA'
    --If the sproc exists
    --IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('dbo.usp_ta_order_status_history'))
    --BEGIN
    --	--AND if CSA is installed
    --    IF ISNULL(@v_nValue,0) = 1
	--BEGIN
	--    DECLARE curOrders INSENSITIVE CURSOR FOR
    --    	SELECT order_number, wh_id
    --        		FROM t_ta_load_detail
    --        		WHERE load_id = @in_vchLoadId
    --    		FOR READ ONLY
    --   	OPEN curOrders
    --
    --		FETCH NEXT FROM curOrders
    --        		INTO @vchOrderNum, @vchWHID
    --
    --		WHILE @@FETCH_STATUS = 0
    --		BEGIN
    --
	--		EXECUTE usp_ta_order_status_history @vchWHID, @vchOrderNum, 'RELEASED'
    --
 	--	FETCH NEXT FROM curOrders
    --        		INTO @vchOrderNum, @vchWHID
    --		END
    --		CLOSE curOrders
   	-- 	DEALLOCATE curOrders
	--END
    --END --Of inserting CSA order status history records.
    
	-- ENDCSA ORDER STATUS HISTORY LOGIC



    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
    EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

    IF @v_nTranCount = 0
    	ROLLBACK TRANSACTION
   
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    
    

    SET @out_vchMessage = @v_vchErrorMsg


ExitLabel:
    RETURN
