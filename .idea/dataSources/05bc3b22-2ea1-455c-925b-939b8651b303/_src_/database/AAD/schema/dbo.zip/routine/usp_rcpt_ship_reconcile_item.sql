
CREATE PROCEDURE usp_rcpt_ship_reconcile_item
@in_vchWarehouse      NVARCHAR(20),    
@in_vchShipmentNumber NVARCHAR(60),
@in_vchItemNumber     NVARCHAR(60),
@in_vchUserID         NVARCHAR(10),
@out_vchMessage       NVARCHAR(200) OUTPUT -- Contains "SUCCESS" or the message to be displayed.

AS

DECLARE 
    -- Error handling variables    
    @c_vchObjName           NVARCHAR(30), -- The name that uniquely tags this object.   
    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER,
    
    -- Local Variables
    @v_nCount               INTEGER,
    @v_chStatus             NCHAR(1),
    @v_chItemStatus         NCHAR(1),
    @v_dtStartDate          DATETIME,
    @v_dtStartTime          DATETIME,
    @v_dtEndDate            DATETIME,
    @v_dtEndTime            DATETIME,
    @v_dtElapsedTime        DATETIME,
    @v_shipAllocateInv      INTEGER,
	
	-- Constants
	@c_nStorageType			INT,
	@c_nReconcile			INT
   
    SET NOCOUNT ON

    -- Set Constants
    SET @c_vchObjName = 'usp_rcpt_ship_reconcile_item'    
	SET @c_nStorageType = 0
	SET @c_nReconcile	= -1
	
    -- Intialize Variables    
    SET @out_vchMessage = 'SUCCESS'
    SET @v_dtStartDate  = GETDATE()
    SET @v_dtStartTime  = GETDATE()

    
    -- get the Ship Allocate Inv warehouse control parameter
    SELECT @v_shipAllocateInv = next_value 
    FROM t_whse_control
    WHERE control_type = 'SHIP_ALLOCATE_INV'
      AND wh_id = @in_vchWarehouse
    
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @out_vchMessage = 'A SQL error occured while retrieving parameter from t_whse_cotrol.'
        GOTO ERROR_HANDLER
    END
    IF @v_nRowCount = 0
      SET  @v_shipAllocateInv = 0 
    
    
    SELECT @v_chStatus = status
    FROM t_rcpt_ship
    WHERE   shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouse
    
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @out_vchMessage = 'A SQL error occured while retrieving status from t_rcpt_ship.'
        GOTO ERROR_HANDLER
    END
    IF @v_nRowCount = 0
    BEGIN
        SET @out_vchMessage = 'Shipment [' + @in_vchShipmentNumber + '] does not exist.'
        GOTO ERROR_HANDLER
    END
    
    -- Check Shipment status
    IF @v_chStatus  <> 'C'
    BEGIN  
        SET @out_vchMessage = 'Shipment [' + @in_vchShipmentNumber + '] not completed or has been reconciled.'
        GOTO ERROR_HANDLER
    END
    
    SELECT @v_chItemStatus = status
    FROM t_rcpt_ship_po_detail
    WHERE   shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouse
        AND item_number     = @in_vchItemNumber
       
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @out_vchMessage = 'A SQL error occured while retrieving status from t_rcpt_ship_po_detail.'
        GOTO ERROR_HANDLER
    END
    IF @v_nRowCount = 0
    BEGIN
        SET @out_vchMessage = 'Item Number [' + @in_vchItemNumber + '] does not exist.'
        GOTO ERROR_HANDLER
    END
    
    -- Check item status
    IF @v_chItemStatus  = 'R'
    BEGIN 
        SET @out_vchMessage = 'Item Number [' + @in_vchItemNumber + '] has been reconciled.'
        GOTO ERROR_HANDLER
    END
    
               
    BEGIN TRANSACTION  
        ----------------------------------------------------------------------
        -- Create t_ran_log (LOG) records for the items about to reconciled.
        -- This is done 1st so trace items can be consolidated properly.
        ----------------------------------------------------------------------
        SET @v_dtEndDate     = GETDATE()
        SET @v_dtEndTime     = GETDATE()
        SET @v_dtElapsedTime = @v_dtStartTime - @v_dtEndTime

        IF @v_shipAllocateInv = 0
        BEGIN

	        INSERT INTO t_tran_log_holding
	        (
	            tran_type, 
	            description, 
	            start_tran_date, 
	            start_tran_time, 
	            end_tran_date, 
	            end_tran_time, 
	            employee_id, 
	            control_number, 
	            wh_id, 
	            item_number, 
	            location_id, 
	            lot_number,
	            elapsed_time,
	            tran_qty,
	            control_number_2,
	            line_number,
                hu_id,
                hu_id_2,
                generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11
	        )
	        SELECT 
	            '156', 
	            'Shipment Reconciliation', 
	            @v_dtStartDate, 
	            @v_dtStartTime, 
	            @v_dtEndDate, 
	            @v_dtEndTime,
	            @in_vchUserID, 
	            rpd.po_number, 
	            @in_vchWarehouse, 
	            @in_vchItemNumber, 
	            sto.location_id, 
	            sto.lot_number,          
	            (SELECT DATEDIFF (millisecond, @v_dtStartTime, @v_dtEndTime)),
	            rpd.received_qty,
	            @in_vchShipmentNumber,
	            rpd.line_number,
                sto.hu_id,
                sto.hu_id,
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_1) AS val1,    
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_2) AS val2, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_3) AS val3, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_4) AS val4, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_5) AS val5, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_6) AS val6, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_7) AS val7, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_8) AS val8, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_9) AS val9, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_10) AS val10, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_11) AS val11
	            FROM t_stored_item sto,
	                 t_rcpt_ship_po_detail rpd,
					 t_attribute_legacy_map alm
	            WHERE  sto.item_number = rpd.item_number
	              AND  sto.wh_id       = rpd.wh_id
	              AND  sto.type        = @c_nReconcile
				  AND  sto.shipment_number = rpd.shipment_number
	              AND  sto.item_number = @in_vchItemNumber
	              AND  sto.shipment_number = @in_vchShipmentNumber
	              AND  sto.wh_id       = @in_vchWarehouse
	        
	        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
	        IF @v_vchSqlErrorNumber <> 0
	        BEGIN    
	            SET @out_vchMessage = 'A SQL error occured while inserting into t_tran_log.'    
	            GOTO ERROR_HANDLER_WITH_ROLLBACK
	        END
	
	        -- Move and consolidate any trace items from type Shipment Number to STORAGE.
	        EXECUTE usp_consolidate_sto_trace @in_vchWarehouse, @c_nReconcile, @in_vchItemNumber,NULL,@in_vchShipmentNumber;
	        
	        -- Move the remaining items to STORAGE.
	        UPDATE t_stored_item
	        SET actual_qty = sto2.actual_qty + sto1.actual_qty
	        FROM 
	        t_stored_item sto2,
	        (
	            SELECT *
	            FROM t_stored_item sto
	            WHERE type = @c_nReconcile
				AND shipment_number = @in_vchShipmentNumber
	            AND wh_id = @in_vchWarehouse
	            AND item_number = @in_vchItemNumber
	        ) sto1 
	        WHERE   sto2.item_number = @in_vchItemNumber
	            AND sto2.type        = @c_nStorageType
	            AND sto2.location_id = sto1.location_id
	            AND ISNULL(sto2.lot_number,'')  = ISNULL(sto1.lot_number, '')
			    AND ISNULL(sto2.stored_attribute_id,'') = ISNULL(sto1.stored_attribute_id,'')
			    AND ISNULL(sto2.hu_id,'') = ISNULL(sto1.hu_id,'')
	            AND sto2.wh_id       = sto1.wh_id
	           
	        SELECT @v_vchSqlErrorNumber = @@ERROR
	        IF @v_vchSqlErrorNumber <> 0     
	        BEGIN 
	            SET @out_vchMessage = 'A SQL error occured while updating t_stored_item.'
	            GOTO ERROR_HANDLER_WITH_ROLLBACK
	        END
	        
	        -- Insert the remaining inventory to the available 'STORAGE' bucket 
	        INSERT INTO t_stored_item 
	        (
	            item_number, 
	            actual_qty, 
	            unavailable_qty, 
	            status, 
	            wh_id, 
	            location_id, 
	            fifo_date,   
	            expiration_date, 
	            reserved_for, 
	            lot_number, 
	            inspection_code, 
	            serial_number, 
	            type,
	            put_away_location, 
				stored_attribute_id,
                hu_id
	        )
	        SELECT 
	            item_number, 
	            actual_qty, 
	            unavailable_qty, 
	            'A', 
	            wh_id, 
	            location_id, 
	            fifo_date,   
	            expiration_date, 
	            reserved_for, 
	            lot_number, 
	            inspection_code, 
	            serial_number, 
	            @c_nStorageType,
	            put_away_location, 
				stored_attribute_id,
                hu_id
	        FROM t_stored_item sto
	        WHERE   sto.item_number = @in_vchItemNumber
	            AND sto.type        = @c_nReconcile
				AND sto.shipment_number = @in_vchShipmentNumber
	            AND sto.wh_id       = @in_vchWarehouse
	            AND NOT EXISTS 
	            (
	                SELECT 1
	                FROM t_stored_item sto1
	                WHERE   sto1.item_number = sto.item_number
	                    AND sto1.type        = @c_nStorageType
	                    AND sto1.location_id = sto.location_id
	                    AND ISNULL(sto1.lot_number, '')  = ISNULL(sto.lot_number, '')
						AND ISNULL(sto1.stored_attribute_id,'') = ISNULL(sto.stored_attribute_id,'')
						AND ISNULL(sto1.hu_id,'') = ISNULL(sto.hu_id,'')
	                    AND sto.wh_id        = sto.wh_id
	            )
	        
	        SELECT @v_vchSqlErrorNumber = @@ERROR
	        IF @v_vchSqlErrorNumber <> 0     
	        BEGIN 
	            SET @out_vchMessage   = 'A SQL error occured while inserting into t_stored_item with a status of A.'
	            GOTO ERROR_HANDLER_WITH_ROLLBACK
	        END      
	                                              
	        -- Release HUMs for Shipment/Item
	        UPDATE t_hu_master 
	        SET status         = 'A',
	            control_number = NULL
	        WHERE control_number = @in_vchShipmentNumber
	            AND wh_id = @in_vchWarehouse
	            AND EXISTS 
	            (
	                SELECT 1 
	                FROM t_stored_item sto
	                WHERE   sto.item_number = @in_vchItemNumber
	                    AND sto.hu_id       = t_hu_master.hu_id
	                    AND sto.wh_id       = t_hu_master.wh_id
	            )
	            AND NOT EXISTS 
	            (
	            SELECT 1 
	            FROM t_stored_item sto
	            WHERE   sto.item_number <> @in_vchItemNumber
	                AND sto.hu_id = t_hu_master.hu_id
	                AND sto.wh_id = t_hu_master.wh_id
	                AND (sto.status = 'H'
	                    OR sto.type <> @c_nStorageType)
	            )
	        
	        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT         
	        IF @v_vchSqlErrorNumber <> 0
	        BEGIN 
	            SET @out_vchMessage = 'A SQL error occured while updating the status and control_number on t_hu_master.'
	            GOTO ERROR_HANDLER_WITH_ROLLBACK
	        END
	                
	        -- Delete all sto records for this Shipment/item
	        DELETE t_stored_item
	        WHERE   item_number = @in_vchItemNumber
	            AND type        = @c_nReconcile
				AND shipment_number = @in_vchShipmentNumber
	            AND wh_id       = @in_vchWarehouse          
	         
	        SELECT @v_vchSqlErrorNumber = @@ERROR
	        IF @v_vchSqlErrorNumber <> 0
	        BEGIN    
	            SET @out_vchMessage = 'A SQL error occured while deleting records from t_stored_item.'
	            GOTO ERROR_HANDLER_WITH_ROLLBACK
	        END
	        
        END
	ELSE
	BEGIN

	        INSERT INTO t_tran_log_holding
	        (
	            tran_type, 
	            description, 
	            start_tran_date, 
	            start_tran_time, 
	            end_tran_date, 
	            end_tran_time, 
	            employee_id, 
	            control_number, 
	            wh_id, 
	            item_number, 
	            location_id, 
	            lot_number,
	            elapsed_time,
	            tran_qty,
	            control_number_2,
	            line_number,
                hu_id,
                hu_id_2,
                generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11
	        )
	        SELECT 
	            '156', 
	            'Shipment Reconciliation', 
	            @v_dtStartDate, 
	            @v_dtStartTime, 
	            @v_dtEndDate, 
	            @v_dtEndTime,
	            @in_vchUserID, 
	            rpd.po_number, 
	            @in_vchWarehouse, 
	            @in_vchItemNumber, 
	            sto.location_id, 
	            sto.lot_number,          
	            (SELECT DATEDIFF (millisecond, @v_dtStartTime, @v_dtEndTime)),
	            rpd.received_qty,
	            @in_vchShipmentNumber,
	            rpd.line_number,
                sto.hu_id,
                sto.hu_id,
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_1) AS val1,    
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_2) AS val2, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_3) AS val3, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_4) AS val4, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_5) AS val5, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_6) AS val6, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_7) AS val7, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_8) AS val8, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_9) AS val9, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_10) AS val10, 
    			(SELECT attribute_value 
    			FROM t_sto_attrib_collection_detail 
    			WHERE stored_attribute_id = sto.stored_attribute_id
    			AND attribute_id = alm.generic_attribute_11) AS val11
	            FROM t_stored_item sto,
	                 t_rcpt_ship_po_detail rpd,
					 t_attribute_legacy_map alm
	            WHERE  sto.item_number = rpd.item_number
	              AND  sto.wh_id       = rpd.wh_id
                  AND rpd.shipment_number = @in_vchShipmentNumber
	              AND  sto.item_number = @in_vchItemNumber
	              AND  rpd.item_number = @in_vchItemNumber
	              AND  sto.type        = @c_nStorageType
	              AND  sto.wh_id       = @in_vchWarehouse 
	              
	              

	        SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
	        IF @v_vchSqlErrorNumber <> 0
	        BEGIN    
	            SET @out_vchMessage = 'A SQL error occured while inserting into t_tran_log.'    
	            GOTO ERROR_HANDLER_WITH_ROLLBACK
	        END

	END
        
    COMMIT TRANSACTION
             
FINALIZE:
    -- Update the status on t_rcpt_ship_po_detail to 'R'
    UPDATE t_rcpt_ship_po_detail
    SET status = 'R',
        reconciled_date = GETDATE()
    WHERE   item_number     = @in_vchItemNumber
        AND shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouse
        AND status          = 'O'
    
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0
    BEGIN 
        SET @out_vchMessage = 'A SQL error occured while updating t_rcpt_ship_po_detail.status to reconciled.'
    END
    IF @v_nRowCount = 0
    BEGIN 
        SET @out_vchMessage = 'No t_rcpt_ship_po_detail records available to update.'
        GOTO ERROR_HANDLER
    END
            
    -- Update status to 'R' on t_rcpt_ship when all items have been reconciled or sent to the host for the Shipment
    UPDATE t_rcpt_ship
    SET status = 'R'
    WHERE   shipment_number = @in_vchShipmentNumber
        AND wh_id           = @in_vchWarehouse
        AND NOT EXISTS 
        (
            SELECT 1
            FROM t_rcpt_ship_po_detail
            WHERE   wh_id           =  @in_vchWarehouse
                AND shipment_number =  @in_vchShipmentNumber
                AND status          = 'O'
        )
    
    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN 
        SET @out_vchMessage = 'A SQL error occured while updating t_rcpt_ship.status to reconciled.'
        GOTO ERROR_HANDLER
    END
    
    GOTO EXIT_LABEL 
    
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER_WITH_ROLLBACK:

    ROLLBACK TRANSACTION
    
ERROR_HANDLER:
    
    SET @out_vchMessage = @c_vchObjName + ': ' + @out_vchMessage + ' SQL Error = '
                          + @v_vchSqlErrorNumber

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

    RETURN
