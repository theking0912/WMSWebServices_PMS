



CREATE PROCEDURE [dbo].[csp_OST_MoveToDest] 
     @wh_id					NVARCHAR(10) 
	,@order_number			NVARCHAR(30)
    ,@pick_id				bigint
	,@item_number			NVARCHAR(30) 
	,@lot_number			nvarchar(30) 
	,@stored_attribute_id   bigint 
	,@source_location_id	nvarchar(30) 
	,@source_hu_id			nvarchar(30) 
	,@dest_location_id      nvarchar(30) 
	,@dest_hu_id			nvarchar(30) 
	,@qty			        FLOAT 
	,@user_id				nvarchar(30)
	,@passornot				int OUTPUT
	,@msg					nvarchar(200) OUTPUT
AS
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
	BEGIN TRANSACTION
		DECLARE @dest_client nvarchar(30)
		DECLARE @dest_item nvarchar(30)
		DECLARE @dest_disp_item nvarchar(30)
		DECLARE	@out_vchCode uddt_output_code,
				@out_vchMsg uddt_output_msg
		DECLARE @fifoDate DATETIME
		DECLARE @expiration_date DATETIME
		DECLARE @remove_qty float

		set @remove_qty = @qty * -1

		SELECT @fifoDate = fifo_date
			,@expiration_date = expiration_date
		 FROM t_stored_item
		WHERE wh_id = @wh_id
		and item_number = @item_number
		and location_id = @source_location_id
		and isnull(hu_id,'') = isnull(@source_hu_id,'')
		and ISNULL(lot_number,'') = ISNULL(@lot_number,'')
		AND type = @pick_id
		and isnull(stored_attribute_id,'0') = isnull(@stored_attribute_id,'0')

		--Move the stock to dest
		EXEC	[dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @wh_id,
				@in_vchItemNumber = @item_number,
				@in_vchLocationID = @dest_location_id,
				@in_nType = 0,
				@in_vchHUID = @dest_hu_id,
				@in_vchLotNumber =@lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @qty,
				@in_dtFifoDate = @fifoDate,
				@in_dtExpirationDate = @expiration_date,
				@in_vchHUType = N'IV',
				@in_vchShipmentNumber =NULL,
				@in_damage_flag = 'N',
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT

		--remove the stock from fork
		EXEC	[dbo].[csp_Inventory_Adjust]
				@in_vchWhID = @wh_id,
				@in_vchItemNumber = @item_number,
				@in_vchLocationID = @source_location_id,
				@in_nType = @pick_id,
				@in_vchHUID = @source_hu_id,
				@in_vchLotNumber =@lot_number,
				@in_nStoredAttributeID = @stored_attribute_id,
				@in_fQty = @remove_qty,
				@in_dtFifoDate = @fifoDate,
				@in_dtExpirationDate = @expiration_date,
				@in_vchHUType = N'IV',
				@in_vchShipmentNumber =NULL,
				@in_damage_flag = 'N',
				@out_vchCode = @out_vchCode OUTPUT,
				@out_vchMsg = @out_vchMsg OUTPUT

		
		--update order status
		UPDATE t_pick_detail
		SET staged_quantity = staged_quantity + @qty
		,loaded_quantity = loaded_quantity + @qty
		WHERE pick_id = @pick_id

		UPDATE t_pick_detail
		SET status = 'LOADED'
		WHERE pick_id = @pick_id
		AND loaded_quantity = planned_quantity

		UPDATE t_order
		SET status = 'LOADED'
		WHERE wh_id = @wh_id
		AND order_number = @order_number
		AND NOT EXISTS ( SELECT 1  FROM t_pick_detail pkd
						 WHERE pkd.wh_id = t_order.wh_id
						 and pkd.order_number = t_order.order_number
						 and pkd.planned_quantity > loaded_quantity)

		--Create tran log
		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
			,wh_id_2,location_id_2,hu_id_2
			,generic_attribute_1,
			generic_attribute_2,
			generic_attribute_3,
			generic_attribute_4,
			generic_attribute_5,
			generic_attribute_6,
			generic_attribute_7,
			generic_attribute_8,
			generic_attribute_9,
			generic_attribute_10,
			generic_attribute_11)
		VALUES
			('104','Ownership Transfer (PUT)',getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@pick_id
			,@wh_id,@source_location_id,@source_hu_id,@item_number,@lot_number,@qty
			,@wh_id,@dest_location_id,@dest_hu_id
			,(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_1),    
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_2), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_3), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_4), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_5), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_6), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_7), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_8), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_9), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_10), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_11)
			)

			
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    



