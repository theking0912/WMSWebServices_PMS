CREATE PROCEDURE [dbo].[csp_Assign_Order2PTL_JERRY]    
     @wh_id				NVARCHAR(10)   
    ,@wave_id		    NVARCHAR(30) 
	,@order_number  NVARCHAR(100)
	,@assigned_count	int output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		
		DECLARE @status				NVARCHAR(20)
		DECLARE @wave_type			NVARCHAR(20)
	--	DECLARE @order_number		NVARCHAR(30)
		DECLARE @wall_id			NVARCHAR(30)
		DECLARE @slot				NVARCHAR(30)
		DECLARE @client_code		NVARCHAR(30)
		DECLARE @pick_wall_loc		NVARCHAR(30)
		DECLARE @pick_conveyor_node	NVARCHAR(30)
		DECLARE @shipping_label		NVARCHAR(30)
		DECLARE @detail_id			INT
		DECLARE @carrier_code		NVARCHAR(30)
		DECLARE @event_data			NVARCHAR(2000)
		DECLARE @msg     			NVARCHAR(2000)
		DECLARE @result             INT
		DECLARE @vip                NVARCHAR(30)
		DECLARE @process_lot_no     NVARCHAR(30)
		DECLARE @route              NVARCHAR(30)
		DECLARE @schedule_code		NVARCHAR(30)
		DECLARE @ass_cnt			int
		DECLARE @zone				NVARCHAR(30)
		DECLARE @seq_id				INT		=	0
		DECLARE @customer_code		NVARCHAR(30)  =''
		DECLARE @customer_name		NVARCHAR(30)
		DECLARE @orderby_id			INT
		BEGIN TRANSACTION

		set @detail_id = 0
		set @ass_cnt = 0
		set @assigned_count = 0
		set @orderby_id = 0

		--while (1=1)
		begin
			
			select top 1 
			@orderby_id = (CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
													 ELSE 2
											   END ),
			@order_number = o.order_number , @client_code = o.client_code, @detail_id = wave_detail_id, @carrier_code = o.carrier_scac,@route = o.route
			,@customer_code = c.customer_code, @customer_name = c.customer_name
			from  t_afo_wave_detail wd, t_order o,dbo.t_customer c
			where wd.wh_id = o.wh_id 
			and wd.order_number = o.order_number 
			and wd.wh_id = @wh_id 
			and wd.wave_id = @wave_id
			AND o.customer_id = c.customer_id
			AND o.wh_id = c.wh_id
			AND o.order_number =@order_number
			--and wd.wave_detail_id > @detail_id
			--and exists (select 1 from tbl_allocation alloc
			--		where o.wh_id = alloc.wh_id
			--		and o.order_number = alloc.order_number
			--		and ABS(alloc.allocated_qty) - alloc.picked_qty > 0)
			--		AND (
			--			 ((CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
			--										 ELSE 2
			--								   END ) = @orderby_id AND customer_code  = @customer_code AND wave_detail_id > @detail_id)
			--			OR
			--			 ((CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
			--										 ELSE 2
			--								   END ) = @orderby_id AND customer_code  > @customer_code)
			--			OR
			--			(CASE WHEN LEFT( customer_code, 2) = 'SH' THEN 1
			--										 ELSE 2
			--								   END ) > @orderby_id)
			order by ( CASE WHEN LEFT(c.customer_code, 2) = 'SH' THEN 1
							 ELSE 2
					   END ) ,
					 c.customer_code,  wave_detail_id


			--select top 1 
			--@orderby_id = ISNULL(c.pick_seq,999999),
			--@order_number = o.order_number , @client_code = o.client_code, @detail_id = wave_detail_id, @carrier_code = o.carrier_scac,@route = o.route
			--,@customer_code = c.customer_code, @customer_name = c.customer_name
			--from  t_afo_wave_detail wd, t_order o,dbo.t_customer c
			--where wd.wh_id = o.wh_id 
			--and wd.order_number = o.order_number 
			--and wd.wh_id = @wh_id 
			--and wd.wave_id = @wave_id
			--AND o.customer_id = c.customer_id
			--AND o.wh_id = c.wh_id
			----and wd.wave_detail_id > @detail_id
			--and exists (select 1 from tbl_allocation alloc
			--		where o.wh_id = alloc.wh_id
			--		and o.order_number = alloc.order_number
			--		and ABS(alloc.allocated_qty) - alloc.picked_qty > 0)
			--AND ( 
			--			(ISNULL(pick_seq,9999999) = @orderby_id AND customer_code = @customer_code AND wave_detail_id >@detail_id)
			--		 OR (ISNULL(pick_seq,9999999) = @orderby_id AND customer_code > @customer_code)
			--		 OR (ISNULL(pick_seq,9999999) > @orderby_id)
			--		 )
			--ORDER BY ISNULL(pick_seq,9999999) ,
			--		 c.customer_code,  wave_detail_id


			--if @@ROWCOUNT = 0
			--break;

			--select @customer_code = tc.customer_code, @customer_name = tc.customer_name from t_order tor with(nolock)
			--left outer join t_customer tc with(nolock)
			--on tor.wh_id = tc.wh_id
			--and tor.customer_id = tc.customer_id
			--where tor.order_number = @order_number
			--  and tor.wh_id = @wh_id

			WHILE (1=1)
			BEGIN
				SELECT TOP 1 @seq_id = MAX(seq_id),@zone = zone FROM tbl_allocation
						WHERE order_number = @order_number
							and wave_id = @wave_id
							and wh_id = @wh_id
							and ABS(allocated_qty) - picked_qty > 0
							AND pick_wall_loc IS null
							AND allo_type = 'S'
							AND seq_id > @seq_id
						GROUP BY zone
						ORDER BY MAX(seq_id),zone ASC

				if @@ROWCOUNT = 0
				break;

				EXEC csp_Get_PTL_Slot @wh_id,@order_number,@zone,@customer_code,@wave_id,@wall_id output,@slot output

				if @wall_id is not null and @slot is not null
				begin
					select @pick_wall_loc = location_id,@pick_conveyor_node = node
					from tbl_pick_wall
					where wh_id = @wh_id
					and wall_id = @wall_id					

					-- insert print_scheduler
					--set @event_data = @shipping_label + '|' + @carrier_code + '|' + '1'

					--insert into tbl_print_scheduler (print_type,print_station,wh_id,print_data,print_date,print_user
					--)values('ShippingLabel',@pick_wall_loc,@wh_id,@event_data,getdate(),'SP:B2C')
	
					update tbl_allocation
					set pick_wall_loc = @pick_wall_loc
					,	pick_wall_slot = @slot
					,	pick_conveyor_node = @pick_conveyor_node
					,	ref_number = @wall_id
					,   shipping_label = @shipping_label
					where order_number = @order_number
					and wh_id = @wh_id
					--and zone = @zone
					AND zone IN (SELECT zone FROM tbl_pick_wall_zone WITH(NOLOCK)
										WHERE wh_id = @wh_id
											AND wall_id = @wall_id)
					
					update tbl_pick_wall_slot
					set ship_label_barcode = ''
					,	order_number = ''
					,customer_code = @customer_code
					,	status = 'A'
					,wave_id = @wave_id
					where wh_id = @wh_id
					AND wall_id = @wall_id
					AND slot = @slot
					
					set @ass_cnt = @ass_cnt + 1
	
					--print 'assign to ptl @wall_id' + isnull(@wall_id,'') + '@slot :' + isnull(@slot ,'') + '@order_number' + @order_number
	/*
					insert into tbl_pick_wall_slot_detail
					(wh_id,wall_id,slot,order_number,barcode,qty,type,send_time,remark)
					values(@wh_id,@wall_id,@slot,@order_number,@shipping_label,1,'SHIPLABEL',getdate(),'')
	
					insert into tbl_pick_wall_slot_detail
					(wh_id,wall_id,slot,order_number,barcode,qty,type,send_time,remark)
					select @wh_id			as wh_id
						,  @wall_id			as wall_id
						,  @slot			as slot
						,  @order_number	as order_number
						,  item_number		as barcode
						,  sum(allocated_qty - picked_qty)	as qty
						,  'ITEM'			as type
						,  getdate()		as send_time
						,  ''				as remark
					from tbl_allocation allo
					where allo.wh_id = @wh_id
					and allo.order_number = @order_number
					group by item_number,wh_id,order_number,lot_number
					*/
	                --SEND WCS IF DATA ADD BY David
					select @vip = vip_flag
					from t_client tc
					where tc.wh_id = @wh_id
					and tc.client_code = @client_code

					update t_control
					set next_value = next_value + 1
					where control_type = 'IF_ORDER_WCS'

					--Get process_lot_no from t_control
					select @process_lot_no = next_value
					from t_control
					where control_type = 'IF_ORDER_WCS'

					--get schedule_code from t_wave_master
					SELECT @schedule_code = wave_schedule
					  FROM t_wave_master
					 WHERE wave_id = @wave_id
					   AND wh_id = @wh_id


					   --select * from tbl_inf_dps_wave_order
					   insert into tbl_inf_dps_wave_order
					(wave_id,order_number,customer_code,customer_name,item_number,item_name,pick_wall_slot,allocated_qty,uom,uom_prompt,create_date)
					select @wave_id			as wave_id
						,  @order_number	as order_number
						,  @customer_code
						,  @customer_name
						,  allo.item_number		as item_number
						,  max(item.description) as item_name
						,  @slot			as pick_wall_slot
						--,  sum(ABS(allocated_qty) - picked_qty)	as qty
						,CASE  WHEN ISNULL(MAX(item.pack_flag),'N') = 'Y' AND ISNULL(MAX(allo.stored_attribute_id),'') <> ''
							THEN sum(ABS(allocated_qty) - picked_qty) / (SELECT tiu.conversion_factor 
									FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
										INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
										ON tscd.attribute_id = tacd.attribute_id
										INNER JOIN t_item_uom tiu WITH(NOLOCK)
										ON tiu.uom_prompt = tscd.attribute_value
										WHERE tacd.attribute_collection_id = MAX(item.attribute_collection_id)
											AND tscd.stored_attribute_id = MAX(allo.stored_attribute_id)
											AND tiu.item_number = MAX(item.item_number)
											AND tiu.wh_id = allo.wh_id)
							WHEN ISNULL(MAX(item.ed_flag),'N') = 'Y'
								THEN SUM(ABS(allocated_qty) - picked_qty) / 
									(SELECT TOP 1 tiu.conversion_factor FROM t_order_detail od
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON od.wh_id = tiu.wh_id
											AND od.item_number = tiu.item_number
											AND od.order_uom = tiu.uom
												WHERE od.wh_id = allo.wh_id
												AND od.order_number = allo.order_number
												AND od.item_number = allo.item_number )
							ELSE
									sum(ABS(allocated_qty) - picked_qty)
							END 	as qty

						,CASE  WHEN ISNULL(MAX(item.pack_flag),'N') = 'Y' AND ISNULL(MAX(allo.stored_attribute_id),'') <> ''
								THEN (SELECT tiu.uom 
										FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
											INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
											ON tscd.attribute_id = tacd.attribute_id
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON tiu.uom_prompt = tscd.attribute_value
											WHERE tacd.attribute_collection_id = MAX(item.attribute_collection_id)
												AND tscd.stored_attribute_id = MAX(allo.stored_attribute_id)
												AND tiu.item_number = MAX(item.item_number)
												AND tiu.wh_id = allo.wh_id)
								WHEN ISNULL(MAX(item.ed_flag),'N') = 'Y'
								THEN 
									(SELECT TOP 1 tiu.uom FROM t_order_detail od
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON od.wh_id = tiu.wh_id
											AND od.item_number = tiu.item_number
											AND od.order_uom = tiu.uom
												WHERE od.wh_id = allo.wh_id
												AND od.order_number = allo.order_number
												AND od.item_number = allo.item_number )

								ELSE
									(SELECT TOP 1 tiu.uom 
											FROM t_item_uom tiu WITH(NOLOCK)
												WHERE wh_id = allo.wh_id
													AND item_number = allo.item_number
												ORDER BY conversion_factor ASC)
								END
						,CASE  WHEN ISNULL(MAX(item.pack_flag),'N') = 'Y' AND ISNULL(MAX(allo.stored_attribute_id),'') <> ''
								THEN (SELECT tiu.uom_prompt 
										FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
											INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK)
											ON tscd.attribute_id = tacd.attribute_id
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON tiu.uom_prompt = tscd.attribute_value
											WHERE tacd.attribute_collection_id = MAX(item.attribute_collection_id)
												AND tscd.stored_attribute_id = MAX(allo.stored_attribute_id)
												AND tiu.item_number = MAX(item.item_number)
												AND tiu.wh_id = allo.wh_id)
								WHEN ISNULL(MAX(item.ed_flag),'N') = 'Y'
								THEN 
									(SELECT TOP 1 tiu.uom_prompt FROM t_order_detail od
											INNER JOIN t_item_uom tiu WITH(NOLOCK)
											ON od.wh_id = tiu.wh_id
											AND od.item_number = tiu.item_number
											AND od.order_uom = tiu.uom
												WHERE od.wh_id = allo.wh_id
												AND od.order_number = allo.order_number
												AND od.item_number = allo.item_number)
								ELSE
									(SELECT TOP 1 tiu.uom_prompt 
											FROM t_item_uom tiu WITH(NOLOCK)
												WHERE wh_id = allo.wh_id
													AND item_number = allo.item_number
												ORDER BY conversion_factor ASC)
								END
						--,  (SELECT TOP 1 uom FROM t_item_uom with(nolock) where wh_id = MAX(item.wh_id) and item_number = MAX(item.item_number) ORDER BY conversion_factor ASC)
						--,  (SELECT TOP 1 uom_prompt FROM t_item_uom with(nolock) where wh_id = MAX(item.wh_id) and item_number = MAX(item.item_number) ORDER BY conversion_factor ASC)
						,  GETDATE()		
					from tbl_allocation allo left join t_item_master item with(nolock) 
					on allo.wh_id = item.wh_id and allo.item_number = item.item_number
					where allo.wh_id = @wh_id
					and allo.order_number = @order_number
					and allo.allo_type = 'S'
					and allo.zone IN (SELECT zone FROM tbl_pick_wall_zone WITH(NOLOCK)
										WHERE wh_id = @wh_id
											AND wall_id = @wall_id)
					group by allo.item_number,allo.wh_id,allo.order_number,zone
					--group by allo.item_number,allo.wh_id,allo.order_number,allo.lot_number,zone

					
					--insert into tbl_if_order_wcs
					--(wh_id,order_number,pick_wall_loc,pick_wall_slot,shipping_label,route,wave_id,vip,item_number,item_name,allocated_qty,status,process_lot_no,wave_schedule_code)
					--select @wh_id			as wh_id
					--	,  @order_number	as order_number
					--	,  @wall_id			as pick_wall_loc
					--	,  @slot			as pick_wall_slot
					--	,  @shipping_label  as shipping_label
					--	,  @route           as route
					--	,  @wave_id         as wave_id
					--	,  (case @vip when 'V' then '1' else '0' end)  as vip
					--	,  allo.item_number		as item_number
					--	,  max(item.description) as item_name
					--	,  sum(ABS(allocated_qty) - picked_qty)	as qty
					--	,  'NEW'			    as status
					--	,  @process_lot_no  as process_lot_no
					--	,  @schedule_code	AS wave_schedule_code
					--from tbl_allocation allo left join t_item_master item on allo.wh_id = item.wh_id and allo.item_number = item.item_number
					--where allo.wh_id = @wh_id
					--and allo.order_number = @order_number
					--and allo.allo_type = 'S'
					--and allo.zone = @zone
					--group by allo.item_number,allo.wh_id,allo.order_number,allo.lot_number
					
					--if @@ROWCOUNT > 0
					--begin
					--	insert into tbl_if_wcs_ptl_job_queue 
					--	(job_type,job_status,job_data,create_date)
					--	values ('WPORDER','NEW',@process_lot_no,getdate())
					--end

				end
			END
	--		if exists (select 1 
	--					from tbl_allocation 
	--					where order_number = @order_number
	--					and wave_id = @wave_id
	--					and wh_id = @wh_id
	--					and allocated_qty - picked_qty > 0
	--					AND pick_wall_loc IS null
	--					AND allo_type = 'S'
	--					)
	--		BEGIN
			
	--			--print 'csp_Get_PTL_Slot' 
				
	--			-- exec get wall and slot
	--			EXEC csp_Get_PTL_Slot @wh_id,@order_number,@wall_id output,@slot output
	
	--			if @wall_id is not null and @slot is not null
	--			begin
	--				select @pick_wall_loc = location_id,@pick_conveyor_node = node
	--				from tbl_pick_wall
	--				where wh_id = @wh_id
	--				and wall_id = @wall_id					

	--				-- insert print_scheduler
	--				--set @event_data = @shipping_label + '|' + @carrier_code + '|' + '1'

	--				--insert into tbl_print_scheduler (print_type,print_station,wh_id,print_data,print_date,print_user
	--				--)values('ShippingLabel',@pick_wall_loc,@wh_id,@event_data,getdate(),'SP:B2C')
	
	--				update tbl_allocation
	--				set pick_wall_loc = @pick_wall_loc
	--				,	pick_wall_slot = @slot
	--				,	pick_conveyor_node = @pick_conveyor_node
	--				,	ref_number = @wall_id
	--				,   shipping_label = @shipping_label
	--				where order_number = @order_number
	--				and wh_id = @wh_id
	
	--				update tbl_pick_wall_slot
	--				set ship_label_barcode = @shipping_label
	--				,	order_number = @order_number
	--				,	status = 'A'
	--				where wh_id = @wh_id
	--				and wall_id = @wall_id
	--				and slot = @slot

	--				set @ass_cnt = @ass_cnt + 1
	
	--				--print 'assign to ptl @wall_id' + isnull(@wall_id,'') + '@slot :' + isnull(@slot ,'') + '@order_number' + @order_number
	--/*
	--				insert into tbl_pick_wall_slot_detail
	--				(wh_id,wall_id,slot,order_number,barcode,qty,type,send_time,remark)
	--				values(@wh_id,@wall_id,@slot,@order_number,@shipping_label,1,'SHIPLABEL',getdate(),'')
	
	--				insert into tbl_pick_wall_slot_detail
	--				(wh_id,wall_id,slot,order_number,barcode,qty,type,send_time,remark)
	--				select @wh_id			as wh_id
	--					,  @wall_id			as wall_id
	--					,  @slot			as slot
	--					,  @order_number	as order_number
	--					,  item_number		as barcode
	--					,  sum(allocated_qty - picked_qty)	as qty
	--					,  'ITEM'			as type
	--					,  getdate()		as send_time
	--					,  ''				as remark
	--				from tbl_allocation allo
	--				where allo.wh_id = @wh_id
	--				and allo.order_number = @order_number
	--				group by item_number,wh_id,order_number,lot_number
	--				*/
	--                --SEND WCS IF DATA ADD BY David
	--				select @vip = vip_flag
	--				from t_client tc
	--				where tc.wh_id = @wh_id
	--				and tc.client_code = @client_code

	--				update t_control
	--				set next_value = next_value + 1
	--				where control_type = 'IF_ORDER_WCS'

	--				--Get process_lot_no from t_control
	--				select @process_lot_no = next_value
	--				from t_control
	--				where control_type = 'IF_ORDER_WCS'

	--				--get schedule_code from t_wave_master
	--				SELECT @schedule_code = wave_schedule
	--				  FROM t_wave_master
	--				 WHERE wave_id = @wave_id
	--				   AND wh_id = @wh_id

	--				insert into tbl_if_order_wcs
	--				(wh_id,order_number,pick_wall_loc,pick_wall_slot,shipping_label,route,wave_id,vip,item_number,item_name,allocated_qty,status,process_lot_no,wave_schedule_code)
	--				select @wh_id			as wh_id
	--					,  @order_number	as order_number
	--					,  @wall_id			as pick_wall_loc
	--					,  @slot			as pick_wall_slot
	--					,  @shipping_label  as shipping_label
	--					,  @route           as route
	--					,  @wave_id         as wave_id
	--					,  (case @vip when 'V' then '1' else '0' end)  as vip
	--					,  allo.item_number		as item_number
	--					,  max(item.description) as item_name
	--					,  sum(ABS(allocated_qty) - picked_qty)	as qty
	--					,  'NEW'			    as status
	--					,  @process_lot_no  as process_lot_no
	--					,  @schedule_code	AS wave_schedule_code
	--				from tbl_allocation allo left join t_item_master item on allo.wh_id = item.wh_id and allo.item_number = item.item_number
	--				where allo.wh_id = @wh_id
	--				and allo.order_number = @order_number
	--				and allo.allo_type = 'S'
	--				group by allo.item_number,allo.wh_id,allo.order_number,allo.lot_number
					
	--				if @@ROWCOUNT > 0
	--				begin
	--					insert into tbl_if_wcs_ptl_job_queue 
	--					(job_type,job_status,job_data,create_date)
	--					values ('WPORDER','NEW',@process_lot_no,getdate())
	--				end

	--			end
	--			else
	--			break;
			--END
		end

		set @assigned_count = @ass_cnt

		commit	
        RETURN

    END TRY

    BEGIN CATCH
		set @msg = ERROR_MESSAGE()
		ROLLBACK
        RETURN
    END CATCH
  
END
