-- =============================================
-- Author:		Laver.Hu
-- Create date: 2013-11-25
-- Description:	Get a new outbound socket msg seq no
-- =============================================
CREATE PROCEDURE [dbo].[csp_Get_New_Socket_SeqNo]
	 @SEQ_NO			AS NVARCHAR(12) OUTPUT
AS
BEGIN
	DECLARE @Nvch_SEQ_No	AS	NVARCHAR(30)

	UPDATE t_control 
		SET @Nvch_SEQ_No = c1 = RIGHT('000000000000' + CONVERT(NVARCHAR,(CONVERT(INT,c1)+ 1)),12) 
		WHERE control_type = 'WMS_OUT_SEQ' 
			AND (CONVERT(BIGINT,c1) + 1) < 999999999999
    
    IF @@ROWCOUNT = 0
    BEGIN
        UPDATE t_control 
		    SET c1 = '000000000001'
		    WHERE control_type = 'WMS_OUT_SEQ'

        SET @Nvch_SEQ_No = '000000000001'
    END
 

	SET @SEQ_NO = @Nvch_SEQ_No

	RETURN
END
