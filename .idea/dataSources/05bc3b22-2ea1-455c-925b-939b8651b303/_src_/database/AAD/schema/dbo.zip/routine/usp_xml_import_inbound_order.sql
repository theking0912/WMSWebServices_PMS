
CREATE PROCEDURE usp_xml_import_inbound_order
    @v_vchHostGroupID		NVARCHAR(36),
	@out_vchCode            uddt_output_code   OUTPUT,
	@out_vchMsg             uddt_output_msg    OUTPUT
AS
-- ********************************************************************************
--                            Copyright ⌐ 2013.
--                           All Rights Reserved.
--                         HighJump Software
--                         Minneapolis, Minnesota, USA
-- ********************************************************************************
-- 
--    PURPOSE:
--          The purpose of this stored procedure is to populate GHI Tables for 
--              Inbound Order Import
--
--    DESCRIPTION:
--	
--    INPUT:
--      Host Group ID
--
--    OUTPUT:
--        out_vchCode - Contains 'SUCCESS' or Error Code.
--        out_vchMsg - Contains the error message or informational log message.:
--      
--  TARGET: SQL Server 
--
-- *********************************************************************************
DECLARE
    -- Error handling variables
	@c_vchObjName               uddt_obj_name,
    @v_nSysErrorNum             INTEGER,
    @v_vchCode                  uddt_output_code,
    @v_vchMsg                   uddt_output_msg,
    @v_nRetryCount				INTEGER,
	@v_nTranCount				INTEGER,
	@v_nXstate					INT,	


    -----------------------------------------------------------------------------------------------	
    -- Local Variables
    -----------------------------------------------------------------------------------------------
	@v_nCount                   INTEGER,
	@v_dtTranDateTime			DATETIME,
	@v_dtRecordCreateDate		DATETIME
    
    -----------------------------------------------------------------------------------------------	
    -- Set Constants
    -----------------------------------------------------------------------------------------------
    SET @c_vchObjName = N'usp_xml_import_inbound_order'	
	SET @v_vchCode = N'SUCCESS'
    SET @v_vchMsg  = N'NONE'
    SET @v_nSysErrorNum = 0
	SET @v_nTranCount = 0


    SET NOCOUNT ON

    SET @v_dtRecordCreateDate = GETDATE()	
    SET @v_nRetryCount = 3

INS_AL:
BEGIN TRY

	SET @v_nTranCount = @@TRANCOUNT

	IF @v_nTranCount = 0 
        BEGIN TRANSACTION 
    ELSE 
        SAVE TRANSACTION SAVEPOINT
		
    SET XACT_ABORT ON


        -------------------------------------------------------------------------------------------	
        -- Insert POM Records
        -------------------------------------------------------------------------------------------
        INSERT INTO t_al_host_po_master (
            host_group_id, record_create_date, processing_code, wh_id, client_code, po_number,
            display_po_number, po_type, vendor_code, status, residential_flag, ship_from_name,
            ship_from_addr1, ship_from_addr2, ship_from_city, ship_from_state, ship_from_postal_code, 
            ship_from_country_code, ship_from_attention, ship_from_phone, ship_from_fax, carrier_scac, 
            carrier_mode, service_level, freight_terms
            )
        SELECT
            @v_vchHostGroupID, @v_dtRecordCreateDate, tb2.TransactionCode, tb1.WarehouseID,
            tb1.ClientCode, tb1.InboundOrderNumber, tb1.DisplayIONumber, tb2.IOType, tb2.VendorCode,
			SUBSTRING(ISNULL(tb2.Status, 'O'),1,1), SUBSTRING(ISNULL(tb2.ResidentialFlag, 'N'),1,1),			 
			tb2.ShipFromName, tb2.ShipFromAddr1, tb2.ShipFromAddr2, tb2.ShipFromCity, tb2.ShipFromState, 
			tb2.ShipFromPostalCode, tb2.ShipFromCountryCode, tb2.ShipFromAttention, tb2.ShipFromPhone, 
			tb2.ShipFromFax, tb2.CarrierSCAC, tb2.CarrierMode, tb2.ServiceLevel, tb2.FreightTerms
        FROM t_xml_imp_io_master tb1 WITH (NOLOCK)
            INNER JOIN t_xml_imp_io_master_info tb2 WITH (NOLOCK)
               ON tb2.hjs_parent_id = tb1.hjs_node_id
		WHERE 
            tb1.hjs_parent_id = @v_vchHostGroupID
		ORDER BY 
            tb2.hjs_sequence 
        
        -------------------------------------------------------------------------------------------	
        -- Insert POD Records
        -------------------------------------------------------------------------------------------   
        INSERT INTO t_al_host_po_detail (
            host_po_master_id,
			host_group_id, record_create_date, processing_code, wh_id, client_code,
            po_number, display_po_number, line_number, item_number, display_item_number, schedule_number,
            quantity, vendor_item_number, delivery_date, originator, order_uom, vas_profile_code, 
            gen_attribute_value1, gen_attribute_value2, gen_attribute_value3, gen_attribute_value4, 
            gen_attribute_value5, gen_attribute_value6, gen_attribute_value7, gen_attribute_value8,
            gen_attribute_value9, gen_attribute_value10, gen_attribute_value11, earliest_ship_date, 
            latest_ship_date, earliest_delivery_date, latest_delivery_date
            )
        SELECT
            ISNULL(tb5.host_po_master_id,0),
			@v_vchHostGroupID, @v_dtRecordCreateDate, tb4.TransactionCode,
            tb1.WarehouseID, tb1.ClientCode, tb1.InboundOrderNumber, tb1.DisplayIONumber, tb3.LineNumber,
            tb4.ItemNumber, tb4.DisplayItemNumber, ISNULL(tb3.ScheduleNumber,0), ISNULL(tb4.Quantity,0), 
			tb4.VendorItemNumber, tb4.DeliveryDate, tb4.Orig, tb4.OrderUOM, tb4.VASProfileCode, tb4.Attribute1,
            tb4.Attribute2, tb4.Attribute3, tb4.Attribute4, tb4.Attribute5, tb4.Attribute6, tb4.Attribute7, 
            tb4.Attribute8, tb4.Attribute9, tb4.Attribute10, tb4.Attribute11,
            CONVERT(DATETIME,ISNULL(tb4.EarliestShipDate, '01/01/1900 00:0:00'),101),
            CONVERT(DATETIME,ISNULL(tb4.LatestShipDate, '01/01/1900 00:0:00'),101),
            CONVERT(DATETIME,ISNULL(tb4.EarliestDeliveryDate, '01/01/1900 00:0:00'),101),
            CONVERT(DATETIME,ISNULL(tb4.LatestDeliveryDate, '01/01/1900 00:0:00'),101)
        FROM t_xml_imp_io_master tb1 WITH (NOLOCK)
            INNER JOIN t_xml_imp_io_lines tb2 WITH (NOLOCK)
                ON tb2.hjs_parent_id = tb1.hjs_node_id
            INNER JOIN t_xml_imp_io_line tb3 WITH (NOLOCK)
                ON tb3.hjs_parent_id = tb2.hjs_node_id
            INNER JOIN t_xml_imp_io_line_info tb4 WITH (NOLOCK)
                ON tb4.hjs_parent_id = tb3.hjs_node_id
            LEFT OUTER JOIN t_al_host_po_master tb5 WITH (NOLOCK)
                ON tb5.host_group_id = tb1.hjs_parent_id
                AND ISNULL(tb5.po_number, -1) = ISNULL(tb1.InboundOrderNumber, -1)
                AND ISNULL(tb5.display_po_number, -1) = ISNULL(tb1.DisplayIONumber, -1)
                AND tb5.wh_id = tb1.WarehouseID
                AND ISNULL(tb5.client_code, -1) = ISNULL(tb1.ClientCode, -1)	
		WHERE 
            tb1.hjs_parent_id = @v_vchHostGroupID
		ORDER BY 
            tb3.hjs_parent_id,
            tb3.hjs_sequence
        
        -------------------------------------------------------------------------------------------	
        -- Insert PMC Records
        -------------------------------------------------------------------------------------------   
		INSERT INTO t_al_host_po_comment (
            host_po_master_id,
            host_group_id,
            record_create_date,
            processing_code,
            wh_id,
            client_code,
            po_number,
            display_po_number,
            line_number,
            schedule_number,
            comment_type,
            comment_sequence,
            comment_date,
            comment_text
            )
        SELECT 
            ISNULL(tb5.host_po_master_id,0),
            @v_vchHostGroupID, 
            @v_dtRecordCreateDate,
            tb4.TransactionCode,
            tbl.WarehouseID,
            tbl.ClientCode,
            tbl.InboundOrderNumber,
            tbl.DisplayIONumber,
            CASE tb4.HeaderFooter 
                WHEN 'Header' THEN '000'
                WHEN 'Footer' THEN '999'
                ELSE NULL
            END,
            0,
            SUBSTRING(tb4.CommentType, 1,1),
			tb4.CommentSequence,
            ISNULL(tb4.CommentDate, GETDATE()),
            tb4.CommentText 
        FROM t_xml_imp_io_master tbl WITH (NOLOCK)            
            INNER JOIN t_xml_imp_io_master_comments tb3 WITH (NOLOCK)
                ON tb3.hjs_parent_id = tbl.hjs_node_id
            INNER JOIN t_xml_imp_io_master_comment tb4 WITH (NOLOCK)
                ON tb4.hjs_parent_id = tb3.hjs_node_id
            LEFT OUTER JOIN t_al_host_po_master tb5 WITH (NOLOCK)
                ON tb5.host_group_id = tbl.hjs_parent_id
                AND ISNULL(tb5.po_number, -1) = ISNULL(tbl.InboundOrderNumber, -1)
                AND ISNULL(tb5.display_po_number, -1) = ISNULL(tbl.DisplayIONumber, -1)
                AND tb5.wh_id = tbl.WarehouseID
                AND ISNULL(tb5.client_code, -1) = ISNULL(tbl.ClientCode, -1)	
		WHERE 
            tbl.hjs_parent_id = @v_vchHostGroupID
		ORDER BY 
            tb4.hjs_sequence 
            
        -------------------------------------------------------------------------------------------	
        -- Insert PDC Records
        -------------------------------------------------------------------------------------------   
		INSERT INTO t_al_host_po_detail_comment (
            host_po_detail_id,
            host_group_id,
            record_create_date,
            processing_code,
            wh_id,
            client_code,
            po_number,
            display_po_number,
            line_number,
            item_number,
            schedule_number,
            comment_type,
            comment_sequence,
            comment_date,
            comment_text
            )
        SELECT
            ISNULL(tb7.host_po_detail_id,0),
            @v_vchHostGroupID, 
            @v_dtRecordCreateDate,
            tb6.TransactionCode,
            tbl.WarehouseID,
            tbl.ClientCode,
            tbl.InboundOrderNumber,
            tbl.DisplayIONumber,
            tb3.LineNumber,
            tb4.ItemNumber,
            ISNULL(tb3.ScheduleNumber, 0),            
			SUBSTRING(tb6.CommentType, 1,1),			
            tb6.CommentSequence,
            ISNULL(tb6.CommentDate, GETDATE()),
            tb6.CommentText
        FROM t_xml_imp_io_master tbl WITH (NOLOCK)
            INNER JOIN t_xml_imp_io_lines tb2 WITH (NOLOCK)
                ON tb2.hjs_parent_id = tbl.hjs_node_id
            INNER JOIN t_xml_imp_io_line tb3 WITH (NOLOCK)
                ON tb3.hjs_parent_id = tb2.hjs_node_id
            INNER JOIN t_xml_imp_io_line_info tb4 WITH (NOLOCK)
                ON tb4.hjs_parent_id = tb3.hjs_node_id
            INNER JOIN t_xml_imp_io_line_comments tb5 WITH (NOLOCK)
                ON tb5.hjs_parent_id = tb4.hjs_parent_id
            INNER JOIN t_xml_imp_io_line_comment tb6 WITH (NOLOCK)
                ON tb6.hjs_parent_id = tb5.hjs_node_id
            LEFT OUTER JOIN t_al_host_po_detail tb7 WITH (NOLOCK)
                ON tb7.host_group_id = tbl.hjs_parent_id
                AND ISNULL(tb7.po_number, -1) = ISNULL(tbl.InboundOrderNumber, -1)
                AND ISNULL(tb7.display_po_number, -1) = ISNULL(tbl.DisplayIONumber, -1)
                AND tb7.wh_id = tbl.WarehouseID
                AND ISNULL(tb7.client_code, -1) = ISNULL(tbl.ClientCode, -1)
				AND ISNULL(tb7.item_number, -1) = ISNULL(tb4.ItemNumber, -1)
				AND ISNULL(tb7.display_item_number, -1) = ISNULL(tb4.DisplayItemNumber, -1)				
		WHERE 
            tbl.hjs_parent_id = @v_vchHostGroupID
		ORDER BY 
            tb6.hjs_sequence 
			 
	COMMIT TRANSACTION
	
	SET XACT_ABORT OFF		
	
END TRY
 
BEGIN CATCH    
    SET @v_nSysErrorNum = ERROR_NUMBER()
	SET @v_nTranCount = @@TRANCOUNT
	SET @v_nXstate = XACT_STATE() 
	
  
	IF @v_nXstate = -1 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount = 0 
        ROLLBACK TRANSACTION
    IF @v_nXstate = 1 and @v_nTranCount > 0 
        ROLLBACK TRANSACTION SAVEPOINT   

		
-- Check for Deadlock and Retry as long as the Retry Counter is greater than zero  
    IF (@v_nRetryCount > 0 AND @v_nSysErrorNum = 1205) 
	BEGIN
		SET @v_nRetryCount = @v_nRetryCount - 1
		SET XACT_ABORT OFF;	
		GOTO INS_AL
	END

	SET @v_vchCode = N'-20001'    
    SET @v_vchMsg = N'A SQL error occured while inserting t_xml_exp records for Inbound Order Import.'	
	SET @v_vchMsg = @v_vchMsg + N' SQL Error = ' + ERROR_MESSAGE()
	GOTO ERROR_HANDLER
END CATCH

GOTO EXIT_LABEL
	
-----------------------------------------------------------------------------------
--                            Error Handling
-----------------------------------------------------------------------------------
ERROR_HANDLER:
    --Need to check for deadlock error so that the app can handle them appropriately.  Instead of the app looking for 1205 it looks for the value 40001
    --within the message string.
    IF @v_nSysErrorNum = 1205
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + N'Deadlock error: 40001 ' + @v_vchMsg
    ELSE    
        SET @v_vchMsg = N'Procedure: ' + @c_vchObjName + N': ' + @v_vchCode + N': ' + @v_vchMsg 
		
    --Should only raise error in the parent sproc
    RAISERROR(@v_vchMsg, 11, 1)
    
    -- Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg
    
-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:

-- Set the output code and Set the output message
    SET @out_vchCode = @v_vchCode
    SET @out_vchMsg = @v_vchMsg

-- Always leave the stored procedure from here.
RETURN 
