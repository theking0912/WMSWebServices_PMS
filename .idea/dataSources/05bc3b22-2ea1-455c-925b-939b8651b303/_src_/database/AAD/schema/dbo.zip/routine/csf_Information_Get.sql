CREATE FUNCTION [dbo].[csf_Information_Get]
  (  @wh_id NVARCHAR(10) ,
    @po_number NVARCHAR(50) ,
    @shipment_number NVARCHAR(50) ,
    @line_number NVARCHAR(30) 
  )
RETURNS NVARCHAR(300)
AS
BEGIN
    DECLARE @information_id INT ,
        @information_value NVARCHAR(50) ,
        @information_id_n NVARCHAR(30) ,
        @information_value_n NVARCHAR(250) ,
        @count INT ,
        @information_type NVARCHAR(50) ,
 --@information_type_n  nvarchar(50),
        @item_number NVARCHAR(50) ,
        @count_row INT,
		  @stored_information_id INT ,
    @information_collection_name NVARCHAR(50)  ,
    @inf_coll_id NVARCHAR(50)  ,
    @inf_coll_value NVARCHAR(100)  ,
    @information_type_n NVARCHAR(50) ,
	@infor_ret NVARCHAR(300) =''


    SET @count = 1 
    SELECT  @information_id_n = ''
    SELECT  @information_value_n = ''
    SELECT  @information_type_n = ''

-- 获取stored_information_id
    SELECT  @stored_information_id = rpd.stored_information_id ,
            @item_number = rpd.item_number
    FROM    t_rcpt_ship_po_detail rpd
    WHERE   rpd.wh_id = @wh_id
            AND rpd.po_number = @po_number
            AND rpd.shipment_number = @shipment_number
            AND rpd.line_number = @line_number

--获取stored_information_id下几个information_id

    SELECT  @count_row = COUNT(1)
    FROM    tbl_sto_information_collection_detail sic
    WHERE   sic.stored_information_id = @stored_information_id
 
    IF @count_row > 0
        BEGIN
  
            WHILE @count <= @count_row
                BEGIN
                    SELECT  @information_id = inftable.information_id ,
                            @information_value = inftable.information_value ,
                            @information_type = tblint.information_type
                    FROM    ( SELECT    ROW_NUMBER() OVER ( ORDER BY sic.information_id ) AS count_inf ,
                                        sic.information_id ,
                                        sic.information_value
                              FROM      tbl_sto_information_collection_detail sic
                              WHERE     sic.stored_information_id = @stored_information_id
                            ) inftable
                            LEFT JOIN tbl_information_type tblint ON inftable.information_id = tblint.information_id
                    WHERE   count_inf = @count
 
   
                    SET @count = @count + 1 
                    SELECT  @information_type_n = @information_type_n + '*'
                            + @information_type
                    SELECT  @information_value_n = @information_value_n + '*'
                            + @information_value
                    SELECT  @information_id_n = @information_id_n + '*'
                            + CAST(@information_id AS NVARCHAR)

					SELECT @infor_ret=@infor_ret + '【'+@information_type+'：'+@information_value+'】'
                END

        END 
   
    SELECT  @inf_coll_value = @information_value_n ,
            @inf_coll_id = @information_id_n

    SELECT  @information_collection_name = tblim.information_collection_name
    FROM    t_rcpt_ship_po_detail rpd
            LEFT JOIN t_item_master itm ON rpd.wh_id = itm.wh_id
                                           AND rpd.item_number = itm.item_number
            LEFT JOIN tbl_information_collection_master tblim ON itm.information_collection_id = tblim.information_collection_id
    WHERE   rpd.wh_id = @wh_id
            AND rpd.item_number = @item_number


    --SET  @infor_ret = @information_type_n+'【'+@information_value_n+'】'


	RETURN @infor_ret

--select  @stored_information_id, @information_collection_name,@inf_coll_id,@inf_coll_value

END