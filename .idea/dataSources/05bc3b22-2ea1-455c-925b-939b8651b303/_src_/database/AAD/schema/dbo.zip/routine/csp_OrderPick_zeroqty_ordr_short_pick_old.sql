



-- =======================================    
-- Author: will   
-- Create Date: 20160307   
-- Description: zero quantity in short pick 
--  
    
-- =======================================    
   
create PROCEDURE [dbo].[csp_OrderPick_zeroqty_ordr_short_pick_old]    
     @wh_id					NVARCHAR(10)  
	,@location_id           Nvarchar(30) 
    ,@pick_id               Nvarchar(30)
	,@item_number           Nvarchar(30)
	,@hu_id					nvarchar(30) = NULL	--20160423 Added by TY		
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
	DECLARE @wave_id      Nvarchar(30)
	DECLARE @order_number Nvarchar(30)
	

	--SET @wave_id=''
	--SET @item_number=''

	-----------------------找出波次--------------------

    select @wave_id =wave_id ,@order_number=order_number from tbl_pick_list 
    where wh_id=@wh_id and seq_id =cast(cast (@pick_id as decimal(9,2)) as int)

	update tbl_allocation set status='C' where wh_id=@wh_id and wave_id=@wave_id and item_number=@item_number
	                                     and location_id=@location_id  and allo_type='O'
										 and isnull(hu_id,'0') = isnull(@hu_id,'0') --20160423 Added by TY	

		 if not exists (select 1 from tbl_allocation allo where allo.wave_id =@wave_id
	                                               and  allo.item_number =@item_number
												   and  allo.wh_id=@wh_id
												   and  allo.status<>'C'
												   and  allo.allo_type='O'
												   )
	     begin

			UPDATE t_pick_detail  SET status='LOADED' 
			where order_number=@order_number and wh_id=@wh_id and item_number =@item_number 

			--IF NOT EXISTS (select 1 from tbl_allocation where wave_id=@wave_id and order_number =@order_number 
			--and status<>'C' and  allo_type='O')

	 IF NOT EXISTS (select 1 from tbl_allocation where wave_id=@wave_id and order_number =@order_number and status<>'C' 
	 and wh_id = @wh_id)
	 /***** Updated by Trevor on 20160407 started *****/
	       begin
		        If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') NOT IN('PICKED','STAGED','LOADED') and a.order_number= @order_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
			      AND EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') ='PICKED' and a.order_number= @order_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
				  UPDATE t_order SET status = 'PICKED', date_picked = getdate() where order_number= @order_number and wh_id=@wh_id

               If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') NOT IN('STAGED','LOADED') and a.order_number= @order_number and a.wh_id=@wh_id)
			      AND EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'') ='STAGED' and a.order_number= @order_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
				  UPDATE t_order SET status = 'STAGED' where order_number= @order_number and wh_id=@wh_id
			    ELSE
				  BEGIN 
				    If NOT EXISTS (SELECT 1 FROM t_order_detail a
			                       left join t_pick_detail b on a.order_number=b.order_number and a.wh_id=b.wh_id and a.line_number=b.line_number and a.item_number=b.item_number
			                       where isnull(b.status,'')<>'LOADED' and a.order_number= @order_number and a.wh_id=@wh_id
								   and isnull(b.work_type,'')='')
			        UPDATE t_order SET status = 'LOADED' where order_number= @order_number and wh_id=@wh_id
			      end
	/***** Updated by Trevor on 20160407 ended *****/
			 end
		 end
END    
    




