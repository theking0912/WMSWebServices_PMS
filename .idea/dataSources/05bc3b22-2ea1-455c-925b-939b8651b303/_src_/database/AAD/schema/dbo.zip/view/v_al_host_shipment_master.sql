
CREATE VIEW v_al_host_shipment_master AS
SELECT
	shipment_id,
	host_group_id,
	transaction_code,
	order_number,
	display_order_number,
	load_id,
	pro_number,
	seal_number,
	carrier_code,
	status,
	split_status,
	delivery_SAP,
	total_weight,
	total_volume,
	user_id,
	wh_id,
	client_code,
	record_create_date
FROM 
    t_al_host_shipment_master
