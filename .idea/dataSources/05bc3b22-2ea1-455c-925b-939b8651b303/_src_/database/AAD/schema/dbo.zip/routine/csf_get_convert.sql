

CREATE FUNCTION [dbo].[csf_get_convert]
(
    @in_item_number    NVARCHAR(30),
	@in_wh_id           NVARCHAR(50),
	@in_att		BIGINT
)
RETURNS FLOAT
AS
BEGIN
    DECLARE @convert FLOAT
	DECLARE @pack_flag NVARCHAR(10)
	DECLARE @ship_uom NVARCHAR(50)

	SELECT @pack_flag =  pack_flag ,
	       @ship_uom=ship_uom
	  from dbo.t_item_master with(nolock)
	 WHERE item_number = @in_item_number 
	   AND wh_id =@in_wh_id
    
	IF  @in_att IS NOT NULL
	  BEGIN
		SELECT  @convert = td.conversion_factor
		  from  t_item_uom td with(nolock)
		  INNER JOIN t_sto_attrib_collection_detail te with(nolock) ON 
					 td.uom_prompt = te.attribute_value
				where te.stored_attribute_id =@in_att
				AND td.item_number = @in_item_number
				AND td.wh_id = @in_wh_id
      END 
	ELSE
	  
	BEGIN
	 IF @pack_flag = 'N' AND EXISTS( SELECT 1 FROM dbo.t_item_uom WHERE item_number=@in_item_number AND wh_id=@in_wh_id
	 AND uom=@ship_uom )
	  BEGIN
	    SELECT @convert = conversion_factor
		  from dbo.t_item_uom with(nolock)
		 WHERE item_number = @in_item_number
		   AND wh_id = @in_wh_id
		   AND uom = @ship_uom
	  END 
     ELSE
	  BEGIN
	    
	    SET @convert =1
	  
	  END

	END

          
    RETURN @convert

END

