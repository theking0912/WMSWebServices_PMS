
--上架主SP
CREATE PROCEDURE [dbo].[csp_during_put_NBO]
	@in_zone_type 				NVARCHAR(10)
	,@in_vchWhID 				NVARCHAR(10)
	,@in_item_number 			NVARCHAR(30)
	,@in_lot_number 			NVARCHAR(30)
	,@in_qty 					INT
	,@out_put_location_id 		NVARCHAR(30) 	OUTPUT
	,@error_code 				NVARCHAR(10) 	OUTPUT
	,@error_msg 				NVARCHAR(100) 	OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @nvch_location_id 		NVARCHAR(30)
	DECLARE @nvch_pick_seq 			NVARCHAR(30)
	DECLARE @c_vchLocTypes 			NVARCHAR(30)
	DECLARE @full_case_qty 			INT

	SET @c_vchLocTypes = 'BZCLPH'

	SELECT TOP 1 @full_case_qty = isnull(itm.full_case_qty, 0) / isnull(itu.conversion_factor, 1)
	FROM t_item_uom itu WITH (NOLOCK)
	INNER JOIN t_item_master itm WITH (NOLOCK) ON itu.wh_id = itm.wh_id AND itu.item_number = itm.item_number
	WHERE
		itu.wh_id = @in_vchWhID
		AND itu.item_number = @in_item_number
		AND itu.status = N'ACTIVE'
	ORDER BY itu.conversion_factor ASC

	IF isnull(@full_case_qty, 0) = 0
	BEGIN
		SET @error_code = 1
		SET @error_msg = N'该商品缺少单位'
	END
	ELSE
	BEGIN		
		--关键假设：除了拆零区和拣货区允许混批，其他区域不允许混批上架
		--如果商品绑定了CB区，且批次更早，则优先上架到CB区的可容下的货位(只校验货位容量)
		--如果上架数量小于满箱数量，如果绑定拣货区，只能上架到拆零拣货区，如果未绑定拣货区，则直接上架到P区 
		IF @in_qty < @full_case_qty
		BEGIN
			IF EXISTS
			(
				SELECT 1
				FROM tbl_loc_item li WITH (NOLOCK)
				INNER JOIN t_location loc WITH (NOLOCK) ON li.wh_id = loc.wh_id AND li.location_id = loc.location_id
				WHERE 
					li.wh_id = @in_vchWhID
					AND li.item_number = @in_item_number
					AND loc.type IN ('B','Z')
			)
			BEGIN
				IF isnull(@nvch_location_id, '') = ''
				BEGIN
					SELECT TOP 1 @nvch_location_id = li.location_id
					FROM tbl_loc_item li WITH (NOLOCK)
					INNER JOIN t_location loc WITH (NOLOCK) ON li.wh_id = loc.wh_id	AND li.location_id = loc.location_id
					INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
					INNER JOIN       t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
					LEFT JOIN
					(
						SELECT wh_id,location_id,item_number,sum(actual_qty) as actual_qty
						FROM t_stored_item WITH (NOLOCK)
						WHERE
							wh_id = @in_vchWhID
							AND item_number = @in_item_number
							AND status = 'A'
							group by wh_id,location_id,item_number
					) sto ON sto.wh_id = li.wh_id AND sto.location_id = li.location_id AND sto.item_number = li.item_number
					LEFT JOIN 
					(
						SELECT wh_id,location_id,COUNT(distinct hu_id) as hu_qty
						FROM t_hu_master WITH (NOLOCK)
						group by wh_id,location_id
					) lp ON lp.wh_id = li.wh_id	AND lp.location_id = li.location_id
					WHERE
						li.wh_id = @in_vchWhID
						AND li.item_number = @in_item_number
						AND z.zone_type + z.zone_group = @in_zone_type
						and (isnull(loc.storage_device_id,0) = 0 or loc.storage_device_id > isnull(lp.hu_qty, 0))
						AND loc.type IN ('B','Z')
						AND loc.status NOT IN ('I','H')
					ORDER BY isnull(sto.actual_qty, 0),zl.pick_seq
				END
			END
			ELSE IF EXISTS 
			(
				SELECT 1
				FROM tbl_loc_item li WITH (NOLOCK)
				INNER JOIN t_location loc WITH(NOLOCK) ON li.wh_id = loc.wh_id AND li.location_id = loc.location_id
				WHERE
					li.wh_id = @in_vchWhID
					AND li.item_number = @in_item_number
					AND loc.type IN ('C')
			)
			BEGIN				
				SELECT TOP 1 @nvch_location_id = li.location_id
				FROM tbl_loc_item li
				INNER JOIN t_location loc WITH (NOLOCK) ON li.wh_id = loc.wh_id	AND li.location_id = loc.location_id
				INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
				INNER JOIN 		 t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
				LEFT JOIN
				(
					SELECT wh_id,location_id,item_number,sum(actual_qty) as actual_qty
					FROM t_stored_item WITH (NOLOCK)
					WHERE
						wh_id = @in_vchWhID
						AND item_number = @in_item_number
						AND status = 'A'
						group by wh_id,location_id,item_number
				) sto ON sto.wh_id = li.wh_id AND sto.location_id = li.location_id AND sto.item_number = li.item_number
				LEFT JOIN 
				(
					SELECT wh_id,location_id,COUNT(distinct hu_id) as hu_qty
					FROM t_hu_master WITH (NOLOCK)
					group by wh_id,location_id
				) lp ON lp.wh_id = li.wh_id	AND lp.location_id = li.location_id
				WHERE
					li.wh_id = @in_vchWhID
					AND li.item_number = @in_item_number
					AND z.zone_type + z.zone_group = @in_zone_type
					and (isnull(loc.storage_device_id,0) = 0 or loc.storage_device_id > isnull(lp.hu_qty, 0))
					AND loc.type IN ('C')
					AND loc.status NOT IN ('I','H')
				ORDER BY isnull(sto.actual_qty, 0),zl.pick_seq --货位比较空的，优先上架
			END
			ELSE--没有绑定BC拣货区，上架到P区
			BEGIN
				--找寻存在此商品的库位
				EXEC csp_put_to_p_lot @in_zone_type
					,@in_vchWhID
					,@in_item_number
					,@in_lot_number
					,@in_qty
					,@nvch_location_id 			OUTPUT
					,@error_code       			OUTPUT
					,@error_msg        			OUTPUT
				
				IF isnull(@nvch_location_id, '') = ''
				BEGIN
					--寻找PCB区不存在该商品的空货位
					--EXEC csp_put_empty @in_zone_type
					EXEC csp_put_nobind @in_zone_type
						,@in_vchWhID
						,@in_item_number
						,@in_lot_number
						,@in_qty
						,@nvch_location_id 		OUTPUT
						,@error_code       		OUTPUT
						,@error_msg        		OUTPUT
				END	
			END
		END
		
		--如果上架数量大于满箱数量，如果绑定拣货区，按照B->C->P的上架逻辑上架，如果未绑定拣货区，则直接上架到P区；如果CB区有未完成的上架任务，则直接上架到P区
		ELSE 
		BEGIN
			IF EXISTS
			(
				SELECT 1
				FROM tbl_loc_item li WITH (NOLOCK)
				INNER JOIN t_location loc ON li.wh_id = loc.wh_id AND li.location_id = loc.location_id
				WHERE
					li.wh_id = @in_vchWhID
					AND li.item_number = @in_item_number
					AND loc.type IN ('B','Z','C')
			)
			BEGIN
				--找寻BC拣货区的空货位
				SELECT TOP 1 @nvch_location_id = li.location_id
				FROM tbl_loc_item li
				INNER JOIN t_location loc WITH (NOLOCK) ON li.wh_id = loc.wh_id	AND li.location_id = loc.location_id
				INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
				INNER JOIN t_zone z       WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone			
				WHERE li.wh_id = @in_vchWhID
					AND li.item_number = @in_item_number
					AND z.zone_type + z.zone_group = @in_zone_type
					AND loc.type IN ('B','Z','C')
					AND loc.status NOT IN ('I','H')
					AND @in_qty <= li.max_qty
					AND NOT EXISTS 
					(
						SELECT 1
						FROM t_stored_item st WITH (NOLOCK)
						WHERE st.wh_id = @in_vchWhID
							AND st.item_number = @in_item_number						
							AND st.status = 'A'
							AND st.location_id = li.location_id 
					)
					AND NOT EXISTS
					(
						SELECT 1
						FROM t_stored_item st WITH (NOLOCK)
						WHERE st.wh_id = @in_vchWhID
							AND st.item_number = @in_item_number						
							AND st.status = 'A'
							AND st.location_id = loc.location_id 
							AND loc.type in ('L','P','H')
					)
					AND NOT EXISTS 
					(
						SELECT 1
						FROM t_work_q wq WITH (NOLOCK)
						WHERE
							wq.wh_id = li.wh_id 
							AND wq.item_number = li.item_number 						
							AND wq.work_status in ('U','A') 
							AND wq.work_type in ('05','06')
							AND wq.location_id = li.location_id 
					)
				ORDER BY CHARINDEX(loc.type, @c_vchLocTypes),zl.pick_seq
			END

			IF isnull(@nvch_location_id, '') = ''
			BEGIN
				--如果有批次控制，且当前待上架商品批次比CB区批次更早，则先在CB区找可容下的货位，否则找寻同品批的上架货位
				IF EXISTS
				(
					SELECT 1
					FROM t_item_master
					WHERE
						wh_id = @in_vchWhID
						AND item_number = @in_item_number
						AND isnull(expiration_date_control, '') = 'Y'
				)
				BEGIN
					SELECT TOP 1 @nvch_location_id = li.location_id
					FROM tbl_loc_item li
					INNER JOIN t_location loc WITH (NOLOCK) ON li.wh_id = loc.wh_id	AND li.location_id = loc.location_id
					INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
					INNER JOIN 		 t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
					INNER JOIN
					(
						SELECT wh_id,location_id,item_number,sum(actual_qty) AS actual_qty
						FROM t_stored_item WITH (NOLOCK)
						WHERE
							wh_id = @in_vchWhID
							AND item_number = @in_item_number
							AND status = 'A'
						GROUP BY wh_id,location_id,item_number
					) sto ON sto.wh_id = li.wh_id AND sto.location_id = li.location_id AND sto.item_number = li.item_number
					WHERE
						li.wh_id = @in_vchWhID
						AND li.item_number = @in_item_number
						AND z.zone_type + z.zone_group = @in_zone_type
						AND loc.type IN ('B','Z','C')
						AND loc.status NOT IN ('I','H')
						AND isnull(sto.actual_qty, 0) + @in_qty <= li.max_qty
						AND EXISTS 
						(
							SELECT 1
							FROM t_stored_item st WITH (NOLOCK)
							WHERE
								st.wh_id = @in_vchWhID
								AND st.item_number = @in_item_number
								AND st.lot_number >= @in_lot_number
								AND st.status = 'A'
								AND st.location_id = li.location_id
						)
						AND NOT EXISTS--补货中的任务
						(
							SELECT 1
							FROM t_work_q wq WITH (NOLOCK)
							WHERE 
								wq.wh_id = li.wh_id 
								AND wq.item_number = li.item_number 						
								AND wq.work_status in ('U','A') 
								AND wq.work_type in ('05','06')
								AND wq.location_id = li.location_id 
						)
					ORDER BY CHARINDEX(loc.type, @c_vchLocTypes),zl.pick_seq									

					IF isnull(@nvch_location_id, '') = ''
					BEGIN	
						--已存改SKU对应的货位
						EXEC csp_put_to_p_lot @in_zone_type
							,@in_vchWhID
							,@in_item_number
							,@in_lot_number
							,@in_qty
							,@nvch_location_id 		OUTPUT
							,@error_code 			OUTPUT
							,@error_msg 			OUTPUT

							--set @break=3
					END

					IF isnull(@nvch_location_id, '') = ''
					BEGIN
						--扇形上架
						EXEC csp_put_by_fan @in_zone_type
							,@in_vchWhID
							,@in_item_number
							,@in_lot_number
							,@in_qty
							,@nvch_location_id 		OUTPUT
							,@error_code 			OUTPUT
							,@error_msg 			OUTPUT 

							--set @break=4
					END		
					
					IF isnull(@nvch_location_id, '') = ''
					BEGIN
						--寻找PCB区不存在该商品的空货位
						--EXEC csp_put_empty @in_zone_type
						EXEC csp_put_nobind @in_zone_type
							,@in_vchWhID
							,@in_item_number
							,@in_lot_number
							,@in_qty
							,@nvch_location_id 		OUTPUT
							,@error_code 			OUTPUT
							,@error_msg 			OUTPUT
					END		
				END
				ELSE ----如果无批次控制，则先找寻同种商品的上架货位
				BEGIN
					SELECT TOP 1 @nvch_location_id = li.location_id
					FROM tbl_loc_item li
					INNER JOIN t_location loc WITH (NOLOCK) ON li.wh_id = loc.wh_id	AND li.location_id = loc.location_id
					INNER JOIN t_zone_loca zl WITH (NOLOCK) ON loc.wh_id = zl.wh_id	AND loc.location_id = zl.location_id
					INNER JOIN  	 t_zone z WITH (NOLOCK) ON zl.wh_id = z.wh_id	AND zl.zone = z.zone
					LEFT JOIN
					(
						SELECT wh_id,location_id,item_number,sum(actual_qty) AS actual_qty
						FROM t_stored_item WITH (NOLOCK)
						WHERE
							wh_id = @in_vchWhID
							AND item_number = @in_item_number
							AND status = 'A'
							group by wh_id,location_id,item_number
					) sto ON sto.wh_id = li.wh_id AND sto.location_id = li.location_id AND sto.item_number = li.item_number
					WHERE 
						li.wh_id = @in_vchWhID
						AND li.item_number = @in_item_number
						AND z.zone_type + z.zone_group = @in_zone_type
						AND loc.type IN ('B','Z','C')
						AND loc.status NOT IN ('I','H')
						AND isnull(sto.actual_qty, 0) + @in_qty <= li.max_qty 
						AND NOT EXISTS
						(
							SELECT 1
							FROM t_work_q wq WITH (NOLOCK)
							WHERE
								wq.wh_id = li.wh_id 
								AND wq.item_number = li.item_number 						
								AND wq.work_status in ('U','A') 
								AND wq.work_type in ('05','06')
								AND wq.location_id = li.location_id 
						)
					ORDER BY CHARINDEX(loc.type, @c_vchLocTypes)
						,zl.pick_seq

					IF isnull(@nvch_location_id, '') = ''
					BEGIN	
						--找寻存在此商品的库位，如果找不到，则按照扇形上架逻辑找寻不存在此商品的库位
						EXEC csp_put_to_p_lot @in_zone_type
							,@in_vchWhID
							,@in_item_number
							,@in_lot_number
							,@in_qty
							,@nvch_location_id 			OUTPUT
							,@error_code 				OUTPUT
							,@error_msg 				OUTPUT
					END

					IF isnull(@nvch_location_id, '') = ''
					BEGIN
						--寻找P区商品绑定货位上方的可上架货位(根据货位容量计算)
						EXEC csp_put_by_fan @in_zone_type
							,@in_vchWhID
							,@in_item_number
							,@in_lot_number
							,@in_qty
							,@nvch_location_id 			OUTPUT
							,@error_code 				OUTPUT
							,@error_msg 				OUTPUT
					END		
					
					IF isnull(@nvch_location_id, '') = ''
					BEGIN
						--寻找PCB区不存在该商品的空货位
						--EXEC csp_put_empty @in_zone_type
						EXEC csp_put_nobind @in_zone_type
							,@in_vchWhID
							,@in_item_number
							,@in_lot_number
							,@in_qty
							,@nvch_location_id 			OUTPUT
							,@error_code 				OUTPUT
							,@error_msg 				OUTPUT
					END		
				END
			END
		END
	END

	--1.有批次控制的商品
	--1.1有同品批的商品库存
	--a.若商品在B区，若B区容量足够，则放下，否则依次校验C区、P区同品批的库位容量，如果都放不下，则按扇形上架逻辑找P区的空库位，如果找不到空库位，则提示找不到有效库位，由人工选择上架库位。
	--b.若商品在C区，若C区容量足够，则放下，否则校验P区同品批的库位容量，如果都放不下，则按扇形上架逻辑找P区的空库位，如果找不到空库位，则提示找不到有效库位，由人工选择上架库位。
	--c.若商品在P区，若P区容量足够，则放下，否则按扇形上架逻辑找P区的空库位，如果找不到空库位，则提示找不到有效库位，由人工选择上架库位。
	--1.2没有同品批的商品库存
	--a.按扇形上架逻辑找P区的空库位，如果找不到空库位，则提示找不到有效库位，由人工选择上架库位。
	--2.无批次控制的商品
	--a.若商品绑定的B、C区域库位，按绑定库位优先上架。若库位容量不够，则按B->C->P的上架顺序上架。
	--3.人工选择上架库位，只能上到P区，只需要校验库位上是否存在不同批次的商品，不允许混批次，可以混SKU。
	IF isnull(@nvch_location_id, '') = ''
	BEGIN
		SET @error_code = 1
		SET @error_msg = N'无可用上架货位'
	END

	
	SET @out_put_location_id = @nvch_location_id
	--select @break,@out_put_location_id

	RETURN
END
