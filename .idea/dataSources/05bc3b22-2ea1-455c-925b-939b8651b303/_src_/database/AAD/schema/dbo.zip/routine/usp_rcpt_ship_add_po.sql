-- ======================================= 
-- Modification: Nov12, 2013 CNSS shawn
-- Description:  Add two of process logistics:
--             1.B2B PO can't be created with B2C PO together.
--             2.'PO' and 'TO' can't be created with 'PSO' together.
--
-- Modification: Dec11, 2013 CNSS shawn
-- Description:  Add two of process logistics:
--             1.Check the added po type as same as the virtual po order type
-- =======================================


CREATE PROCEDURE [dbo].[usp_rcpt_ship_add_po]
@in_vchShipmentNumber   NVARCHAR(30),
@in_vchPo               NVARCHAR(30),
@in_vchWarehouseID      NVARCHAR(10),
@user_localeID          NVARCHAR(10),
@out_vchMessage         NVARCHAR(200) OUTPUT
AS

DECLARE

    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER
    SET NOCOUNT ON
    BEGIN TRANSACTION

    
    --Insert po into receipt shipment po
    INSERT INTO t_rcpt_ship_po
        (
            wh_id, 
            shipment_number, 
            po_number, 
            cases_received, 
            open_to_buy_date
        )
        SELECT 
            @in_vchWarehouseID, 
            @in_vchShipmentNumber, 
            po_number, 
            0, 
            GETDATE()
        FROM t_po_master
        WHERE   po_number = @in_vchPo
            AND wh_id     = @in_vchWarehouseID  
            AND EXISTS (SELECT 1
                        FROM t_po_detail pod
                        WHERE   po_number = @in_vchPo
                            AND wh_id     = @in_vchWarehouseID)
                                           
    -- Be sure a row was inserted
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN 
            SET @out_vchMessage   = dbo.usf_get_locale_text('Execute_DB_Error','constant',@user_localeID,'CONSTANT')
        END
        ELSE
        BEGIN
            SET @out_vchMessage =  dbo.usf_get_locale_text('Execute_Failure_WithOtherReasons','constant',@user_localeID,'CONSTANT')
        END
        GOTO ErrorHandler
    END
    
    --Insert po detail into receipt shipment po detail
    INSERT  INTO t_rcpt_ship_po_detail
            ( wh_id ,
              shipment_number ,
              po_number ,
              line_number ,
              item_number ,
              schedule_number ,
              expected_qty ,
              reconciled_date ,
              status ,
              more_qty ,
              less_qty
            )
            SELECT  @in_vchWarehouseID ,
                    @in_vchShipmentNumber ,
                    pod.po_number ,
                    pod.line_number ,
                    pod.item_number ,
                    schedule_number ,
                    dbo.csf_uom_convert(pod.wh_id, pod.item_number, order_uom,
                                        (SELECT TOP 1 uom FROM t_item_uom WHERE item_number = pod.item_number AND wh_id = pod.wh_id ORDER BY conversion_factor ASC)
										, pod.qty)
                    - ISNULL(rspdl.received_qty, 0) qty ,
                    NULL ,
                    'O' ,
                    dbo.csf_uom_convert(pod.wh_id, pod.item_number, order_uom,
                                        (SELECT TOP 1 uom FROM t_item_uom WHERE item_number = pod.item_number AND wh_id = pod.wh_id ORDER BY conversion_factor ASC)
										, pod.more_qty),
                     dbo.csf_uom_convert(pod.wh_id, pod.item_number, order_uom,
                                        (SELECT TOP 1 uom FROM t_item_uom WHERE item_number = pod.item_number AND wh_id = pod.wh_id ORDER BY conversion_factor ASC)
										, pod.less_qty)
            FROM    t_po_detail pod WITH ( NOLOCK )
                    LEFT JOIN ( SELECT  wh_id ,
                                        po_number ,
                                        line_number ,
                                        item_number ,
                                        SUM(received_qty) received_qty
                                FROM    t_rcpt_ship_po_detail WITH ( NOLOCK )
                                WHERE   shipment_number <> @in_vchShipmentNumber
                                GROUP BY wh_id ,
                                        po_number ,
                                        line_number ,
                                        item_number
                              ) rspdl ON pod.wh_id = rspdl.wh_id
                                         AND pod.po_number = rspdl.po_number
                                         AND pod.line_number = rspdl.line_number
            WHERE   pod.po_number = @in_vchPo
                    AND pod.wh_id = @in_vchWarehouseID
					AND ISNULL(pod.cancel_flag,N'N') != 'Y'
                    AND dbo.csf_uom_convert(pod.wh_id, pod.item_number,
                                            order_uom, N'EA', pod.qty)
                    - ISNULL(rspdl.received_qty, 0) > 0
                    AND NOT EXISTS ( SELECT 1
                                     FROM   t_rcpt_ship_po_detail WITH ( NOLOCK )
                                     WHERE  shipment_number = @in_vchShipmentNumber
                                            AND po_number = @in_vchPo
                                            AND item_number = pod.item_number
                                            AND line_number = pod.line_number
                                            AND schedule_number = pod.schedule_number
                                            AND wh_id = @in_vchWarehouseID )
    
    -- Be sure a row was inserted
    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nRowCount = 0 OR @v_vchSqlErrorNumber <> 0
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
        BEGIN 
           SET @out_vchMessage = dbo.usf_get_locale_text('Execute_DB_Error','constant',@user_localeID,'CONSTANT')
        END
        ELSE
        BEGIN
           SET @out_vchMessage = dbo.usf_get_locale_text('Execute_Failure_WithOtherReasons','constant',@user_localeID,'CONSTANT')
        END
        GOTO ErrorHandler
    END
    SET @out_vchMessage = dbo.usf_get_locale_text('Execute_Success','constant',@user_localeID,'CONSTANT')
    COMMIT TRANSACTION
    GOTO ExitLabel 
    
ErrorHandler:
    --ROLLBACK TRANSACTION   
	--RETURN
    RAISERROR(@out_vchMessage,0,0)
    IF @@TRANCOUNT > 0   
	BEGIN
		ROLLBACK TRANSACTION   
		RETURN
	END

ExitLabel:
    RETURN
