


-- =============================================
-- Author:		Lij
-- Create date: 2016-1-15 11:04:34
-- Description:	定时任务Job，用于监测是否需要补货
-- =============================================
CREATE PROCEDURE [dbo].[csp_Replenishment_Task_Monitoring] 
	-- Add the parameters for the stored procedure here
	-- 暂时省略
	@zone_type NVARCHAR(50) = ''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRANSACTION;
	IF @zone_type = ''
	BEGIN
	    SET @zone_type = 'C'
	END
	--如果临时表不为空则删除
	IF OBJECT_ID('#tmp_monitoring') IS NOT NULL
	DROP TABLE #tmp_monitoring;

	DECLARE @i INT  --用于循环
	SET @i = 1;
	DECLARE @row_count INT --总行数
	DECLARE @item_number NVARCHAR(50) --物料号
	DECLARE @count_qty DECIMAL(30, 8) --库存数量之和(非绑定订单号)
	DECLARE @minSum_qty DECIMAL(30, 8) --商品绑定库位安全量之和
	DECLARE @pass_result INT --调用结果
	DECLARE @msg NVARCHAR(500)  --调用错误失败字符串
	DECLARE @b_zone_flag NVARCHAR(4) = 'N'  --B区是否补货

	BEGIN TRY
		--创建临时表，只有两个字段，一个是自增长Id,一个是商品编码
		CREATE TABLE #tmp_monitoring (id INT IDENTITY(1,1), item_number NVARCHAR(200));
		--为临时表赋值
		INSERT INTO #tmp_monitoring SELECT item_number FROM dbo.tbl_loc_item GROUP BY item_number;
		--获取临时表的总行数
		SELECT @row_count = COUNT(*) FROM #tmp_monitoring;
		WHILE @i <= @row_count
		BEGIN
			--获取物料号根据Id
		    SELECT @item_number = item_number FROM #tmp_monitoring WHERE id = @i;
			--获取库存数量之和
			SELECT @count_qty = ISNULL(SUM(ISNULL(ts.actual_qty, 0)), 0) FROM dbo.tbl_loc_item tl 
			LEFT OUTER JOIN dbo.t_stored_item ts ON tl.wh_id = ts.wh_id AND 
			tl.location_id = ts.location_id AND tl.item_number = ts.item_number 
			LEFT OUTER JOIN dbo.t_location AS loc ON tl.location_id = loc.location_id 
			AND tl.wh_id = loc.wh_id
			WHERE ts.item_number = @item_number --AND ISNULL(ts.shipment_number, '') = '' 
			AND loc.type = SUBSTRING(@zone_type,1,1);
			--if @count_qty=''---
			--set @count_qty=0----
			--获取物料库存安全数量之和
			SELECT @minSum_qty = ISNULL(SUM(tl.min_qty), 0) FROM dbo.tbl_loc_item AS tl
			LEFT OUTER JOIN dbo.t_location AS loc ON tl.wh_id = loc.wh_id 
			AND tl.location_id = loc.location_id
			WHERE tl.item_number = @item_number AND loc.type = SUBSTRING(@zone_type,1,1);
			--判断库存总数是否小于安全数量
			IF @count_qty < @minSum_qty
			BEGIN
				BEGIN TRY
					EXECUTE dbo.csp_Replenishment_Task @item_number = @item_number, -- nvarchar(500)
						@zone_type = @zone_type -- nvarchar(50)
				END TRY
				BEGIN CATCH
				END CATCH
			    
			END
			SET @i = @i + 1;
			IF SUBSTRING(@zone_type,1,1) <> 'B'
			BEGIN
			    SET @b_zone_flag = 'Y';
			END
			ELSE IF @zone_type <> 'B-1'
			BEGIN
			    SET @b_zone_flag = 'Y-1'
			END
		END

		IF @b_zone_flag = 'Y'
		BEGIN
		    EXECUTE dbo.csp_Replenishment_Task_Monitoring @zone_type = N'B' -- nvarchar(50)
		END
		ELSE IF @b_zone_flag = 'Y-1'
		BEGIN
		    EXECUTE dbo.csp_Replenishment_Task_Monitoring @zone_type = N'B-1' -- nvarchar(50)
		END
		COMMIT;
	END TRY

	BEGIN CATCH
		ROLLBACK;
	END CATCH
END



