
CREATE PROCEDURE usp_afo_release_wave
@in_vchWarehouseId     NVARCHAR(10),    
@in_vchWaveId          NVARCHAR(20),
@in_vchPriority        NVARCHAR(10),
@in_nWorkersRequired   INTEGER,
@in_dtEarliestShipDate DATETIME,
@in_dtLatestShipDate   DATETIME,
@out_vchMessage        NVARCHAR(500) OUTPUT -- Contains "SUCCESS" or the message to be displayed.

AS

DECLARE 
    @v_nErrorNumber       INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(500),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,
    @v_nReturn            INTEGER,
    @v_vchErrorMsg        NVARCHAR(500),

    @e_GenSqlError   	  INTEGER,
    @e_InvalidWorkType    INTEGER,
    @e_UpdLDMFailed       INTEGER,
    @e_InsWKQFailed       INTEGER,
    @e_UpdWKQFailed       INTEGER,
    @e_SprocError         INTEGER,
    @e_MissingUomData     INTEGER,

    @c_chReleaseStatus    CHAR(1),
    @c_chUnassigned       CHAR(1),
    @v_nLoopCount         INTEGER,
    @v_vchWhId            NVARCHAR(20),
    @v_vchNextWhId        NVARCHAR(20),

    @v_nContAdvFlag       INTEGER,
    @v_nTranCount         INTEGER,
    @v_vchDescription     NVARCHAR(100),
    @v_dtTimeDue          DATETIME,
    @v_dtDateDue          DATETIME,
    @v_vchWorkqId         NVARCHAR(60),
    @v_PKDStagingLoc      NVARCHAR(20),
    @v_vchStageLoc        NVARCHAR(50),
    @v_vchDoorLoc         NVARCHAR(50),
    @vchOrderNum          NVARCHAR(60), 
    @vchWHID              NVARCHAR(20),
    @v_nValue             INTEGER,
    @v_vchOutMsg          NVARCHAR(500),
    @v_nLogErrorNum       INTEGER,
    @v_vchStartTran       INTEGER,

	--TMSIM
    @v_chMsgWh_id  		  NCHAR(10),  --NCHAR being used as the value needs to be padded with spaces before adding it to the message data
    @v_chMsgWave_id		  NCHAR(20),  --NCHAR being used as the value needs to be padded with spaces before adding it to the message data
	@v_vchMessageName     NVARCHAR(50),
	@v_vchMessageData	  NVARCHAR(40)


    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @c_chReleaseStatus = 'R'
    SET @c_chUnassigned = 'U'

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 7
    

    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_UpdLDMFailed = 2
    SET @e_InvalidWorkType = 3
    SET @e_InsWKQFailed = 4
    SET @e_UpdWKQFailed = 5
    SET @e_SprocError = 6
    SET @e_MissingUomData = 7
    SET @v_vchStartTran = 0

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    -- Check t_control to see if Container Advnatage is used.
    SELECT 
        @v_nContAdvFlag = ISNULL(next_value, 0)
    FROM 
        t_control
    WHERE control_type = 'CONTAINER-OPTIMIZE';

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler	
    END

    -- If no rows then assume this container advantage is not in use.
    IF @v_nRowCount = 0 
        SET @v_nContAdvFlag = 0

    IF @v_nContAdvFlag = 1
    BEGIN
        -- If using container advantage make sure all items on the wave have uom data.  It is required for container.
        SELECT @v_nRowCount = COUNT (*) 
        FROM t_afo_wave_detail wvd, t_afo_wave_detail_line wdl
        WHERE wvd.wave_id = @in_vchWaveId
        AND wvd.wave_detail_id = wdl.wave_detail_id
        AND wvd.wh_id = wdl.wh_id
        AND wvd.wh_id = @in_vchWarehouseId 
        AND NOT EXISTS (SELECT 1
                        FROM t_item_uom itu
                        WHERE itu.item_number = wdl.item_number
                          AND itu.wh_id = wdl.wh_id
                          AND itu.wh_id = @in_vchWarehouseId)

        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0 
        BEGIN
            SET @v_nErrorNumber = @e_GenSqlError
            GOTO ErrorHandler	
        END
        -- If no rows then error dat is missing
        IF @v_nRowCount > 0 
        BEGIN
            SET @v_nErrorNumber = @e_MissingUomData
            GOTO ErrorHandler	
        END
    END -- End CTA uom data check


    -- Begin transaction 
    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

    SET @v_vchStartTran = 1

    -- Call the usp_afo_units_of_work stored procedure to get the wave detail line
    --  records into the t_pick_detail table broken down by unit of measure.
    -- Note this calls usp_breakdown_unplanned
    EXECUTE @v_nReturn = usp_afo_units_of_work @in_vchWaveId, @in_vchWarehouseId, @v_vchOutMsg OUTPUT

    -- Check the result value returned from the called stored procedure
    IF @v_nReturn <> 0 
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
            ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + ': Stored Procedure Message:[' + @v_vchOutMsg + ']'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler
    END

    -- Call release work which sets up picks and creates work q's
    -- Call the stored proc with named arguments so we don't have to supply arguments we don't have data for.
    EXECUTE @v_nReturn = usp_release_work_q @in_WaveNumber = @in_vchWaveId, @in_WHID = @in_vchWarehouseId, @in_nResultsFlag = 0

    IF @v_nReturn <> 0 
    BEGIN
       SET @v_vchErrorMsg = 'An error occurred in a usp_release_work_q with a return code of ' +
           ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') 
       SET @v_nErrorNumber = @e_SprocError
       GOTO ErrorHandler
    END

    --SELECT @v_dtDateDue = CONVERT(NVARCHAR (8), GETDATE(), 1)
    --SELECT @v_dtTimeDue = CONVERT(NVARCHAR (10), GETDATE(), 108)

    -- If LatestShipDate < EarliestShipDate, then write a NULL for LatestShipDate
    IF (@in_dtLatestShipDate < @in_dtEarliestShipDate)
    BEGIN
        UPDATE t_wave_master
        SET status = @c_chReleaseStatus, 
		  earliest_ship_date = @in_dtEarliestShipDate,
		  latest_ship_date = NULL
        WHERE wh_id = @in_vchWarehouseId
            AND wave_id = @in_vchWaveId
    END
    ELSE
    BEGIN
        UPDATE t_wave_master
        SET status = @c_chReleaseStatus, 
		  earliest_ship_date = @in_dtEarliestShipDate,
		  latest_ship_date = @in_dtLatestShipDate
        WHERE wh_id = @in_vchWarehouseId
            AND wave_id = @in_vchWaveId
    END

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
    BEGIN
        IF @v_vchSqlErrorNumber <> 0
            SET @v_nErrorNumber = @e_GenSqlError
        ELSE
            SET @v_nErrorNumber = @e_UpdLDMFailed
        GOTO ErrorHandler	
    END

    /* -- Temporary fix part 2
     -- set wave_id back to zero where not type '04'
     UPDATE t_pick_detail
     SET wave_id = '0'
     WHERE wave_id = 'DEFAULT_WAVE'
     AND work_type <> '04'
     AND load_id = @in_vchLoadId*/


    -- Get door and staging loc from t_load_master
    SELECT @v_vchDoorLoc = door_location, @v_vchStageLoc = staging_location
    FROM t_wave_master
    WHERE wave_id = @in_vchWaveId

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END

    IF NOT @v_vchDoorLoc IS NULL and @v_vchDoorLoc <> ''
        SET @v_PKDStagingLoc = @v_vchDoorLoc
    IF NOT @v_vchStageLoc IS NULL and @v_vchStageLoc <> ''
        SET @v_PKDStagingLoc = @v_vchStageLoc
    

    BEGIN
        -- Update the t_pick_detail staging location if not assigned yet
        UPDATE t_pick_detail
        SET staging_location = @v_PKDStagingLoc
        WHERE wave_id = @in_vchWaveId
            AND type = 'PP' AND (staging_location IS NULL OR staging_location = '')
        AND wh_id = @in_vchWarehouseId


        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_nErrorNumber = @e_GenSqlError
            GOTO ErrorHandler
        END
    END -- End Update Stage Loc


    -- Update the pick requests with the priority & workers required that was passed in
    UPDATE t_work_q
    SET priority = @in_vchPriority,
    workers_required = @in_nWorkersRequired
    WHERE wh_id = @in_vchWarehouseId
        AND work_q_id IN (SELECT work_q_id
                          FROM t_pick_detail
                          WHERE wh_id = @in_vchWarehouseId
                              AND wave_id = @in_vchWaveId)

    SELECT @v_vchSqlErrorNumber = @@ERROR
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
        SET @v_nErrorNumber = @e_GenSqlError
        GOTO ErrorHandler
    END


    IF @v_nContAdvFlag = 1 

    BEGIN
        -- Save off the paramaters passed in from AFO
        UPDATE t_container_optimize_queue
        SET wa_wkq_workers_required = @in_nWorkersRequired,
            wa_wkq_work_priority = @in_vchPriority
        WHERE wh_id = @in_vchWarehouseId
            AND EXISTS (SELECT 1
                        FROM t_pick_detail pkd
                        WHERE pkd.cartonization_batch_id = t_container_optimize_queue.cartonization_batch_id
                            AND pkd.wave_id = @in_vchWaveId
                            AND pkd.wh_id = t_container_optimize_queue.wh_id
                            AND pkd.wh_id = @in_vchWarehouseId)

        SELECT @v_vchSqlErrorNumber = @@ERROR
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
            SET @v_nErrorNumber = @e_GenSqlError
            GOTO ErrorHandler
        END

    END


-- START CSA ORDER STATUS HISTORY LOGIC
-- Add Code here to loop through all the orders on a wave and write an order status history record for CSA.

--If CSA is installed and the order history sproc exists then insert order status history records.
--First check to see if CSA is installed and the usp_ta_order_status_history sproc are installed.
--     SELECT @v_nValue = next_value FROM t_control WHERE control_type = 'CSA'
--     --If the sproc exists
--     IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('dbo.usp_ta_order_status_history'))
--     BEGIN
--     	--AND if CSA is installed
--         IF ISNULL(@v_nValue,0) = 1 
-- 	BEGIN
-- 	    DECLARE curOrders INSENSITIVE CURSOR FOR
--         	SELECT order_number, wh_id
--             		FROM t_load_detail
--             		WHERE load_id = @in_vchLoadId
--         		FOR READ ONLY
--         	OPEN curOrders
-- 
--     		FETCH NEXT FROM curOrders
--             		INTO @vchOrderNum, @vchWHID
--             
--     		WHILE @@FETCH_STATUS = 0
--     		BEGIN
-- 
-- 			EXECUTE usp_ta_order_status_history @vchWHID, @vchOrderNum, 'RELEASED'
-- 
--  		FETCH NEXT FROM curOrders
--             		INTO @vchOrderNum, @vchWHID
--     		END
--     		CLOSE curOrders
--    	 	DEALLOCATE curOrders
-- 	END
--     END --Of inserting CSA order status history records.

-- END CSA ORDER STATUS HISTORY LOGIC

    --TMSIM--
	--Before Commit, check if the TMSIM is setup for Wave Release message publish, and that there is no pick detail for the wave which is a candidate for 
    --Container Advantage cartonization and if so publish the message to TMSIM, otherwise Container Advantage will publish the message.
	
	--Check if whse control TMSIM OB WAVERELEASE is ON for the warehouse
	IF EXISTS (SELECT 1 FROM t_whse_control whc
	           WHERE whc.control_type = 'TMSIM OB WAVERELEASE'
				 AND whc.wh_id = @in_vchWarehouseId
                 AND whc.next_value = 1)
		BEGIN
		--If there is any pick detail for the wave which is a candidate for Container Advantage cartonization, then do not publish the message.
		   SELECT @v_nRowCount = count(0)
			 FROM t_work_types wkt
			WHERE wkt.wh_id = @in_vchWarehouseId 
			  AND UPPER(wkt.release_sproc_name) = 'USP_RELEASE_WORK_Q_CTA'
			  AND EXISTS (SELECT 1 
							FROM t_pick_detail pkd
						   WHERE pkd.work_type = wkt.work_type
							 AND pkd.wave_id = @in_vchWaveId
							 AND pkd.wh_id = @in_vchWarehouseId
							 AND (pkd.status = 'CARTONIZE'  --pick details are being cartonized but cartonization batch id has not been generated yet
								  OR pkd.cartonization_batch_id IS NOT NULL))  --pick details are being cartonized and cartonization batch id has been generated yet 

			SELECT @v_vchSqlErrorNumber = @@ERROR
			IF @v_vchSqlErrorNumber <> 0
			BEGIN
				SET @v_nErrorNumber = @e_GenSqlError
				GOTO ErrorHandler
			END

			--If there is any unreleased pick detail for the wave e.g., due to incomplete base cartonization, then do not publish the message.
		  SELECT @v_nRowCount = @v_nRowCount + count(0) 
			FROM t_pick_detail pkd
			WHERE pkd.wave_id = @in_vchWaveId
			AND pkd.wh_id = @in_vchWarehouseId
			AND pkd.status in ('CREATED', 'CARTONIZE', 'PRERLSE')  --pick details are not released yet
			
			SELECT @v_vchSqlErrorNumber = @@ERROR
			IF @v_vchSqlErrorNumber <> 0
			BEGIN
				SET @v_nErrorNumber = @e_GenSqlError
				GOTO ErrorHandler
			END

			IF @v_nRowCount = 0
			BEGIN	
				SET @v_vchMessageName  = 'TMSIM Outbound Order Wave Release Msg WA'
				SET @v_chMsgWh_id  = 	@in_vchWarehouseId  --padding the values
				SET @v_chMsgWave_id = @in_vchWaveId  --padding the values
				--Concatenate padded wh_id and wave_id to create the message data 
				SET @v_vchMessageData  = @v_chMsgWh_id + @v_chMsgWave_id

				IF LTRIM(RTRIM(@v_vchMessageData)) <> ''
				BEGIN
					--Publish Message
					EXEC @v_nReturn = dbo.usp_advpublish_msg @v_vchMessageName, 'WA', @v_vchMessageData

					IF @v_nReturn <> 0 
					BEGIN
					   SET @v_vchErrorMsg = 'An error occurred in usp_release_container_complete with a return code of ' +
						   ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') 
					   SET @v_nErrorNumber = @e_SprocError
					   GOTO ErrorHandler
					END
				END
			END
		END
    --TMSIM Complete

    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        --EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(NVARCHAR(30),@v_vchErrorMsg),'(NULL)') + '.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(NVARCHAR(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END
    IF @v_nErrorNumber = @e_UpdLDMFailed
    BEGIN -- 
        -- Log Error    
        SET @v_vchLogMsg = 'An update to the t_wave_master table for wave ' +
            ISNULL(@in_vchWaveId,'(NULL)') + ' failed.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50003 -- Update Failed
    END
    IF @v_nErrorNumber = @e_InsWKQFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An attempt to insert a record for wave ' +
            ISNULL(@in_vchWaveId,'(NULL)') + ' into ' +
            ' the t_work_q table failed.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50002 -- Insert failed
    END
    IF @v_nErrorNumber = @e_UpdWKQFailed
    BEGIN 
        -- Log Error    
        SET @v_vchLogMsg = 'An attempt to Update a record for wave ' +
            ISNULL(@in_vchWaveId,'(NULL)') + ' in ' +
            ' the t_work_q table failed.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50003 -- Update failed
    END
    IF @v_nErrorNumber = @e_MissingUomData
    BEGIN 
        -- Log Error    
        SET @v_vchLogMsg = 'Unable to release wave.  One or more items are missing item unit of measure data.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber

        SET @v_nRaiseErrorNumber = 50003 -- Update failed
    END
    ELSE IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(NVARCHAR(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(NVARCHAR(30),@v_vchErrorMsg),'(NULL)') + '.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(NVARCHAR(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END
    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_vchStartTran = 1
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN
