
CREATE  FUNCTION usf_arch_valid_table_chars (
                            @in_vchText  NVARCHAR(10),
                            @in_vchType  VARCHAR(10)
                            )
RETURNS NVARCHAR(3)
 AS   
BEGIN 
        DECLARE @Result         NVARCHAR(3),
                @vCount         INTEGER,
                @vValue_Ascii   INTEGER

SET @Result = 'YES'
SET @vCount = 0
SET @vValue_Ascii = 0

WHILE @vCount < LEN(@in_vchText)
 BEGIN
   SET @vCount = @vCount + 1
   SET @vValue_Ascii = CAST(ASCII(SUBSTRING(@in_vchText,@vCount,1))AS INTEGER)

   IF (@vValue_Ascii >= 48 AND @vValue_Ascii <= 57 AND NOT (@in_vchType = 'PREFIX' AND @vCount = 1)) 
     OR (@vValue_Ascii >= 65 AND @vValue_Ascii <= 90) 
     OR (@vValue_Ascii >= 97 AND @vValue_Ascii <= 122)
     OR (@vValue_Ascii = 95)
      SET @Result = 'YES'
     ELSE 
      BEGIN
       SET @Result = 'NO'
       BREAK
      END
 END
  
ExitLabel:
    RETURN @Result
END




