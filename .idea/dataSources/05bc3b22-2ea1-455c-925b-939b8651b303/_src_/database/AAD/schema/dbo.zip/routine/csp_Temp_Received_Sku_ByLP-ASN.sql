

-- Procedure
-- =======================================    
-- Author: Laver.hu    
-- Create Date: 08 Nov 2013    
-- Description: Return Receiving by LP   
--  
    
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Received_Sku_ByLP]    
     @wh_id					NVARCHAR(10)    
    ,@control_number		NVARCHAR(30) --asn number/receipt id  
	,@control_number_2		NVARCHAR(30) --po number  
	,@item_number			Nvarchar(30)
	,@lot_number			Nvarchar(30)
	,@stored_attribute_id	Nvarchar(30)
	,@expiration_date		datetime
	,@discount_qty			float
	,@qty					float
	,@hu_id					Nvarchar(30)
	,@location_id			Nvarchar(30)
	,@type					Nvarchar(30) --D:Damage;  N:Normal
	,@user_id				nvarchar(30)
	,@tran_type				nvarchar(30)
	,@tran_description		nvarchar(50)
	--,@ciq_number			nvarchar(50)
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		DECLARE @zone_type			NVARCHAR(30)
		DECLARE @po_number			NVARCHAR(30)
		DECLARE @line_number		NVARCHAR(30)
		DECLARE @scheduler_number	NVARCHAR(30)
		DECLARE @received_qty		float
		DECLARE @expected_qty		float
		DECLARE @rcpt_qty			float
		DECLARE @total_rcpt_qty		float
		DECLARE @vendor				NVARCHAR(30)
		DECLARE @client_code		NVARCHAR(30)
		DECLARE @display_po_number		NVARCHAR(30)

		BEGIN TRANSACTION

			SET @total_rcpt_qty = @qty
			--GET PO NUMBER
			WHILE (1=1)
				BEGIN

						SELECT TOP 1 @po_number = tad.po_number
								,@line_number = tad.po_line_number
								,@scheduler_number = tad.schedule_number
								,@expected_qty = tad.qty
								,@received_qty = tad.received_qty
						    FROM t_asn_detail tad
							WHERE tad.wh_id = @wh_id
							  AND tad.asn_number = @control_number
							  AND tad.item_number = @item_number
							  AND tad.qty > tad.received_qty
							ORDER BY tad.po_number
									,tad.po_line_number
									,tad.schedule_number

						IF @@ROWCOUNT = 0 
							BEGIN								

								SELECT TOP 1 @po_number = tad.po_number
											,@line_number = tad.po_line_number
											,@scheduler_number = tad.schedule_number
											,@expected_qty = tad.qty + tad.more_qty
											,@received_qty = tad.received_qty
								FROM t_asn_detail tad
								WHERE tad.wh_id = @wh_id
								  AND tad.asn_number = @control_number
								  AND tad.item_number = @item_number
								  AND (tad.qty + tad.more_qty) > tad.received_qty
								ORDER BY tad.po_number
										,tad.po_line_number
										,tad.schedule_number

								IF @@ROWCOUNT = 0
									BEGIN
										SET @msg = '收货数量已经超出预收数量!'
										RAISERROR (66666, -- Message id.   
												   16, -- Severity,   
												   1 -- State,   
												  ) 
									END
								ELSE
									BEGIN
										IF @total_rcpt_qty <= @expected_qty - @received_qty
											BEGIN
												SET @rcpt_qty = @total_rcpt_qty
												SET @total_rcpt_qty = 0
											END
										ELSE
											BEGIN
												SET @rcpt_qty = @expected_qty - @received_qty
												SET @total_rcpt_qty = @total_rcpt_qty - @rcpt_qty
											END
									END
							END
						ELSE
							BEGIN
								IF @total_rcpt_qty <= @expected_qty - @received_qty
									BEGIN
										SET @rcpt_qty = @total_rcpt_qty
										SET @total_rcpt_qty = 0
									END
								ELSE
									BEGIN
										SET @rcpt_qty = @expected_qty - @received_qty
										SET @total_rcpt_qty = @total_rcpt_qty - @rcpt_qty
									END
							END
					
				
					SELECT @client_code = client_code
					FROM t_item_master 
					WHERE wh_id = @wh_id
					and item_number = @item_number

					SELECT @vendor = vendor_code
						,@display_po_number = display_po_number
					FROM t_po_master
					WHERE wh_id = @wh_id
					and po_number = @po_number

					--Insert into t_receipt
					UPDATE t_receipt
					SET [qty_received] = [qty_received] + @rcpt_qty
						,[qty_damaged] = [qty_damaged] + ( case @type when 'D' then @rcpt_qty else 0 end)
					WHERE receipt_id = @control_number
					and wh_id = @wh_id
					and po_number = @po_number
					and line_number = @line_number
					and item_number = @item_number
					and schedule_number = @scheduler_number
					and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
					--and (ciq_number = @ciq_number or (ciq_number is null and @ciq_number is null))
					and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
					and hu_id = @hu_id

					IF @@ROWCOUNT =0 
						BEGIN
							INSERT INTO t_receipt
								([receipt_id],[vendor_code],po_number,line_number,schedule_number,[receipt_date]
								,[item_number],[lot_number],[qty_received],[qty_damaged]
								,[hu_id],[fork_id],[wh_id],[stored_attribute_id],[shipment_number])
							VALUES
								(@control_number,@vendor,@po_number,@line_number,@scheduler_number,getdate()
								,@item_number,@lot_number,@rcpt_qty, case @type when 'D' then @rcpt_qty else 0 end
								,@hu_id,@location_id,@wh_id,@stored_attribute_id,NULL )
						END
	
					--Insert into [dbo].[int_upd_receipt]
					Insert into [dbo].[tbl_inf_exp_receipt]
						(receipt_id,vendor_code,po_number,display_po_number,receipt_date
						,scac_code,status,item_number,display_item_number,lot_number
						,line_number,schedule_number,qty_received,qty_damaged,hu_id
						,packing_slip,fork_id,uom,shipment_number,warehouse_id,client_code
						,generic_attribute1	,generic_attribute2	,generic_attribute3
						,generic_attribute4	,generic_attribute5	,generic_attribute6
						,generic_attribute7	,generic_attribute8	,generic_attribute9
						,generic_attribute10,generic_attribute11,process_status)
					VALUES
						(@control_number,@vendor,@po_number,@display_po_number,getdate()
						,null,'N',@item_number,NULL,@lot_number
						,@line_number,@scheduler_number,@rcpt_qty, case @type when 'D' then @qty else 0 end,@hu_id
						,NULL,@location_id,NULL,NULL,@wh_id,@client_code
						,(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_1),    
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_2), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_3), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_4), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_5), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_6), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_7), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_8), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_9), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_10), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_11)
						,'Ready'
						)

					UPDATE t_asn_detail
					SET received_qty = received_qty + @rcpt_qty
					WHERE wh_id = @wh_id
					AND asn_number = @control_number
					and po_number = @po_number
					and item_number = @item_number
					and po_line_number = @line_number
					and schedule_number = @scheduler_number

					IF @total_rcpt_qty <= 0
						BEGIN
							BREAK
						END
				END
			
			-- Discount Receive
			---------------------------------------------------------------------
			SET @total_rcpt_qty = @discount_qty
			WHILE (1=1)
				BEGIN

						SELECT TOP 1 @po_number = tad.po_number
								,@line_number = tad.po_line_number
								,@scheduler_number = tad.schedule_number
								,@expected_qty = tad.qty
								,@received_qty = tad.received_qty
						    FROM t_asn_detail tad
							WHERE tad.wh_id = @wh_id
							  AND tad.asn_number = @control_number
							  AND tad.item_number = @item_number
							  AND tad.qty > tad.received_qty
							ORDER BY tad.po_number
									,tad.po_line_number
									,tad.schedule_number

						IF @@ROWCOUNT = 0 
							BEGIN								

								SELECT TOP 1 @po_number = tad.po_number
											,@line_number = tad.po_line_number
											,@scheduler_number = tad.schedule_number
											,@expected_qty = tad.qty + tad.more_qty
											,@received_qty = tad.received_qty
								FROM t_asn_detail tad
								WHERE tad.wh_id = @wh_id
								  AND tad.asn_number = @control_number
								  AND tad.item_number = @item_number
								  AND (tad.qty + tad.more_qty) > tad.received_qty
								ORDER BY tad.po_number
										,tad.po_line_number
										,tad.schedule_number

								IF @@ROWCOUNT = 0
									BEGIN
										SET @msg = '收货数量已经超出预收数量!'
										RAISERROR (66666, -- Message id.   
												   16, -- Severity,   
												   1 -- State,   
												  ) 
									END
								ELSE
									BEGIN
										IF @total_rcpt_qty <= @expected_qty - @received_qty
											BEGIN
												SET @rcpt_qty = @total_rcpt_qty
												SET @total_rcpt_qty = 0
											END
										ELSE
											BEGIN
												SET @rcpt_qty = @expected_qty - @received_qty
												SET @total_rcpt_qty = @total_rcpt_qty - @rcpt_qty
											END
									END
							END
						ELSE
							BEGIN
								IF @total_rcpt_qty <= @expected_qty - @received_qty
									BEGIN
										SET @rcpt_qty = @total_rcpt_qty
										SET @total_rcpt_qty = 0
									END
								ELSE
									BEGIN
										SET @rcpt_qty = @expected_qty - @received_qty
										SET @total_rcpt_qty = @total_rcpt_qty - @rcpt_qty
									END
							END
					
				
					SELECT @client_code = client_code
					FROM t_item_master 
					WHERE wh_id = @wh_id
					and item_number = @item_number

					SELECT @vendor = vendor_code
						,@display_po_number = display_po_number
					FROM t_po_master
					WHERE wh_id = @wh_id
					and po_number = @po_number

					--Insert into t_receipt
					UPDATE t_receipt
					SET [qty_received] = [qty_received] + @rcpt_qty
						,[qty_damaged] = [qty_damaged] + ( case @type when 'D' then @rcpt_qty else 0 end)
						,[qty_discount] = [qty_discount] + @rcpt_qty
					WHERE receipt_id = @control_number
					and wh_id = @wh_id
					and po_number = @po_number
					and line_number = @line_number
					and item_number = @item_number
					and schedule_number = @scheduler_number
					and (lot_number = @lot_number or (lot_number is null and @lot_number is null))
					--and (ciq_number = @ciq_number or (ciq_number is null and @ciq_number is null))
					and (stored_attribute_id = @stored_attribute_id or (stored_attribute_id is null and @stored_attribute_id is null))
					and hu_id = @hu_id

					IF @@ROWCOUNT = 0 
						BEGIN
							INSERT INTO t_receipt
								([receipt_id],[vendor_code],po_number,line_number,schedule_number,[receipt_date]
								,[item_number],[lot_number],[qty_received],[qty_damaged]
								,[hu_id],[fork_id],[wh_id],[stored_attribute_id],[shipment_number],qty_discount)
							VALUES
								(@control_number,@vendor,@po_number,@line_number,@scheduler_number,getdate()
								,@item_number,@lot_number,@rcpt_qty, case @type when 'D' then @rcpt_qty else 0 end
								,@hu_id,@location_id,@wh_id,@stored_attribute_id,NULL,@discount_qty )
						END
	
					--Insert into [dbo].[int_upd_receipt]
					Insert into [dbo].[tbl_inf_exp_receipt]
						(receipt_id,vendor_code,po_number,display_po_number,receipt_date
						,scac_code,status,item_number,display_item_number,lot_number
						,line_number,schedule_number,qty_received,qty_damaged,hu_id
						,packing_slip,fork_id,uom,shipment_number,warehouse_id,client_code
						,generic_attribute1	,generic_attribute2	,generic_attribute3
						,generic_attribute4	,generic_attribute5	,generic_attribute6
						,generic_attribute7	,generic_attribute8	,generic_attribute9
						,generic_attribute10,generic_attribute11,process_status)
					VALUES
						(@control_number,@vendor,@po_number,@display_po_number,getdate()
						,null,'N',@item_number,NULL,@lot_number
						,@line_number,@scheduler_number,@rcpt_qty, case @type when 'D' then @qty else 0 end,@hu_id
						,NULL,@location_id,NULL,NULL,@wh_id,@client_code
						,(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_1),    
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_2), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_3), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_4), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_5), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_6), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_7), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_8), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_9), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_10), 
    					(SELECT a.attribute_value 
    					FROM t_sto_attrib_collection_detail a,
							t_attribute_legacy_map alm
    					WHERE a.stored_attribute_id = @stored_attribute_id
    					AND a.attribute_id = alm.generic_attribute_11)
						,'Ready'
						)

					UPDATE t_asn_detail
					SET received_qty = received_qty + @rcpt_qty
					WHERE wh_id = @wh_id
					AND asn_number = @control_number
					and po_number = @po_number
					and item_number = @item_number
					and po_line_number = @line_number
					and schedule_number = @scheduler_number

					IF @total_rcpt_qty <= 0
						BEGIN
							BREAK
						END
				END
		-------------------------------------------------------------------------
		-------------------------------------------------------------------------

			--Create LP information
			IF NOT EXISTS(SELECT 1 FROM t_hu_master
					   WHERE wh_id = @wh_id
					   and hu_id = @hu_id)
				BEGIN
					
					SET @zone_type = dbo.fn_Get_StorageType_ByItem(@wh_id,@item_number,@type)

					INSERT INTO t_hu_master
					(wh_id,hu_id,type,control_number,location_id,subtype
					,status, fifo_date,zone)
					VALUES
					(@wh_id,@hu_id,'IV',@control_number,@location_id,@zone_type
					,'A',GETDATE(),NULL)
				END
				
			--Insert into t_stored_item
			SET @qty = @qty + @discount_qty
			
			IF @expiration_date IS NOT NULL
				SELECT @expiration_date = DATEADD(DAY,shelf_life,@expiration_date) FROM t_item_master

			IF EXISTS (SELECT 1 FROM t_stored_item
						WHERE wh_id = @wh_id
						AND location_id = @location_id
						AND item_number = @item_number
						and isnull(lot_number,'') =isnull( @lot_number,'')
						--AND ISNULL(ciq_number,'') = ISNULL(@ciq_number,'')
						and isnull(stored_attribute_id,0) = isnull(@stored_attribute_id,0)
						and isnull(expiration_date,'') =isnull( @expiration_date,'')						
						AND hu_id = @hu_id)
				BEGIN
					UPDATE t_stored_item
					SET [actual_qty] = [actual_qty] + @qty
					WHERE wh_id = @wh_id
					AND location_id = @location_id
					AND item_number = @item_number
					and isnull(lot_number,'') =isnull( @lot_number,'')
					and isnull(expiration_date,'') =isnull( @expiration_date,'')
					--AND ISNULL(ciq_number,'') = ISNULL(@ciq_number,'')
					and isnull(stored_attribute_id,0) = isnull(@stored_attribute_id,0)
					AND hu_id = @hu_id
				END
			ELSE
				BEGIN
					INSERT INTO t_stored_item
					([item_number],lot_number,[wh_id],[location_id],[actual_qty],[status],[fifo_date],[type],[stored_attribute_id],[hu_id],expiration_date)
					VALUES
					(@item_number,@lot_number,@wh_id,@location_id,@qty,'A',GETDATE(),'0',@stored_attribute_id,@hu_id,@expiration_date)
				END
			
		

			--Insert t_tran_log_holding
			INSERT INTO t_tran_log_holding
				([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
				,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
				,generic_attribute_1,
                generic_attribute_2,
                generic_attribute_3,
                generic_attribute_4,
                generic_attribute_5,
                generic_attribute_6,
                generic_attribute_7,
                generic_attribute_8,
                generic_attribute_9,
                generic_attribute_10,
                generic_attribute_11)
			VALUES
				(@tran_type,@tran_description,getdate(),getdate(),getdate(),getdate(),@user_id,@control_number,NULL
				,@wh_id,@location_id,@hu_id,@item_number,@lot_number,@qty,
				(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_1),    
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_2), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_3), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_4), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_5), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_6), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_7), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_8), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_9), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_10), 
    			(SELECT a.attribute_value 
    			FROM t_sto_attrib_collection_detail a,
					t_attribute_legacy_map alm
    			WHERE a.stored_attribute_id = @stored_attribute_id
    			AND a.attribute_id = alm.generic_attribute_11)
				)

				--Interface 
				--INSERT INTO [dbo].[int_upd_receipt]



			 SET @passornot = 0
			 SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END


