



--=======================================     
-- 存储过程名: csp_imp_load_atporder_inbound   
-- 描述：预留单接口入库业务处理  
-- =======================================   

CREATE  PROCEDURE [dbo].[csp_imp_load_atporder_inbound]
	  @DataID varchar(100),
	  @process_status varchar(100),
	  @wh_id varchar(100),
	  @client_code varchar(100),
	  @order_no varchar(100),
	  @line_no varchar(100),
	  @ZFLAG VARCHAR(100)
AS
BEGIN
		/*
		//SAP字段	SAP描述
        //ZPOSITION	发送位置
        //RKPF-RSNUM	预留编号
        //RKPF-RSDAT	创建日期
        //ZBSART        订单类型(固定：RSV)
        //ZFLAG	        出入库标识
        //RESB-RSPOS	行号
        //RESB-MATNR	物料
        //RESB-BDMNG	数量
        //              单位
        //RESB-WERKS	工厂
		*/
        declare @ZPOSITION varchar(100)
        declare @RSNUM varchar(100)
        declare @RSDAT varchar(100)
		declare @ZBSART varchar(100)
      --  declare @ZFLAG varchar(100)
        declare @RSPOS varchar(100)
        declare @MATNR varchar(100)
        declare @BDMNG varchar(100)
		declare @MEINS varchar(100)
        declare @WERKS varchar(100)
        declare @LGORT varchar(100) 
		declare @XLOEK  varchar(100)
 
		declare @order_typeid int
	    declare @order_type varchar(100)
	    declare @cancel_flag varchar(100)

		 

	  	/*if exists(select top 1 * from t_po_master  WITH(NOLOCK) where po_number=@order_no  and status<>'O')
		begin
		   insert into #returnresult values(-101,N'Fail',N'订单号['+@order_no+N']订单状态已经变化，不能修改.')
		   return
		end


		if exists(select top 1 * from t_po_detail  WITH(NOLOCK) where po_number=@order_no and line_number=@line_no and complete_flag='Y')
		begin
		   insert into #returnresult values(-101,N'Fail',N'订单号['+@order_no+N']行号['+@line_no+N']订单明细处理状态已经完成，不能修改.')
		   RETURN
		end*/

		if exists(SELECT 1 from t_rcpt_ship trs WITH(NOLOCK) 
					 INNER JOIN t_rcpt_ship_po rsp WITH(NOLOCK) 
					 ON trs.wh_id = rsp.wh_id
					 AND trs.shipment_number = rsp.shipment_number
					 WHERE   rsp.po_number = @order_no  and  trs.wh_id =@wh_id
					 AND (status <> 'C' 
					      OR (ISNULL(trs.is_confirm,'N') = 'N' 
						       AND EXISTS(SELECT 1 FROM t_control WHERE control_type = 'C_RECEIPT_CONFIRM' AND c1='Y')
						     )
                         )
					)
		begin
				insert into #returnresult values(-101,N'Fail',N'订单号['+@order_no+N'],入库单下存在未关闭的 运单，SAP提示不能更新该入库单')
		         RETURN
		end


		select top 1       @ZPOSITION=ZPOSITION,
							@RSNUM  =RSNUM,
							@RSDAT  =RSDAT,
							@ZBSART =ZBSART,
							@ZFLAG  =ZFLAG,
							@RSPOS  =RSPOS,
							@MATNR  =MATNR,
							@BDMNG  =BDMNG,
							@MEINS  =MEINS,
							@WERKS  =WERKS,
							@LGORT  =LGORT,
							@XLOEK=@XLOEK
		from  tbl_inf_imp_atporder   WITH(NOLOCK)
		where DATA_ID=@DataID 
				and PROCESS_STATUS=@process_status 
				and RSNUM=@order_no  
				and RSPOS=@line_no
				and ZFLAG=@ZFLAG

		if (@XLOEK='X') 
		set @cancel_flag='Y' 
	else 
		set @cancel_flag='N'
			
		
		 select top 1 @order_typeid=type_id,@order_type=wms_ordertype 
		 from tbl_inf_sap_wms_ordertype   WITH(NOLOCK)
		 where sap_ordertype=@ZBSART  and flag_inoutbound=@ZFLAG 

 
		if not exists(select top 1 po_number  from t_po_master  WITH(NOLOCK) where po_number=@order_no)
			 insert into t_po_master(po_number 
							  ,type_id 
							  ,create_date 
							  ,wh_id 
							  ,status 
							  ,display_po_number 
							  ,client_code 
							  ,residential_flag 
							  ,locked_flag 
							  ,sap_ordertype)
					select top 1 @order_no
					            ,@order_typeid
								,cast(@RSDAT as date)
								,@wh_id
								,'O'
								,@order_no
								,@client_code
								,'N'
								,'N'
								,@ZBSART
					from tbl_inf_imp_atporder  WITH(NOLOCK)
					where	DATA_ID=@DataID 
							and PROCESS_STATUS=@process_status 
							and RSNUM=@order_no  
							and RSPOS=@line_no
							and ZFLAG=@ZFLAG
	ELSE
		   update t_po_master
		   set   create_date=cast(@RSDAT as date),
		         type_id=@order_typeid,
				 sap_ordertype=@ZBSART
		   from  t_po_master 
		   where  po_number=@order_no 

		declare @uom varchar(100)
		--select top 1 @uom=uom from t_item_master  where item_number=@MATNR
		 
		set @uom=@MEINS
		declare @stored_attribute_id bigint
		if exists( select top 1 item_number  from t_item_master WITH(NOLOCK) where item_number=@WERKS+'-'+@MATNR  and wh_id=@wh_id and pack_flag='Y')
		begin
			SELECT @stored_attribute_id=CONVERT(INT,tscd.stored_attribute_id)
			FROM t_sto_attrib_collection_detail tscd WITH(NOLOCK)
			INNER JOIN 
			(SELECT TOP 1 tacd.attribute_id,tiu.uom_prompt FROM t_item_master tim WITH(NOLOCK) 
			INNER JOIN t_attribute_collection_detail tacd WITH(NOLOCK) 
			ON tim.attribute_collection_id = tacd.attribute_collection_id
			INNER JOIN t_item_uom tiu WITH(NOLOCK)
			ON tim.wh_id = tiu.wh_id
			AND tim.item_number = tiu.item_number
			WHERE tim.item_number = @WERKS+'-'+@MATNR
			AND tim.wh_id = @wh_id
			AND tiu.uom = @uom) a
			ON tscd.attribute_id = a.attribute_id
			AND tscd.attribute_value = a.uom_prompt
		END 

		declare @storage_location1 nvarchar(30),@storage_location2 nvarchar(30)
		select  @storage_location2=@WERKS, @storage_location1=@LGORT

		if (@XLOEK='X') 
				set @cancel_flag='Y'
		 else
				set @cancel_flag='N'

	if not exists(select top 1  po_number from t_po_detail WITH(NOLOCK) where  po_number=@order_no and line_number=@line_no)
	   insert into  t_po_detail(wh_id 
							  ,po_number
							  ,line_number
							  ,item_number
							  ,qty
							  ,order_uom
							  ,cancel_flag
							  ,storage_location
							  ,factory
							  ,complete_flag
							  ,delivery_date
							  ,schedule_number
							 )
							  values( @wh_id,
									 @order_no,
							         @line_no,
									@WERKS+'-'+@MATNR,
									 cast(@BDMNG as float),
									 @MEINS
									,@cancel_flag
									,@storage_location1
									,@storage_location2
									 ,'N'
									 ,cast(@RSDAT as date)
									 ,1
									 )
		else 
		    update t_po_detail
			set item_number=@WERKS+'-'+@MATNR
				,qty=@BDMNG
				,wh_id=@wh_id
				,order_uom=@MEINS
				,cancel_flag=@cancel_flag
				,storage_location=@storage_location1
				,factory=@storage_location2
				,complete_flag='N'
				 ,delivery_date=cast(@RSDAT as date)
			where po_number=@order_no and line_number=@line_no

   
    
     insert into #returnresult values(1,'OK',N'ATP Inbound成功.')
END







