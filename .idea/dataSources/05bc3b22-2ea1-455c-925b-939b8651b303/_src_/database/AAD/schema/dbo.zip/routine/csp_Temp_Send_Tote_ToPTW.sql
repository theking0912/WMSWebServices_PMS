


CREATE PROCEDURE [dbo].[csp_Send_Tote_ToPTW]    
     @wh_id				NVARCHAR(10),  
     @hu_id			    NVARCHAR(30),
	 @passornot			INT output,			--0:PASS, 1: FAIL
	 @msg				NVARCHAR(200) output
as    
begin    
    -- set nocount on added to prevent extra result sets from    
    set nocount on;    

	begin try
		DECLARE @seq_id NVARCHAR(36)

		IF NOT EXISTS ( SELECT 1 
					FROM t_hu_master hum
					     inner join tbl_pick_wall pw on hum.wh_id = pw.wh_id 
									and hum.control_number = pw.wall_id
					WHERE hum.wh_id = @wh_id
					AND hum.hu_id = @hu_id)
			BEGIN
				SET @passornot = 0
				RETURN
			END


		begin transaction
		SELECT @seq_id = newid()

		INSERT INTO tbl_if_tote_wcs
		(job_guid,tote,wh_id,wall_id,order_number,item_number,item_name,qty,
		[status],create_date)
		SELECT @seq_id,sto.hu_id,sto.wh_id,sto.shipment_number,pkd.order_number,sto.item_number,MAX(itm.[description]),sum(sto.actual_qty)
		,'NEW',GETDATE()
		FROM t_stored_item sto
			inner join t_item_master itm on sto.wh_id = itm.wh_id
										and sto.item_number = itm.item_number
			inner join t_pick_detail pkd on pkd.pick_id = sto.[type]
		WHERE sto.wh_id = @wh_id
		AND sto.hu_id = @hu_id
		GROUP BY sto.hu_id,sto.wh_id,sto.shipment_number,pkd.order_number,sto.item_number
		ORDER BY sto.hu_id,sto.wh_id,sto.shipment_number,pkd.order_number,sto.item_number

		INSERT INTO tbl_if_wcs_ptl_job_queue
		(job_type,job_status,job_data,create_date)
		VALUES
		('WPTOTE','NEW',@seq_id,GETDATE())
		
		commit	
		SET @passornot = 0	
        return

    end try

    begin catch
		IF @@TRANCOUNT > 0 
        rollback
		SET @msg = ERROR_MESSAGE()
		   SET @passornot = 1
        return
    end catch  
end    
    
