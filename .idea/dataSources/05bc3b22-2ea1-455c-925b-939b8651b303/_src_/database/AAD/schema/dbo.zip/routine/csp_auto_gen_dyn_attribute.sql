CREATE PROCEDURE [dbo].[csp_auto_gen_dyn_attribute]

AS

Declare @v_item_number NVARCHAR(50)
Declare @wh_id	Nvarchar(20)
Declare @msg NVARCHAR(200)
Declare @item_master_id int 

BEGIN

	SET @item_master_id=0

    WHILE ( 1 = 1 )
        BEGIN

		select top 1 @item_master_id=item_master_id,@v_item_number=item_number,@wh_id=wh_id 
		from t_item_master 
		where isnull(pack_flag,'N')='Y' 
		and item_master_id > @item_master_id 
		order by item_master_id asc

		if @@ROWCOUNT=0
			break

		BEGIN TRY
			Exec csp_gen_dyn_attribute_NBO
				  @v_item_number,
				  @wh_id,
				  @msg OUTPUT

		END TRY
		BEGIN CATCH
			continue
		END CATCH

		END
END

GRANT EXEC ON csp_auto_gen_dyn_attribute TO AAD_USER,WA_USER