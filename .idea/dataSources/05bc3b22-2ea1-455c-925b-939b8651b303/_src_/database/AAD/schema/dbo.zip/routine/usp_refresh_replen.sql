
CREATE PROCEDURE usp_refresh_replen
@in_vchType     NVARCHAR(10),
@in_vchWhID     NVARCHAR(10) = '01',
@in_vchUserID   NVARCHAR(10)
AS

DECLARE
-- Error handling and logging variables.
@c_nModuleNumber            INTEGER, -- The # that uniquely tags the WA collection of objects.
@c_nFileNumber              INTEGER, -- The # that uniquely tags this object.
@c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
@v_nLogErrorNum             INTEGER, -- The # that uniquely tags the error message.
@v_nLogLevel                INTEGER, -- Holds log level (1-5).
@v_vchErrorMsg              NVARCHAR(500),
@v_nSysErrorNum             INTEGER,
@v_nSysRowCount             INTEGER,
@v_nReturn                  INTEGER,
@v_nCount                   INTEGER,

-- Log Error numbers used for branching in the Error Handler.
@e_GenSqlError              INTEGER,
@e_SprocError               INTEGER,
@e_InvalidType              INTEGER,

-- Local Variables
@v_nRecCounter              INTEGER,
@v_nPickID                  INTEGER,
@v_vchStageLoc              NVARCHAR(50),
@v_vchItem                  NVARCHAR(30),
@v_fPlannedQty              FLOAT,
@v_vchPickLoc               NVARCHAR(50),
@v_vchCalcFlag              NVARCHAR(3),
@v_nQty                     INTEGER,
@v_nMaxQty                  INTEGER,
@v_chWorkType               NVARCHAR(2),
@v_vchLoc                   NVARCHAR(50),
@v_chLocalType              NVARCHAR(2),
@v_vchStoredAttributeID     BIGINT


-- Set constant values.
SET @c_nModuleNumber = 60     -- Always #60 for WA.
SET @c_nFileNumber = 1        -- This # must be unique per object
SET @c_vchObjName = 'usp_refresh_replen'
SET @e_GenSqlError = 1
SET @e_SprocError = 2
SET @e_InvalidType = 3

-- Set the Work Type based on the type passed in.
IF @in_vchType IN ('MINMAX','71')
    SET @v_chWorkType = '71'
ELSE IF @in_vchType IN ('TOPOFF','72')
    SET @v_chWorkType = '72'
ELSE IF @in_vchType IN ('SLOT','17')
    SET @v_chWorkType = '17'
ELSE
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': Attempting to create a replenishment for an invalid work type.'
    SET @v_nLogErrorNum = @e_InvalidType
    GOTO ERROR_HANDLER
END

SET NOCOUNT ON

-- Grab the database object log level.
EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
IF @v_nReturn <> 0 -- A zero means success.
BEGIN
    SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '.'
    SET @v_nLogErrorNum = @e_SprocError
    GOTO ERROR_HANDLER
END

-- Temp table used to hold items from t_pick_detail.
-- Items will be updated with a location_id and picking flow based on any specific
-- rules which are executed.
CREATE TABLE #tmp_pick_details_to_update (
   unique_id       	      INT IDENTITY(1,1)  NOT NULL,
   wh_id          	      NVARCHAR(10)       COLLATE DATABASE_DEFAULT NOT NULL,
   pick_id       	      INT                NOT NULL,
   wave_id       	      NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   load_id       	      NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   work_q_id     	      NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   item_number   	      NVARCHAR(30)       COLLATE DATABASE_DEFAULT NOT NULL,
   line_number   	      NVARCHAR(5)           COLLATE DATABASE_DEFAULT NULL,
   lot_number    	      NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
   serial_number  	      NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   pick_quantity  	      FLOAT              NULL,
   uom            	      NVARCHAR(10)       COLLATE DATABASE_DEFAULT NULL,
   pick_put_id     	      NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
   location_id    	      NVARCHAR(50)       COLLATE DATABASE_DEFAULT NULL,
   pick_location  	      NVARCHAR(50)       COLLATE DATABASE_DEFAULT NULL,
   picking_flow   	      NVARCHAR(3)           COLLATE DATABASE_DEFAULT NULL,
   pick_area      	      NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   work_type       	      NVARCHAR(15)       COLLATE DATABASE_DEFAULT NULL,
   order_number           NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   cartonization_batch_id NVARCHAR(150)      COLLATE DATABASE_DEFAULT NULL,
   status                 NVARCHAR(20)       COLLATE DATABASE_DEFAULT NULL,
   staging_location       NVARCHAR(50)       COLLATE DATABASE_DEFAULT NULL,
   type                   NVARCHAR(25)       COLLATE DATABASE_DEFAULT NULL,
   container_id           NVARCHAR(30)       COLLATE DATABASE_DEFAULT NULL,
   planned_qty            FLOAT              NULL,
   calc_flag              NVARCHAR(3)        COLLATE DATABASE_DEFAULT NULL,
   max_qty                INTEGER            NULL,
   update_flag            NVARCHAR(3)        COLLATE DATABASE_DEFAULT NULL,
   manifest_carrier_flag  NVARCHAR(1)        COLLATE DATABASE_DEFAULT NULL,
   stored_attribute_id    BIGINT             NULL,
   before_pick_rule            NVARCHAR(50)  COLLATE DATABASE_DEFAULT NULL,
   during_pick_rule            NVARCHAR(50)  COLLATE DATABASE_DEFAULT NULL,
   pick_location_change_date   DATETIME                          NULL  
)

-----------------------------------------------------------------------------------
--                     Build Temp Table for Candidates
-----------------------------------------------------------------------------------


CREATE TABLE #tmp_replenishments
(
   pick_id                INTEGER,     
   stage_loc              NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,
   item                   NVARCHAR(30) COLLATE DATABASE_DEFAULT NULL,
   planned_qty            FLOAT,
   calc_flag              NVARCHAR(3) COLLATE DATABASE_DEFAULT NULL,
   max_qty                INTEGER,
   update_flag            NVARCHAR(3) COLLATE DATABASE_DEFAULT NULL,
   stored_attribute_id    BIGINT            NULL
)

-----------------------------------------------------------------------------------
--                     Find and Insert Candidates                  
-----------------------------------------------------------------------------------


IF @v_chWorkType <> '17' 
BEGIN
	INSERT INTO #tmp_replenishments (pick_id, stage_loc, item, planned_qty,
									 calc_flag, max_qty, update_flag, stored_attribute_id)
	SELECT
		pkd.pick_id,
		pkd.staging_location,
		pkd.item_number,
		pkd.planned_quantity,
		fwd.calculate_qty_flag,
		fwd.maximum_replenishment_qty,
		'NO', -- Intialize with NO
        pkd.stored_attribute_id
	FROM
		t_pick_detail pkd,
		t_fwd_pick fwd
	WHERE
		pkd.type = 'RP'
		AND pkd.work_type = @v_chWorkType
		AND pkd.status = 'RELEASED'
		AND pkd.user_assigned IS NULL
		AND pkd.wh_id = @in_vchWhID
		AND ISNULL(pkd.picked_quantity,0) = 0  -- Don't touch after picking has started.
		AND pkd.item_number = fwd.item_number
        AND ISNULL(pkd.stored_attribute_id,'') = ISNULL(fwd.stored_attribute_id,'')
		AND pkd.staging_location = fwd.location_id
		AND pkd.wh_id = fwd.wh_id
	ORDER BY pkd.pick_id

	SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
	IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
			+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
	END
END
ELSE
BEGIN
	INSERT INTO #tmp_replenishments (pick_id, stage_loc, item, planned_qty,
									 calc_flag, max_qty, update_flag, stored_attribute_id)
	SELECT
		pkd.pick_id,
		pkd.staging_location,
		pkd.item_number,
		pkd.planned_quantity,
		'YES' AS calculate_qty_flag,
		pkd.planned_quantity AS maximum_replenishment_qty,
		'NO', -- Intialize with NO
        pkd.stored_attribute_id
	FROM
		t_pick_detail pkd
	WHERE
		pkd.type = 'SM'
		AND pkd.work_type = @v_chWorkType
		AND pkd.status = 'RELEASED'
		AND pkd.user_assigned IS NULL
		AND pkd.wh_id = @in_vchWhID
		AND ISNULL(pkd.picked_quantity,0) = 0  -- Don't touch after picking has started.
	ORDER BY pkd.pick_id

	SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
	IF @v_nSysErrorNum <> 0
	BEGIN
		SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
			+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
		SET @v_nLogErrorNum = @e_GenSqlError
		GOTO ERROR_HANDLER
	END
END

-----------------------------------------------------------------------------------
--                     Cycle through Temp Table
-----------------------------------------------------------------------------------
SELECT
    @v_nCount = COUNT(*)
FROM
    #tmp_replenishments

-- Initialize variables
SET @v_nRecCounter = 1
SET @v_nPickID = 0

WHILE @v_nRecCounter <= @v_nCount
BEGIN
    SELECT TOP 1
        @v_nPickID = pick_id,
        @v_vchStageLoc = stage_loc,
        @v_vchItem = item,
        @v_vchStoredAttributeID = stored_attribute_id,
        @v_fPlannedQty = planned_qty,
        @v_vchCalcFlag = calc_flag,
        @v_nMaxQty = max_qty
    FROM
        #tmp_replenishments
    WHERE
        pick_id > @v_nPickID
    ORDER BY
        pick_id

    SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
    IF @v_nSysErrorNum <> 0
    BEGIN
        SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error ['
            + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ERROR_HANDLER
    END
    
    IF @v_vchCalcFlag = 'YES' OR ( @in_vchType = 'TOPOFF' OR @in_vchType = 'SLOT')
    BEGIN -- @v_vchCalcFlag = 'YES' OR @in_vchType = 'TOPOFF'
        SELECT
            -- If no STO record was found, the calulation will come back with a NULL, so just use the max qty.
            @v_nQty = ISNULL(@v_nMaxQty - SUM(actual_qty - unavailable_qty), @v_nMaxQty)
        FROM
            t_stored_item
        WHERE
            wh_id = @in_vchWhID
            AND location_id = @v_vchStageLoc
            AND item_number = @v_vchItem
            AND (stored_attribute_id = @v_vchStoredAttributeID OR @v_vchStoredAttributeID IS NULL)
            -- Limit to only a positive quantity. A negative will cause it to end up greater than the max.
            AND actual_qty > 0;
    
        SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
        IF @v_nSysErrorNum <> 0
        BEGIN
            SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
                + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ERROR_HANDLER
        END
    
        -- If STO exists with a quantity greater than or equal to the max, a replenishment is no longer needed, complete.
        -- Note: @v_nQty will be either 0 or negative.
        IF @v_nSysRowCount > 0 AND @v_nQty <= 0
        BEGIN -- @v_nSysRowCount > 0 AND @v_nQty <= 0
            UPDATE t_work_q
            SET work_status = 'C'
            WHERE work_q_id = (SELECT work_q_id FROM t_pick_detail WHERE pick_id = @v_nPickID);
                
            UPDATE t_pick_detail
            SET status = 'PICKED'
            WHERE pick_id = @v_nPickID;
        END -- @v_nSysRowCount > 0 AND @v_nQty <= 0
        ELSE
        BEGIN
            IF @v_nQty <> @v_fPlannedQty
                UPDATE #tmp_replenishments
                SET planned_qty = @v_nQty,
                    update_flag = 'YES'
                WHERE pick_id = @v_nPickID;
        END        
    
    END -- @v_vchCalcFlag = 'YES' OR @in_vchType = 'TOPOFF'
    
    -- Increment Record Counter
    SET @v_nRecCounter = @v_nRecCounter + 1

END -- WHILE @v_nRecCounter <= @v_nCount

-----------------------------------------------------------------------------------
--                            Apply PKD Updates
-----------------------------------------------------------------------------------
UPDATE
    t_pick_detail
SET
    planned_quantity = (SELECT tmp.planned_qty
                        FROM #tmp_replenishments tmp
                        WHERE t_pick_detail.pick_id = tmp.pick_id        
                            AND tmp.update_flag = 'YES')
WHERE EXISTS (SELECT 1
              FROM #tmp_replenishments tmp2
              WHERE t_pick_detail.pick_id = tmp2.pick_id
                  AND tmp2.update_flag = 'YES')                
        
SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    SET @v_nLogErrorNum = @e_GenSqlError
    GOTO ERROR_HANDLER
END        

-----------------------------------------------------------------------------------
--                           Refresh Pick Locations
-----------------------------------------------------------------------------------

IF @v_chWorkType <> '17' 
   SET @v_chLocalType = 'RP'
ELSE
   SET @v_chLocalType = 'SM'


EXECUTE @v_nReturn = usp_before_pick_release
		@in_vchType = @v_chLocalType,
		@in_vchWhID = @in_vchWhID,
		@in_vchPKDStatus = 'RELEASED'

IF @v_nReturn <> 0 -- A zero means success.
BEGIN
	SET @v_vchErrorMsg = 'An error occurred in a stored procedure [usp_before_pick] '
		+ 'with a return code of ' + ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
	SET @v_nLogErrorNum = @e_SprocError
	GOTO ERROR_HANDLER
END

-----------------------------------------------------------------------------------
--   Update t_pick_detail from temp table with results from before_pick_release
-----------------------------------------------------------------------------------
UPDATE pkd
SET pkd.pick_location = tmp.pick_location,
    pkd.picking_flow = tmp.picking_flow
    -- pkd.pick_area = tmp.pick_area, (currently set to 'ALL', see "Update PKD pick_area" comment
    --                                 section in usp_work_q_release_replen for other 2 updates)
FROM t_pick_detail pkd, 
    #tmp_pick_details_to_update tmp
WHERE pkd.pick_id = tmp.pick_id

SELECT @v_nSysErrorNum = @@ERROR
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    SET @v_nLogErrorNum = @e_GenSqlError
    GOTO ERROR_HANDLER
END

DROP TABLE #tmp_replenishments
DROP TABLE #tmp_pick_details_to_update

GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling Code
-----------------------------------------------------------------------------------
ERROR_HANDLER:
-- Log the error message in ADV.t_log
EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

-- Raise the error with error message, severity, state
SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
    + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
    + ' ERROR [' + @v_vchErrorMsg + ']'
RAISERROR(@v_vchErrorMsg, 11, 1)

SET @v_nReturn = @v_nLogErrorNum

--ROLLBACK TRANSACTION

-----------------------------------------------------------------------------------
--                            Exit the Process
-----------------------------------------------------------------------------------
EXIT_LABEL:
RETURN
