CREATE FUNCTION dbo.fn_GetFormatMoney (@money numeric(14,2))
RETURNS NVARCHAR(32) AS
BEGIN
    DECLARE @money_num NVARCHAR(20)    --存储金额的字符形式
        , @money_chn NVARCHAR(32)    --存储金额的中文大写形式
        , @n_chn NVARCHAR(1), @i INT    --临时变量
 
    SELECT @money_chn=CASE WHEN @money>=0 THEN '' ELSE '(负)' END
        , @money=ABS(@money)
        , @money_num=STUFF(STR(@money, 15, 2), 13, 1, '')    --加前置空格补齐到14位（去掉小数点）
        , @i=PATINDEX('%[1-9]%', @money_num)    --找到金额最高位
 
    WHILE @i>=1 and @i<=14
    BEGIN
        SET @n_chn=SUBSTRING(@money_num, @i, 1)    
        IF @n_chn<>'0' or (SUBSTRING(@money_num,@i+1,1)<>'0' and @i not in(4, 8, 12, 14))    --转换阿拉伯数字为中文大写形式     
            SET @money_chn=@money_chn+SUBSTRING('零壹贰叁肆伍陆柒捌玖', @n_chn+1, 1)
        IF @n_chn<>'0' or @i in(4, 8, 12)    --添加中文单位
            SET @money_chn=@money_chn+SUBSTRING('仟佰拾亿仟佰拾万仟佰拾元角分',@i,1)      
     
        SET @i=@i+1
    END
 
    SET @money_chn=REPLACE(@money_chn, '亿万', '亿')    --当金额为X亿零万时去掉万
    IF @money=0 SET @money_chn='零元整'    --当金额为零时返回'零圆整'
    IF @n_chn='0' SET @money_chn=@money_chn+'整'    --当金额末尾为零分时以'整'结尾
 
    RETURN @money_chn    --返回大写金额
 
END
