

CREATE PROCEDURE usp_get_stored_attribute_id  
@in_vchItemNumber NVARCHAR(30), 
@in_vchWhId NVARCHAR(10), 
@in_vchAttValue1 NVARCHAR(250), 
@in_vchAttValue2 NVARCHAR(250), 
@in_vchAttValue3 NVARCHAR(250), 
@in_vchAttValue4 NVARCHAR(250), 
@in_vchAttValue5 NVARCHAR(250), 
@in_vchAttValue6 NVARCHAR(250), 
@in_vchAttValue7 NVARCHAR(250), 
@in_vchAttValue8 NVARCHAR(250), 
@in_vchAttValue9 NVARCHAR(250), 
@in_vchAttValue10 NVARCHAR(250), 
@in_vchAttValue11 NVARCHAR(250),
@out_vchErrMsg VARCHAR(100) OUTPUT,
--@out_vchStoAttId VARCHAR(36) OUTPUT 
@out_nStoAttId BIGINT OUTPUT 
AS

DECLARE 
    @v_nAttId1 INT, 
    @v_nAttId2 INT, 
    @v_nAttId3 INT, 
    @v_nAttId4 INT, 
    @v_nAttId5 INT, 
    @v_nAttId6 INT, 
    @v_nAttId7 INT, 
    @v_nAttId8 INT, 
    @v_nAttId9 INT, 
    @v_nAttId10 INT, 
    @v_nAttId11 INT,

    @v_nCollId	INT,
--    @v_vchStoAttributeId varchar(36) 
    @v_nStoAttributeId BIGINT 

DECLARE
    @x INT

DECLARE -- checksum variables
    @v_vchAuxStr NVARCHAR(3000),
    @v_vchQryStr NVARCHAR(4000),
    @v_vchParamStr NVARCHAR(1000),
    @v_nOutchk int


SET NOCOUNT ON

SET @out_vchErrMsg = ''
SET @out_nStoAttId = NULL

SELECT @v_nCollId = attribute_collection_id
FROM t_item_master
WHERE item_number = @in_vchItemNumber
AND   wh_id = @in_vchWhId

-- Checking that the Item has an attribute_collection associated
-- If the attribute_collection_id is NULL then go out returning a NULL	
IF (@v_nCollId IS NULL)
    BEGIN
        SET @out_nStoAttId = NULL
        SET @out_vchErrMsg = 'Item Without Attribute Collection'
        RETURN(0)
    END

SELECT 
 @v_nAttId1 = generic_attribute_1,
 @v_nAttId2 = generic_attribute_2,
 @v_nAttId3 = generic_attribute_3,
 @v_nAttId4 = generic_attribute_4,
 @v_nAttId5 = generic_attribute_5,
 @v_nAttId6 = generic_attribute_6,
 @v_nAttId7 = generic_attribute_7,
 @v_nAttId8 = generic_attribute_8,
 @v_nAttId9 = generic_attribute_9,
 @v_nAttId10 = generic_attribute_10,
 @v_nAttId11 = generic_attribute_11 
FROM t_attribute_legacy_map

CREATE TABLE #temp_att_values (id tinyint, att_id int NULL, att_value varchar(250) COLLATE DATABASE_DEFAULT NULL)

INSERT INTO #temp_att_values
SELECT  1, @v_nAttId1, @in_vchAttValue1 
UNION ALL SELECT  2, @v_nAttId2, @in_vchAttValue2 
UNION ALL SELECT  3, @v_nAttId3, @in_vchAttValue3 
UNION ALL SELECT  4, @v_nAttId4, @in_vchAttValue4 
UNION ALL SELECT  5, @v_nAttId5, @in_vchAttValue5 
UNION ALL SELECT  6, @v_nAttId6, @in_vchAttValue6 
UNION ALL SELECT  7, @v_nAttId7, @in_vchAttValue7 
UNION ALL SELECT  8, @v_nAttId8, @in_vchAttValue8 
UNION ALL SELECT  9, @v_nAttId9, @in_vchAttValue9 
UNION ALL SELECT  10, @v_nAttId10, @in_vchAttValue10 
UNION ALL SELECT  11, @v_nAttId11, @in_vchAttValue11

-- ignoring attributes that are not in the attribute collection
UPDATE #temp_att_values
SET att_id = NULL
WHERE att_id NOT IN (SELECT attribute_id 
                     FROM t_attribute_collection_detail
                     WHERE attribute_collection_id = @v_nCollId)


-- check if exists values for attributes not populated 
IF EXISTS(SELECT * FROM #temp_att_values 
          WHERE att_id is NULL 
          AND att_value is NOT NULL)
    BEGIN
    -- mark the error
        SET @out_vchErrMsg = 'Warning: More attribute values than attributes on t_legacy_map. Values ignored'
   
    -- ignore attribute values 
        UPDATE #temp_att_values
        SET att_value = NULL
        WHERE att_id is NULL
   
    END
   	  

-- Checking trace exceptions
-- If some attribute has a trace exception for this item then the attribute value is ignored (Set NULL)
-- "Warning: Attribue values ignored by trace control exception"
UPDATE #temp_att_values
SET att_value = NULL
WHERE EXISTS (SELECT * FROM t_attribute_exception_control
              WHERE item_number = @in_vchItemNumber
              AND wh_id = @in_vchWhId
              AND attribute_id = att_id
              AND attribute_control in ('I','O','T'))


-- Checking that all full trace attributes have a value	
-- If there are required attributes with NULL values then return an error
IF EXISTS (SELECT * FROM #temp_att_values
           WHERE att_value IS NULL 
           AND att_id IS NOT NULL
           AND NOT EXISTS (SELECT * FROM t_attribute_exception_control
                           WHERE item_number = @in_vchItemNumber
                           AND wh_id = @in_vchWhId
                           AND attribute_id = att_id
                           AND attribute_control in ('I','O','T')))
    BEGIN --There are required attributes with NULL values
        SET @out_vchErrMsg = 'Error: Required attribute with NULL value'
        RETURN(-1) 
    END


-- check the attribute values in t_attribute_values
-- count valid attribute values
SELECT @x = COUNT(*) 
FROM #temp_att_values tav
WHERE 
(NOT EXISTS (SELECT * FROM t_attribute_values 
             WHERE attribute_id = tav.att_id) 
OR (EXISTS  (SELECT * FROM t_attribute_values
             WHERE attribute_id = tav.att_id
             AND attribute_value = tav.att_value)))
AND att_id IS NOT NULL
AND att_value IS NOT NULL

IF ((SELECT COUNT(*) FROM #temp_att_values 
     WHERE att_id IS NOT NULL
     AND att_value IS NOT NULL) > @x) -- agregar validaci≤n de que cantidad de valores sea mayor que 0, aunque no deberφa ir aquφ
    BEGIN -- There are invalid attribute values
        SET @out_vchErrMsg = 'Error: Invalid attribute value'
        RETURN(-1) 
    END
ELSE
    BEGIN
    --All the attribute values are valid

        -- Checking if the collection has required attributes 
        IF ((SELECT COUNT(*) 
             FROM #temp_att_values
             WHERE att_value IS NOT NULL
               AND att_id is NOT NULL) = 0)
            BEGIN -- No attribute values required, all attributes in the collection with trace exceptions
                SET @out_nStoAttId = NULL
                SET @out_vchErrMsg = 'Empty Stored Attribute Collection'
                RETURN(0)
            END


        -- calculating checksum of the attribute values ordered by attribute_id
        SET @v_vchAuxStr = N''
        
        SELECT @v_vchAuxStr = @v_vchAuxStr + '''' + att_value + ''',' 
	FROM #temp_att_values tav
	WHERE att_value IS NOT NULL
          AND att_id is NOT NULL
	ORDER BY att_id ASC
	
	SELECT @v_vchAuxStr = SUBSTRING(@v_vchAuxStr,1,LEN(@v_vchAuxStr)-1)
	SELECT @v_vchQryStr = N'select @chksum = checksum('+@v_vchAuxStr+')'
	SELECT @v_vchParamStr = N'@chksum int OUTPUT'
	
	EXECUTE sp_executesql @v_vchQryStr, @v_vchParamStr,  @chksum = @v_nOutchk OUTPUT
	-- end of checksum calculation


        SET @v_nStoAttributeId = NULL

        SELECT @v_nStoAttributeId = t2.stored_attribute_id 
        FROM
            (SELECT 
                (SELECT tt.att_value 
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 1) as attrib_val1,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 2) as attrib_val2,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 3) as attrib_val3,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 4) as attrib_val4,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 5) as attrib_val5,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 6) as attrib_val6,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 7) as attrib_val7,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 8) as attrib_val8,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 9) as attrib_val9,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 10) as attrib_val10,
                (SELECT tt.att_value
                 FROM #temp_att_values tt,
                      t_attribute_collection_detail tacd
                 WHERE tacd.attribute_collection_id = @v_nCollId
                     AND tacd.attribute_id = tt.att_id
                     AND tacd.sequence_id = 11) as attrib_val11) t1,

            (SELECT tsacm.stored_attribute_id, tsacm.attribute_collection_id,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 1) as val1 ,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 2) as val2 ,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 3) as val3,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 4) as val4,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 5) as val5,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 6) as val6,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 7) as val7,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 8) as val8,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 9) as val9,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 10) as val10,
                    (SELECT attribute_value 
                     FROM t_sto_attrib_collection_detail tsacd,
                          t_attribute_collection_detail tacd
                     WHERE tsacd.stored_attribute_id = tsacm.stored_attribute_id
                         AND tsacd.attribute_id = tacd.attribute_id
                         AND tacd.attribute_collection_id = tsacm.attribute_collection_id
                         AND tacd.sequence_id = 11) as val11
             FROM t_sto_attrib_collection_master tsacm
             WHERE attribute_collection_id = @v_nCollId
               AND detail_checksum = @v_nOutchk) t2
        WHERE ISNULL(t1.attrib_val1,'') = ISNULL(t2.val1,'')
        AND ISNULL(t1.attrib_val2,'') = ISNULL(t2.val2,'')
        AND ISNULL(t1.attrib_val3,'') = ISNULL(t2.val3,'')
        AND ISNULL(t1.attrib_val4,'') = ISNULL(t2.val4,'')
        AND ISNULL(t1.attrib_val5,'') = ISNULL(t2.val5,'')
        AND ISNULL(t1.attrib_val6,'') = ISNULL(t2.val6,'')
        AND ISNULL(t1.attrib_val7,'') = ISNULL(t2.val7,'')
        AND ISNULL(t1.attrib_val8,'') = ISNULL(t2.val8,'')
        AND ISNULL(t1.attrib_val9,'') = ISNULL(t2.val9,'')
        AND ISNULL(t1.attrib_val10,'') = ISNULL(t2.val10,'')
        AND ISNULL(t1.attrib_val11,'') = ISNULL(t2.val11,'')


        IF @v_nStoAttributeId IS NULL --Create a stored_attribute_collection
            BEGIN
	
                INSERT INTO t_sto_attrib_collection_master 
                (attribute_collection_id, detail_checksum)
                VALUES (@v_nCollId, @v_nOutchk)

                SELECT @v_nStoAttributeId = SCOPE_IDENTITY()
	
                INSERT INTO t_sto_attrib_collection_detail
                SELECT @v_nStoAttributeId, att_id, att_value
                FROM #temp_att_values
                WHERE att_id IS NOT NULL
                AND att_value IS NOT NULL

            END

        SET @out_nStoAttId = @v_nStoAttributeId
        RETURN(0)
    END
