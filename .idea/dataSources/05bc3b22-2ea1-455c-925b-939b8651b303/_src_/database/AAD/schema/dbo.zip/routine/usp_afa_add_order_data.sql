
CREATE PROCEDURE usp_afa_add_order_data
@in_vchOrderNumber        NVARCHAR(60),
@in_vchWarehouseId        NVARCHAR(20),
@in_vchLoadId             NVARCHAR(60),
@out_vchMessage           NVARCHAR(200) OUTPUT, -- Contians "SUCCESS" or the message to be displayed.
@out_vchLoadDetailId      NVARCHAR(50)  OUTPUT

AS

DECLARE
    @v_nErrorNumber	  INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(250),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,

    @v_nReturn            INTEGER,
    @v_vchErrorMsg        NVARCHAR(200),

    @v_nLoadDetailId      INTEGER,

    @e_GenSqlError   	  INTEGER,
    @e_SprocError         INTEGER,
    @e_LoadMustBeHeld     INTEGER,

    @v_nTranCount         INTEGER,
    @v_nSequence          INTEGER,
    @v_nValue		  INTEGER,
    @v_chStatus           CHAR(1)


    SET NOCOUNT ON
    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 4

    SET @out_vchMessage = 'SUCCESS'
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_LoadMustBeHeld = 3

    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0
        BEGIN TRANSACTION

    -- Verify the load is on hold before manipulating data.
    -- First check for pick detail records.  If none then it is new.  If PKD, then check WKQs
    SELECT @v_nRowCount = COUNT (*)
    FROM t_pick_detail
    WHERE wh_id = @in_vchWarehouseId
        AND load_id = @in_vchLoadId

    -- If no record found then load is new (never released). If not new verify status.
    IF @v_nRowCount > 0 -- A record was found so check the status.
        BEGIN
            -- Check wkq for the load
            SELECT @v_nRowCount = COUNT (*)
            FROM t_work_q
            WHERE wh_id = @in_vchWarehouseId                         
                AND work_q_id IN (SELECT work_q_id 
                                  FROM t_pick_detail
                                  WHERE wh_id = @in_vchWarehouseId
                                      AND load_id = @in_vchLoadId)
                AND work_status <> 'H' 

            IF @v_nRowCount > 0 -- The the load is not on hold
            BEGIN
                SET @v_nErrorNumber = @e_LoadMustBeHeld
                GOTO ErrorHandler
            END
        END

    -- Count to see if record for load,order,warehouse combination already exits in the load detail table
     SELECT @v_nLoadDetailId = load_detail_id
     FROM t_afa_load_detail
     WHERE wh_id = @in_vchWarehouseId
         AND order_number = @in_vchOrderNumber
         AND load_id = @in_vchLoadId

    SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    -- Check for errors
    IF @v_vchSqlErrorNumber <> 0
    BEGIN
           SET @v_nErrorNumber = @e_GenSqlError
           GOTO ErrorHandler
    END

    IF @v_nRowCount = 0
    BEGIN -- Build a load detail record

        -- Get the next available sequence number for the order
        SELECT @v_nSequence = MAX (load_seq)
        FROM t_afa_load_detail
        WHERE load_id = @in_vchLoadId
            AND wh_id = @in_vchWarehouseId

        SELECT @v_vchSqlErrorNumber = @@ERROR
        -- Check for errors
        IF @v_vchSqlErrorNumber <> 0
        BEGIN
           SET @v_nErrorNumber = @e_GenSqlError
           GOTO ErrorHandler
        END

        -- If no rows were selected then set sequence to 1
        IF @v_nSequence IS NULL
            SET @v_nSequence = 1
        ELSE
            SET @v_nSequence = @v_nSequence + 1

        INSERT INTO t_afa_load_detail
           (wh_id, order_number, load_id, load_seq)
        VALUES ( @in_vchWarehouseId,  @in_vchOrderNumber ,
                @in_vchLoadId, @v_nSequence)

        -- Get the load_detail_id so it can be returned to the calling program
        SELECT @out_vchLoadDetailId =  @@IDENTITY -- Returns the last inserted identity column

    END
    ELSE  --Find the load detail id of the existing record and retrun the value
    BEGIN
        SET @out_vchLoadDetailId = @v_nLoadDetailId
    END
	
	-- START CSA ORDER STATUS HISTORY LOGIC
    --Now insert an order status history record.
    --First check to see if CSA is installed and the usp_ta_order_status_history sproc are installed.
    --SELECT @v_nValue = next_value FROM t_control WHERE control_type = 'CSA'
    --
    --If the sproc exists
    --IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('dbo.usp_ta_order_status_history'))
    --BEGIN
    --	--AND if CSA is installed
    --    IF ISNULL(@v_nValue,0) = 1
	--BEGIN
	--    EXECUTE usp_ta_order_status_history @in_vchWarehouseId, @in_vchOrderNumber, 'PLANNING'
	--END
    --END
    -- END CSA ORDER STATUS HISTORY LOGIC

    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    ELSE IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
       EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(varchar(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END
    ELSE IF @v_nErrorNumber = @e_LoadMustBeHeld
    BEGIN
        -- Log Error
        SET @v_vchLogMsg = 'Load must be put on hold before adding orders.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = 't_work_q'
        SET @v_nRaiseErrorNumber = 50005 -- Select Failed Error
        -- Reset message after logged to return to optimizer
        SET @v_vchLogMsg = 'NOT ON HOLD'

    END




    --THE FOLLOWING VALUE WAS SET AT THE BEGINING OF THE PROCEDURE TO THE TRANSACTION COUNT BEFORE ENTERING
    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    -- Raiserror parameters: Error #, Severity(11=ADO requirement), State(1), Parameter(to be used in error)
    RAISERROR (@v_nRaiseErrorNumber, 11, 1, @v_vchParam1)

ExitLabel:
    RETURN

