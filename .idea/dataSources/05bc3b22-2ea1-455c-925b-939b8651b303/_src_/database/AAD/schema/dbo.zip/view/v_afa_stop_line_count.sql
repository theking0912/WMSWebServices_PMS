
CREATE VIEW dbo.v_afa_stop_line_count
AS
SELECT
    wh_id,
    load_id,
    stop_id,
    stop_sequence,
    COUNT(num_items) AS num_lines
FROM
    v_afa_lines
GROUP BY
    wh_id,
    load_id,
    stop_id,
    stop_sequence

