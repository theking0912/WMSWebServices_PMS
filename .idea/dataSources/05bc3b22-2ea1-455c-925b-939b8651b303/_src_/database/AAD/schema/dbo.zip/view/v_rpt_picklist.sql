


/*
GROUP BY pl.order_number, od.order_date, pl.line_number, pl.allocated_qty, pl.wh_id, pl.list_number, z.description, pl.location_id, pl.item_number, item.description, 
                      pl.allocated_qty, item.pack_flag, pl.allocated_qty, pl.picking_flow, item.pack_flag, pl.wave_id, pl.allocated_qty, item.pack_flag, pl.wave_id, cus.short_name, 
                      cus.customer_name, cus.short_name, cus.customer_name, cus.short_name, tf.name, pl.stored_attribute_id, pl.wh_id, pl.hu_id, od.department, od.order_type
*/
CREATE VIEW [dbo].[v_rpt_picklist]
AS
SELECT   CONVERT(CHAR(10), od.earliest_ship_date, 120) AS earliest_ship_date, CONVERT(CHAR(10), od.order_date, 120) 
                AS order_date, pl.wh_id, pl.order_number, pl.list_number, z.description AS zone, pl.location_id, pl.line_number, 
                pl.item_number,item.display_item_number,item.description, pl.allocated_qty, ROUND(pl.allocated_qty / ISNULL
                    ((SELECT   TOP (1) conversion_factor
                      FROM      dbo.t_item_uom AS tiu WITH (NOLOCK) 
                      WHERE   (item_number = pl.item_number) AND (wh_id = pl.wh_id)  and tiu.status='ACTIVE'
                      ORDER BY wh_id, item_number, conversion_factor DESC), 1), 2) AS max_uom_qty,
                    (SELECT   TOP (1) conversion_factor
                     FROM      dbo.t_item_uom AS tiu WITH (NOLOCK)
                     WHERE   (item_number = pl.item_number) AND (wh_id = pl.wh_id)  and tiu.status='ACTIVE'
                     ORDER BY wh_id, item_number, conversion_factor DESC) AS max_convertion,
                    (SELECT   TOP (1) uom_prompt
                     FROM      dbo.t_item_uom AS tiu WITH (NOLOCK)
                     WHERE   (item_number = pl.item_number) AND (wh_id = pl.wh_id)  and tiu.status='ACTIVE'
                     ORDER BY wh_id, item_number, conversion_factor DESC) AS max_description, CASE ISNULL(item.pack_flag, 'N') 
                WHEN 'Y' THEN CONVERT(NVARCHAR, pl.allocated_qty / ISNULL
                    ((SELECT   conversion_factor
                      FROM      t_sto_attrib_collection_detail tscd INNER JOIN
                                      t_item_uom tiu WITH (NOLOCK) ON tscd.attribute_value = tiu.uom_prompt
                      WHERE   tscd.stored_attribute_id = pl.stored_attribute_id AND tiu.item_number = pl.item_number and tiu.status='ACTIVE' AND 
                                      tiu.wh_id = pl.wh_id), 1)) +
                    (SELECT   '(' + uom_prompt + ')'
                     FROM      t_sto_attrib_collection_detail tscd INNER JOIN
                                     t_item_uom tiu WITH (NOLOCK) ON tscd.attribute_value = tiu.uom_prompt
                     WHERE   tscd.stored_attribute_id = pl.stored_attribute_id AND tiu.item_number = pl.item_number and tiu.status='ACTIVE' AND 
                                     tiu.wh_id = pl.wh_id) ELSE '--' END AS unit, pl.hu_id, ISNULL(pl.picking_flow, 9999999) AS picking_flow, 
                item.pack_flag, pl.wave_id, pl.allocated_qty / ISNULL
                    ((SELECT   tiu.conversion_factor
                      FROM      dbo.t_sto_attrib_collection_detail AS tscd INNER JOIN
                                      dbo.t_item_uom AS tiu WITH (NOLOCK) ON tscd.attribute_value = tiu.uom_prompt
                      WHERE   (tscd.stored_attribute_id = pl.stored_attribute_id) AND (tiu.item_number = pl.item_number) and tiu.status='ACTIVE' AND 
                                      (tiu.wh_id = pl.wh_id)), 1) AS pack_qty, CASE ISNULL(item.pack_flag, 'N') WHEN 'Y' THEN
                    (SELECT   uom_prompt
                     FROM      t_sto_attrib_collection_detail tscd INNER JOIN
                                     t_item_uom tiu WITH (NOLOCK) ON tscd.attribute_value = tiu.uom_prompt
                     WHERE   tscd.stored_attribute_id = pl.stored_attribute_id AND tiu.item_number = pl.item_number and tiu.status='ACTIVE' AND 
                                     tiu.wh_id = pl.wh_id) ELSE '--' END AS pack_prompt, pl.wave_id AS Expr1, 
                CASE WHEN ISNULL(cus.short_name, cus.customer_name) IS NULL 
                THEN od.department ELSE ISNULL(cus.short_name, cus.customer_name) END AS short_name, ISNULL(tf.name,
                    (SELECT   description
                     FROM      dbo.t_lookup
                     WHERE   (source = 't_order') AND (lookup_type = 'TYPE') AND (locale_id = 2052) AND (text = od.order_type))) 
                AS order_type, od.department
FROM      dbo.tbl_pick_list AS pl WITH (NOLOCK) INNER JOIN
                dbo.t_order AS od WITH (NOLOCK) ON pl.wh_id = od.wh_id AND pl.order_number = od.order_number INNER JOIN
                dbo.t_item_master AS item WITH (NOLOCK) ON pl.wh_id = item.wh_id AND 
                pl.item_number = item.item_number INNER JOIN
                dbo.t_zone AS z WITH (NOLOCK) ON pl.zone = z.zone AND pl.wh_id=z.wh_id INNER JOIN
                dbo.tbl_allocation AS ta WITH (NOLOCK) ON ta.seq_id = pl.seq_id LEFT OUTER JOIN
                dbo.t_customer AS cus WITH(nolock) ON od.customer_id = cus.customer_id AND pl.wh_id = cus.wh_id LEFT OUTER JOIN
                dbo.tbl_move_type AS tf WITH(nolock) ON od.move_code = tf.code



