
CREATE FUNCTION usf_aud_config_valid ()
RETURNS int
AS 
BEGIN
    DECLARE    @target_count INT,      -- database target count
        @source_count INT;             -- source count
    DECLARE    @v_return INT           -- return variable 

    SELECT @target_count = COUNT(DISTINCT audit_db_name) 
    FROM t_aud_target_db
    WHERE target_db_scope='DATABASE'

    SELECT @source_count = COUNT(DISTINCT audit_db_name) 
    FROM t_aud_target_db
    WHERE target_db_scope='SCHEMA'

    IF ((@target_count = 0 AND @source_count = 0) OR (@source_count > 1) OR (@target_count > 1)) 
    -- configuration error
        SET @v_return = 0    -- errors found
    ELSE 
        SET @v_return = 1    -- no errors found

    RETURN(@v_return)
END 




