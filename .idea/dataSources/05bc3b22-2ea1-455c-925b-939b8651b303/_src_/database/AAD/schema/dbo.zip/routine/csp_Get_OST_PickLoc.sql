



CREATE PROCEDURE [dbo].[csp_Get_OST_PickLoc] 
     @wh_id NVARCHAR(10) 
    ,@pick_id bigint
	,@item_number NVARCHAR(30) 
	,@location_id nvarchar(30) OUTPUT
	,@hu_id nvarchar(30) OUTPUT
	,@lot_number nvarchar(30) OUTPUT
	,@stored_attribute_id bigint OUTPUT
	,@qty FLOAT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from    
	SET NOCOUNT ON;	

	DECLARE @alloc_qty float
	DECLARE @int_err_num NVARCHAR(30)
	DECLARE @nvch_log_msg NVARCHAR(30)  

	SELECT @stored_attribute_id = stored_attribute_id
	FROM t_pick_detail 
	WHERE pick_id = @pick_id
	and wh_id = @wh_id
	
	SELECT top 1 @location_id = sto.location_id
			,@hu_id = sto.hu_id
			,@lot_number = sto.lot_number
	FROM t_stored_item sto
		inner join t_location loc on sto.wh_id = loc.wh_id and sto.location_id = loc.location_id
		inner join t_zone_loca loca on loca.wh_id=sto.wh_id and  sto.location_id = loca.location_id--------------------will  add  20160804
		inner join t_zone zon on zon.wh_id=loca.wh_id and zon.zone=loca.zone--------------------will  add  20160804
	WHERE sto.wh_id = @wh_id
	AND sto.item_number = @item_number
	AND isnull(sto.stored_attribute_id,'0') = isnull(@stored_attribute_id,'0') 
	AND sto.type ='0'
	AND sto.status ='A'
	AND loc.type IN ('P','L','H','C','B','Z')
	AND damage_flag ='N'---------------will  add 20160804
	AND zon.zone_type='N'---------------will  add 20160804
	and not exists (select 1 from tbl_allocation allo 
					where allo.wh_id = sto.wh_id 
					and allo.location_id = sto.location_id
					and allo.status <>'C')
	and (isnull(sto.hu_id,'') = '' 
		or (isnull(sto.hu_id,'') <> '' 
			and exists (select 1 from t_hu_master hum
						 where hum.wh_id = sto.wh_id and hum.hu_id = sto.hu_id
						and hum.type ='IV')))
	order by lot_number, (case when loc.type in ('H','P','L') then 0 when loc.type ='C' then 1 else 2 end ) 


	RETURN	
END





