

CREATE PROCEDURE usp_advpublish_msg
    @in_vchMessageName   NVARCHAR(100),
    @in_vchSolutionName  NVARCHAR(40),
    @in_vchMessageData   NVARCHAR(4000), 
    @in_vchChannelId     NVARCHAR(40) = NULL 

AS

  --declare variables
  DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nItemRowCount            INT,
    @v_nReturn                  INT,
    @v_nTranCount               INT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @e_InsPKDFailed             INT,
    @e_UOMSqlError              INT,           
       
    -- Local Variables
    @vMsgBusID                  NVARCHAR(40),
    @vMsgDefMasterID            NVARCHAR(40),
    @vMsgDefDetailID            NVARCHAR(40),
    @vChannelId                 NVARCHAR(40),
    @vPubAppId                  NVARCHAR(40),
    @vPubServerId               NVARCHAR(40),
    @dtActivated                DATETIME,
    @nPriority                  INT,
    @vMessage                   NVARCHAR(4000);
     
	
    SET NOCOUNT ON	    
    
    
    -- Set Constants
    SET @c_nModuleNumber = 63     
    SET @c_nFileNumber = 9        -- This # must be unique per object.
    
    -- Log/Local Error Constants
	SET @v_nReturn = 0
    SET @e_GenSqlError  = 1
    SET @e_SprocError   = 2
    SET @e_InsPKDFailed = 3
    SET @e_UOMSqlError  = 4

    SET @vMsgBusID = NEWID()
    
    SET @vChannelId = @in_vchChannelId
    IF @vChannelId IS NULL
    BEGIN
        SET @vChannelId = NEWID()
    END
    
    SET @dtActivated = GETDATE()

    --@in_vchMessageData
    SET @vMessage = '<?xml version="1.0"?><list locale="1033"><record>'+@in_vchMessageData+'</record></list>'

    SELECT @vPubAppId       = app.application_id,
           @vMsgDefMasterID = mdm.msg_def_master_id,
           @vMsgDefDetailID = mdd.msg_def_detail_id,
           @vPubServerId    = slt.server_id,
           @nPriority = 50,
           @dtActivated = GETDATE()     
      FROM [ADV].dbo.t_application    app 
           INNER JOIN [ADV].dbo.t_msg_def_master mdm 
		   ON app.application_id     = mdm.application_id  
           INNER JOIN [ADV].dbo.t_msg_def_detail mdd 
                   ON mdm.msg_def_master_id  = mdd.msg_def_master_id  
           INNER JOIN [ADV].dbo.t_solution       slt 
                   ON app.application_id  = slt.application_id  
           INNER JOIN [ADV].dbo.t_server         srv 
                   ON srv.server_id = slt.server_id 
     WHERE srv.msg_mgr_startup = 'Y'    
       AND RTRIM(UPPER(slt.name)) = RTRIM(UPPER(@in_vchSolutionName))  
       AND RTRIM(UPPER(mdm.name)) = RTRIM(UPPER(@in_vchMessageName))


    INSERT INTO [ADV].dbo.t_msg_bus
           (msg_bus_id,
            msg_def_detail_id,
            pub_application_id,
            pub_server_id,
            date_activated,
            priority,
            channel_id,
            message)
       VALUES
           (@vMsgBusID,
            @vMsgDefDetailID,
            @vPubAppId,
            @vPubServerId,
            @dtActivated,
            @nPriority,
            @vChannelId,
            @vMessage)
    

    GoTo ExitLabel

ErrorHandler:
    -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    
	
	-- Return the Error Message to the caller through the output parameter
	--SET @out_vchMessage = @v_vchErrorMsg
	SET @v_nReturn = @v_nLogErrorNum
	
	-- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE 
	-- IT GETS ROLLED BACK HERE BECAUSE OF THE ERROR
	IF @v_nTranCount = 0 
		ROLLBACK TRANSACTION

ExitLabel:
    RETURN @v_nReturn

