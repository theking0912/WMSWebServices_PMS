 CREATE PROCEDURE csp_exp_updatedate
 AS--
 /*
 
 UPDATE dbo.tbl_inf_exp_inoutbound
 SET  BUDAT=n.BUDAT,
      BLDAT=n.BLDAT
 FROM  tbl_inf_exp_inoutbound m,
 (SELECT   a.id AS DATA_DETAILID
			  
			  ,REPLACE(CONVERT(VARCHAR(10),a.inf_date,120),'-','') AS BUDAT   --记账日期
			  ,REPLACE(CONVERT(VARCHAR(10),ISNULL(b.shipped_date,a.inf_date),120),'-','') AS BLDAT   --凭证日期
			   
	   FROM tbl_inf_exp_so_detail a with(NOLOCK),
	        tbl_inf_exp_so_master b with(NOLOCK)
	 where  a.order_number=b.order_number) n
	WHERE m.DATA_DETAILID=n.DATA_DETAILID  AND m.ZFLAG='O'
	*/       