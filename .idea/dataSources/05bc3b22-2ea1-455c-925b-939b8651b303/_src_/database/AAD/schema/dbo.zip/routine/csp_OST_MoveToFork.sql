



CREATE PROCEDURE [dbo].[csp_OST_MoveToFork] 
     @wh_id			NVARCHAR(10) 
	,@order_number  NVARCHAR(30)
    ,@pick_id		bigint
	,@item_number	NVARCHAR(30) 
	,@location_id	nvarchar(30) 
	,@hu_id			nvarchar(30) 
	,@lot_number	nvarchar(30) 
	,@stored_attribute_id bigint 
	,@qty			FLOAT 
	,@fork_loc		nvarchar(30)
	,@user_id		nvarchar(30)
	,@passornot		int OUTPUT
	,@msg			nvarchar(200) OUTPUT
AS
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
	BEGIN TRANSACTION
		DECLARE @dest_client nvarchar(30)
		DECLARE @dest_item nvarchar(30)
		DECLARE @dest_disp_item nvarchar(30)

		SELECT @dest_client = department
		FROM t_order 
		WHERE wh_id = @wh_id
		and order_number = @order_number

		SELECT @dest_disp_item = display_item_number
		FROM t_item_master
		WHERE wh_id = @wh_id
		and item_number = @item_number

		SELECT @dest_item = item_number
		FROM t_item_master
		WHERE wh_id = @wh_id
		and display_item_number = @dest_disp_item
		and client_code = @dest_client

		--create target stock
		UPDATE t_stored_item
		SET actual_qty =  actual_qty + @qty
		WHERE wh_id = @wh_id
		and item_number = @dest_item
		and location_id = @fork_loc
		and isnull(hu_id,'') = ''
		and isnull(lot_number,'') = isnull(@lot_number,'')
		and isnull(stored_attribute_id,'0') = isnull(@stored_attribute_id,'0')
		IF @@ROWCOUNT = 0
		BEGIN
			INSERT INTO dbo.t_stored_item 
			(sequence, item_number, actual_qty, unavailable_qty, 
			status, wh_id, location_id, fifo_date, expiration_date, 
			reserved_for, lot_number, inspection_code, serial_number,
			 type, put_away_location, stored_attribute_id, hu_id, shipment_number, ciq_number, damage_flag)
			SELECT sequence, @dest_item, @qty, 0,
			 status, wh_id, @fork_loc, fifo_date, expiration_date,
			  reserved_for, lot_number, inspection_code, serial_number, 
			  @pick_id, put_away_location, stored_attribute_id, NULL, shipment_number, ciq_number, damage_flag
			FROM t_stored_item
			WHERE wh_id = @wh_id
			and item_number = @item_number
			and location_id = @location_id
			and isnull(hu_id,'') = isnull(@hu_id,'')
			and isnull(lot_number,'') = isnull(@lot_number,'')
			and isnull(stored_attribute_id,'0') = isnull(@stored_attribute_id,'0')
		END

		--remove the source stock
		UPDATE t_stored_item
		SET actual_qty =  actual_qty - @qty
		WHERE wh_id = @wh_id
		and item_number = @item_number
		and location_id = @location_id
		and isnull(hu_id,'') = isnull(@hu_id,'')
		and isnull(lot_number,'') = isnull(@lot_number,'')
		and isnull(stored_attribute_id,'0') = isnull(@stored_attribute_id,'0')

		delete from t_stored_item
		WHERE wh_id = @wh_id
		and item_number = @item_number
		and location_id = @location_id
		and isnull(hu_id,'') = isnull(@hu_id,'')
		and isnull(lot_number,'') = isnull(@lot_number,'')
		and actual_qty = 0
		and isnull(stored_attribute_id,'0') = isnull(@stored_attribute_id,'0')

		delete from t_hu_master
		WHERE wh_id = @wh_id
		AND hu_id = @hu_id
		AND NOT EXISTS (SELECT 1 FROM t_stored_item sto
						where sto.wh_id = t_hu_master.wh_id
						and sto.hu_id = t_hu_master.hu_id)

		--update order status
		UPDATE t_pick_detail
		SET picked_quantity = picked_quantity + @qty
		WHERE pick_id = @pick_id

		UPDATE t_pick_detail
		SET status = 'PICKED'
		WHERE pick_id = @pick_id
		AND picked_quantity = planned_quantity

		UPDATE t_order
		SET status = 'PICKED'
		WHERE wh_id = @wh_id
		AND order_number = @order_number
		AND NOT EXISTS ( SELECT 1  FROM t_pick_detail pkd
						 WHERE pkd.wh_id = t_order.wh_id
						 and pkd.order_number = t_order.order_number
						 and pkd.planned_quantity > picked_quantity)

		--Create tran log
		--Insert t_tran_log_holding
		INSERT INTO t_tran_log_holding
			([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
			,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
			,wh_id_2,location_id_2,hu_id_2
			,generic_attribute_1,
			generic_attribute_2,
			generic_attribute_3,
			generic_attribute_4,
			generic_attribute_5,
			generic_attribute_6,
			generic_attribute_7,
			generic_attribute_8,
			generic_attribute_9,
			generic_attribute_10,
			generic_attribute_11)
		VALUES
			('103','Ownership Transfer (pick)',getdate(),getdate(),getdate(),getdate(),@user_id,@order_number,@pick_id
			,@wh_id,@location_id,@hu_id,@item_number,@lot_number,@qty
			,@wh_id,@fork_loc,null
			,(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_1),    
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_2), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_3), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_4), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_5), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_6), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_7), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_8), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_9), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_10), 
    		(SELECT a.attribute_value 
    		FROM t_sto_attrib_collection_detail a,
				t_attribute_legacy_map alm
    		WHERE a.stored_attribute_id = @stored_attribute_id
    		AND a.attribute_id = alm.generic_attribute_11)
			)

		

		
			
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    



