-- =============================================
-- Author           :Tony.Chen
-- Create date      :Nov 18, 2013
-- Description      :Update Serialno Info during wms operation
-- Modification     :
-- =============================================
CREATE PROCEDURE [dbo].[csp_Update_Serialno]
    -- Add the parameters for the stored procedure here
    @wh_id					nvarchar(10),
    @control_number			nvarchar(30),
    @serial_no				nvarchar(30),
    @item_number			nvarchar(30),
    @lot_number				nvarchar(30),
	@stored_attribute_id	nvarchar(30),
    @expiration_date		DATETIME,
    @location_id			nvarchar(30),
    @hu_id					nvarchar(30),
    @scan_type				nvarchar(30),
	@tran_type				nvarchar(30),
    @passornot				int output  ,--0 pass|1 fail
    @msg					nvarchar(200) output

AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION

        DECLARE @po_number			nvarchar(30)
		DECLARE @client_code		nvarchar(30)
		DECLARE @sn_control_sign	nvarchar(10)
		DECLARE @order_number		nvarchar(30)
			
		--Get client code 
		SELECT @client_code = client_code
			   ,@sn_control_sign = serialized
		FROM t_item_master
		WHERE wh_id = @wh_id
		and item_number = @item_number

        --1. If @scan_type = 'INBOUND', then insert the serial no information.
        IF @scan_type = 'RCPT'
        BEGIN
			--Get PO information
			IF @tran_type = '125' OR @tran_type = '126'
				BEGIN
					 SET @po_number = @control_number
				END
			ELSE
				BEGIN
					SELECT TOP 1 @po_number = po_number
					FROM dbo.t_rcpt_ship_po_detail
					WHERE wh_id = @wh_id
					AND shipment_number = @control_number
					AND item_number = @item_number
					AND expected_qty > (
									SELECT COUNT(1)
										FROM dbo.tbl_sn_master sn
										WHERE sn.wh_id = t_rcpt_ship_po_detail.wh_id
										AND sn.po_number = t_rcpt_ship_po_detail.po_number
										AND sn.item_number = t_rcpt_ship_po_detail.item_number)
					ORDER BY po_number

					IF @@ROWCOUNT = 0
						BEGIN
							SELECT TOP 1 @po_number = po_number
							FROM dbo.t_rcpt_ship_po_detail
							WHERE wh_id = @wh_id
							AND shipment_number = @control_number
							AND item_number = @item_number
							ORDER BY po_number
						END

					IF isnull(@po_number,'') = ''
						BEGIN
							SET @po_number = @control_number
						END
				END

            INSERT INTO dbo.tbl_sn_master(
				[wh_id]
				,[serial_number]
				,[item_number]
				,[lot_number]
				,[stored_attribute_id]
				,[expiration_date]
				,[hu_id]
				,[location_id]
				,[receipt_date]
				,[po_number]
				,[status]
            )
            VALUES(
                 @wh_id
				,@serial_no
                ,@item_number
                ,@lot_number
                ,@stored_attribute_id
				,@expiration_date
				,@hu_id
				,@location_id
				,getdate()
				,@po_number
				,'RCPT'
                )

			-- Insert interface table
			INSERT INTO tbl_inf_exp_receipt_sn
				(inbound_order_number
				,wh_id
				,serial_number
				,item_number
				,client_code
				,comment
				,process_status
				,lot_number
				)
			VALUES
				(@po_number
				,@wh_id
				,@serial_no
				,@item_number
				,@client_code
				,''
				,'Ready'
				,@lot_number
				)
				
        END

        --2. update the serial no information for putaway
        IF @scan_type = 'PUT'
        BEGIN
            UPDATE dbo.tbl_sn_master
            SET hu_id = @hu_id
                ,last_scan_time = Getdate()
				,location_id = @location_id
				,status =@scan_type
            WHERE wh_id = @wh_id
            And item_number = @item_number
            And serial_number = @serial_no
        END

		 --2. update the serial no information for pick,pack
        IF @scan_type = 'PICK' or (@scan_type = 'PACK' and (@sn_control_sign = 'F' OR @sn_control_sign = 'T'))
        BEGIN
			IF @scan_type = 'PICK'
				BEGIN
					SELECT top 1 @order_number = order_number
					FROM (SELECT order_number, sum(actual_qty) as qty
							FROM t_stored_item sto
								 inner join t_pick_detail pkd on sto.type = pkd.pick_id
							WHERE sto.wh_id = @wh_id
							and sto.item_number = @item_number
							and sto.hu_id = @hu_id
							group by order_number
						  ) sto
					WHERE sto.qty > (select count(1) from dbo.tbl_sn_master
										WHERE wh_id = @wh_id
										And item_number = @item_number
										and order_number = sto.order_number)
					ORDER BY order_number;
				END
			ELSE
				BEGIN
					SET @order_number = @control_number
				END

            UPDATE dbo.tbl_sn_master
            SET hu_id = @hu_id
                ,last_scan_time = Getdate()
				,location_id = @location_id
				,status =@scan_type
				,order_number = @order_number
            WHERE wh_id = @wh_id
            And item_number = @item_number
            And serial_number = @serial_no
        END
		--catch the sn for outbound trace
		IF (@scan_type = 'PACK' and @sn_control_sign = 'O')
			BEGIN
				 INSERT INTO dbo.tbl_sn_master(
					[wh_id]
					,[serial_number]
					,[item_number]
					,[lot_number]
					,[stored_attribute_id]
					,[hu_id]
					,[location_id]
					,[receipt_date]
					,last_scan_time
					,[order_number]
					,[status]
					)
				VALUES(
					 @wh_id
					,@serial_no
					,@item_number
					,@lot_number
					,@stored_attribute_id
					,@hu_id
					,@location_id
					,getdate()
					,getdate()
					,@control_number
					,'PACK'
					)
			END

        COMMIT TRANSACTION
        SET NOCOUNT OFF
        SET @msg = 'Success'
        SET @passornot=0
        RETURN
    END TRY

    BEGIN CATCH
        ROLLBACK
        SET NOCOUNT OFF
        SET @msg = ERROR_MESSAGE()
        SET @passornot=1
        RETURN
    END CATCH

END

