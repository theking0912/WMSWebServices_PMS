-- =======================================
-- Author: CNSS Shawn Chou
-- Create Date: Dec09, 2013
-- Description: Get Next Virtual PO
-- =======================================

CREATE  FUNCTION [dbo].[fn_Get_Next_Virtual_PO] 
(@wh_id NVARCHAR(10)
)  
RETURNS NVARCHAR(30) 
AS   
BEGIN 
    DECLARE @passornot int,
			@outmsg nvarchar(200),
			@seq_id	   nvarchar(10),
			@wh_code   nvarchar(10),
			@current_date nvarchar(10)


	SELECT @current_date = CONVERT(NVARCHAR(10), GETDATE(),120)

	SELECT @wh_code = code from t_whse where wh_id = @wh_id
    
	EXEC csp_Get_AutoSeqNo_ByWH @wh_id,'VirtualPOSeqNo',@current_date,@seq_id output, @passornot output, @outmsg output

	SET @seq_id = @wh_code + RIGHT(@current_date,6) + RIGHT('0000' + @seq_id,4)

    RETURN @seq_id
END
