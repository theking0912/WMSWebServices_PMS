
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Special_Assign]
	-- Add the parameters for the stored procedure here
	@in_order_number		AS	NVARCHAR(30)
	,@in_item_number		AS	NVARCHAR(30)
	,@in_wh_id				AS	NVARCHAR(10)
	,@in_location_id		AS	NVARCHAR(50)
	,@in_hu_id				AS	NVARCHAR(30)
	,@in_qty				AS	FLOAT
	,@in_item_line_number	AS  NVARCHAR(5)
	,@user_id				AS	NVARCHAR(20)
	,@passornot				nvarchar(1) OUTPUT
	,@msg					nvarchar(200) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @i_cnt                      AS  INT
	DECLARE @lot_number					AS	Nvarchar(30)
	DECLARE @stored_attribute_id		AS	Nvarchar(30)
	DECLARE @expiration_date			AS	DATETIME
	DECLARE @damage_flag				AS	NVARCHAR(1)
	DECLARE @pick_id					AS	INT 
	DECLARE @remove_qty					AS	FLOAT
	DECLARE @put_hu_id					AS NVARCHAR(30)
	DECLARE @wave_id					AS	NVARCHAR(30)
	DECLARE	@out_vchCode uddt_output_code,
			@out_vchMsg uddt_output_msg

    SET @remove_qty = @in_qty * -1
	SET @put_hu_id = @in_location_id + '-' + @in_order_number
	
	BEGIN TRY
	SELECT TOP 1 
		@expiration_date = expiration_date
		,@lot_number = lot_number
		,@stored_attribute_id = stored_attribute_id
		,@damage_flag = damage_flag
	 FROM dbo.t_stored_item
	WHERE wh_id = @in_wh_id
	AND location_id = @in_location_id
	AND hu_id = @in_hu_id
	AND item_number = @in_item_number
	AND actual_qty >= @in_qty
	AND actual_qty > 0 
	AND type = 0

	IF @@ROWCOUNT = 0
	BEGIN
		SET @msg = '未分配的播种数量不够'
		SET @passornot = 1
		RETURN
	END

	
	BEGIN TRANSACTION


	SELECT @pick_id = pick_id FROM dbo.t_pick_detail
	where wh_id = @in_wh_id
		AND order_number = @in_order_number
		AND item_number = @in_item_number
		AND line_number = @in_item_line_number
		AND type = 'PP'

	IF ISNULL(@pick_id,'') = ''
	BEGIN
		select TOP 1 @wave_id = wave_id from t_afo_wave_detail WITH(NOLOCK) WHERE order_number = @in_order_number

		EXEC csp_Create_Pick_Dtl 
			@in_order_number,@in_item_line_number,NULL,NULL,'LOADED'
			,@in_item_number,0,@in_qty,@in_qty,@in_qty,@in_qty,@in_location_id,@in_wh_id,'PP',
			@wave_id,
			@pick_id OUTPUT

			INSERT INTO tbl_allocation 
			(
			      [wave_id]
      	         ,[order_number]
                 ,[pick_id]
                 ,[item_number]
                 ,[lot_number]
                 ,[stored_attribute_id]
                 ,[location_id]
                 ,[hu_id]
                 ,[allocated_qty]
                 ,[picked_qty]
                 ,[expected_qty]
                 ,[status]
                 ,[released_date]
                 ,[ref_number]
                 ,[pick_wall_loc]
                 ,[pick_wall_slot]
                 ,[pick_conveyor_node]
                 ,[zone]
                 ,[wh_id]
                 ,[user_assign]
                 ,[line_number]
                 ,[shipping_label]
                 ,[picking_flow]
                 ,[allo_type]
                 ,[damage_flag]
                 ,[expiration_date]
			 )
					VALUES( @wave_id
						  ,@in_order_number
						  ,@pick_id
						  ,@in_item_number
						  ,@lot_number
						  ,@stored_attribute_id
						  ,@in_location_id
						  ,@put_hu_id
						  ,@in_qty
						  ,@in_qty
						  ,0
						  ,'C'
						  ,GETDATE()
						  ,NULL
						  ,NULL
						  ,NULL
						  ,NULL
						  ,NULL
						  ,@in_wh_id
						  ,NULL
						  ,@in_item_line_number
						  ,NULL
						  ,NULL
						  ,NULL
						  ,@damage_flag
						  ,@expiration_date)


           -- add by bruce 2016-03-24 begin  订单明细全部生成了t_pick_detail,更新状态

		   SELECT @i_cnt = COUNT(1)
		     FROM t_order_detail
			WHERE order_number = @in_order_number
			  AND wh_id = @in_wh_id
			  AND line_number not in
				 (
				  select line_number
				 	from t_pick_detail
			       where wh_id = @in_wh_id
				 	 and order_number = @in_order_number
				 )

           IF (@i_cnt = 0 )
		   BEGIN
				UPDATE t_order
					SET status = 'LOADED'
					WHERE order_number = @in_order_number
					AND wh_id = @in_wh_id
			END
			-- add by bruce 2016-03-24 end

	END
	ELSE
    BEGIN
		
		UPDATE t_pick_detail 
			SET planned_quantity = planned_quantity + @in_qty
				,picked_quantity = picked_quantity + @in_qty
				,staged_quantity = staged_quantity + @in_qty
				,loaded_quantity = loaded_quantity + @in_qty
			where pick_id  = @pick_id
		
		--UPDATE t_pick_detail
		--	SET status = 'LOADED'
		--	WHERE pick_id  = @pick_id
		--	AND NOT EXISTS(SELECT 1 FROM dbo.t_pick_detail
		--							WHERE 


		UPDATE t_pick_detail
		SET status = CASE WHEN staged_quantity = planned_quantity THEN 'LOADED' ELSE status END 
		 WHERE  pick_id  = @pick_id

		 UPDATE dbo.t_order
			SET status = 'LOADED'
		WHERE order_number  = @in_order_number
			AND NOT EXISTS(SELECT 1 FROM dbo.t_pick_detail
									WHERE wh_id = @in_wh_id
									AND order_number = @in_order_number
									AND planned_quantity <> loaded_quantity
									AND type = 'PP')
			AND wh_id = @in_wh_id

		UPDATE tbl_allocation
			SET allocated_qty = allocated_qty + @in_qty
				,picked_qty = picked_qty + @in_qty
			WHERE pick_id = @pick_id
			AND	wh_id = @in_wh_id
			AND order_number = @in_order_number
			AND item_number = @in_item_number
			AND line_number = @in_item_line_number
			AND lot_number = @lot_number
			AND damage_flag = @damage_flag
		
		IF @@ROWCOUNT = 0
		BEGIN
			INSERT INTO tbl_allocation 
			([wave_id],[order_number],[pick_id],[item_number],[lot_number],[stored_attribute_id]
           ,[location_id],[hu_id],[allocated_qty],[picked_qty],[expected_qty]
           ,[status],[released_date],[ref_number],[pick_wall_loc],[pick_wall_slot],[pick_conveyor_node]
		   ,[zone],[wh_id],[user_assign],[line_number],[shipping_label],[picking_flow],[allo_type],[damage_flag]
		,[expiration_date])
					VALUES( (select TOP 1 wave_id from t_afo_wave_detail WITH(NOLOCK) 
						WHERE order_number = @in_order_number)
						  ,@in_order_number
						  ,@pick_id
						  ,@in_item_number
						  ,@lot_number
						  ,@stored_attribute_id
						  ,@in_location_id
						  ,@put_hu_id
						  ,@in_qty
						  ,@in_qty
						  ,0
						  ,'C'
						  ,GETDATE()
						  ,NULL
						  ,NULL
						  ,NULL
						  ,NULL
						  ,NULL
						  ,@in_wh_id
						  ,@user_id
						  ,@in_item_line_number
						  ,NULL
						  ,NULL
						  ,NULL
						  ,@damage_flag
						  ,@expiration_date)
		END
	END
    
	

	EXEC	[dbo].[csp_Inventory_Adjust]
					@in_vchWhID = @in_wh_id,
					@in_vchItemNumber = @in_item_number,
					@in_vchLocationID = @in_location_id,
					@in_nType = @pick_id,
					@in_vchHUID = @put_hu_id,
					@in_vchLotNumber =@lot_number,
					@in_nStoredAttributeID = @stored_attribute_id,
					@in_fQty = @in_qty,
					@in_dtFifoDate = NULL,
					@in_dtExpirationDate = @expiration_date,
					@in_vchHUType = N'SO',
					@in_vchShipmentNumber = @in_order_number,
					@in_damage_flag = @damage_flag,
					@out_vchCode = @out_vchCode OUTPUT,
					@out_vchMsg = @out_vchMsg OUTPUT

	EXEC	[dbo].[csp_Inventory_Adjust]
			@in_vchWhID = @in_wh_id,
			@in_vchItemNumber = @in_item_number,
			@in_vchLocationID = @in_location_id,
			@in_nType =0,
			@in_vchHUID = @in_hu_id,
			@in_vchLotNumber =@lot_number,
			@in_nStoredAttributeID = @stored_attribute_id,
			@in_fQty =@remove_qty,
			@in_dtFifoDate = NULL,
			@in_dtExpirationDate = @expiration_date,
			@in_vchHUType = N'IV',
			@in_vchShipmentNumber =NULL,
			@in_damage_flag = @damage_flag,
			@out_vchCode = @out_vchCode OUTPUT,
			@out_vchMsg = @out_vchMsg OUTPUT

	--Create tran log
	--Insert t_tran_log_holding
	INSERT INTO t_tran_log_holding
		([tran_type],[description],[start_tran_date],[start_tran_time],[end_tran_date],[end_tran_time],[employee_id],[control_number],[control_number_2]
		,[wh_id],[location_id],[hu_id],[item_number],[lot_number],[tran_qty]
		,wh_id_2,location_id_2,hu_id_2
		,generic_attribute_1,
		generic_attribute_2,
		generic_attribute_3,
		generic_attribute_4,
		generic_attribute_5,
		generic_attribute_6,
		generic_attribute_7,
		generic_attribute_8,
		generic_attribute_9,
		generic_attribute_10,
		generic_attribute_11)
	VALUES
		('302','Picking (put)',getdate(),getdate(),getdate(),getdate(),@user_id,@in_order_number,@pick_id
		,@in_wh_id,@in_location_id,@in_hu_id,@in_item_number,@lot_number,@in_qty
		,@in_wh_id,@in_location_id,@put_hu_id
		,(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_1),    
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_2), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_3), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_4), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_5), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_6), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_7), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_8), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_9), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_10), 
    	(SELECT a.attribute_value 
    	FROM t_sto_attrib_collection_detail a,
			t_attribute_legacy_map alm
    	WHERE a.stored_attribute_id = @stored_attribute_id
    	AND a.attribute_id = alm.generic_attribute_11)
		)



		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
	END CATCH
END

