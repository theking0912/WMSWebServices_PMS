
CREATE PROCEDURE usp_afa_release_wave
@in_vchWarehouseId     NVARCHAR(20),    
@in_vchWaveId          NVARCHAR(60),
@in_vchPriority        NVARCHAR(10),
@in_nWorkersRequired   INTEGER,
@in_dtEarliestShipDate DATETIME,
@in_dtLatestShipDate   DATETIME,
@in_OverrideWorkType   NVARCHAR(2),
@out_vchMessage        NVARCHAR(500) OUTPUT -- Contians "SUCCESS" or the message to be displayed.

AS

DECLARE 
    @v_nErrorNumber       INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(500),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,

    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,
    @v_nReturn            INTEGER,
    @v_vchErrorMsg        NVARCHAR(500),
    @v_nSysErrorNum       INTEGER,

    @e_GenSqlError   	  INTEGER,
    @e_InvalidWorkType    INTEGER,
    @e_UpdLDMFailed       INTEGER,
    @e_InsWKQFailed       INTEGER,
    @e_UpdWKQFailed       INTEGER,
    @e_SprocError         INTEGER,
    @e_MissingUomData     INTEGER,

    @c_chReleaseStatus    CHAR(1),
    @c_chUnassigned       CHAR(1),
    @v_nLoopCount         INTEGER,
    @v_vchWhId            NVARCHAR(20),
    @v_vchNextWhId        NVARCHAR(20),

    @v_nContAdvFlag       INTEGER,
    @v_nTranCount         INTEGER,
    @v_vchDescription     NVARCHAR(100),
    @v_dtTimeDue          DATETIME,
    @v_dtDateDue          DATETIME,
    @v_vchWorkqId         NVARCHAR(60),
    @v_PKDStagingLoc      NVARCHAR(20),
    @v_vchStageLoc        NVARCHAR(50),
    @v_vchDoorLoc         NVARCHAR(50),
    @vchOrderNum          NVARCHAR(60), 
    @vchWHID              NVARCHAR(20),
    @v_nValue             INTEGER,
    @v_vchOutMsg          NVARCHAR(500),
    @v_nLogErrorNum       INTEGER,
    @v_vchStartTran       INTEGER

    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @c_chReleaseStatus = 'R'
    SET @c_chUnassigned = 'U'

    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 7
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_UpdLDMFailed = 2
    SET @e_InvalidWorkType = 3
    SET @e_InsWKQFailed = 4
    SET @e_UpdWKQFailed = 5
    SET @e_SprocError = 6
    SET @e_MissingUomData = 7
    SET @v_vchStartTran = 0

    	EXECUTE usp_afo_release_wave 
    		@in_vchWarehouseId,    
		@in_vchWaveId,
		@in_vchPriority,
		@in_nWorkersRequired,
		@in_dtEarliestShipDate,
		@in_dtLatestShipDate,
		@v_vchErrorMsg OUTPUT
	
    	SELECT @v_nSysErrorNum = @@ERROR
    	IF @v_nSysErrorNum <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            	+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        	SET @v_nLogErrorNum = @e_GenSqlError
        	GOTO ErrorHandler
    	END
    	
    	IF @in_OverrideWorkType IS NOT NULL AND @in_OverrideWorkType <> '00'
    	BEGIN
    		EXECUTE usp_release_override_wk_type
			@in_OrderNumber =NULL,
			@in_LoadNumber = NULL, 
			@in_WaveNumber = @in_vchWaveId,
            @in_ItemNumber = NULL,
			@in_LotNumber = NULL,			
			@in_PickArea	= NULL,   
			@in_vchType = NULL, 
			@in_WHID = @in_vchWarehouseId,
			@in_OverrideWorkType = @in_OverrideWorkType,
			@in_nResultsFlag = 0
		
		SELECT @v_nSysErrorNum = @@ERROR
    		IF @v_nSysErrorNum <> 0
    		BEGIN
        		SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            		+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        		SET @v_nLogErrorNum = @e_GenSqlError
        		GOTO ErrorHandler
    		END
    	END 

--Fix Defect D-08697
    --IF AFA is Installed and profile is 4 for "Wave then Load"
    --Then update tran_plan_qty in t_order_detail
    IF (SELECT next_value
        FROM t_whse_control WITH (NOLOCK)
        WHERE wh_id = @in_vchWarehouseId
            AND control_type = 'AFA_INSTALLED') = 4 
    BEGIN
        UPDATE ord
        SET tran_plan_qty = tran_plan_qty + wdl.planned_qty
        FROM t_order_detail ord 
            INNER JOIN 
            t_afo_wave_detail wd 
                ON ord.wh_id = wd.wh_id
               AND ord.order_number = wd.order_number
            INNER JOIN
            t_afo_wave_detail_line wdl 
                ON wd.wave_detail_id = wdl.wave_detail_id
               AND wd.wh_id = wdl.wh_id
               AND ord.line_number = wdl.line_number 
        WHERE wd.wave_id = @in_vchWaveId
            AND wd.wh_id = @in_vchWarehouseId

		SELECT @v_nSysErrorNum = @@ERROR
    		IF @v_nSysErrorNum <> 0
    		BEGIN
        		SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
            		+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        		SET @v_nLogErrorNum = @e_GenSqlError
        		GOTO ErrorHandler
    		END
    END

    --Update release date
    UPDATE t_wave_master
       SET released_date = GETDATE()
     WHERE wave_id = @in_vchWaveId
       AND wh_id = @in_vchWarehouseId

    SELECT @v_nSysErrorNum = @@ERROR
        IF @v_nSysErrorNum <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
           		+ '] occured.  Check SQL Server System Log, Application Status Console, etc.'
        	SET @v_nLogErrorNum = @e_GenSqlError
        	GOTO ErrorHandler
    	END

--DONE Fix Defect D-08697

    GoTo ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        --EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(VARCHAR(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END
    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_vchStartTran = 1
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN
