-- =============================================
-- Author:		laver
-- Create date: 2014-02-14
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[csp_Close_Shipment] 
	-- Add the parameters for the stored procedure here
	@In_Nvch_Wh_ID			AS	NVARCHAR(10) ,
	@In_Nvch_Shipment_No	AS	NVARCHAR(30),
	@Out_Nvch_Result		AS	NVARCHAR(10)		OUTPUT,
	@Out_Nvch_Msg			AS	NVARCHAR(200)		OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE	@Int_Rec_Count	INT

	BEGIN TRY
	
		-- check package open of rec exists
		SELECT @Int_Rec_Count = COUNT(1) FROM tbl_rcpt_ship_package 
		WHERE status <> 'C'
		  AND shipment_number = @In_Nvch_Shipment_No
		  AND wh_id = @In_Nvch_Wh_ID

		IF @Int_Rec_Count > 0
		BEGIN
			SET @Out_Nvch_Result = 'FAILED'
			SET @Out_Nvch_Msg = 'Package has not been closed.'
		END
		ELSE
		BEGIN
			UPDATE t_rcpt_ship
			   SET status = 'C'
			  WHERE shipment_number = @In_Nvch_Shipment_No
				AND wh_id = @In_Nvch_Wh_ID

			SET @Out_Nvch_Result = 'SUCCESS'
		END

		RETURN
	END TRY
	BEGIN CATCH
		SET @Out_Nvch_Msg = ERROR_MESSAGE()
		SET @Out_Nvch_Result = 'FAILED'
		RETURN
	END CATCH
END
