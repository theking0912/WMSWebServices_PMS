CREATE PROCEDURE  [dbo].[csp_Print_Shippping_Label]
    @in_WarehouseID     nvarchar(20),
    @in_OrderNumber		nvarchar(30),	
	@in_PrintStatus		nvarchar(30),	
	@in_PrintUser		nvarchar(30),
	@out_Result         nvarchar(10) output,
	@out_ErrMess        nvarchar(200) output
AS
 DECLARE      
        @v_nError               INT,      
        @v_nRowCount            INT,
		@client					nvarchar(30)

		begin try
			
			select @client = client_code
			from t_order
			where wh_id = @in_WarehouseID
			and order_number = @in_OrderNumber

			update tbl_shipping_label
			set print_sign = 'Y'
			where wh_id = @in_WarehouseID
			and order_number = @in_OrderNumber
			and print_sign like @in_PrintStatus
			
			insert into tbl_print_scheduler (print_type,print_station,wh_id,print_data,print_date,print_user)
			select 'ShippingLabel', @client,@in_WarehouseID,ship_label_barcode + '|' + carrier + '|' + '1',getdate(),@in_PrintUser
			from tbl_shipping_label
			where wh_id = @in_WarehouseID
			and order_number = @in_OrderNumber
			and print_sign like @in_PrintStatus

			SET @out_Result = 'pass'
			SET @out_ErrMess = 'Success'
		end try
		begin catch
			SET @out_ErrMess = ERROR_MESSAGE()
			SET @out_Result = 'fail'
		end catch
RETURN
