-- =======================================
-- Author: CNSS Shawn Chou
-- Create Date: Dec10, 2013
-- Description: Get Next PO Detail Line Number&Schedule Number
-- =======================================

CREATE  FUNCTION [dbo].[fn_Get_Next_Line_Number] 
(
	@in_wh_id     NVARCHAR(10),
	@in_po_number NVARCHAR(30)
)  
RETURNS NVARCHAR(5) 
AS   
BEGIN 
    DECLARE @Result    NVARCHAR(5)
    
	SET @Result = (select ISNULL(MAX(cast(line_number as int)),0) + 1 as line_max from t_po_detail where wh_id = @in_wh_id and po_number = @in_po_number)

    RETURN @Result
END
