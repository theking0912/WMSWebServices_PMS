-- Batch submitted through debugger:


-- Procedure
-- =======================================    
-- Author: Jerry
-- Create Date: 2015-05-23   
-- Description: Return    
--  
    
-- =======================================    
    
create PROCEDURE [dbo].[csp_qty_check] 
	 @qty					float
	,@passornot				nvarchar(1) output
	,@msg					nvarchar(200) output
AS    

BEGIN    
 -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    



	if cast(@qty as int)<>@qty 
	begin
	  set @msg='不能为小数'
	  goto ERRORHANDLE

	end


	SET @passornot = 0
	return
	
ERRORHANDLE:
	
    SET @msg = ISNULL(ERROR_MESSAGE(),'')+@msg
    SET @passornot = 1
    RETURN
  
END


