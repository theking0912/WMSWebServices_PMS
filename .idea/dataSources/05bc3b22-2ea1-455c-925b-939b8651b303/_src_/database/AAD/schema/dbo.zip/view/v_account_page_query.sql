

CREATE VIEW [dbo].[v_account_page_query]
AS
SELECT   ta.seq_id, ta.account_time, ta.wh_id, ta.item_number, tb.description, ta.lot_number, ta.qty * ta.conversion_factor AS qty, 
                ta.uom, tc.uom_prompt as uom_prompt, ta.conversion_factor AS uom_conversion_factor, ta.conversion_factor, ta.order_number, 
                ISNULL(td.customer_name, te.vendor_name) AS customer_name, ISNULL(td.customercode_report, te.vendor_name) 
                AS customer_sname, ISNULL(td.customer_code, te.vendor_code) AS customer_code, ISNULL
                    ((SELECT   description
                      FROM      dbo.t_lookup
                      WHERE   (source = CASE WHEN ta.type = 'IN' THEN 't_po_master' WHEN ta.type = 'OUT' THEN 't_order' WHEN ta.type
                                       = 'INV' THEN 'INV' END) AND (lookup_type = 'TYPE') AND (locale_id = '2052') AND (text = ta.order_type)), 
                N'盘点') AS order_type, ta.qty_stored
FROM      dbo.tbl_account_page AS ta INNER JOIN
                dbo.t_item_master AS tb ON ta.wh_id = tb.wh_id AND ta.item_number = tb.item_number INNER JOIN
                dbo.t_item_uom AS tc ON ta.item_number = tc.item_number AND ta.uom = tc.uom AND 
                ta.wh_id = tc.wh_id LEFT OUTER JOIN
                dbo.t_customer AS td ON ta.customer_id = CAST(td.customer_id AS NVARCHAR(100)) AND 
                ta.wh_id = td.wh_id LEFT OUTER JOIN
                dbo.t_vendor AS te ON ta.customer_id = CAST(te.vendor_code AS NVARCHAR(100))


