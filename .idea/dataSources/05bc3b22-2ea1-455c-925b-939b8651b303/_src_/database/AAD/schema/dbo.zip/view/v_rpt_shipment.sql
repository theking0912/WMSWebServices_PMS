
/*, line_number1*/
CREATE VIEW [dbo].[v_rpt_shipment]
AS
SELECT     TOP (100) PERCENT rs.wh_id, wh.name AS wh_name, rs.shipment_number, po.po_number, po.vendor_code, ISNULL(vd.vendor_name, N'') AS vendor_name, 
                      CONVERT(VARCHAR(19), po.create_date, 23) AS create_date, CONVERT(VARCHAR(19), rsp.asn_time, 23) AS asn_time, rs.trailer_number, CAST(rspd.line_number AS int)
                       AS line_number1, item.item_number,item.display_item_number, item.description, rspd.expected_qty, tiu.conversion_factor, pod.qty - dbo.csf_received_qty(rs.wh_id, rs.shipment_number, 
                      item.item_number, rspd.line_number, po.po_number) / tiu.conversion_factor AS po_qty, pod.qty AS qty_ord, CONVERT(VARCHAR(19), pod.delivery_date, 23) 
                      AS delivery_date, CONVERT(VARCHAR(19), po.create_date, 23) AS po_date, item.storage_type, 
                      pod.price / CASE WHEN price_unit = 0 THEN 1 ELSE price_unit END * (CASE WHEN (ISNULL(tax_code, 'J0') = 'J0' OR
                      tax_code = '') THEN 1 WHEN tax_code IN ('J1', 'J2') THEN 1 + tax_rate WHEN tax_code = 'J3' THEN 1 - tax_rate END) AS tax_price, pod.price_unit,
                          (SELECT     TOP (1) uom_prompt
                            FROM          dbo.t_item_uom WITH (nolock)
                            WHERE      (item_number = rspd.item_number) AND (wh_id = rspd.wh_id) and status='ACTIVE'
                            ORDER BY conversion_factor) AS uom_prompt, tl.description AS type_desc, pod.order_uom, tiu.layers_per_uom, tiu.units_per_layer, rsp.print_num, 
                      rspd.line_number, pod.storage_location, CASE WHEN po.sap_ordertype = 'TH' THEN po.vendor_code ELSE pod.factory END AS factory, 
                      CASE WHEN po.sap_ordertype = 'TH' THEN '退货客户:' + po.customer_code ELSE '' END AS back_cus
FROM         dbo.t_rcpt_ship AS rs INNER JOIN
                      dbo.t_rcpt_ship_po AS rsp ON rs.shipment_number = rsp.shipment_number AND rs.wh_id = rsp.wh_id INNER JOIN
                      dbo.t_rcpt_ship_po_detail AS rspd ON rsp.shipment_number = rspd.shipment_number AND rsp.po_number = rspd.po_number AND rsp.wh_id = rspd.wh_id INNER JOIN
                      dbo.t_po_master AS po ON rsp.po_number = po.po_number AND rsp.wh_id = po.wh_id INNER JOIN
                      dbo.t_po_detail AS pod ON po.po_number = pod.po_number AND po.wh_id = pod.wh_id AND pod.po_number = rspd.po_number AND pod.wh_id = rspd.wh_id AND 
                      pod.line_number = rspd.line_number AND pod.schedule_number = rspd.schedule_number AND pod.item_number = rspd.item_number INNER JOIN
                      dbo.t_item_master AS item WITH (NOLOCK) ON item.wh_id = rspd.wh_id AND item.item_number = rspd.item_number INNER JOIN
                      dbo.t_whse AS wh ON rs.wh_id = wh.wh_id LEFT OUTER JOIN
                      dbo.t_vendor AS vd ON po.vendor_code = vd.vendor_code LEFT OUTER JOIN
                      dbo.t_lookup AS tl ON po.type_id = tl.lookup_id LEFT OUTER JOIN
                      dbo.t_item_uom AS tiu WITH (NOLOCK) ON tiu.wh_id = pod.wh_id AND tiu.item_number = pod.item_number AND tiu.uom = pod.order_uom and tiu.status='ACTIVE'
ORDER BY rs.wh_id, rs.shipment_number, rsp.po_number

