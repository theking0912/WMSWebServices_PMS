
CREATE VIEW v_pkd_planned_qty
AS
SELECT SUM(planned_quantity) AS pkd_planned, order_number, line_number, load_id, wh_id
	FROM t_pick_detail 
	GROUP BY wh_id, order_number, load_id, line_number, item_number

