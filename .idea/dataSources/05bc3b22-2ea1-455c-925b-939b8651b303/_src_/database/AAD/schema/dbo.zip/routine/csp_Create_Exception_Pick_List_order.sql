
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE PROCEDURE [dbo].[csp_Create_Exception_Pick_List_order]
	-- Add the parameters for the stored procedure here	
	@wh_id					AS	nvarchar(10)
	,@wave_id					AS	nvarchar(10)
	,@order_number			AS	NVARCHAR(30)
	,@item_number           AS	NVARCHAR(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	DECLARE @next_value INTEGER
		,@v_vchOutMsg NVARCHAR(500)
		,@v_nErrorNumber INTEGER
		,@customer_id NVARCHAR(30)

	SET NOCOUNT ON;
		
		SET @customer_id=''

        INSERT INTO tbl_pick_list
	      ([list_number]
		  ,[seq_id]
		  ,[wave_id]
		  ,[order_number]
		  ,[pick_id]
		  ,[item_number]
		  ,[lot_number]
		  ,[stored_attribute_id]
		  ,[location_id]
		  ,[hu_id]
		  ,[allocated_qty]
		  ,[picked_qty]
		  ,[status]
		  ,[released_date]
		  ,[ref_number]
		  ,[pick_wall_loc]
		  ,[pick_wall_slot]
		  ,[pick_conveyor_node]
		  ,[zone]
		  ,[wh_id]
		  ,[user_assign]
		  ,[line_number]
		  ,[shipping_label]
		  ,[picking_flow]
		  ,[type]
		  ,[damage_flag]
	   )
	   select 
	       (select TOP 1 list_number from tbl_pick_list tpl 
				WHERE tpl.zone = ta.zone 
					and tpl.order_number = ta.order_number
					--and tpl.item_number = ta.item_number
					and tpl.type = ta.allo_type)
		  ,[seq_id]
		  ,[wave_id]
		  ,[order_number]
		  ,[pick_id]
		  ,[item_number]
		  ,[lot_number]
		  ,[stored_attribute_id]
		  ,[location_id]
		  ,[hu_id]
		  ,[allocated_qty]
		  ,[picked_qty]
		  ,[status]
		  ,[released_date]
		  ,[ref_number]
		  ,[pick_wall_loc]
		  ,[pick_wall_slot]
		  ,[pick_conveyor_node]
		  ,[zone]
		  ,[wh_id]
		  ,[user_assign]
		  ,[line_number]
		  ,(select TOP 1 shipping_label from tbl_pick_list tpl 
				WHERE tpl.zone = ta.zone 
					and tpl.order_number = ta.order_number
					and tpl.item_number = ta.item_number
					and tpl.type = ta.allo_type)
		  ,[picking_flow]
		  ,[allo_type]
		  ,[damage_flag]
	     from tbl_allocation ta with(nolock)
	    where order_number  = @order_number
		  and wh_id    = @wh_id
		  and item_number = @item_number
		  AND ta.status NOT IN ('C','E')
		  AND ta.allo_type ='O'
		  and not exists
		  (
		     select 'x'
			   from tbl_pick_list with(nolock)
			  where seq_id  = ta.seq_id
			    and wave_id = ta.wave_id
		  )  

		DELETE pl
		FROM tbl_pick_list pl
		WHERE NOT EXISTS(SELECT 1 FROM tbl_allocation al WHERE pl.wh_id = al.wh_id and pl.seq_id=al.seq_id)

END

