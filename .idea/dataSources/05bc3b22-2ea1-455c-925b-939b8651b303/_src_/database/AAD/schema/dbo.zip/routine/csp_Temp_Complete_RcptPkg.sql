CREATE  procedure [dbo].[csp_Complete_RcptPkg]
  (
	@wh_id nvarchar(10),
	@package_number nvarchar(30),
	@status nvarchar(10)
  )
  as 
    declare @Result int;    
  begin
    begin  transaction	
    if exists (select 1 from tbl_rcpt_ship_package where wh_id= @wh_id and package_number=@package_number) --查找包裹
		begin 
		    update tbl_rcpt_ship_package set status=@status where wh_id=@wh_id and package_number=@package_number 
			if @@error<>0  --更新失败 
				begin 				    
					 goto Error					
				end
			else --更新成功
				begin					    			
					goto ExitHandler														
				end  
		end 
	else    --未找到数据
		begin 	
		  goto Error   
		end

		Error:  --失败
			set @Result=0;
			rollback transaction
			return @Result;

		ExitHandler:  --成功
			set @Result=1;
				commit transaction
			return @Result;
  end
