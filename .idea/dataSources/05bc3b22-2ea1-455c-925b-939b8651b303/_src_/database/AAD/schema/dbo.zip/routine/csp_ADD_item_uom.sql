



-- =============================================
-- Author:		<Author,,Name>
-- Create date:  1/7/2016
-- Description:	Add bound SKU
-- =============================================
CREATE PROCEDURE [dbo].[csp_ADD_item_uom]
	-- Add the parameters for the stored procedure here
@user_id             NVARCHAR(10),
@page_title    NVARCHAR(30),
@item_uom_id    int,
@uom_prompt   NVARCHAR(30),
@item_number    NVARCHAR(30),
@wh_id          NVARCHAR(10),
@uom    NVARCHAR(20),
@conversion_factor      float,

@item_master_id        int,
@package_weight        float,
@units_per_layer         float,
@layers_per_uom        float,
@uom_weight        float,
@pickable        nchar(1),
@box_type         int,
@length         float,
@width         float,
@height        float,
@no_overhang_on_top        int,
@stack_code          int,
@batch        int,
@use_orientation_data        int,
@turnable        int,
@on_bottom_ok       int,
@on_side_ok        int,
@on_end_ok   int,
@bottom_only        int,
@top_only       int,
@max_in_layer       int,
@max_support_weight       float,
@stack_index         int,
@container_value        float,
@load_separately        int,
@nesting_height_increase        float,
@nested_volume      float,
@unit_volume       float,
@pattern     NVARCHAR(20),
@priority      int,
@status      NVARCHAR(10),
@default_receipt_uom      NVARCHAR(3),
@default_pick_uom     NVARCHAR(3),
@class_id    NVARCHAR(10),
@pick_put_id     NVARCHAR(15),
@conveyable     NVARCHAR(3),
@std_hand_qty      float,
@min_hand_qty      float,
@max_hand_qty       float,
@default_pick_area     NVARCHAR(10),
@pick_location    NVARCHAR(50),
@display_config      NVARCHAR(3),
@vas_profile     NVARCHAR(30),
@cartonization_flag       NVARCHAR(3),
@gtin        NVARCHAR(14),
@shippable_uom       NCHAR(1),
@units_per_grab    numeric(12,3),





@out_vchMsg             NVARCHAR(200) OUTPUT

AS
begin



	

			INSERT INTO t_item_uom
			 		
     (	
	        [item_master_id] ,[item_number] ,[wh_id],[uom] ,[conversion_factor] ,
			[package_weight] ,[units_per_layer] ,[layers_per_uom] ,[uom_weight] ,[pickable] ,[box_type] ,[length] ,[width],[height] ,
			[no_overhang_on_top] ,[stack_code] ,[batch] ,[use_orientation_data] ,[turnable] ,[on_bottom_ok] ,[on_side_ok] ,[on_end_ok] ,[bottom_only] ,
			[top_only] ,[max_support_weight] ,[stack_index] ,[container_value] ,[load_separately] ,[nesting_height_increase] ,[nested_volume] ,
			[unit_volume] ,[pattern] ,[priority] ,[status],[uom_prompt] ,[default_receipt_uom] ,[default_pick_uom] ,[class_id] ,
			[pick_put_id] ,[conveyable],[std_hand_qty] ,[min_hand_qty],[max_hand_qty] ,[default_pick_area] ,[pick_location] ,[display_config] ,
			[vas_profile] ,[cartonization_flag] ,[gtin] ,[shippable_uom] ,[units_per_grab] 
	 )
			values   
	(		@item_master_id,@item_number,@wh_id,@uom,@conversion_factor,
			@package_weight,@units_per_layer ,@layers_per_uom ,@uom_weight,@pickable ,@box_type ,@length ,@width ,@height ,
			@no_overhang_on_top ,@stack_code ,@batch ,@use_orientation_data  ,@turnable ,@on_bottom_ok,@on_side_ok ,@on_end_ok ,@bottom_only ,
			@top_only ,@max_support_weight,@stack_index,@container_value  ,@load_separately,@nesting_height_increase  ,@nested_volume    ,
			@unit_volume  ,@pattern   ,@priority      ,@status ,@uom_prompt  ,@default_receipt_uom   ,@default_pick_uom    ,@class_id   ,
			@pick_put_id ,@conveyable,@std_hand_qty,@min_hand_qty   ,@max_hand_qty     ,@default_pick_area ,@pick_location  ,@display_config   ,
			@vas_profile ,@cartonization_flag  ,@gtin,@shippable_uom,@units_per_grab    
      ) 
	   
		   INSERT INTO tbl_web_tran_log
		(
		   type_id,object_id,tran_date,employee_id,remark1,remark2
		)
		VALUES
		(
		'1','2',getdate(),@user_id ,'',''
		)


			 INSERT INTO tbl_tran_item_uom
		
     (	
	        tran_log_id,is_new,[item_uom_id] ,[item_master_id] ,[item_number] ,[wh_id],[uom] ,[conversion_factor] ,
			[package_weight] ,[units_per_layer] ,[layers_per_uom] ,[uom_weight] ,[pickable] ,[box_type] ,[length] ,[width],[height] ,
			[no_overhang_on_top] ,[stack_code] ,[batch] ,[use_orientation_data] ,[turnable] ,[on_bottom_ok] ,[on_side_ok] ,[on_end_ok] ,[bottom_only] ,
			[top_only] ,[max_support_weight] ,[stack_index] ,[container_value] ,[load_separately] ,[nesting_height_increase] ,[nested_volume] ,
			[unit_volume] ,[pattern] ,[priority] ,[status],[uom_prompt] ,[default_receipt_uom] ,[default_pick_uom] ,[class_id] ,
			[pick_put_id] ,[conveyable],[std_hand_qty] ,[min_hand_qty],[max_hand_qty] ,[default_pick_area] ,[pick_location] ,[display_config] ,
			[vas_profile] ,[cartonization_flag] ,[gtin] ,[shippable_uom] ,[units_per_grab] 
	 )
	select
           (select top 1 tran_log_id from tbl_web_tran_log order by tran_log_id desc), 'Y',
			[item_uom_id] ,[item_master_id] ,[item_number] ,[wh_id],[uom] ,[conversion_factor] ,
			[package_weight] ,[units_per_layer] ,[layers_per_uom] ,[uom_weight] ,[pickable] ,[box_type] ,[length] ,[width],[height] ,
			[no_overhang_on_top] ,[stack_code] ,[batch] ,[use_orientation_data] ,[turnable] ,[on_bottom_ok] ,[on_side_ok] ,[on_end_ok] ,[bottom_only] ,
			[top_only] ,[max_support_weight] ,[stack_index] ,[container_value] ,[load_separately] ,[nesting_height_increase] ,[nested_volume] ,
			[unit_volume] ,[pattern] ,[priority] ,[status],[uom_prompt] ,[default_receipt_uom] ,[default_pick_uom] ,[class_id] ,
			[pick_put_id] ,[conveyable],[std_hand_qty] ,[min_hand_qty],[max_hand_qty] ,[default_pick_area] ,[pick_location] ,[display_config] ,
			[vas_profile] ,[cartonization_flag] ,[gtin] ,[shippable_uom] ,[units_per_grab] 
			from t_item_uom  where wh_id=@wh_id and item_number=@item_number  and item_uom_id=(select top 1 item_uom_id from t_item_uom order by item_uom_id desc)


           
if @@ROWCOUNT=0
  set @out_vchMsg='failed'
  else 
set @out_vchMsg='success'
return	
end


