
CREATE VIEW v_type AS
SELECT lookup_id as type_id, locale_id, source, sequence, text as type, description, lookup_type
    FROM t_lookup
    WHERE lookup_type = 'TYPE'
