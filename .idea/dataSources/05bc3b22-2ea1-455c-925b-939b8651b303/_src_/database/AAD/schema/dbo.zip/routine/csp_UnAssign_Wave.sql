





-- =======================================    
 
--      
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_UnAssign_Wave]    
     @in_wh_id					NVARCHAR(10)  
    ,@in_wave_id				NVARCHAR(30)  	
	,@passornot				NVARCHAR(1)		OUTPUT
	,@msg					NVARCHAR(200)	OUTPUT
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY  
		 
		
			IF EXISTS(SELECT 1 FROM tbl_allocation
							WHERE wave_id = @in_wave_id
								AND wh_id = @in_wh_id
								AND (picked_qty > 0 
										OR ISNULL(pick_wall_slot,'') <> '')
					)
				OR EXISTS(SELECT 1 FROM t_pick_detail 
							WHERE wave_id = @in_wave_id
								AND wh_id = @in_wh_id
								AND type='PO' 
								AND (status<>'RELEASED' OR (status='RELEASED' and isnull(user_assigned,'')<>'')))
				---ADD WILL 20160621 START----------------------
				OR EXISTS(SELECT 1 FROM t_pick_detail 
							WHERE wave_id = @in_wave_id
								AND wh_id = @in_wh_id
								AND type='PP' 
								AND status='LOADED'
								AND EXISTS(SELECT 1 FROM t_order WHERE t_order.order_number=t_pick_detail.order_number 
								                                   AND t_order.wh_id=t_pick_detail.wh_id
																   AND t_order.status='LOADED'))
				---ADD WILL 20160621 END----------------------
			BEGIN
				SET @passornot = 1
				SET @msg = N'波次中已有任务开始作业.'
				RETURN
			END
		
		BEGIN TRANSACTION
			DELETE FROM t_work_q
				WHERE wh_id = @in_wh_id
					AND work_type = '06'
					AND EXISTS(SELECT 1 FROM t_pick_detail
								WHERE t_work_q.pick_ref_number = pick_id
										AND wave_id = @in_wave_id)

			DELETE FROM tbl_allocation
					WHERE wh_id = @in_wh_id
						AND wave_id = @in_wave_id

			DELETE FROM tbl_pick_list
				WHERE wh_id = @in_wh_id
				AND wave_id = @in_wave_id

			DELETE FROM t_pick_detail
					WHERE wh_id = @in_wh_id
						AND wave_id = @in_wave_id

			UPDATE t_order
				SET status = 'WAVED'
			WHERE wh_id = @in_wh_id
				AND EXISTS(SELECT 1 FROM t_afo_wave_detail
							WHERE t_order.wh_id = t_afo_wave_detail.wh_id
								AND t_order.order_number = t_afo_wave_detail.order_number
								AND wave_id = @in_wave_id)
			
			UPDATE t_wave_master
				SET status = 'N'
				WHERE wh_id = @in_wh_id
					AND wave_id = @in_wave_id
											
		SET @passornot = 0
		SET @msg = ''
		COMMIT	TRANSACTION
        RETURN

    END TRY

    BEGIN CATCH
		ROLLBACK TRANSACTION
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END    
    






