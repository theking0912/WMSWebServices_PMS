
CREATE PROCEDURE usp_confirm_label_picking

AS 
    DECLARE
    @in_nRowSelect         AS INT,
    @in_flag_Insert        AS INT,

    @v_item_number         AS NVARCHAR (30),
    @v_lot_number          AS NVARCHAR (20),
    @v_qty                 AS FLOAT,
    @v_location            AS NVARCHAR (50),
    @v_wh_id               AS NVARCHAR (10),
    @v_staging_location    AS NVARCHAR(50),

      --generated file variables
    @v_path                NVARCHAR (50),
    @v_folder              NVARCHAR (50),
    @v_str                 NVARCHAR (1000),

    -- Error handling and logging variables
    @c_nModuleNumber       INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber         INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum        INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel           INT, -- Holds log level (1-5).
    @v_vchErrorMsg         NVARCHAR(500),
    @v_nErrorNumber        INT,
    @v_nRowCount           INT,
    @v_nReturn             INT,
    
    -- Log Error numbers used for branching in the Error Handler 
    @e_GenSqlError         INT,
    @e_SprocError          INT,
    @e_InsITMFailed        INT,              
       
    -- Local Variables
    @v_vchItem             NVARCHAR(30),
    @v_flag                NCHAR(1),

    --Variables to hold the values of records from labels_to_confirm_cursor in every fetch
    @location              NVARCHAR(50),
    @item_number           NVARCHAR(30), 
    @lot_number            NVARCHAR(20), 
    @picked_qty            INT,
    @wh_id                 NVARCHAR(20),
    @pick_id               INT,
    @stored_attribute_id   INT,
    @order_number          NVARCHAR(30),
    @line_number           NVARCHAR(5), 
    @staging_loc           NVARCHAR(50), 
    @pick_loc              NVARCHAR(50), 
    @uom                   NVARCHAR(30),
	@source_storage_device  	 	INT,
	@destination_storage_device  	INT,
    @col1                  NVARCHAR(250),  
    @col2                  NVARCHAR(250),  
    @col3                  NVARCHAR(250),  
    @col4                  NVARCHAR(250),  
    @col5                  NVARCHAR(250),  
    @col6                  NVARCHAR(250),  
    @col7                  NVARCHAR(250),  
    @col8                  NVARCHAR(250),  
    @col9                  NVARCHAR(250),  
    @col10                 NVARCHAR(250),  
    @col11                 NVARCHAR(250),
    @ret_val               INT,
	
    --Other auxiliary variables
    @actual_hu_id             NVARCHAR(30), --Will contain the actual hu_id inside the nested loop.
    @actual_qty_in_actual_hu  INT, --Will contain the actual_qty of items for the actual hu_id inside the nested loop
    @location_of_actual_hu    NVARCHAR(30), --The location for the hu being analized inside the nested loop
    @item_number_of_actual_hu NVARCHAR(30), --The item number for the hu being analized inside the nested loop
    @lot_number_of_actual_hu  NVARCHAR(30), --The lot number of the hu being analized inside the nested loop
    @wh_id_of_actual_hu       NVARCHAR(30), --The wh_id of the hu being analized inside the nested loop
    @HUs_qty_for_specific_item_lot_loc INT  --Will contain the quantity of HUs for the specific wh/item/lot/location.

    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 1        -- This # must be unique per object.
    
    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_InsITMFailed = 3
    SET @v_nReturn = 0
    SET @in_flag_Insert= 0

    SET NOCOUNT ON

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END
       
    --------------------
    -- Body of procedure
    BEGIN TRAN

        --Updates all the Work Qs for any confirmed or cancelled label to complete
        UPDATE t_work_q SET work_status = 'C', workers_assigned = 0
        WHERE work_q_id IN (SELECT pkd.work_q_id 
                            FROM t_pick_detail pkd
                            JOIN t_label lbl ON pkd.pick_id = lbl.pick_id
                            JOIN t_label_confirm lcf ON lbl.label_id = lcf.label_id)


        --------------------------------------------------
        -- START of Update Labels and Pick Details section
        --Updates all the records with the action_type field = CANCEL in t_label_confirm as processed
        UPDATE t_label_confirm 
        SET t_label_confirm.processed = 1
        WHERE t_label_confirm.action_type = 'CANCEL'   
		   
		--Updates the label status for all the labels in t_label that were sent to be CANCELLED through t_label_confirm
        UPDATE t_label
        SET t_label.label_status = 'CANCELLED'
        FROM t_label, t_label_confirm
        WHERE t_label.label_id = t_label_confirm.label_id 
            AND t_label_confirm.action_type = 'CANCEL' 
            AND t_label_confirm.processed = 1
		
        --Deletes all the processed records from t_label_confirm to avoid occupying resources with unnecessary data
        DELETE FROM t_label_confirm 
        WHERE t_label_confirm.processed = 1 
            AND t_label_confirm.action_type = 'CANCEL'
		
        -- Print a trace level log message.
		IF @v_nLogLevel >= 4        
		   BEGIN
		       PRINT 'Label"s status set to CANCELLED'
           END 
 
        -- Update staging location values where staging location is null
        UPDATE t_pick_detail 
        SET staging_location = ROLLPA.stage
        FROM t_label_confirm lcf, t_label lbl, 
            (SELECT MIN(location_id) AS stage, pick_area AS pick_area 
             FROM t_location_relation lcr 
             WHERE lcr.relation_type = 'PICKAREA_STAGE'
             GROUP by lcr.pick_area) AS ROLLPA	
        WHERE t_pick_detail.staging_location IS NULL
            AND t_pick_detail.pick_area = ROLLPA.pick_area
            AND t_pick_detail.pick_id = lbl.pick_id
            AND lcf.label_id = lbl.label_id
            AND lcf.processed = 0
            AND (lcf.action_type = 'CONFIRM'  OR lcf.action_type = 'SHORTQTY')
            AND (lbl.label_status = 'PRINTED' OR lbl.label_status = 'REPRINTED')                                       				  

       	SELECT  @v_staging_location = c1 
        FROM t_control
        WHERE control_type = 'DEFAULT_LABEL_STAGE'  
    	    
        UPDATE t_pick_detail 
        SET staging_location = @v_staging_location
        FROM t_label_confirm lcf, t_label lbl		
        WHERE t_pick_detail.staging_location IS NULL
            AND t_pick_detail.pick_id = lbl.pick_id
            AND lcf.label_id = lbl.label_id
            AND lcf.processed = 0
            AND (lcf.action_type = 'CONFIRM'  OR lcf.action_type = 'SHORTQTY')
            AND (lbl.label_status = 'PRINTED' OR lbl.label_status = 'REPRINTED')	         				 																 
  
        --Changes the value of the field processed in t_label_confirm to 1 for the processed records
        UPDATE t_label_confirm 
        SET processed = 1
        FROM t_label_confirm lcf, t_label lbl
        WHERE lcf.label_id = lbl.label_id 
            AND lcf.processed = 0 
            AND (lcf.action_type = 'CONFIRM'  OR lcf.action_type = 'SHORTQTY')
            AND (lbl.label_status = 'PRINTED' OR lbl.label_status = 'REPRINTED')

        IF @@ROWCOUNT < 1 
            BEGIN
                GOTO EXIT_RETURN
            END

        --Changes the label_status to PICKED for the processed labels
        UPDATE t_label 
        SET label_status = 'PICKED'
        FROM t_label_confirm lcf, t_label lbl
        WHERE lcf.label_id = lbl.label_id 
            AND lcf.processed = 1 
            AND (lcf.action_type = 'CONFIRM' OR lcf.action_type = 'SHORTQTY')
            AND (lbl.label_status = 'PRINTED' OR lbl.label_status = 'REPRINTED')

        IF @@ROWCOUNT < 1 
            BEGIN
                ROLLBACK TRAN 
                PRINT 'ROLLBACK TRAN'
                GOTO EXIT_RETURN
            END
       
        --Updates picked_quantity and staged_quantity 
        --Sets status = 'STAGED' in t_pick_detail for the processed labels 
        UPDATE t_pick_detail 
        SET picked_quantity = picked_quantity + lcf.picked_qty, 
            status = 'STAGED', 
            staged_quantity = staged_quantity + lcf.picked_qty
        FROM t_label_confirm lcf, t_label lbl, t_pick_detail pkd
        WHERE lcf.label_id = lbl.label_id 
            AND lcf.processed = 1 
            AND (lcf.action_type = 'CONFIRM' OR lcf.action_type = 'SHORTQTY')
            AND (lbl.label_status = 'PICKED') 
            AND lbl.pick_id = pkd.pick_id 
            AND pkd.status = 'RELEASED'

        IF @@ROWCOUNT < 1 
            BEGIN
                ROLLBACK TRAN 
                PRINT 'ROLLBACK TRAN'
                GOTO EXIT_RETURN
            END
        -- END of Update Labels and Pick Details section


        ---------------------------------------
        -- START of Update stored Items section 
        --Gets the default staging location for the Pick Area "LABEL"
        SELECT TOP 1 @v_staging_location = location_id 
        FROM t_location_relation
        WHERE pick_area = 'LABEL'
        ORDER BY location_id ASC

        -- Print a trace level log message  
        IF @v_nLogLevel >= 4        
            BEGIN
                PRINT 'Executing INSERT in t_stored_item with pick_id as type'
            END 
        
        -- Insert new destination location record with pick_id as type
        INSERT INTO t_stored_item (item_number,actual_qty,wh_id,location_id,type,lot_number, stored_attribute_id)
        SELECT pkd.item_number, lcf.picked_qty,
            pkd.wh_id, pkd.staging_location, 
            CONVERT(NVARCHAR(30),pkd.pick_id), 
            pkd.lot_number, pkd.stored_attribute_id
        FROM t_label_confirm lcf, t_label lbl, t_pick_detail pkd
        WHERE lcf.processed = 1 
            AND (lcf.action_type = 'CONFIRM' OR lcf.action_type = 'SHORTQTY') 
            AND lbl.label_status = 'PICKED'
            AND pkd.pick_id = lbl.pick_id 
            AND lbl.label_id = lcf.label_id 
            AND ((pkd.lot_number IS NULL) OR (pkd.lot_number IS NOT NULL))
            AND NOT EXISTS (SELECT * 
                            FROM t_stored_item sto
                            WHERE sto.location_id = pkd.staging_location
                                AND sto.item_number = pkd.item_number 
                                AND ISNULL(sto.stored_attribute_id,'-1') = ISNULL(pkd.stored_attribute_id,'-1')
                                AND ((pkd.lot_number = sto.lot_number) OR ((pkd.lot_number IS NULL) AND (sto.lot_number IS NULL)))
                                AND sto.type = CONVERT(NVARCHAR(30),pkd.pick_id))

        IF @@ROWCOUNT < 1 
            BEGIN
                ROLLBACK TRAN 
                PRINT 'ROLLBACK TRAN'
                GOTO EXIT_RETURN
            END
        -- END of Update stored Items section 


        ----------------------------
        -- START of Tran Log section 
        IF @v_nLogLevel >= 4        
            BEGIN
                PRINT 'Executing INSERT in t_tran_log'
            END   
       
       DECLARE labels_to_confirm_log_cursor CURSOR FOR
             SELECT
             pkd.order_number,
             pkd.line_number,
             pkd.wh_id,
             pkd.staging_location,
             pkd.item_number,
             pkd.lot_number,
             pkd.uom, 
             pkd.stored_attribute_id,
             lcf.picked_qty,
             pkd.pick_location,
             CONVERT(NVARCHAR(30),pkd.pick_id) AS pick_id,
			 ISNULL(tsd_src.storage_device_id,0),
			 ISNULL(tsd_des.storage_device_id,0)
             FROM t_label_confirm lcf 
			 INNER JOIN t_label lbl	ON lcf.label_id = lbl.label_id
			 INNER JOIN t_pick_detail pkd ON pkd.pick_id = lbl.pick_id
			 LEFT OUTER JOIN t_location tsd_src ON pkd.pick_location = tsd_src.location_id AND pkd.wh_id = tsd_src.wh_id
			 LEFT OUTER JOIN t_location tsd_des ON pkd.staging_location = tsd_src.location_id AND pkd.wh_id = tsd_des.wh_id
             WHERE  lcf.processed = 1  AND (lcf.action_type = 'CONFIRM' OR lcf.action_type = 'SHORTQTY') AND lbl.label_status = 'PICKED' 

			 --Cursor labels_to_confirm_cursor is opened.
        OPEN labels_to_confirm_log_cursor

        --Returns the first row in the result set of labels_to_confirm_cursor into variables.
        FETCH NEXT 
        FROM labels_to_confirm_log_cursor
        INTO @order_number, 
		@line_number, 
		@wh_id, 
		@staging_loc, 
        @item_number, 
		@lot_number, 
		@uom, 
		@stored_attribute_id, 
		@picked_qty, 
		@pick_loc, 
		@pick_id,
		@source_storage_device,
		@destination_storage_device

        WHILE @@FETCH_STATUS = 0 
            BEGIN
                EXECUTE @ret_val = usp_dynamic_get_attribute_data 
                               @stored_attribute_id, 
                               @col1 OUTPUT,
                               @col2 OUTPUT,
                               @col3 OUTPUT,
                               @col4 OUTPUT,
                               @col5 OUTPUT,
                               @col6 OUTPUT,
                               @col7 OUTPUT,
                               @col8 OUTPUT,
                               @col9 OUTPUT,
                               @col10 OUTPUT,
                               @col11 OUTPUT

        -- Write entries in t_tran_log_holding
        INSERT t_tran_log_holding
            (
			 tran_type,
             description,
             start_tran_date,
             end_tran_date,
             employee_id,
             control_number,
             line_number,
             wh_id,
             location_id,
             item_number,
             lot_number,
             uom,
             tran_qty,
             wh_id_2,
             location_id_2,
			 src_storage_device_id,
			 det_storage_device_id
			 )
        VALUES
            (
             '304',
             'Confirm Label Picking',
             GETDATE(),
             GETDATE(),
             user, 
             @order_number, 
             @line_number, 
             @wh_id,
			 @pick_loc, 
             @item_number, 
             @lot_number, 
             @uom, 
             @picked_qty, 
             @wh_id, 
             @staging_loc,
			 @source_storage_device, 
             @destination_storage_device
            )
        
            FETCH NEXT FROM labels_to_confirm_log_cursor
            INTO @order_number, 
			@line_number, 
			@wh_id, 
			@staging_loc, 
			@item_number, 
			@lot_number, 
			@uom, 
			@stored_attribute_id, 
			@picked_qty, 
			@pick_loc,
			@pick_id,
			@source_storage_device,
			@destination_storage_device
			END --end of outer While

        CLOSE labels_to_confirm_log_cursor
        DEALLOCATE labels_to_confirm_log_cursor

        ----------------------------------
        -- START of Update HUM/STO section 
        -- Reduces stock from HUs with Wh/Item/Lot/Location of Confirmed Label Picks

        -- If a temporary table named dbo.##t_hu_actual_qttties already exists it is dropped.
        IF EXISTS (SELECT name FROM sysobjects WHERE id = object_id('##t_hu_actual_qttties'))
            BEGIN
                DROP TABLE ##t_hu_actual_qttties
            END

        --Temporary table ##t_hu_actual_qttties is created.
        CREATE TABLE ##t_hu_actual_qttties(
            hu_id 	              NVARCHAR(30)   COLLATE DATABASE_DEFAULT     NULL,
       		wh_id                 NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,	
       		location_id           NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       		item_number           NVARCHAR(30)   COLLATE DATABASE_DEFAULT NOT NULL,
       		lot_number            NVARCHAR(30)   COLLATE DATABASE_DEFAULT NULL,
       		actual_qty            INT            NOT NULL,
            pick_id               INT            NOT NULL,
            stored_attribute_id   INT
       		) 

        --Rows are inserted in ##t_hu_actual_qttties
        --One row for every HU (License Plate) containing the same item/lot/location described by labels that are being confirmed
        INSERT INTO ##t_hu_actual_qttties 
        SELECT DISTINCT sto.hu_id, sto.wh_id, sto.location_id, 
             sto.item_number,
             sto.lot_number, 
             sto.actual_qty, 
             pkd.pick_id, 
             pkd.stored_attribute_id
        FROM t_stored_item sto, 
             t_pick_detail pkd, 
             t_label_confirm lcf, 
             t_label lbl
        WHERE  lcf.processed = 1
      	    AND (lcf.action_type = 'CONFIRM' OR lcf.action_type = 'SHORTQTY') 
      	    AND lbl.label_status = 'PICKED'
      	    AND lcf.label_id = lbl.label_id
      	    AND lbl.pick_id = pkd.pick_id
      	    AND pkd.item_number = sto.item_number
      	    AND (pkd.lot_number = sto.lot_number OR ((pkd.lot_number IS NULL) AND (sto.lot_number IS NULL)))
            AND ISNULL(pkd.stored_attribute_id,'-1') = ISNULL(sto.stored_attribute_id,'-1')
      	    AND pkd.wh_id = sto.wh_id
      	    AND sto.location_id = pkd.pick_location
            AND sto.type = 0

        --If there are not HUs related to the labels being confirmed nothing is done
        IF @@ROWCOUNT < 1
            GOTO No_HUs_To_Modify

        --The cursor labels_to_confirm_cursor is declared.
        --This cursor will contain one record for every group of labels with coincident wh/item/lot/location being confirmed.
        --The sum of picked quantities in every group is one field in the result set of the cursor
        DECLARE labels_to_confirm_cursor CURSOR FOR
         SELECT pkd.wh_id, 
                pkd.pick_location, 
                pkd.item_number, 
                pkd.lot_number, 
                pkd.stored_attribute_id,
                SUM(lcf.picked_qty)
           FROM t_pick_detail pkd, 
                t_label_confirm lcf, 
                t_label lbl
	    WHERE  lcf.processed = 1
            AND (lcf.action_type = 'CONFIRM' OR lcf.action_type = 'SHORTQTY') 
      	    AND lbl.label_status = 'PICKED'
      	    AND lcf.label_id = lbl.label_id
      	    AND lbl.pick_id = pkd.pick_id
        GROUP BY pkd.wh_id, pkd.pick_location, pkd.item_number, pkd.lot_number, pkd.stored_attribute_id

        --Cursor labels_to_confirm_cursor is opened.
        OPEN labels_to_confirm_cursor

        --Returns the first row in the result set of labels_to_confirm_cursor into variables.
        FETCH NEXT 
        FROM labels_to_confirm_cursor
        INTO @wh_id, @location, @item_number, @lot_number, @stored_attribute_id, @picked_qty

        --Outer loop. Will be executed once for every row in labels_to_confirm_cursor's result set.
        --Is executed once for every wh/item/lot/location group of labels being confirmed.
        WHILE @@FETCH_STATUS = 0 
        BEGIN
			-- END of Tran Log section 
		    --stores in variable @HUs_qty_for_specific_item_lot_loc the Quantity of 
		    --existing HUs for the wh/item/lot/location related to the processed wh/item/lot/location group of labels.
		    SELECT @HUs_qty_for_specific_item_lot_loc = COUNT(*)
              FROM t_stored_item sto
             WHERE sto.wh_id = @wh_id
               AND ((sto.lot_number = @lot_number) OR ((sto.lot_number IS NULL) AND (@lot_number IS NULL)))
               AND sto.location_id = @location
               AND sto.item_number = @item_number
               AND ISNULL(sto.stored_attribute_id,'-1') = ISNULL(@stored_attribute_id,'-1')
               AND sto.type = 0
                
	
            --If there is no HU related to the processed wh/item/lot/location group of labels nothing is done for this group of labels. 
		    IF @HUs_qty_for_specific_item_lot_loc >=1
                BEGIN
                --This nested While is to decrement the actual_qty of items stored in HUs
                --related to the wh/item/lot/location of the wh/item/lot/location group of labels being processed.
                --Every loop will decrement actual_qty from HUs until the picked qty of items for the group of labels is completed.
                --actual_qty is reduced first from HUs with lower values in actual_qty.
                    WHILE @picked_qty > 0
                        BEGIN
                            --stores in Variables the hu_id and actual_qty for the HU with lower value of actual_qty
                            --between the HUs related to the wh/item/lot/location of the actual group of labels being processed
                            SELECT TOP 1  @actual_hu_id = hu_id, 
                                @actual_qty_in_actual_hu = actual_qty,
                                @location_of_actual_hu = location_id,
                                @item_number_of_actual_hu = item_number,
                                @lot_number_of_actual_hu = lot_number,
                                @wh_id_of_actual_hu = wh_id,
                                @stored_attribute_id = stored_attribute_id
                             FROM ##t_hu_actual_qttties
                            WHERE wh_id = @wh_id
                              AND location_id = @location
                              AND item_number = @item_number
                              AND ISNULL(stored_attribute_id,'-1') = ISNULL(@stored_attribute_id,'-1')
                              AND ((lot_number = @lot_number) OR ((lot_number IS NULL) AND (@lot_number IS NULL)))
                            ORDER BY actual_qty ASC       
							
                            --If the value of picked_qty for the current group of labels is higher than 
                            --actual_qty for the HU with the lower value in actual_qty between the HUs related to the group of labels being processed...                 
                            IF @picked_qty >= @actual_qty_in_actual_hu
                                BEGIN
                                    --If there is more than one HU related to the actual group of labels being processed 
                                    IF @HUs_qty_for_specific_item_lot_loc > 1
                                        BEGIN
                                            SET @HUs_qty_for_specific_item_lot_loc = @HUs_qty_for_specific_item_lot_loc - 1 
                                            SET @picked_qty = @picked_qty - @actual_qty_in_actual_hu
                                            --@picked_qty is reduced in the actual_qty in current HU.
                                        END
                                    --If there is just one HU related to the actual group of labels being processed
                                    ELSE 
                                        SET @picked_qty = 0 
                                    --This case will occur just if there are errors in inventory (Picked qty is higher than the sum of items in HUs in specific location)
	                      		    --As the HU has 0 available quantity of items, it is deleted from t_stored_item.
                                    DELETE FROM t_stored_item 
                                    WHERE t_stored_item.wh_id = @wh_id
                                        AND ((t_stored_item.hu_id = @actual_hu_id) OR ((t_stored_item.hu_id IS NULL) AND (@actual_hu_id IS NULL)))
                                        AND t_stored_item.item_number =@item_number
                                        AND ((t_stored_item.lot_number = @lot_number) OR ((t_stored_item.lot_number IS NULL) AND (@lot_number IS NULL)))
                                        AND @wh_id_of_actual_hu =  @wh_id  
                                        AND @location_of_actual_hu = @location   
                                        AND @item_number_of_actual_hu = @item_number
                                        AND ((stored_attribute_id = @stored_attribute_id) OR (@stored_attribute_id is NULL))
                                        AND ((@lot_number_of_actual_hu = @lot_number) OR ((@lot_number_of_actual_hu IS NULL) AND (@lot_number IS NULL)))
                                        AND type = 0
                                    --If not HUs related in t_stored_item hu_id is deleted from t_hu_master
                                  IF @actual_hu_id IS NOT NULL
                                    DELETE FROM t_hu_master 
                                    WHERE t_hu_master.wh_id = @wh_id
                                        AND t_hu_master.hu_id = @actual_hu_id
                                        AND t_hu_master.hu_id NOT IN (SELECT hu_id
                                                                      FROM t_stored_item)
                                END		               
                            --If the value of picked_qty for the current group of labels is lower than 
                            --actual_qty for the HU with the lower value in actual_qty between the HUs related to the group of labels being processed... 
                            ELSE           --@picked_qty < @actual_qty_in_actual_hu
                                BEGIN
                                    --The actual_qty of items for the current HU is reduced in @picked_qty
                                    UPDATE t_stored_item 
                                    SET t_stored_item.actual_qty = (@actual_qty_in_actual_hu - @picked_qty)
                                    WHERE t_stored_item.wh_id = @wh_id
                                        AND ((t_stored_item.hu_id = @actual_hu_id) OR ((t_stored_item.hu_id IS NULL) AND (@actual_hu_id IS NULL)))
                                        AND t_stored_item.item_number =@item_number
                                        AND ((t_stored_item.lot_number = @lot_number) OR ((t_stored_item.lot_number IS NULL) AND (@lot_number IS NULL)))
                                        AND @wh_id_of_actual_hu =  @wh_id  
                                        AND @location_of_actual_hu = @location   
                                        AND @item_number_of_actual_hu = @item_number
                                        AND ((stored_attribute_id = @stored_attribute_id) OR (@stored_attribute_id is NULL))
                                        AND ((@lot_number_of_actual_hu = @lot_number) OR ((@lot_number_of_actual_hu IS NULL) AND (@lot_number IS NULL)))
                                        AND type = 0
                                    SET @picked_qty = 0
                                END 
                            --The HU which has just been processed is deleted from temporary table.
                            DELETE FROM ##t_hu_actual_qttties
                            WHERE ##t_hu_actual_qttties.wh_id = @wh_id_of_actual_hu
                                AND ##t_hu_actual_qttties.hu_id = @actual_hu_id
                                AND ##t_hu_actual_qttties.item_number = @item_number_of_actual_hu
                                AND ##t_hu_actual_qttties.location_id = @location_of_actual_hu
                                AND (##t_hu_actual_qttties.lot_number = @lot_number_of_actual_hu OR @lot_number_of_actual_hu IS NULL)
                                AND (##t_hu_actual_qttties.stored_attribute_id = @stored_attribute_id OR @stored_attribute_id IS NULL)
                        END --End related to inner WHILE @picked_qty > 0
                END --End related to 'IF @HUs_qty_for_specific_item_lot_loc >=1'
            --Once the current label has been processed (the proper actual_qty for the related HUs have been decremented)
            --The next label's data is stored into variables.
            FETCH NEXT FROM labels_to_confirm_cursor
            INTO @wh_id, @location, @item_number, @lot_number, @stored_attribute_id, @picked_qty

        END --end of outer While

        CLOSE labels_to_confirm_cursor
        DEALLOCATE labels_to_confirm_cursor

        No_HUs_To_Modify:
        DROP TABLE ##t_hu_actual_qttties
        -- END of Update HUM/STO section 


        ---------------------------------
        -- START of Update Orders section 
        IF @v_nLogLevel >= 4        
            BEGIN
                PRINT 'Executing Update in t_order, when the order is fully picked and staged '
            END 
      
        -- Create temp table for update ORDER when is fully picked and staged 
        CREATE TABLE ##tmp_order
            (
             order_number NVARCHAR (30) COLLATE DATABASE_DEFAULT,
             qty INT
            )
    
        -- Insert only ORDERS
        INSERT INTO ##tmp_order (order_number)
        SELECT DISTINCT pkd.order_number
        FROM t_pick_detail pkd, t_label_confirm lcf, t_label lbl, t_order ORD
        WHERE lcf.processed = 1
            AND (lcf.action_type = 'CONFIRM'  OR lcf.action_type = 'SHORTQTY')
            AND lbl.label_status = 'PICKED'
            AND pkd.pick_id = lbl.pick_id 
            AND lbl.label_id = lcf.label_id
            AND ORD.order_number = pkd.order_number
            AND ORD.status = 'U' 
    
        -- Update the ORDERS that are fully picked and staged 
        UPDATE tmpORD
        SET tmpORD.qty = 0
        FROM ##tmp_order tmpORD
        WHERE tmpORD.order_number IN (SELECT (SELECT DISTINCT pkd1.order_number
                                              FROM t_pick_detail pkd1
                                              WHERE pkd1.order_number = pkd.order_number
                                              GROUP BY pkd1.order_number
                                              HAVING ((SELECT SUM(pkd2.planned_quantity)
                                                       FROM t_pick_detail pkd2
                                                       WHERE pkd2.order_number =  pkd1.order_number) - 
                                                      (SELECT  SUM(pkd3.staged_quantity)
                                                       FROM t_pick_detail pkd3
                                                       WHERE pkd3.order_number = pkd1.order_number) = 0))
                                      FROM  t_pick_detail pkd, t_label_confirm lcf, t_label lbl, t_order ORD
                                      WHERE lcf.processed = 1
                                          AND (lcf.action_type = 'CONFIRM'  OR lcf.action_type = 'SHORTQTY')
                                          AND lbl.label_status = 'PICKED'
                                          AND pkd.pick_id = lbl.pick_id 
                                          AND lbl.label_id = lcf.label_id
                                          AND ORD.order_number = pkd.order_number
                                          AND ORD.status = 'U' 
                                      GROUP BY pkd.order_number)
        
        -- Update in t_order the status columns to 'D' WHERE tmpORD.qty = 0
        UPDATE ORD 
        SET status = 'D'
        FROM t_order ORD, ##tmp_order tmpORD
        WHERE ORD.order_number = tmpORD.order_number
            AND tmpORD.qty = 0

        DROP TABLE ##tmp_order
        -- END of Update Orders section 


        --------------------------
        -- START of Close section 
        SELECT @v_nErrorNumber = @@ERROR
        -- Check for any errors. If so, error number will not be equal to zero.
        IF @v_nErrorNumber <> 0
            BEGIN
                SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                    'the exact nature of the error.'
                SET @v_nLogErrorNum = @e_GenSqlError
                GOTO ErrorHandler
            END 
        IF @v_nLogLevel >= 4        
            BEGIN
                PRINT 'Executing DELETE  in t_label_confirm WHERE processed = 1'
            END 
        
        --Deletes the already processed rows from t_label_confirm
        DELETE t_label_confirm 
        WHERE processed = 1

        IF @@ROWCOUNT < 1
            BEGIN
                ROLLBACK TRAN
                PRINT 'ROLLBACK TRAN'
                GOTO EXIT_RETURN
            END

        IF @v_nLogLevel >= 4        
            BEGIN
                PRINT 'Executing DELETE  in t_stored_item  WHERE actual_qty = 0  AND unavailable_qty = 0'
            END
 
        -- Deletes rows from t_stored_item with actual_qty = 0  AND unavailable_qty = 0 (if some)
        DELETE t_stored_item  
         WHERE actual_qty = 0  
           AND unavailable_qty = 0

        GOTO EXIT_RETURN
        -- END of Close section 


        -----------------
        -- Error Handling         
        ErrorHandler:
        -- Raise the error with error message, severity, state
        SET @v_vchErrorMsg = 'SQL stoRED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
            + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
            + ' ERROR [' + @v_vchErrorMsg + ']'
        RAISERROR(@v_vchErrorMsg, 11, 1)    
        SET @v_nReturn = @v_nLogErrorNum
        ROLLBACK TRAN
        PRINT 'ROLLBACK TRAN'
        RETURN @v_nReturn

    EXIT_RETURN:
    COMMIT TRAN

SET NOCOUNT OFF
RETURN @v_nReturn
