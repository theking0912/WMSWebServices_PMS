--台账修改收货数量         规则：更新数量为>=0的整数，更改完后调用SP更新库存表   
CREATE PROCEDURE [dbo].[csp_upd_RF_recpt_qty]
    @shipment_number NVARCHAR(30) ,
    @line_number NVARCHAR(5) ,
    @item_number NVARCHAR(30) ,
    @lot_number NVARCHAR(15) ,
    @fork_id NVARCHAR(30) ,
    @in_qty_damaged FLOAT ,
    @in_qty_discount FLOAT ,
    @in_qty_received FLOAT ,
    @wh_id NVARCHAR(10) ,
    @hu_id NVARCHAR(22) ,
    @in_is_confirm NCHAR(5) ,
	@USER NVARCHAR(30) ,
    @out_nvch_err_code NVARCHAR(10) OUTPUT ,
    @out_nvch_err_msg NVARCHAR(30) OUTPUT
AS
    BEGIN    
	
	
        DECLARE @old_qty_damaged FLOAT ,
            @old_qty_discount FLOAT ,
            @old_qty_received FLOAT ,
            @stored_attribute_id BIGINT ,
            @old_qty_sum FLOAT ,
            @qty_sum FLOAT ,
            @diff_qty_sum FLOAT ,        -------2次更改总数量差
            @vchLocationID NVARCHAR(50) ,
            @nType BIGINT ,
            @nStoredAttributeID BIGINT ,
            @dtExpirationDate DATETIME ,
            @damage_flag NVARCHAR(1) ,
            @vchHUType NVARCHAR(10) ,
            @dtFifoDate DATETIME ,
            @out_vchCode uddt_output_code ,   ---调用SP输出信息
            @out_vchMsg uddt_output_msg   , 
			@n_rcpt_ship float 

        BEGIN TRANSACTION
        IF @in_is_confirm = 'N'
            BEGIN

                IF @lot_number = ''                   -----webwise参数传入时状态
                    SET @lot_number = NULL 
   
    ---修改的数量为>=0的整数
                IF ( ISNULL(@in_qty_damaged, '0') >= 0
                     AND ROUND(@in_qty_damaged, 0) = ROUND(@in_qty_damaged, 1)
                   )
                    AND ( ISNULL(@in_qty_discount, '0') >= 0
                          AND ROUND(@in_qty_discount, 0) = ROUND(@in_qty_discount,
                                                              1)
                        )
                    AND ( ISNULL(@in_qty_received, '0') >= 0
                          AND ROUND(@in_qty_received, 0) = ROUND(@in_qty_received,
                                                              1)
                        )
                    BEGIN

                        SELECT  @old_qty_damaged = ISNULL(qty_damaged, '0') ,
                                @old_qty_discount = ISNULL(qty_discount, '0') ,
                                @old_qty_received = ISNULL(qty_received, '0')
                        FROM    t_receipt
                        WHERE   wh_id = @wh_id
                                AND receipt_id = @shipment_number
                                AND line_number = @line_number
                                AND item_number = @item_number
								AND hu_id =@hu_id
 
                        

                        BEGIN 

                            IF @@ROWCOUNT = 0
                                BEGIN
                                    SET @out_nvch_err_code = 1
                                    SET @out_nvch_err_msg = '无可用值'
                                    GOTO ErrorHandler
                                END

                            IF ( @old_qty_damaged = 0
                                 AND @old_qty_discount = 0
                                 AND @old_qty_received = 0
                               )
                                BEGIN 
                                    SET @out_nvch_err_code = 6
                                    SET @out_nvch_err_msg = '收货和为0，不可再更新数量'
                                    GOTO ErrorHandler
                                END 

                /*
                        IF ( ISNULL(@in_qty_received, '0') <= @old_qty_received )
                            AND ( ISNULL(@in_qty_discount, '0') <= @old_qty_discount )
                            AND ( ISNULL(@in_qty_damaged, '0') <= @old_qty_damaged )
				*/
                            BEGIN
                                UPDATE  t_receipt
                                SET     qty_damaged = @in_qty_damaged ,
                                        qty_discount = @in_qty_discount ,
                                        qty_received = @in_qty_received
                                WHERE   wh_id = @wh_id
                                        AND receipt_id = @shipment_number
                                        AND line_number = @line_number
                                        AND item_number = @item_number
										AND hu_id = @hu_id

                                UPDATE  t_rcpt_ship_po_detail
                                SET     return_qty = return_qty +@in_qty_damaged-@old_qty_damaged,
                                        free_qty = free_qty+@in_qty_discount-@old_qty_discount ,
                                        received_qty = received_qty+@in_qty_received-@old_qty_received
                                WHERE   wh_id = @wh_id
                                        AND shipment_number = @shipment_number
                                        AND line_number = @line_number
                                        AND item_number = @item_number
  
                                SELECT  @out_nvch_err_code = @@ERROR
                                IF @out_nvch_err_code <> 0
                                    BEGIN

                                        SELECT  @out_nvch_err_msg = '更新失败' ,
                                                @out_nvch_err_code = 2
                                        GOTO ErrorHandler
                                    END
			    
			---计入库存

                                SELECT  @qty_sum = @in_qty_damaged
                                        + @in_qty_discount + @in_qty_received
                                SELECT  @old_qty_sum = @old_qty_damaged
                                        + @old_qty_discount
                                        + @old_qty_received 

                                SELECT  @diff_qty_sum = @qty_sum
                                        - @old_qty_sum     
                                
                       --         IF @diff_qty_sum < 0
                                BEGIN

                                    SELECT  @vchHUType = type
                                    FROM    t_hu_master
                                    WHERE   hu_id = @hu_id
                                            AND wh_id = @wh_id
                                            AND control_number = @shipment_number  ---写入库存参数

                                    SELECT  @vchLocationID = location_id ,
                                            @nType = type ,
                                            @dtExpirationDate = expiration_date ,
                                            @nStoredAttributeID = stored_attribute_id ,
                                            @damage_flag = damage_flag ,
                                            @dtFifoDate = fifo_date
                                    FROM    t_stored_item
                                    WHERE   hu_id = @hu_id
                                            AND wh_id = @wh_id
                                            AND item_number = @item_number
                                            AND ISNULL(lot_number, '') = ISNULL(@lot_number,
                                                              '')
                                    BEGIN TRY
                                        EXEC [dbo].[csp_Inventory_Adjust] @wh_id,
                                            @item_number, @vchLocationID,
                                            @nType, @hu_id, @lot_number,
                                            @nStoredAttributeID, @diff_qty_sum,
                                            @dtFifoDate, @dtExpirationDate,
                                            @vchHUType, @shipment_number,
                                            @damage_flag, @out_vchCode OUTPUT,
                                            @out_vchMsg OUTPUT


                                        IF ( @out_vchMsg <> 'NONE' )
                                            BEGIN 
                                                SELECT  @out_nvch_err_code = @out_vchCode ,
                                                        @out_nvch_err_msg = '更新库存表失败'
                                                        + @out_vchMsg 
                                                GOTO ErrorHandler
                                            END
                                    END TRY 
                                    BEGIN CATCH 
                                        SET @out_nvch_err_code = 7
                                        SET @out_nvch_err_msg = '更新库存表失败' 
                                        GOTO ErrorHandler

                                    END CATCH
            
                                END
                       --         ELSE
                                    
                                IF ( @in_qty_damaged = @old_qty_damaged
                                     AND @in_qty_discount = @old_qty_discount
                                     AND @in_qty_received = @old_qty_received
                                   )
                                    BEGIN
                                        SELECT  @out_nvch_err_msg = '数据未改变，请按X'
                                                        
                                        GOTO ErrorHandler
                                    END
				/*
									ELSE
									BEGIN
                                        SET @out_nvch_err_code = 4
                                        SET @out_nvch_err_msg = '更新库存失败'
                                        GOTO ErrorHandler
                                    END
				*/
			--将差异数据写入日志
			    
                                INSERT  INTO t_tran_log_holding
                                        ( [tran_type] ,
                                          [description] ,
                                          [start_tran_date] ,
                                          [start_tran_time] ,
                                          [end_tran_date] ,
                                          [end_tran_time] ,
                                          [employee_id] ,
                                          [control_number] ,
                                          [control_number_2] ,
                                          [wh_id] ,
                                          [location_id] ,
                                          [hu_id] ,
                                          [item_number] ,
                                          [lot_number] ,
                                          [tran_qty] ,
                                          [location_id_2] ,
                                          [hu_id_2] ,
                                          generic_attribute_1 ,
                                          generic_attribute_2 ,
                                          generic_attribute_3 ,
                                          generic_attribute_4 ,
                                          generic_attribute_5 ,
                                          generic_attribute_6 ,
                                          generic_attribute_7 ,
                                          generic_attribute_8 ,
                                          generic_attribute_9 ,
                                          generic_attribute_10 ,
                                          generic_attribute_11
                                        )
                                VALUES  ( '666' ,
                                          'UPDATE_RF_recpt_qty' ,
                                          GETDATE() ,
                                          GETDATE() ,
                                          GETDATE() ,
                                          GETDATE() ,
                                          @USER ,
                                          @shipment_number ,
                                          @line_number ,
                                          @wh_id ,
                                          @fork_id ,
                                          @hu_id ,
                                          @item_number ,
                                          @lot_number ,
                                          @diff_qty_sum ,
                                          @fork_id ,
                                          @hu_id ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_1
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_2
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_3
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_4
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_5
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_6
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_7
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_8
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_9
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_10
                                          ) ,
                                          ( SELECT  a.attribute_value
                                            FROM    t_sto_attrib_collection_detail a ,
                                                    t_attribute_legacy_map alm
                                            WHERE   a.stored_attribute_id = @stored_attribute_id
                                                    AND a.attribute_id = alm.generic_attribute_11
                                          )
                                        )
			 
                            END
                     /*
					    ELSE
                            BEGIN 
                                SELECT  @out_nvch_err_msg = '数据过大' ,
                                        @out_nvch_err_code = 3
                                GOTO ErrorHandler
                            END
					*/

                            IF @out_nvch_err_msg IS NULL
                                BEGIN
                                    SET @out_nvch_err_msg = '数据更新成功'
			--			PRINT @out_nvch_err_msg
                                    COMMIT TRANSACTION
                                    RETURN
                                END
                        END
                    END 
			
                ELSE
                    BEGIN
                        SET @out_nvch_err_msg = '修改的数量应为>=0的整数'
                        SET @out_nvch_err_code = 5
                        GOTO ErrorHandler
                    END
		

            END
	 
        ELSE
            BEGIN 
                SELECT  @out_nvch_err_msg = '预到货通知单此商品已确认过' ,
                        @out_nvch_err_code = 5
                GOTO ErrorHandler
            END
    END

    ErrorHandler:
    RAISERROR(@out_nvch_err_msg,11,1)
    ROLLBACK TRANSACTION
    RETURN

	

	
	 

	


	
