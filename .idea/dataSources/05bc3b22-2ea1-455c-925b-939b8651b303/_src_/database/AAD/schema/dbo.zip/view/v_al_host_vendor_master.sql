
CREATE VIEW v_al_host_vendor_master AS
SELECT
host_vendor_id,
host_group_id,
record_create_date,
processing_code,
vendor_code,
vendor_name,
inspection_flag,
ownership_control,
audit_percent,
vqm_profile
  FROM t_al_host_vendor_master
