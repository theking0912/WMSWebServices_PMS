CREATE PROCEDURE  csp_imp_order_status_so_start
AS --
update t_control 
set c1='Y' 
WHERE control_type  ='C_LOCK_SALE' AND UPPER(isnull(c1,'N'))<>'Y'