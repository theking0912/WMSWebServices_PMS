
CREATE  PROCEDURE usp_gen_cyclecount_byitem

    @in_vchFromItem  	AS NVARCHAR(20) = NULL,
    @in_vchToItem   AS NVARCHAR(20) = NULL,
    @in_vchWhID			AS NVARCHAR(10) = '01'

AS

  --declare variables
  DECLARE
    @n_StartWKQ 	        	INT,
    @n_FinishWKQ 		        INT,
    @n_Count 			        INT,
    @n_Range			        INT,

    -- Error handling and logging variables.
--     @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
--     @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_vchOutMsg		        NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @v_nTranCount		        INT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @e_MissingITMError          INT,
    @e_GetWKQRangeError		    INT,
    @e_SetWKQTempError          INT,
    @e_AddWKQError		        INT     

    SET NOCOUNT ON
       
    -- Retrieve Database Log Level from t_control.  If it doesn't exist, insert it.
    -- 0 = Off, 1 = On
    SELECT @v_nLogLevel = next_value FROM t_control WHERE control_type = 'DB OBJ LOG LEVEL'

    IF @@ROWCOUNT = 0
    BEGIN
      INSERT INTO t_control (control_type, description, next_value, config_display, allow_edit)
        VALUES ('DB OBJ LOG LEVEL', 'Database Object Log Level', '0', 'SHOW_VA', '1')
      SET @v_nLogLevel = 0
    END

    SET @v_nReturn = 0
    SET @n_Count = 0
    
    -- Set Constants
--     SET @c_nModuleNumber = 60     -- Always #60 for WA.
--     SET @c_nFileNumber = 7        -- This # must be unique per object.

    -- Log/Local Error Constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2
    SET @e_MissingITMError = 3
    SET @e_SetWKQTempError = 4
    SET @e_AddWKQError = 5

    -- Print a trace level log message.
    IF @v_nLogLevel >= 5  
    	PRINT 'Paramters passed: From Item: ' +  @in_vchFromItem  +
                                 ' to Item:' +  @in_vchToItem +
                                 ' Warehouse ID ' +  @in_vchWhID

    --  Check to see if any PKD records will be process by this release.
    SELECT @n_Count = COUNT(*)
	    FROM t_item_master itm
			 LEFT JOIN t_work_q wkq
			 ON (itm.item_number = wkq.item_number
			     AND itm.wh_id = wkq.wh_id
				 AND wkq.work_type = '08'
				 AND wkq.work_status <> 'C')
		WHERE itm.wh_id = @in_vchWhID
			AND itm.item_number >= @in_vchFromItem
			AND itm.item_number <= @in_vchToItem
			AND wkq.work_q_id is NULL

    SELECT @v_nErrorNumber = @@ERROR 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END
    -- Check for Number of rows affected.
    IF @n_Count = 0
    BEGIN 
    		select 'No New Cycle Count requests created for Items from: ' + 
					@in_vchFromItem + ' to ' + @in_vchToItem + '.'
        GOTO ExitLabel
    END

    -- create temp table for holding pick details grouped as per order release
    CREATE TABLE #t_items (
	   id              INT IDENTITY(1,1) NOT NULL,
	   item_number     NVARCHAR(30)      COLLATE DATABASE_DEFAULT NOT NULL,
	   work_q_id       NVARCHAR(30)      COLLATE DATABASE_DEFAULT NULL,
	   wh_id           NVARCHAR(10)      COLLATE DATABASE_DEFAULT NOT NULL
       )


    -- Print a trace level log message.
    IF @v_nLogLevel >= 5  PRINT 'Query to fill #t_items about to be executed: '

    --  Fill #t_items for cycle count requests that do not already exist
    INSERT #t_items (item_number, wh_id)
	    SELECT DISTINCT itm.item_number, itm.wh_id
		    FROM t_item_master itm
				 LEFT JOIN t_work_q wkq
				 ON (itm.item_number = wkq.item_number
				     AND itm.wh_id = wkq.wh_id
					 AND wkq.work_type = '08'
					 AND wkq.work_status <> 'C')
			WHERE itm.wh_id = @in_vchWhID
				AND itm.item_number >= @in_vchFromItem
				AND itm.item_number <= @in_vchToItem
				AND wkq.work_q_id is NULL

    -- Print a trace level log message.
    IF @v_nLogLevel >= 4        
      BEGIN
          PRINT 'After filling temp table #t_items: '
          SELECT * from #t_items
      END 

    -- Count number of groups in order to determine how many Work Q ID's to get
    SELECT @n_Count = COUNT(*) FROM #t_items

    -- Check to se that records were found to release
    IF @n_Count = 0 
    	BEGIN
        	SET @v_vchErrorMsg = 'No New Cycle Count requests created for Items from: ' + 
					@in_vchFromItem + ' to ' + @in_vchToItem + '.'
       		SET @v_nLogErrorNum = @e_MissingITMError
       		GOTO ErrorHandler
    	END

    -- Increment the t_control WORK_Q_ID entry for the number of Work Q's needed
    BEGIN TRAN

        SET @n_Range = @n_Count


        EXEC @v_nReturn = usp_get_next_value_range @in_vchType = 'WORK_Q_ID', @in_nIncrement = @n_Range ,
                      @out_nUIDFirst = @n_StartWKQ OUTPUT, @out_nUIDLast = 	@n_FinishWKQ OUTPUT ,
                      @out_nErrorNumber = @v_nErrorNumber OUTPUT, @out_vchLogMsg = @v_vchOutMsg OUTPUT
    	-- Check for errors
        IF @v_nReturn <> 0
	        BEGIN
	            ROLLBACK TRAN
	            SET @v_vchErrorMsg = @v_vchOutMsg
	            SET @v_nLogErrorNum = @e_GetWKQRangeError
		        GOTO ErrorHandler
	        END
        ELSE
	        BEGIN	
		        COMMIT
	        END

    -- Print a trace level log message.
    IF @v_nLogLevel >= 5  PRINT 'Starting WKQ: ' + CAST(@n_StartWKQ as NVARCHAR(20)) +
							    ' Ending WKQ: ' + CAST((@n_FinishWKQ)as NVARCHAR(20))

    --decrement starting work q becuse the first id in the table is 1
    SET @n_StartWKQ = @n_StartWKQ - 1

    -- Update #t_pick_d_work with the Work Q ID's that have been reserved
    UPDATE itt
    	SET itt.work_q_id = (itt.id + @n_StartWKQ)
    	FROM #t_items itt

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
    	BEGIN
        	SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
       	     'the exact nature of the error.'
       		SET @v_nLogErrorNum = @e_GenSqlError
       		GOTO ErrorHandler
    	END
    -- Check for Number of rows affected.
    IF @v_nRowCount = 0
	    BEGIN
	        SET @v_vchErrorMsg = 'Failed to update temp table with Work Q ID''s, '
	        SET @v_nLogErrorNum = @e_SetWKQTempError
	        GOTO ErrorHandler
	    END

    -- Create Work Q entries from PKD with a PRERLSE status.
    INSERT t_work_q (work_q_id, work_type, description, priority, date_due, time_due, wh_id, 
					item_number, work_status, qty, workers_required, workers_assigned)
    	SELECT itt.work_q_id, '08' , 'Cycle Count Item' , '50', GETDATE(), GETDATE(), itt.wh_id,
			   itt.item_number, 'U', 0, 1 , 0
			FROM #t_items itt

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    -- Check for any errors. If so, error number will not be equal to zero.
    IF @v_nErrorNumber <> 0
        BEGIN
            SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
                'the exact nature of the error.'
            SET @v_nLogErrorNum = @e_GenSqlError
            GOTO ErrorHandler
        END
        -- Check for Number of rows affected.
    IF @v_nRowCount = 0
        BEGIN
            SET @v_vchErrorMsg = 'Failed to insert t_work_q records for Cycle Counts. '
            SET @v_nLogErrorNum = @e_AddWKQError
            GOTO ErrorHandler
        END

    DROP TABLE #t_items

    SELECT CAST(@n_Count AS NVARCHAR(10)) + ' New Cycle Count requests created for Items from: ' + 
					@in_vchFromItem + ' to ' + @in_vchToItem + '.'

	GOTO ExitLabel


ErrorHandler:
    -- Log the error message in ADV.t_log
--   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- Raise the error with error message, severity, state
--     SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
--         + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
--         + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    
	
    SET @v_nReturn = @v_nLogErrorNum

    IF @v_nTranCount > 0
        ROLLBACK TRANSACTION

ExitLabel:
    -- Always leave the stored procedure from here.
    RETURN @v_nReturn

