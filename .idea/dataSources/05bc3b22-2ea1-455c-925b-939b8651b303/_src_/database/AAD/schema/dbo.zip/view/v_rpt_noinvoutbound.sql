CREATE VIEW dbo.v_rpt_noinvoutbound
AS
SELECT   od.wh_id, wh.name AS wh_name, od.order_number, CONVERT(CHAR(10), od.order_date, 120) AS order_date, 
                od.ship_to_code, ctm.customer_name AS ship_to_name, odl.line_number, odl.item_number, item.description, item.uom, 
                odl.qty, CASE WHEN tc.short_name IS NULL 
                THEN tc.customer_name ELSE tc.short_name END AS customer_name
FROM      dbo.t_order AS od INNER JOIN
                dbo.t_order_detail AS odl WITH (NOLOCK) ON od.wh_id = odl.wh_id AND 
                od.order_number = odl.order_number INNER JOIN
                dbo.t_item_master AS item WITH (NOLOCK) ON odl.wh_id = item.wh_id AND 
                odl.item_number = item.item_number INNER JOIN
                dbo.t_whse AS wh WITH (NOLOCK) ON od.wh_id = wh.wh_id LEFT OUTER JOIN
                dbo.t_customer AS ctm WITH (NOLOCK) ON od.ship_to_code = ctm.customer_code AND 
                od.wh_id = ctm.wh_id LEFT OUTER JOIN
                dbo.t_customer AS tc WITH (NOLOCK) ON od.customer_id = tc.customer_id
