
CREATE VIEW dbo.v_alp_ship
AS
SELECT 
      car.flagship_carrier_code 
    , mcr.flagship_service_code
    , sva.flagship_ship_via_code 
    , pkd_cntr.container_id
    , orm.cust_po_number
    , orm.wh_id
    , orm.ship_to_name
    , mrd.ship_to_attention   
    , orm.ship_to_addr1 
    , orm.ship_to_addr2 
    , orm.ship_to_addr3
    , orm.ship_to_city  
    , orm.ship_to_state
    , orm.ship_to_zip
    , orm.ship_to_country_code 
    , orm.ship_to_phone
    , orm.freight_terms
    , mrd.sat_delivery_flag 
    , orm.ship_to_residential_flag 
    , mrd.registered_mail_flag 
    , mrd.restricted_mail_flag 
    , container_weight
    , CASE WHEN pct.container_type = 'UOM' THEN COALESCE(itu.length,0)
          ELSE COALESCE(cnt.full_length,0) END length
    , CASE WHEN pct.container_type = 'UOM' THEN COALESCE(itu.height,0)
          ELSE COALESCE(cnt.full_height,0) END height
    , CASE WHEN pct.container_type = 'UOM' THEN COALESCE(itu.width,0)
          ELSE COALESCE(cnt.full_width,0) END width
    , mrd.cod_flag 
    , mrd.cod_amount 
    , mrd.cod_pay_type 
    , mrd.cod_option
    , mrd.insurance_flag
    , insurance_amount 
    , pnt.printer_ip
    , pnt.printer_port
    , pnt.flagship_type
    , orm.bill_frght_to_name 
    , mrd.bill_frght_to_attention 
    , orm.bill_frght_to_addr1 
    , orm.bill_frght_to_addr2 
    , orm.bill_frght_to_addr3 
    , orm.bill_frght_to_city 
    , orm.bill_frght_to_state 
    , orm.bill_frght_to_zip 
    , orm.bill_frght_to_country_code
    , orm.bill_frght_to_phone
    , pkd_cntr.status
FROM     
    (SELECT 
            pkd.container_id
          , pkd.manifest_batch_id 
          , pkd.wh_id
          , mbq.status
          , SUM (pkd.planned_quantity * itm.unit_weight) container_weight                   
     FROM 
          t_pick_detail pkd
          INNER JOIN t_item_master itm 
          ON  itm.item_number = pkd.item_number
          AND itm.wh_id = pkd.wh_id
          INNER JOIN t_manifest_batch_queue mbq
               ON mbq.manifest_batch_id = pkd.manifest_batch_id
     WHERE pkd.container_id IS NOT NULL 
       AND pkd.manifest_batch_id IS NOT NULL
     GROUP BY pkd.container_id
            , pkd.manifest_batch_id
            , mbq.status
            , pkd.wh_id
     ) pkd_cntr
     --pick the (virtually) largest size set of the items in the container
     INNER JOIN (SELECT 
                       MAX(itu2.length) length 
                     , MAX(itu2.width)  width  
                     , MAX(itu2.height) height 
                     , pkd2.container_id
                     , pkd2.manifest_batch_id
                     , pkd2.wh_id
                 FROM t_pick_detail pkd2
                      JOIN t_item_uom itu2
                      ON  itu2.wh_id = pkd2.wh_id
                      AND itu2.item_number = pkd2.item_number
                 GROUP BY 
                       pkd2.container_id 
                     , pkd2.manifest_batch_id
                     , pkd2.wh_id
                 ) itu
     ON    itu.container_id = pkd_cntr.container_id
       AND itu.manifest_batch_id = pkd_cntr.manifest_batch_id 
       AND itu.wh_id = pkd_cntr.wh_id
     --for each container, select a single order for shipping information
     ----assumes one to many orders per container 
     INNER JOIN (SELECT 
                       MAX(order_number) order_number
                     , pkd2.container_id
                     , pkd2.manifest_batch_id
                     , pkd2.wh_id
                 FROM t_pick_detail pkd2
                 GROUP BY 
                       pkd2.container_id 
                     , pkd2.manifest_batch_id
                     , pkd2.wh_id
                 ) pkd_orm
     ON    pkd_orm.container_id = pkd_cntr.container_id
       AND pkd_orm.manifest_batch_id = pkd_cntr.manifest_batch_id 
       AND pkd_orm.wh_id = pkd_cntr.wh_id
     --select a pick area with a printer
     INNER JOIN (SELECT
                       MAX(pkd2.pick_area) pick_area
                     , pkd2.container_id
                     , pkd2.manifest_batch_id
                     , pkd2.wh_id
                 FROM t_pick_detail pkd2
                      INNER JOIN t_pick_area pka2
                      ON     pka2.pick_area = pkd2.pick_area
                         AND pka2.wh_id = pkd2.wh_id  
                 WHERE pka2.default_printer IS NOT NULL
                 GROUP BY 
                       pkd2.container_id 
                     , pkd2.manifest_batch_id
                     , pkd2.wh_id
                 ) pkd_pka
     ON    pkd_pka.container_id = pkd_cntr.container_id
       AND pkd_pka.manifest_batch_id = pkd_cntr.manifest_batch_id 
       AND pkd_pka.wh_id = pkd_cntr.wh_id
     INNER JOIN t_pick_area pka
     ON (pkd_pka.pick_area = pka.pick_area AND pkd_pka.wh_id = pka.wh_id)
     INNER JOIN t_printer pnt
     ON (pka.default_printer = pnt.printer_id AND pka.wh_id = pnt.wh_id)
     INNER JOIN t_order orm
     ON    orm.order_number = pkd_orm.order_number
       AND orm.wh_id = pkd_cntr.wh_id
     INNER JOIN t_order_manifest mrd
     ON  orm.order_id = mrd.order_id               
	 LEFT JOIN t_pick_container pct
     ON	   (pkd_cntr.container_id = pct.container_id AND pkd_cntr.wh_id = pct.wh_id)
     LEFT JOIN t_container cnt
     ON    (pct.container_type = cnt.container_type AND pct.wh_id = cnt.wh_id)
     LEFT JOIN t_carrier car
     ON (orm.carrier_id = car.carrier_id)
     LEFT JOIN t_manifest_carrier mcr
     ON (orm.manifest_carrier_id = mcr.manifest_carrier_id)
     LEFT JOIN t_ship_via sva
     ON (orm.ship_via_id = sva.ship_via_id)
