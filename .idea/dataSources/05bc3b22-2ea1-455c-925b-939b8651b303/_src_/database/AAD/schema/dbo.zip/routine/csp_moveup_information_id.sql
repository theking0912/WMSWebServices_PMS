
CREATE PROCEDURE [dbo].[csp_moveup_information_id]
   @in_Information_Collection_ID INT
 , @in_Information_ID  INT
AS
DECLARE 
   @n_Seq INT
 , @n_SeqUp INT
 , @n_InforID INT

SET NOCOUNT ON

SELECT @n_Seq = Coalesce(sequence_id,1)
FROM tbl_information_collection_detail
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @in_Information_ID

IF @n_Seq = 1 GOTO ExitLabel;
SET @n_SeqUp = @n_Seq-1

SELECT @n_InforID = information_id
FROM tbl_information_collection_detail
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND sequence_id = @n_SeqUp

UPDATE tbl_information_collection_detail 
  SET sequence_id = @n_SeqUp
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @in_Information_ID

UPDATE tbl_information_collection_detail 
  SET sequence_id = @n_Seq
WHERE 
     information_collection_id = @in_Information_Collection_ID
 AND information_id = @n_InforID

ExitLabel:
    RETURN
