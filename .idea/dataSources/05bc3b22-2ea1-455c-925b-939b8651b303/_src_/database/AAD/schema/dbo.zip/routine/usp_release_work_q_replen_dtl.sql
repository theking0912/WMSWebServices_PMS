
CREATE PROCEDURE usp_release_work_q_replen_dtl
    @in_OrderNumber     AS NVARCHAR(20) = NULL,  -- order specific release not supported yet
    @in_LoadNumber      AS NVARCHAR(20) = NULL,  -- load specific release not supported yet
    @in_WaveNumber      AS NVARCHAR(20) = NULL,
    @in_ItemNumber      AS NVARCHAR(30) = NULL,  -- item specific release not supported yet
    @in_LotNumber       AS NVARCHAR(15) = NULL,  -- lot specific release not supported yet
    @in_PickArea        AS NVARCHAR(10) = 'ALL',
    @in_chWorkType      AS NVARCHAR(2),             -- NOTE: This is the WKQ.work_type, not PKD.type
    @in_WHID            AS NVARCHAR(10) = '01',
    @in_nResultsFlag    AS INTEGER              -- 1 means return results;  0 means don't return results

AS

DECLARE
-- Error handling and logging variables.
@c_nModuleNumber            INTEGER, -- The # that uniquely tags the WA collection of objects.
@c_nFileNumber              INTEGER, -- The # that uniquely tags this object.
@c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
@v_nLogErrorNum             INTEGER, -- The # that uniquely tags the error message.
@v_nLogLevel                INTEGER, -- Holds log level (1-5).
@v_vchErrorMsg              NVARCHAR(500),
@v_vchOutMsg                NVARCHAR(500),
@v_nSysErrorNum             INTEGER,
@v_nSysRowCount             INTEGER,
@v_nReturn                  INTEGER,
@v_nCount                   INTEGER,
@v_nTranCount               INTEGER,

-- Log Error numbers used for branching in the Error Handler.
@e_GenSqlError              INTEGER,
@e_SprocError               INTEGER,
@e_MissingITMError          INTEGER,
@e_TControlError            INTEGER,
@e_BeforePickError          INTEGER,
@e_GetWKQRangeError         INTEGER,
@e_SetWKQTempError          INTEGER,
@e_SetWKQIDError            INTEGER,
@e_InsWKQError              INTEGER,
@e_UpdPKDError              INTEGER,

-- Local Variables
@v_nStartWKQ                INTEGER,
@v_nFinishWKQ               INTEGER,
@v_nRange                   INTEGER

SET NOCOUNT ON

-- Set Constants
SET @c_nModuleNumber = 60     -- Always #60 for WA.
SET @c_nFileNumber = 7        -- This # must be unique per object.
SET @c_vchObjName = 'usp_release_work_q_replen_dtl'

-- Log/Local Error Constants
SET @e_GenSqlError = 1
SET @e_SprocError = 2
SET @e_MissingITMError = 3
SET @e_TControlError = 4
SET @e_BeforePickError = 5
SET @e_GetWKQRangeError = 6
SET @e_SetWKQTempError = 7
SET @e_InsWKQError = 8
SET @e_UpdPKDError = 9

-- Intialize Variables
SET @v_nReturn = 0
SET @v_nCount = 0

-- Grab the database object log level.
EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
IF @v_nReturn <> 0 -- A zero means success.
BEGIN
    SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
    	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
    SET @v_nLogErrorNum = @e_SprocError
    GOTO ERROR_HANDLER
END

-- Print a trace level log message.
IF @v_nLogLevel >= 5
    PRINT @c_vchObjName + ': Paramters passed: Order Number ['   + ISNULL(@in_OrderNumber,'(NULL)') +
                                             '], Load Number ['  + ISNULL(@in_LoadNumber,'(NULL)') +
                                             '], Wave Number ['  + ISNULL(@in_WaveNumber,'(NULL)') +
                                             '], Pick Area ['    + ISNULL(@in_PickArea,'(NULL)') +
                                             '], Item Number ['  + ISNULL(@in_ItemNumber,'(NULL)') +
                                             '], Lot Number ['   + ISNULL(@in_LotNumber,'(NULL)') +
                                             '], Work Type ['    + ISNULL(@in_chWorkType,'(NULL)') +
                                             '], Warehouse ID [' + ISNULL(@in_WHID,'(NULL)') + ']'

-----------------------------------------------------------------------------------
--   Create/fill temp table for holding pick details
-----------------------------------------------------------------------------------
CREATE TABLE #t_pick_d_work (
   id                   INT IDENTITY(1,1) NOT NULL,
   work_q_id            NVARCHAR(30)      COLLATE DATABASE_DEFAULT  NULL,
   load_work_q_id       NVARCHAR(30)      COLLATE DATABASE_DEFAULT  NULL,
   audit_work_q_id      NVARCHAR(30)      COLLATE DATABASE_DEFAULT  NULL,
   ship_work_q_id       NVARCHAR(20)      COLLATE DATABASE_DEFAULT  NULL,
   order_number         NVARCHAR(30)      COLLATE DATABASE_DEFAULT  NOT NULL,
   load_id              NVARCHAR(30)      COLLATE DATABASE_DEFAULT  NULL,
   wave_id              NVARCHAR(30)      COLLATE DATABASE_DEFAULT  NULL,
   pick_area            NVARCHAR(10)      COLLATE DATABASE_DEFAULT  NULL,
   status               NVARCHAR(20)      COLLATE DATABASE_DEFAULT  NULL,
   staging_location     NVARCHAR(50)      COLLATE DATABASE_DEFAULT  NOT NULL,
   item_number          NVARCHAR(30)      COLLATE DATABASE_DEFAULT  NOT NULL,
   wh_id                NVARCHAR(10)      COLLATE DATABASE_DEFAULT  NOT NULL
   )

-- Print a trace level log message.
IF @v_nLogLevel >= 5
    PRINT @c_vchObjName + ': Query to fill #t_pick_d_work about to be executed: '

--  Fill #t_pick_d_work for picks
INSERT #t_pick_d_work
    (
    work_q_id, load_work_q_id, audit_work_q_id, ship_work_q_id,
    order_number, load_id, wave_id, pick_area,
    status, staging_location, item_number, wh_id
    )
SELECT
    NULL, NULL, NULL, NULL,
    MIN(tmp.order_number), MIN(tmp.load_id), MIN(tmp.wave_id), MIN(tmp.pick_area),
    MIN(tmp.status), tmp.staging_location, tmp.item_number, tmp.wh_id
FROM
    #tmp_pick_details_to_update tmp
WHERE
    tmp.status = 'CREATED'
    AND ((tmp.order_number = @in_OrderNumber) OR (@in_OrderNumber is NULL)
          OR (@in_OrderNumber = 'ALL'))
    AND ((tmp.load_id = @in_LoadNumber) OR (@in_LoadNumber is NULL)
          OR (@in_LoadNumber = 'ALL'))
    AND ((tmp.wave_id = @in_WaveNumber) OR (@in_WaveNumber is NULL)
          OR (@in_WaveNumber = 'ALL'))
    AND ((tmp.item_number = @in_ItemNumber) OR (@in_ItemNumber is NULL)
          OR (@in_ItemNumber = 'ALL'))
    AND ((tmp.lot_number = @in_LotNumber) OR (@in_LotNumber is NULL)
          OR (@in_LotNumber = 'ALL'))
    AND ((tmp.pick_area = @in_PickArea) OR (@in_PickArea is NULL)
          OR (@in_PickArea = 'ALL'))
    AND tmp.wh_id = @in_WHID
    AND tmp.type = 'RP' -- Replenishments
    AND tmp.work_type = @in_chWorkType
GROUP BY
    tmp.wh_id,
    tmp.work_type,
    tmp.staging_location,    tmp.item_number,
    tmp.pick_area

SELECT @v_nSysErrorNum = @@ERROR, @v_nCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    SET @v_nLogErrorNum = @e_GenSqlError
    GOTO ERROR_HANDLER
END

-- Print a trace level log message.
IF @v_nCount = 0
   GOTO RESULTS

-----------------------------------------------------------------------------------
--   Increment the t_control WORK_Q_ID entry for the number of Work Q's needed
-----------------------------------------------------------------------------------
BEGIN TRANSACTION

    SET @v_nRange = @v_nCount

    EXECUTE @v_nReturn = usp_get_next_value_range @in_vchType = 'WORK_Q_ID', @in_nIncrement = @v_nRange,
                  @out_nUIDFirst = @v_nStartWKQ OUTPUT, @out_nUIDLast = @v_nFinishWKQ OUTPUT,
                  @out_nErrorNumber = @v_nSysErrorNum OUTPUT, @out_vchLogMsg = @v_vchOutMsg OUTPUT

    -- Check for errors
    IF @v_nReturn <> 0
        BEGIN
            ROLLBACK TRAN
            SET @v_vchErrorMsg = @c_vchObjName + ': (usp_get_next_value_range): ' + @v_vchOutMsg
            SET @v_nLogErrorNum = @e_GetWKQRangeError
            GOTO ERROR_HANDLER
        END
    ELSE
        BEGIN
            COMMIT
        END

-- Print a trace level log message.
IF @v_nLogLevel >= 5  PRINT 'Starting WKQ: ' + CAST(@v_nStartWKQ as NVARCHAR(20)) +
                            ' Ending WKQ: ' + CAST((@v_nFinishWKQ)as NVARCHAR(20))

-- Decrement starting work q becuse the first id in the table is 1
SET @v_nStartWKQ = @v_nStartWKQ - 1

-----------------------------------------------------------------------------------
--     Update #t_pick_d_work with the Work Q ID's that have been reserved
-----------------------------------------------------------------------------------
UPDATE
    #t_pick_d_work
SET
    work_q_id = (id + @v_nStartWKQ)
FROM
    #t_pick_d_work

SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    SET @v_nLogErrorNum = @e_GenSqlError
    GOTO ERROR_HANDLER
END
IF @v_nSysRowCount = 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': Failed to update temp table with Work Q IDs for work '
        + 'type [' + @in_chWorkType + '] Replenishments.'
    SET @v_nLogErrorNum = @e_SetWKQTempError
    GOTO ERROR_HANDLER
END

-- Print a trace level log message.
IF @v_nLogLevel >= 4
BEGIN
    PRINT @c_vchObjName + ': After updating #t_pick_d_work with WKQ IDs:'
    SELECT * from #t_pick_d_work
END

-----------------------------------------------------------------------------------
--     Update t_pick_detail with the Work Q ID's that have been created
-----------------------------------------------------------------------------------
UPDATE
    tmp
SET
    tmp.work_q_id = pdw.work_q_id,
    tmp.status = 'RELEASED'
FROM
    #tmp_pick_details_to_update tmp,
    #t_pick_d_work pdw
WHERE
    tmp.status = 'CREATED'
    AND ((tmp.order_number = pdw.order_number) OR
           (@in_OrderNumber IS NULL) OR (@in_OrderNumber = 'ALL'))
    AND ((tmp.load_id = pdw.load_id) OR
           (@in_LoadNumber IS NULL) OR (@in_LoadNumber = 'ALL'))
    AND ((tmp.wave_id = pdw.wave_id) OR
           (@in_WaveNumber is NULL) OR (@in_WaveNumber = 'ALL'))
    AND tmp.staging_location = pdw.staging_location
    AND tmp.item_number = pdw.item_number
    AND ((ISNULL(tmp.pick_area,0) = ISNULL(pdw.pick_area,0)) OR
           (@in_PickArea IS NULL))
    AND tmp.wh_id = pdw.wh_id

SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    SET @v_nLogErrorNum = @e_GenSqlError
    GOTO ERROR_HANDLER
END
IF @v_nCount = 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': Failed to update t_pick_detail table with Work Q IDs for work '
        + 'type [' + @in_chWorkType + '] Replenishments.'
    SET @v_nLogErrorNum = @e_UpdPKDError
    GOTO ERROR_HANDLER
END

-----------------------------------------------------------------------------------
--           Create Work Q entries from PKD with a RELEASED status
-----------------------------------------------------------------------------------

-- The case below determines which default priority is greater either the t_work_types
-- or the t_fwd_picks.

INSERT t_work_q
    (
    work_q_id,
    work_type,
    priority,
    description,
    date_due,
    time_due,
    wh_id,
    work_status,
    workers_required,
    workers_assigned
    )
SELECT
    tmp.work_q_id,
    tmp.work_type,
    CASE WHEN (MIN(wkt.default_priority) > MIN(fwd.default_priority))
         THEN MIN(wkt.default_priority)
         ELSE MIN(fwd.default_priority)
    END,
    MIN(wkt.description),
    GETDATE(),
    GETDATE(),
    tmp.wh_id,
    'U',
    1,
    0
FROM
    #tmp_pick_details_to_update tmp,
    t_work_types wkt,
    t_fwd_pick fwd,
    #t_pick_d_work pdw
WHERE
    tmp.status = 'RELEASED'
    AND tmp.work_type = wkt.work_type
    AND tmp.wh_id = wkt.wh_id
    AND tmp.work_q_id = pdw.work_q_id
    AND tmp.staging_location = fwd.location_id
    AND tmp.item_number = fwd.item_number
    AND tmp.wh_id = fwd.wh_id
GROUP BY
    tmp.work_q_id,
    tmp.work_type,
    tmp.wh_id,
    tmp.pick_area

SELECT @v_nSysErrorNum = @@ERROR, @v_nSysRowCount = @@ROWCOUNT
IF @v_nSysErrorNum <> 0
BEGIN
    SET @v_vchErrorMsg = @c_vchObjName + ': A SQL Server error [' + CONVERT(VARCHAR(30), @v_nSysErrorNum)
        + '] occured.  Check SQL Server System Log, Application Status Console, etc.'
    SET @v_nLogErrorNum = @e_GenSqlError
    GOTO ERROR_HANDLER
END
IF @v_nSysRowCount = 0
BEGIN
    SET @v_vchErrorMsg = 'Failed to insert t_work_q records for work type [' + @in_chWorkType
        + '] Replenishments. '
    SET @v_nLogErrorNum = @e_InsWKQError
    GOTO ERROR_HANDLER
END

-- Clean up temporary tables here because this temporary table won't be created when there are no PKDs.
DROP TABLE #t_pick_d_work

-----------------------------------------------------------------------------------
--                   Return message if called from WebWise                       --
-----------------------------------------------------------------------------------
RESULTS:
IF @v_nCount =  0
BEGIN
    IF @in_nResultsFlag = 1
        SELECT 'No Records to Release for Criteria Provided!' AS message
    GOTO EXIT_LABEL
END
ELSE
    IF @in_nResultsFlag = 1
        SELECT 'Replenishment Release Successful for Work Type [' + @in_chWorkType + ']!' AS message

GOTO EXIT_LABEL

-----------------------------------------------------------------------------------
--                            Error Handling Code                                --
-----------------------------------------------------------------------------------
ERROR_HANDLER:
-- Log the error message in ADV.t_log
EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1

-- Raise the error with error message, severity, state
SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
    + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
    + ' ERROR [' + @v_vchErrorMsg + ']'
RAISERROR(@v_vchErrorMsg, 11, 1)

SET @v_nReturn = @v_nLogErrorNum

IF @v_nTranCount > 0
    ROLLBACK TRANSACTION

-----------------------------------------------------------------------------------
--                            Exit the Process                                   --
-----------------------------------------------------------------------------------
EXIT_LABEL:
-- Always leave the stored procedure from here.
RETURN @v_nReturn


