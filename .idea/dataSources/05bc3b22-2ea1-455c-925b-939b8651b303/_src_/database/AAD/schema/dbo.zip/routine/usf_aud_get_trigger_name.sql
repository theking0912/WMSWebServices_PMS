
CREATE FUNCTION usf_aud_get_trigger_name(
                   @in_vchTableName     VARCHAR(100), -- Name of the table the trigger will be created for
                   @in_vchTriggerPrefix VARCHAR(20)   -- Prefix for the trigger, e.g. 'ti_' for insert trigger
                   )
RETURNS VARCHAR(100)
AS 
BEGIN
    DECLARE    @c_nMaxLength       INT,               -- max length for trigger name
               @c_vchTablePrefix   VARCHAR(20),       -- prefix of all tables
               @v_vchTriggerName   VARCHAR(100),      -- return variable
               @v_nCounter         INT;

    SET @c_nMaxLength     = 30;    -- to be identical with Oracle. 30 is the limit for object names in Oracle.
    SET @c_vchTablePrefix = 't_';  -- standard table prefix for HighJump tables


    IF (LEFT(@in_vchTableName, LEN(@c_vchTablePrefix)) = @c_vchTablePrefix)  
      SET @v_vchTriggerName = @in_vchTriggerPrefix 
                            + SUBSTRING(@in_vchTableName, 
                                        LEN(@c_vchTablePrefix)+1, 
                                        @c_nMaxLength - LEN(@in_vchTriggerPrefix));
    ELSE /* don't cut off beginning of table names */
      SET @v_vchTriggerName = @in_vchTriggerPrefix 
                            + SUBSTRING(@in_vchTableName, 
                                        1, 
                                        @c_nMaxLength);
      
    
    /* check if trigger yet exists for a different table and add a tailing number to the name */
    SET @v_nCounter = 1;
    WHILE EXISTS (SELECT 1 
                    FROM sys.triggers
                   WHERE parent_id IN (SELECT object_id
                                         FROM sys.tables
                                        WHERE name <> @in_vchTableName)
                     AND name = @v_vchTriggerName) 
      BEGIN
        IF @v_nCounter = 1
          SET @v_vchTriggerName = SUBSTRING(@v_vchTriggerName, 
                                            1,
                                            @c_nMaxLength - 1)
                                + CONVERT(VARCHAR,@v_nCounter)
        ELSE
          SET @v_vchTriggerName = SUBSTRING(@v_vchTriggerName, 
                                            1, 
                                            LEN(@v_vchTriggerName) - LEN(@v_nCounter))
                                + CONVERT(VARCHAR,@v_nCounter)
        SET @v_nCounter = @v_nCounter + 1;
      END

    RETURN(@v_vchTriggerName)
END 




