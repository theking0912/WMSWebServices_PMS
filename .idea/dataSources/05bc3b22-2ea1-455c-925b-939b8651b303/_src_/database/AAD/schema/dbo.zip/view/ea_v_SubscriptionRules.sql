
CREATE VIEW dbo.ea_v_SubscriptionRules AS
SELECT DISTINCT
    s.subscription_id,
    s.userid,
    s.alert_id,
    ag.filter_id as alertgroup_filter_id,
    s.filter_id as subscription_filter_id, 
    s.notifyprofile_id,
    r.transportconfig_id,
    r.sunday,
    r.monday,
    r.tuesday,
    r.wednesday,
    r.thursday,
    r.friday,
    r.saturday,
    r.begin_time,
    r.end_time,
    t.transport_type,
    t.pager_type,
    at.priority
FROM
    ea_t_subscription s,
    ea_t_notifyprofile n,
    ea_t_notifyprofile_rule r,
    ea_t_transportconfig t,
    ea_t_alert_transport at,
    ea_t_user u,
    ea_t_alert a,
    ea_t_alertgroup g,
    ea_t_alert_alertgroup ag,
    ea_t_user_alertgroup ug
WHERE
    s.notifyprofile_id = n.notifyprofile_id AND
    n.notifyprofile_id = r.notifyprofile_id AND
    r.transportconfig_id = t.transportconfig_id AND
    s.userid = u.userid AND
    n.userid = u.userid AND
    t.userid = u.userid AND
    s.alert_id = at.alert_id AND
    s.active = 1 AND
    n.active = 1 AND
    r.active = 1 AND
    t.active = 1 AND
    at.active = 1 AND
    at.transport_type = t.transport_type AND
    s.alert_id = a.alert_id AND
    a.alert_id = ag.alert_id AND
    u.userid = ug.userid AND
    ag.alertgroup_id = g.alertgroup_id AND
    ug.alertgroup_id = g.alertgroup_id
