
CREATE VIEW v_al_host_order_comment AS
SELECT
host_order_comment_id,
host_group_id,
processing_code,
record_create_date,
wh_id,
order_number,
header_footer,
comment_type,
comment_sequence,
comment_date,
comment_text
  FROM t_al_host_order_comment
