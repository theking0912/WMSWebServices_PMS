CREATE VIEW dbo.View_0423
AS
SELECT   TOP (100) PERCENT o.wh_id, wa.wave_id, list.list_number, ord.earliest_ship_date, o.order_number, 
                ISNULL(cus.short_name, cus.customer_name) AS customer_name, o.line_number, o.item_number, im.description, o.qty, 
                ISNULL(ta.allocated_qty, pd.planned_quantity) /
                    (SELECT   conversion_factor
                     FROM      dbo.t_item_uom
                     WHERE   (uom = o.order_uom) AND (item_number = o.item_number)) AS order_alloqty, ISNULL(ta.picked_qty, 
                pd.picked_quantity) /
                    (SELECT   conversion_factor
                     FROM      dbo.t_item_uom AS t_item_uom_4
                     WHERE   (uom = o.order_uom) AND (item_number = o.item_number)) AS order_pick, 
                ISNULL(ta.allocated_qty - ta.picked_qty, pd.planned_quantity - pd.picked_quantity) /
                    (SELECT   conversion_factor
                     FROM      dbo.t_item_uom AS t_item_uom_3
                     WHERE   (uom = o.order_uom) AND (item_number = o.item_number)) AS order_unpick,
                    (SELECT   uom + '-' + uom_prompt AS Expr1
                     FROM      dbo.t_item_uom AS t_item_uom_2
                     WHERE   (uom = o.order_uom) AND (item_number = o.item_number)) AS order_uom, lk.description AS task_status, 
                ta.zone, ta.location_id, ISNULL(ta.allocated_qty, pd.planned_quantity) AS allocated_qty, ISNULL(ta.picked_qty, 
                pd.picked_quantity) AS picked_qty, ISNULL(ta.allocated_qty - ta.picked_qty, pd.planned_quantity - pd.picked_quantity) 
                AS unpicked_qty,
                    (SELECT   uom + '-' + uom_prompt AS Expr1
                     FROM      dbo.t_item_uom AS t_item_uom_1
                     WHERE   (conversion_factor = '1') AND (item_number = o.item_number)) AS UOM, ta.ref_number, ta.pick_wall_loc, 
                ta.pick_wall_slot, ta.user_assign, ta.lot_number, ISNULL(dbo.csf_get_lookup(N't_pick_detail', N'STATUS', '2052', 
                pd.status), N'新建') AS order_status
FROM      dbo.t_order_detail AS o WITH (NOLOCK) INNER JOIN
                dbo.t_order AS ord WITH (NOLOCK) ON o.order_number = ord.order_number AND o.wh_id = ord.wh_id LEFT OUTER JOIN
                dbo.tbl_allocation AS ta INNER JOIN
                dbo.tbl_pick_list AS list ON ta.seq_id = list.seq_id LEFT OUTER JOIN
                dbo.t_lookup AS lk ON lk.source = 'tbl_allocation' AND lk.lookup_type = 'STATUS' AND lk.text = ta.status AND 
                lk.locale_id = N'2052' ON ta.order_number = o.order_number AND o.item_number = ta.item_number AND 
                ta.line_number = o.line_number LEFT OUTER JOIN
                dbo.t_pick_detail AS pd ON o.order_number = pd.order_number AND o.line_number = pd.line_number AND 
                o.item_number = pd.item_number AND pd.type = 'PP' LEFT OUTER JOIN
                dbo.t_afo_wave_detail AS wa ON o.order_number = wa.order_number AND o.wh_id = wa.wh_id LEFT OUTER JOIN
                dbo.t_customer AS cus ON ord.customer_id = cus.customer_id AND cus.wh_id = o.wh_id INNER JOIN
                dbo.t_item_master AS im ON o.wh_id = im.wh_id AND o.item_number = im.item_number
ORDER BY o.wh_id, o.order_number, o.line_number
