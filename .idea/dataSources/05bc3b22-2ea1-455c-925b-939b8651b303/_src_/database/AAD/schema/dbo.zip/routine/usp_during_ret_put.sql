
CREATE PROCEDURE usp_during_ret_put
@in_vchItem       NVARCHAR(30),
@in_vchLot        NVARCHAR(30),
@in_nQty          INT,
@in_dtFIFODate    DATETIME,
@in_vchForkZone   NVARCHAR(10),
@in_vchWhID       NVARCHAR(10),
@in_nStoAttID     BIGINT,
@in_vchEmpID      NVARCHAR(10),
@in_vchRMA        NVARCHAR(40)

AS
DECLARE
    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @c_vchObjName               NVARCHAR(30), -- The name that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nErrorNumber             INT,
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    
    -- Log Error numbers used for branching in the Error Handler. 
    @e_nGenSqlError             INT,
    @e_nSprocError              INT,
    @e_nItemNotFound            INT,              
    @e_nNoPickPutRules          INT,

    -- Local Variables
    @v_vchRule                  NVARCHAR(30),
    @v_nProfileCntr             INT,
    @v_nNumOfProfiles           INT,
    @v_nNumOfRules              INT,
    @v_nRuleCntr                INT,
    @v_vchLoc					NVARCHAR(50),
    @v_vchDisposition           NVARCHAR(30)

    -- Set Constants
    SET @c_nModuleNumber = 60     -- Always #60 for WA.
    SET @c_nFileNumber = 10        -- This # must be unique per object.
    
    -- Log/Local Error Constants
    SET @e_nGenSqlError = 1
    SET @e_nSprocError = 2
    SET @e_nItemNotFound = 3
    SET @e_nNoPickPutRules  = 4

   -- Set constant values.
   SET @c_vchObjName = 'usp_during_ret_put'

CREATE TABLE #tmp_rule_set
(
   sequence SMALLINT,
   pick_put_rule NVARCHAR(30) COLLATE DATABASE_DEFAULT
) 

  SET NOCOUNT ON

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_nSprocError
        GOTO ErrorHandler			
    END
    
    -- Clear the t_employee.sp_return field used to communicate with the WA application.
    EXECUTE @v_nReturn = usp_clear_emp @in_vchWhID, @in_vchEmpID
    IF @v_nReturn <> 0
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_nSprocError
        GOTO ErrorHandler			
    END
  -- Be sure the item exists in the item master table.
  IF (SELECT COUNT(*) FROM t_item_master WHERE item_number = @in_vchItem) = 0
    BEGIN
        UPDATE t_employee SET sp_return = 'ERR ITM' WHERE id = @in_vchEmpID AND wh_id = @in_vchWhID
        GOTO ExitLabel
    END

  -- Fill the temporary table of rules for the item.
  INSERT INTO #tmp_rule_set (sequence, pick_put_rule)
    SELECT ppd.sequence, ppr.during
      FROM t_pick_put_detail ppd
      INNER JOIN t_pick_put_rules ppr
        ON ppd.rule_id = ppr.rule_id
        AND ppd.type = ppr.type
      INNER JOIN t_item_master itm
        ON ppd.pick_put_id = itm.pick_put_id    
      WHERE ppd.type = 'RET'
        AND itm.item_number = @in_vchItem
        AND itm.wh_id = @in_vchWhID
      ORDER BY ppd.sequence

   -- Get and Set ErrorHandler Variables
   SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
   -- Check for any errors. If so, error number will not be equal to zero.
   IF @v_nErrorNumber <> 0
   BEGIN
       SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
           'the exact nature of the error.'
       SET @v_nLogErrorNum = @e_nGenSqlError
       GOTO ErrorHandler
   END

  IF @v_nRowCount = 0
  BEGIN
    UPDATE t_employee SET sp_return = 'ERR PPID' WHERE id = @in_vchEmpID AND wh_id = @in_vchWhID
    GOTO ExitLabel
  END 
  ELSE
  	SET @v_nNumOfRules = @v_nRowCount

  IF (@v_nLogLevel = 1)
    BEGIN
      PRINT @c_vchObjName + ': Here are the rules for ' + @in_vchItem + ':'
      SELECT * FROM #tmp_rule_set
    END

  SELECT @v_vchDisposition = disposition
    FROM t_returns
    WHERE rma_number = @in_vchRMA
      AND item_number = @in_vchItem
      AND wh_id = @in_vchWhID

  SET @v_nRuleCntr = 1    -- Set the @counter = 1.

  -- Cycle through the set of rules.
  WHILE @v_nNumOfRules >= @v_nRuleCntr
    BEGIN
      -- Find the rule.
      SELECT @v_vchRule = pick_put_rule
        FROM #tmp_rule_set
       WHERE sequence = @v_nRuleCntr

      IF (@v_nLogLevel = 1)
        PRINT @c_vchObjName + ': About to execute rule #' + CONVERT(CHAR(2),@v_nRuleCntr) + ', rule: ' + @v_vchRule

      EXEC @v_vchRule @in_vchItem, @in_vchLot, @in_nQty, @in_dtFIFODate, @in_vchForkZone, @in_vchWhID, @v_vchDisposition, @in_nStoAttID, @v_vchLoc OUTPUT  -- Execute the rule!

       -- Get and Set ErrorHandler Variables
       SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
       -- Check for any errors. If so, error number will not be equal to zero.
       IF @v_nErrorNumber <> 0
       BEGIN
           SET @v_vchErrorMsg = 'Called stored procedure: ' + @v_vchRule + ' Failed!  Check SQL Server System Log for ' +
               'the exact nature of the error.'
           SET @v_nLogErrorNum = @e_nSprocError
           GOTO ErrorHandler
       END

      IF @v_vchLoc IS NOT NULL  -- Was a location was found?
        BEGIN
          UPDATE t_employee  -- Update the table and the application will SELECT it.
            SET sp_return = @v_vchLoc
            WHERE id = @in_vchEmpID
              AND wh_id = @in_vchWhID

          IF (@v_nLogLevel = 1)
            PRINT @c_vchObjName + ': Found location: ' + ISNULL(@v_vchLoc,' ')

          -- You have successfully found a location, leave this loop.
          BREAK
        END

    --  Note: Currently the Engine doesn't allow output parameters in stored procs,
    --  so for the sake of consistancy with Oracle we write the location to the
    --  EMP.sp_return field and select it in the app.

    -- Increment the counter if a location was not found.
    SET @v_nRuleCntr = @v_nRuleCntr + 1
  END

  GOTO ExitLabel

ErrorHandler:

   -- Log the error message in ADV.t_log
   -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nLogErrorNum, 1, @v_vchErrorMsg, 1
    
    -- This is the application's way of knowing there was an error in this sproc.  Be sure the app
    -- looks at this field immediately after running the sproc.
    UPDATE t_employee SET sp_return = 'PROC ERROR' WHERE id = @in_vchEmpID AND @in_vchWhID = wh_id
    
    -- Raise the error with error message, severity, state
    SET @v_vchErrorMsg = 'SQL STORED PROCEDURE ' + CONVERT(VARCHAR(3),@c_nModuleNumber) + '-'
        + CONVERT(VARCHAR(3),@c_nFileNumber) + '-' + CONVERT(VARCHAR(3),@v_nLogErrorNum)
        + ' ERROR [' + @v_vchErrorMsg + ']'
    RAISERROR(@v_vchErrorMsg, 11, 1)    

ExitLabel:
  RETURN
