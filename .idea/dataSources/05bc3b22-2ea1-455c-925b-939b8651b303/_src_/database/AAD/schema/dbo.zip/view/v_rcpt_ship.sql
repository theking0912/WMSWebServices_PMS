
CREATE VIEW v_rcpt_ship 
AS
SELECT 
    wh_id, 
    shipment_number, 
    carrier_id, 
    trailer_number, 
    date_expected, 
    date_received, 
    date_shipped, 
    status, 
    comments, 
    workers_assigned, 
    pro_number, 
    wh_id as aux_wh_id, 
    shipment_number as aux_shipment_number 
FROM t_rcpt_ship 
