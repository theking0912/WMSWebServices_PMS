-- ======================================= 
-- Modification: Sep29, 2014 HDL bruce  
-- Description: when po is  'No inventory Purchase Orders',add inventory by PageEdit 

--Oct 2014 modified by Jerry
-- =======================================


CREATE PROCEDURE [dbo].[csp_ImportExcel]
@in_vchPo               NVARCHAR(30),
@in_vchWhID              NVARCHAR(10),
@out_vchMsg             NVARCHAR(200) OUTPUT
AS

DECLARE

    @v_vchSqlErrorNumber    NVARCHAR(50),
    @v_nRowCount            INTEGER,
	@v_nSequence            INTEGER,

	@v_vchPoType            NVARCHAR(10),
	@v_vchItemNumber        NVARCHAR(30),
	@n_vchDescription       NVARCHAR(60),
	@n_vchUom               NVARCHAR(10),
	@in_fQty                FLOAT,  
	@v_LineNumber           INTEGER,
	@v_vchClientCode        NVARCHAR(30),
	@v_vchPo                NVARCHAR(30),
	@v_customer				NVARCHAR(50),
	@v_customer_id			INT ,
	@v_vendor_id				NVARCHAR(50),
	@v_vendor				NVARCHAR(50),
	@v_cnt					INT,
	@v_cnt1					INT ,
	@client_code			NVARCHAR(50)

    SET @v_vchPoType = 'OMO'
	SET @v_nSequence = 0


    SET NOCOUNT ON

	BEGIN TRANSACTION


    WHILE ( 1 = 1 )
        BEGIN
		   
            SELECT TOP 1 @v_vchPo= po_number,@v_customer=customer,@v_vendor=col01,@client_code=col02
		      FROM    tbl_temp_podetail WITH ( NOLOCK )
			 GROUP BY po_number,customer,col01,col02
			 ORDER BY po_number
				 
            SELECT  @v_nRowCount = @@ROWCOUNT
            IF @v_nRowCount = 0
                BEGIN
                  BREAK
                END
			
			SELECT @v_cnt =COUNT(DISTINCT col01),@v_cnt1=COUNT(DISTINCT customer)
		     FROM tbl_temp_podetail WITH ( NOLOCK )
		    WHERE po_number = @v_vchPo

			IF @v_cnt+@v_cnt1>2 
			  BEGIN
			    select @out_vchMsg = '单据'+ @v_vchPo+'出错:'+'同订单对应两个供应商或客户，请检查'
				    break 
			  END 

			select top 1 @v_vendor_id=vendor_id
				from dbo.t_vendor 
				where (vendor_code = @v_vendor OR vendor_name =@v_vendor)

			SELECT  @v_nRowCount = @@ROWCOUNT

			if @v_nRowCount=0 
				begin
				    select @out_vchMsg = '单据'+ @v_vchPo+'出错:'+'未找到对应供应商资料'
				    break 
				end

            INSERT INTO t_po_master(po_number,type_id,vendor_code,create_date,wh_id,status,display_po_number,client_code,
									residential_flag,create_by,locked_flag)
			values(@v_vchPo,'1443',@v_vendor,GETDATE(),@in_vchWhID,'O',@v_vchPo,@client_code,'N','Administrator','N')

			EXEC csp_ImportExcel_IN @v_vchPo,@in_vchWhID,@out_vchMsg output

			if @out_vchMsg is not null 
			   begin
			     select @out_vchMsg = '单据'+ @v_vchPo+'出错:'+@out_vchMsg
			     BREAK
			   end

			--添加杂货出库单
			BEGIN
			  select top 1 @v_customer_id=customer_id
				from dbo.t_customer 
				where (customer_code = @v_customer OR customer_name =@v_customer)

			  SELECT  @v_nRowCount = @@ROWCOUNT

			  if @v_nRowCount=0 
				begin
				  select @out_vchMsg = '单据'+ @v_vchPo+'出错:'+'未找到对应客户资料'
				  break 
				end

				insert into t_order
				(wh_id,order_number,type_id,customer_id,order_date,status,display_order_number,client_code,order_type)
				values
				(@in_vchWhID,@v_vchPo,'9552',@v_customer_id,GETDATE(),'NEW',@v_vchPo,@client_code,'OO')

				SELECT @@IDENTITY

				INSERT  INTO t_order_detail
				( wh_id ,
				  order_id,
				  order_number ,
				  line_number ,
				  item_number ,
				  qty ,
				  order_uom
				)
				select wh_id,@@IDENTITY,po_number,line_number,item_number,qty,'EA'
				  from t_po_detail ta
				 where po_number = @v_vchPo
			 
              SELECT   @v_vchSqlErrorNumber = @@ERROR

			  if @v_vchSqlErrorNumber<>0 
			    begin
				  select @out_vchMsg = '插入出库单出错'
				end

			END

			if @out_vchMsg is not null 
			   begin
			     select @out_vchMsg = '单据'+ @v_vchPo+'出错:'+@out_vchMsg
			     BREAK
			   end

		 
        END   

		IF @out_vchMsg IS NULL 
			BEGIN
				--SET @out_vchMsg = '数据插入成功'

				COMMIT TRANSACTION
			END
		ELSE
		  BEGIN
		   
			 GOTO ErrorHandler
		  END

ErrorHandler:
    RAISERROR(@out_vchMsg,0,0)
    IF @@TRANCOUNT > 0   
	BEGIN
		ROLLBACK TRANSACTION
	END
