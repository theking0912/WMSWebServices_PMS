
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE PROCEDURE [dbo].[csp_Update_huid]
	@wh_id							AS	NVARCHAR(10),
	@hu_id			   	 		    AS	NVARCHAR(30)
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @storage_type			AS	NVARCHAR(10)
	DECLARE @damage_flag		  	AS	NVARCHAR(1)
	declare @item_number            AS  NVARCHAR(30)


	BEGIN TRY
    IF NOT EXISTS(SELECT 1 FROM t_hu_master hu
				WHERE hu.wh_id = @wh_id 
				  AND hu.hu_id = @hu_id)
	BEGIN
		RETURN
	END

	

	BEGIN TRANSACTION


	select top 1 @damage_flag = damage_flag ,@item_number = item_number
	from t_stored_item sto
	where wh_id = @wh_id
	and hu_id = @hu_id

	select @storage_type = storage_type
	from t_item_master 
	where wh_id = @wh_id
	and item_number = @item_number


	update t_hu_master
	set subtype = @damage_flag + @storage_type
	where wh_id = @wh_id
	and hu_id = @hu_id


		COMMIT
		RETURN
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		RETURN
	END CATCH
END

