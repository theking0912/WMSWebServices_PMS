
CREATE TRIGGER tr_t_attribute_behavior_delete ON dbo.t_attribute_behavior
INSTEAD OF DELETE
AS
   DECLARE
      @BehaviorID     INT

      SELECT @BehaviorID = attribute_behavior_id
        FROM deleted

      IF EXISTS (SELECT 1 
          FROM deleted
         WHERE deleted.attribute_behavior_id = @BehaviorID
           AND deleted.attribute_behavior_type = 'DEFAULT' ) 
	    BEGIN 
            RAISERROR('Cannot delete DEFAULT Behavior type', 10, 1)
            ROLLBACK TRANSACTION
            RETURN
	    END
