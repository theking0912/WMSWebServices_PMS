CREATE PROCEDURE [dbo].[csp_afo_delete_wave_data]
@in_vchWarehouseId    NVARCHAR(20),    
@in_vchWaveId         NVARCHAR(60),
@out_vchMessage       NVARCHAR(500) OUTPUT -- Contians "SUCCESS" or the message to be displayed.

AS

DECLARE 
    @v_nErrorNumber       INTEGER,
    @v_vchParam1          NVARCHAR(100),
    @v_vchLogMsg          NVARCHAR(500),
    @v_vchSqlErrorNumber  NVARCHAR(50),
    @v_nRowCount          INTEGER,
 
    @c_nModuleNumber      INTEGER,
    @c_nFileNumber        INTEGER,
    @v_nRaiseErrorNumber  INTEGER,
    @v_nReturn            INTEGER,
    @v_vchErrorMsg        NVARCHAR(500),

    @e_GenSqlError          INTEGER,
    @e_UpdOrderDetailFailed INTEGER,
    @e_DelWVDFailed         INTEGER,
    @e_DelWDLineFailed      INTEGER,
    @v_nTranCount           INTEGER

    SET NOCOUNT ON

    SET @out_vchMessage = 'SUCCESS'
    SET @c_nModuleNumber = 76
    SET @c_nFileNumber = 7

    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_UpdOrderDetailFailed = 2
    SET @e_DelWVDFailed = 3
    SET @e_DelWDLineFailed = 4

 
    SET @v_nTranCount = @@TRANCOUNT --GET THE COUNT OF CURRENT TRANSACTIONS SO WE KNOW WETHER OR NOT TO START OUR OWN

    IF @v_nTranCount = 0 
        BEGIN TRANSACTION

            --Delete wave detail line records associated with the wave
            DELETE FROM t_afo_wave_detail_line
            WHERE wave_detail_id IN 
                 (SELECT wave_detail_id 
                  FROM t_afo_wave_detail wd 
                  WHERE wd.wave_id = @in_vchWaveId
                  AND wd.wh_id = @in_vchWarehouseId
				  and exists (select 1 from tbl_allocation allo
								where wd.wh_id =  allo.wh_id
								and wd.order_number = allo.order_number
								and allo.status = 'H'))
            AND wh_id = @in_vchWarehouseId


            
            --Make sure the update was successful   
            SELECT @v_vchSqlErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
            BEGIN
            IF @v_vchSqlErrorNumber <> 0
                SET @v_nErrorNumber = @e_GenSqlError
            ELSE
                SET @v_nErrorNumber = @e_DelWDLineFailed
            GOTO ErrorHandler                                
            END

            --Delete the wave detail records for the wave
            DELETE FROM t_afo_wave_detail
            WHERE wave_id = @in_vchWaveId
                AND wh_id = @in_vchWarehouseId
				and exists (select 1 from tbl_allocation allo
								where t_afo_wave_detail.wh_id =  allo.wh_id
								and t_afo_wave_detail.order_number = allo.order_number
								and allo.status = 'H')
			
			update t_order
			set status = 'NEW'
			where order_number in (select order_number
									from tbl_allocation
									where wh_id = @in_vchWarehouseId
									and wave_id = @in_vchWaveId
									and status = 'H')
			and wh_id = @in_vchWarehouseId

			DELETE FROM t_pick_detail
			where wh_id = @in_vchWarehouseId
			and wave_id = @in_vchWaveId
			and status = 'H' 

			DELETE FROM t_pick_detail
			where wh_id = @in_vchWarehouseId
			and wave_id = @in_vchWaveId
			and picked_quantity = 0

			delete from tbl_allocation
			where wh_id = @in_vchWarehouseId
			and wave_id = @in_vchWaveId
			and status = 'H'
             
            --Make sure the delete worked.
            IF @v_vchSqlErrorNumber <> 0 OR @v_nRowCount = 0 
            BEGIN
            IF @v_vchSqlErrorNumber <> 0
                SET @v_nErrorNumber = @e_GenSqlError
            ELSE
                SET @v_nErrorNumber = @e_DelWVDFailed
            GOTO ErrorHandler                                
            END

			if not exists (select 1 from t_afo_wave_detail
							where wave_id = @in_vchWaveId
							and wh_id = @in_vchWarehouseId)
			delete from t_wave_master
			 WHERE wave_id = @in_vchWaveId
                AND wh_id = @in_vchWarehouseId
			else
			update t_wave_master
			set status = 'R'
			WHERE wave_id = @in_vchWaveId
            AND wh_id = @in_vchWarehouseId 

    --Success
 
    -- IF THE TRANSACTION WAS STARTED IN THIS PROCEDURE THEN WE NEED TO MAKE SURE IT GETS COMMITTED HERE
    IF @v_nTranCount = 0
        COMMIT TRANSACTION

    GoTo ExitLabel


ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_UpdOrderDetailFailed
    BEGIN -- 
        -- Log Error    
        SET @v_vchLogMsg = 'An update to the t_order_detail table for wave ' +
            ISNULL(@in_vchWaveId,'(NULL)') + ' failed while unbuilding the wave.'
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50003 -- Update Failed
    END
    IF @v_nErrorNumber = @e_DelWDLineFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'Error while deleting t_afo_wave_detail_line records for wave ' + ISNULL(@in_vchWaveId,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General
    END
    IF @v_nErrorNumber = @e_DelWVDFailed
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'Error while deleting t_afo_wave_detail records for wave ' + ISNULL(@in_vchWaveId,'(NULL)')
        EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General
    END

    -- Return Error to caller
    SET @out_vchMessage = @v_vchLogMsg

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION

ExitLabel:
    RETURN
