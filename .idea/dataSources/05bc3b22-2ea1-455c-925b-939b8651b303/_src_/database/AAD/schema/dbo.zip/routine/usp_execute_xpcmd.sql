

CREATE PROC usp_execute_xpcmd 

  @in_vstrSysCMD NVARCHAR(1000)

AS

  --declare variables
  DECLARE -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_vchErrorMsg              NVARCHAR(500),
    @v_vchLogMsg                NVARCHAR(500),
    @v_vchParam1                NVARCHAR(100),
    @v_nRaiseErrorNumber        INT,
    @v_nErrorNumber             INT,
    @v_vchSqlErrorNumber        INT,
    @v_nCustomError             INT,  
    @v_nRowCount                INT,
    @v_nReturn                  INT,
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @v_nTranCount               INT

    SET NOCOUNT ON
    
    -- Set error constants
    SET @e_GenSqlError = 1
    SET @e_SprocError = 2

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT
    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END

	BEGIN
	
		IF SUBSTRING(@in_vstrSysCMD, 1, 22)  = 'bcp "SELECT label_data' 
			BEGIN	
			EXEC master..xp_cmdshell @in_vstrSysCMD , no_output
			END
	END
 
  GOTO ExitLabel

ErrorHandler:
    IF @v_nErrorNumber = @e_GenSqlError
    BEGIN -- SQL Server Error
        -- Log Error    
        SET @v_vchLogMsg = 'An unknown SQL Server Error has occurred.'
        --EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = @v_vchSqlErrorNumber
        SET @v_nRaiseErrorNumber = 50001 -- General SQL Server Error
    END
    IF @v_nErrorNumber = @e_SprocError
    BEGIN -- Stored Procedure Error
        -- Log Error    
        SET @v_vchLogMsg = 'An error occured in a stored procedure with a return code of ' --+
                --ISNULL(CONVERT(VARCHAR(30),@v_nReturn),'(NULL)') + '. Error Message: ' +
            --ISNULL(CONVERT(varchar(30),@v_vchErrorMsg),'(NULL)') + '.'
       -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
        -- Raiserror
        SET @v_vchParam1 = CONVERT(VARCHAR(30),@v_nReturn)
        SET @v_nRaiseErrorNumber = 50009 -- Stored Procedure Error
    END

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN
