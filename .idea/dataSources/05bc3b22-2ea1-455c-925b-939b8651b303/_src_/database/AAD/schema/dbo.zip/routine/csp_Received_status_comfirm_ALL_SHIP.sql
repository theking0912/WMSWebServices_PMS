
-- Procedure
-- =======================================    
-- Author: GAOYM    
-- Create Date: 2015-01-09
-- Description: all_shipment_Received status comfirm   
-- =======================================    
    
CREATE PROCEDURE [dbo].[csp_Received_status_comfirm_ALL_SHIP]
    @in_wh_id NVARCHAR(10) ,
    @in_shipment_number NVARCHAR(30) ,
    @in_is_confirm NCHAR(5) ,
    @passornot NVARCHAR(5) OUTPUT ,
    @msg NVARCHAR(200) OUTPUT
AS
    BEGIN
  

        DECLARE @po_type NVARCHAR(50) ,
     
            @ship_status NCHAR(1) ,
            @stored_attribute_id INT ,
           
            @po_number NVARCHAR(30) ,
			--@qty_received float,@qty_damaged float,   @qty_discount float,
           
           
	 --传入SAP参数
            @col1 NVARCHAR(250) ,
            @col2 NVARCHAR(250) ,
            @col3 NVARCHAR(250) ,
            @col4 NVARCHAR(250) ,
            @col5 NVARCHAR(250) ,
            @col6 NVARCHAR(250) ,
            @col7 NVARCHAR(250) ,
            @col8 NVARCHAR(250) ,
            @col9 NVARCHAR(250) ,
            @col10 NVARCHAR(250) ,
            @col11 NVARCHAR(250) ,
            @vendor NVARCHAR(10) ,
            @display_po_number NVARCHAR(30) ,
            @sap_order_tpy NVARCHAR(30) ,
            @client_code NVARCHAR(30) ,
            @relation_order_number NVARCHAR(30) ,
            @date_posting DATETIME ,
            @item_type NVARCHAR(10),@qty_sum float
		
        BEGIN TRAN
        SET NOCOUNT ON; 

        BEGIN TRY
		    
		    
            SELECT  @ship_status = status 
   
            FROM    t_rcpt_ship
            WHERE   shipment_number = @in_shipment_number
                    AND wh_id = @in_wh_id                                    
            
            IF @ship_status = 'C'
                AND @in_is_confirm = 'N'
                BEGIN

                    SELECT     @stored_attribute_id = stored_attribute_id ,
                               @po_number = po_number
							   --, @qty_damaged = qty_damaged ,@qty_discount = qty_discount,@qty_received   =qty_received      
                    FROM    t_receipt
                    WHERE   receipt_id = @in_shipment_number
                            AND wh_id = @in_wh_id
                            --AND line_number = @in_line_number
                            AND is_confirm = @in_is_confirm 
			        
					--set @qty_sum = @qty_damaged + @qty_discount +@qty_received
			 --UPDATE 明细级，运单级SHIP的is_confirm 标志
                  BEGIN 
				  --明细级
					UPDATE  t_receipt
                    SET     is_confirm = 'Y'
                    WHERE   receipt_id = @in_shipment_number
                            AND wh_id = @in_wh_id
                            AND is_confirm = 'N'
                   --运单级 
					UPDATE  t_rcpt_ship
                    SET     is_confirm = 'Y'
                    WHERE   shipment_number = @in_shipment_number
                            AND wh_id = @in_wh_id
                            AND is_confirm = 'N'
			      END
                    IF @@ROWCOUNT = 0
                        BEGIN
                            SELECT  @passornot = 2 ,
                                    @msg = '更新' + @in_wh_id + '的'
                                    + @in_shipment_number 
                                    + '运单状态失败'
                            GOTO ERRORHANDLER
                        END

			 ----将收货信息传给SAP系统
                    BEGIN
                        SELECT  
                                @po_type = tl.text
                        FROM    t_po_master pm
                                LEFT JOIN t_lookup tl ON pm.type_id = tl.lookup_id
                        WHERE   wh_id = @in_wh_id
                                AND po_number = @po_number
                    
                        EXECUTE usp_dynamic_get_attribute_data @stored_attribute_id,
                            @col1 OUTPUT, @col2 OUTPUT, @col3 OUTPUT,
                            @col4 OUTPUT, @col5 OUTPUT, @col6 OUTPUT,
                            @col7 OUTPUT, @col8 OUTPUT, @col9 OUTPUT,
                            @col10 OUTPUT, @col11 OUTPUT

					
                        IF @po_type NOT IN ( '3PLO', 'OMO', 'SWP', 'PPO' )
                            BEGIN
					--Insert into [dbo].[int_upd_receipt]
                               
                                INSERT  INTO [dbo].[tbl_inf_exp_receipt]
                                        ( receipt_id ,
                                          vendor_code ,
                                          po_number ,
                                          display_po_number ,
                                          receipt_date ,
                                          scac_code ,
                                          status ,
                                          item_number ,
                                          display_item_number ,
                                          lot_number ,
                                          line_number ,
                                          schedule_number ,
                                          qty_received ,
                                          qty_damaged ,
                                          qty_discount ,
                                          hu_id ,
                                          packing_slip ,
                                          fork_id ,
                                          uom ,
                                          shipment_number ,
                                          warehouse_id ,
                                          client_code ,
                                          generic_attribute1 ,
                                          generic_attribute2 ,
                                          generic_attribute3 ,
                                          generic_attribute4 ,
                                          generic_attribute5 ,
                                          generic_attribute6 ,
                                          generic_attribute7 ,
                                          generic_attribute8 ,
                                          generic_attribute9 ,
                                          generic_attribute10 ,
                                          generic_attribute11 ,
                                          process_status ,
                                          item_type ,
                                          sap_ordertype ,
                                          date_posting,
										  expiration_date,
										  production_date
                                        )
                                        SELECT  @in_shipment_number ,
                                                pom.vendor_code ,
                                                r.po_number ,
                                                CASE @po_type
                                                  WHEN 'RO'
                                                  THEN pom.relation_order_number
                                                  ELSE pom.display_po_number
                                                END ,
                                                GETDATE() ,
                                                NULL ,
                                                'N' ,
                                                r.item_number ,
                                                NULL ,
                                                r.lot_number ,
                                                r.line_number ,
                                                r.schedule_number ,
                                                r.qty_received ,
                                                r.qty_damaged ,
                                                r.qty_discount ,
                                                r.hu_id ,
                                                NULL ,
                                                r.fork_id ,
                                                NULL ,
                                                NULL ,
                                                @in_wh_id ,
                                                pom.client_code ,
                                                @col1 ,
                                                @col2 ,
                                                @col3 ,
                                                @col4 ,
                                                @col5 ,
                                                @col6 ,
                                                @col7 ,
                                                @col8 ,
                                                @col9 ,
                                                @col10 ,
                                                @col11 ,
                                                'Ready' ,
                                                r.item_type ,
                                                pom.sap_ordertype 
                                                --rcs.date_posting
												, (select date_posting from  t_rcpt_ship where  wh_id =  @in_wh_id 
                                                              AND shipment_number = @in_shipment_number ) as date_posting,
												expiration_date,
												production_date
	--@in_is_confirm , r.stored_attribute_id , rcs.status ,	pom. text 
                                        FROM    t_receipt r
                                                --LEFT JOIN t_rcpt_ship rcs ON r.wh_id = rcs.wh_id
                                                --              AND r.shipment_number = rcs.shipment_number
                                                LEFT JOIN ( SELECT
                                                              vendor_code ,
                                                              display_po_number ,
                                                              sap_ordertype ,
                                                              client_code ,
                                                              relation_order_number ,
                                                              tl.text ,
                                                              pm.wh_id ,
                                                              pm.po_number
                                                            FROM
                                                              t_po_master pm
                                                              LEFT JOIN t_lookup tl ON pm.type_id = tl.lookup_id
                                                            WHERE
                                                              wh_id =  @in_wh_id 
                                                              AND po_number = @po_number
                                                          ) pom ON pom.wh_id = r.wh_id
                                                              AND pom.po_number = r.po_number
                                        WHERE   r.receipt_id = @in_shipment_number
                                                AND r.wh_id = @in_wh_id
                                                AND r.is_confirm = 'Y'
												AND r.qty_received+r.qty_damaged+r.qty_discount>0
							
							        
			
                                IF @@ROWCOUNT = 0
                                    BEGIN
                                        SELECT  @passornot = 3 ,
                                                @msg = @in_wh_id + '的'
                                                + @in_shipment_number 
                                                 + '传入SAP接口表失败'
                                        GOTO ERRORHANDLER
                                    END


										 --记录流水帐页
								  BEGIN
									EXEC [dbo].[csp_add_account_page]
									@in_wh_id  ,
									NULL ,
									NULL ,
									NULL ,
									NULL ,
									@in_shipment_number ,
									NULL ,
									NULL  ,
									'IN' ,			----IN /OUT /INV  帐页类型
									@msg OUTPUT

								  END      

                            END
            
                    END    
		

						
         IF @msg  IS  NULL
	      BEGIN
			--log
                    INSERT  INTO t_tran_log_holding
                            ( [tran_type] ,
                              [description] ,
                              [start_tran_date] ,
                              [start_tran_time] ,
                              [end_tran_date] ,
                              [end_tran_time] ,
                              [employee_id] ,
                              [control_number] ,
                              [control_number_2] ,
                              [wh_id] ,
                              [location_id] ,
                              [hu_id] ,
                              [item_number] ,
                              [lot_number] ,
                              [tran_qty] ,
                              generic_attribute_1 ,
                              generic_attribute_2 ,
                              generic_attribute_3 ,
                              generic_attribute_4 ,
                              generic_attribute_5 ,
                              generic_attribute_6 ,
                              generic_attribute_7 ,
                              generic_attribute_8 ,
                              generic_attribute_9 ,
                              generic_attribute_10 ,
                              generic_attribute_11
                            )
                    VALUES  ( '667' ,
                              (SELECT DISTINCT description  FROM  dbo.t_transaction WHERE tran_type = '667') ,
                              GETDATE() ,
                              GETDATE() ,
                              GETDATE() ,
                              GETDATE() ,
                              'HJS' ,
                              @in_shipment_number ,
                              null,
                              @in_wh_id ,
                              null ,
                              null,
                              null ,
                              null,
                             0.0,           --在 [dbo].[tbl_inf_exp_receipt]查看数量明细
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_1
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_2
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_3
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_4
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_5
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_6
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_7
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_8
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_9
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_10
                              ) ,
                              ( SELECT  a.attribute_value
                                FROM    t_sto_attrib_collection_detail a ,
                                        t_attribute_legacy_map alm
                                WHERE   a.stored_attribute_id = @stored_attribute_id
                                        AND a.attribute_id = alm.generic_attribute_11
                              )
                            )


                    
                            SET @passornot = 0
                            SET @msg = '收货状态更新成功'
                            COMMIT TRANSACTION
                            RETURN
                        END
                END
              

            ELSE
                BEGIN
                    SELECT  @passornot = 1 ,
                            @msg = '运单已确认过'
                    GOTO ERRORHANDLER
                END

        END TRY

        BEGIN CATCH
            ROLLBACK TRANSACTION
            SET @msg = ERROR_MESSAGE()
            SET @passornot = 4
            RETURN
        END CATCH

        ErrorHandler:
        RAISERROR(@msg,11,1)
        ROLLBACK TRANSACTION
        RETURN

    END