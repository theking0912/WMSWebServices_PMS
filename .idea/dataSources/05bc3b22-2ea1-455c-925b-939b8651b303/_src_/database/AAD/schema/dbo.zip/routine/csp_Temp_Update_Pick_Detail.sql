CREATE PROC dbo.csp_Update_Pick_Detail
@wh_id nvarchar(10),
@po_number nvarchar(30),
@shipping_label nvarchar(50)	
AS
BEGIN
	DECLARE @order_Number NVARCHAR(30)
		SELECT @order_Number=order_number FROM tbl_po_so 
		WHERE po_number=@po_number AND 
		shipping_label_code=@shipping_label AND 
		wh_id=@wh_id
	DECLARE update_Cursor CURSOR  SCROLL FOR 
	SELECT line_number,item_number,qty,order_uom 
	FROM t_po_detail 
	WHERE po_number=@po_number and wh_id=@wh_id
	OPEN update_Cursor
		DECLARE @line_number nvarchar(5)
		DECLARE @item_nuber nvarchar(30)
		DECLARE @qty float
		DECLARE @order_uom nvarchar(10)
		FETCH NEXT FROM update_Cursor INTO @line_number,@item_nuber,@qty,@order_uom
			WHILE @@FETCH_STATUS=0
			BEGIN
				PRINT @line_number
				PRINT @item_nuber
				PRINT @qty
				UPDATE t_pick_detail 
				set picked_quantity=picked_quantity+@qty,status='PICKED'
				WHERE order_number=@order_Number and 
				wh_id=@wh_id and
				line_number=@line_number and 
				item_number=@item_nuber and 
				uom=@order_uom
				FETCH NEXT FROM update_Cursor INTO @line_number,@item_nuber,@qty,@order_uom
			END
	CLOSE update_Cursor
	DEALLOCATE update_Cursor
END
