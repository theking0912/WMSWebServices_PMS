
CREATE VIEW dbo.ea_v_AlertHistoryAckRes AS
SELECT
    ah.alert_event_id,
    ah.alert_id,
    a.priority,
    a.alert_name,
    ah.date_added,
    COUNT(ahu.alert_event_id) AS user_count,
    MIN(ahu.date_acknowledged) AS first_acknowledged,
    MIN(ahu.date_resolved) AS first_resolved,
    (SELECT COUNT(ahu2.acknowledged)
        FROM ea_t_alert_history_user ahu2
        WHERE ahu2.alert_event_id = ah.alert_event_id
        AND ahu2.acknowledged = 1)
            AS acknowledged_count,
    (SELECT COUNT(ahu3.resolved)
        FROM ea_t_alert_history_user ahu3
        WHERE ahu3.alert_event_id = ah.alert_event_id
        AND ahu3.resolved = 1)
            AS resolved_count
FROM
    dbo.ea_t_alert_history ah
        INNER JOIN dbo.ea_t_alert a
            ON ah.alert_id = a.alert_id
        LEFT OUTER JOIN dbo.ea_t_alert_history_user ahu
            ON ah.alert_event_id = ahu.alert_event_id
GROUP BY
    ah.alert_event_id,
    ah.alert_id,
    a.alert_name,
    a.priority,
    ah.date_added
