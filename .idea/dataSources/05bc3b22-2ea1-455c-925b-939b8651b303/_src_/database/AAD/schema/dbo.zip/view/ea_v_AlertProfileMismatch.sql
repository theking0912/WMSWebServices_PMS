

CREATE VIEW dbo.ea_v_AlertProfileMismatch AS
SELECT
    s.subscription_id,
    s.userid,
    u.webwise_username,
    u.display_name,
    s.alert_id,
    a.alert_name,
    s.notifyprofile_id,
    n.notifyprofile_name,
    r.rule_id,
    r.transportconfig_id,
    t.transportconfig_name,
    t.transport_type
FROM
    ea_t_notifyprofile_rule r
    INNER JOIN ea_t_notifyprofile n
        ON r.notifyprofile_id = n.notifyprofile_id
    INNER JOIN ea_t_subscription s
        ON n.notifyprofile_id = s.notifyprofile_id
    INNER JOIN ea_t_transportconfig t
        ON r.transportconfig_id = t.transportconfig_id
    INNER JOIN ea_t_alert a
        ON a.alert_id = s.alert_id
    INNER JOIN ea_t_user u
        ON u.userid = s.userid
WHERE
    (t.transport_type NOT IN
        (SELECT at.transport_type
            FROM ea_t_alert_transport at
            WHERE at.alert_id = s.alert_id)
    )
--ORDER BY
--    u.display_name,
--    a.alert_name,
--    n.notifyprofile_name,
--    t.transportconfig_name
