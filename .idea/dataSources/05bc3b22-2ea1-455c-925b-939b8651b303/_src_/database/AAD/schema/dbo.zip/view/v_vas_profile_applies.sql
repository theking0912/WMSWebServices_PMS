

CREATE VIEW v_vas_profile_applies
AS
SELECT vas_applies_id, vas_profile_id, client_code, item_number, display_item_number, uom, 
		inv_class, inv_cat, inventory_type, inbound_order_type, tran_type, vendor_code, 
       carrier_id, gen_attribute_value1, gen_attribute_value2, gen_attribute_value3, 
       gen_attribute_value4, gen_attribute_value5, gen_attribute_value6, 
       gen_attribute_value7, gen_attribute_value8, gen_attribute_value9, 
       gen_attribute_value10, gen_attribute_value11, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_1 ) as attribute_type_1, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_2 ) as attribute_type_2, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_3 ) as attribute_type_3, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_4 ) as attribute_type_4, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_5 ) as attribute_type_5, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_6 ) as attribute_type_6, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_7 ) as attribute_type_7, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_8 ) as attribute_type_8, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_9 ) as attribute_type_9, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_10 ) as attribute_type_10, 
       (SELECT attribute_type FROM t_attribute_type tat, t_attribute_legacy_map alm
        WHERE tat.attribute_id = alm.generic_attribute_11 ) as attribute_type_11 
FROM t_vas_profile_applies

