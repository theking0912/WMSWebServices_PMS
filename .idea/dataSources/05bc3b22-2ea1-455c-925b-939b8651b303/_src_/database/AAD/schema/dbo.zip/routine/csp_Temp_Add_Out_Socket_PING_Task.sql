-- =============================================
-- Author:		Laver.Hu
-- Create date: 2013-12-03
-- Description:	add PING task
-- =============================================
CREATE PROCEDURE [dbo].[csp_Add_Out_Socket_PING_Task] 
	-- Add the parameters for the stored procedure here
	@Out_WMS_SeqNo		AS	NVARCHAR(12)	OUTPUT,
	@Out_ERR_Msg		AS	NVARCHAR(250)	OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE		@WMS_SEQ_NO		NVARCHAR(12)
	DECLARE		@stopTGW1		NVARCHAR(12)
	DECLARE		@stopTGW2		NVARCHAR(12)

	BEGIN TRY		
	
		BEGIN TRANSACTION

		if not exists (select 1 from t_control where control_type ='STOPTGW1')
		insert into t_control
		(control_type,description,c1)
		values('STOPTGW1','Stop send message to TGW','N')

		if not exists (select 1 from t_control where control_type ='STOPTGW2')
		insert into t_control
		(control_type,description,c1)
		values('STOPTGW2','the 1st send message to tgw.','N')

		select @stopTGW1 = c1
		from t_control
		where control_type = 'STOPTGW1'

		select @stopTGW2 = c1
		from t_control
		where control_type = 'STOPTGW2'



		if isnull(@stopTGW1,'N') = 'N'		-- 1st send
		begin
			-- get a new socket msg's SeqNo
			EXEC csp_Get_New_Socket_SeqNo @WMS_SEQ_NO OUTPUT

			-- Insert a tran record
			INSERT INTO tbl_out_socket_ping
						([msg_type]
						,[wms_seq]
						,[tgw_seq]
						,[response]
						,[create_date])
					VALUES
						('PING'
						,@WMS_SEQ_NO
						,NULL
						,'N'
						,GETDATE())

			
			update t_control
				set c1 = 'Y'
				where control_type = 'STOPTGW1'	
		end
		else if isnull(@stopTGW2,'N') = 'N'		--2nd send
		begin
			-- get a new socket msg's SeqNo
			EXEC csp_Get_New_Socket_SeqNo @WMS_SEQ_NO OUTPUT

			-- Insert a tran record
			INSERT INTO tbl_out_socket_ping
						([msg_type]
						,[wms_seq]
						,[tgw_seq]
						,[response]
						,[create_date])
					VALUES
						('PING'
						,@WMS_SEQ_NO
						,NULL
						,'N'
						,GETDATE())

			if not exists(select 1
				from tbl_in_socket_msg_queue
				where dateadd(second,60,cast(msgdate + ' ' + substring(msgtime,1,2) + ':' + substring(msgtime,3,2) + ':' + substring(msgtime,5,2) as datetime)) >= getdate())
			begin
				update t_control
				set c1 = 'Y'
				where control_type = 'STOPTGW2'			
			end
		end
		else
		begin
			if exists(select 1
				from tbl_in_socket_msg_queue
				where dateadd(second,60,cast(msgdate + ' ' + substring(msgtime,1,2) + ':' + substring(msgtime,3,2) + ':' + substring(msgtime,5,2) as datetime)) >= getdate())
			begin
				update t_control
				set c1 = 'N'
				where control_type = 'STOPTGW2'			
			end
			SET @WMS_SEQ_NO = ''
		end

		--if not exists(select 1
		--		from tbl_in_socket_msg_queue
		--		where dateadd(second,20,cast(msgdate + ' ' + substring(msgtime,1,2) + ':' + substring(msgtime,3,2) + ':' + substring(msgtime,5,2) as datetime)) >= getdate())
		--begin
		--	update t_control
		--	set c1 = 'Y'
		--	where control_type = 'STOPTGW'			
		--end

		SET @Out_WMS_SeqNo = @WMS_SEQ_NO

		COMMIT

		RETURN
	END TRY

    BEGIN CATCH
        ROLLBACK
        SET @Out_ERR_Msg = ERROR_MESSAGE()
		RAISERROR(@Out_ERR_Msg, 11, 1)
        RETURN
    END CATCH
END
