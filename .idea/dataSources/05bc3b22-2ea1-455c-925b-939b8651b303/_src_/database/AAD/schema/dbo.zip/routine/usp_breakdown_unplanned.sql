
CREATE  PROCEDURE usp_breakdown_unplanned
--   @in_vchEmpID     NVARCHAR(10), 
 --   @in_vchWhID      NVARCHAR(10)
AS

  --declare variables
  DECLARE

    -- Error handling and logging variables.
    @c_nModuleNumber            INT, -- The # that uniquely tags the WA collection of objects.
    @c_nFileNumber              INT, -- The # that uniquely tags this object.
    @v_nLogLevel                INT, -- Holds log level (1-5).
    @v_nLogErrorNum             INT, -- The # that uniquely tags the error message. 
    @v_vchLogMsg                NVARCHAR(500),
    @v_vchParam1                NVARCHAR(100),
    @v_vchErrorMsg              NVARCHAR(500),
    @v_nRaiseErrorNumber        INT,
    @v_nErrorNumber             INT,
    @v_vchSqlErrorNumber        INT,
    @v_nCustomError             INT,  
    @v_nRowCount                INT,
    @v_nCount                   INT,   
    @v_nReturn                  INT,

    -- Log/Local Error Constants
    @e_GenSqlError              INT,
    @e_SprocError               INT,
    @e_InsPKDFailed_1           INT,
    @e_InsPKDFailed_2           INT,
    @e_UpdPKDFailed_1           INT,
    @e_UpdPKDFailed_2           INT,
    @e_UpdPKDFailed_3           INT,
    @v_nTranCount               INT  
    
    -- Set Constants
    SET @c_nModuleNumber = 60    
    SET @c_nFileNumber = 9       
    SET @e_InsPKDFailed_1 = 1
    SET @e_UpdPKDFailed_1 = 2
    SET @e_InsPKDFailed_2 = 3
    SET @e_UpdPKDFailed_2 = 4
    SET @e_UpdPKDFailed_3 = 5
    SET @e_GenSqlError    = 6
  
    SET NOCOUNT ON


    -- Clear the t_employee.sp_return field used to communicate with the WA application.
    /*EXECUTE @v_nReturn = usp_clear_emp @in_vchWhID, @in_vchEmpID
    IF @v_nReturn <> 0
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
                ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler                       
    END*/

    -- Grab the database object log level.
    EXECUTE @v_nReturn = usp_db_obj_log_level @v_nLogLevel OUTPUT

    IF @v_nReturn <> 0 -- A zero means success.
    BEGIN
        SET @v_vchErrorMsg = 'An error occurred in a stored procedure with a return code of ' +
        	ISNULL(CONVERT(varchar(30),@v_nReturn),'(NULL)') + '.'
        SET @v_nLogErrorNum = @e_SprocError
        GOTO ErrorHandler			
    END

    SET @v_nCount = 1

  -- No UOM
  -- Create entries in t_pick_detail for items that do not have t_item_uom entries.
  -- When a new PKD record is inserted the unplanned_qty is reduced.  Continue until all the
  -- PKD records with unplanned qty have been reduced below the top level UOM conversion factor.

    WHILE @v_nCount > 0
        BEGIN --@v_nCount > 0 No UOM
        -- PKD to be created are determined by locating PKD records where unplanned_qty > 0.
        -- Quantity for the PKD record is detemined by comarision to the item standard handling 
        -- unit quantity.  A PKD record planned quantity cannot be larger that std_had_qty unless 
        -- the std_hand_qty is 0.
        -- When a new PKD record is inserted the unplanned_qty is reduced.  Continue until all the
        -- PKD records with unplanned qty have been reduced below the top level UOM conversion factor.
            INSERT #tmp_pick_detail ( 
                order_number, 
                line_number, 
                type, uom, 
                work_type, 
                status, 
                item_number, 
                lot_number,  
                unplanned_quantity, 
                planned_quantity, 
                pick_location, 
                picking_flow, 
                staging_location, 
                zone, 
                wave_id, 
                load_id, 
                load_sequence, 
                stop_id, 
                pick_area, 
                wh_id,
		stored_attribute_id)
            SELECT 
                order_number, 
                line_number, 
                type,
                uom.uom, 
                pkd.work_type, 
                'NEW',
                pkd.item_number, 
                lot_number,  
                --0, 
                unplanned_quantity AS planned_qty,
                0,
                pkd.pick_location, 
                picking_flow, 
                staging_location, 
                zone, 
                wave_id, 
                load_id,
                load_sequence,
                stop_id,
                pick_area,
                pkd.wh_id,
		pkd.stored_attribute_id
            FROM #tmp_pick_detail pkd
                LEFT JOIN t_item_uom uom 
                ON (pkd.item_number = uom.item_number AND pkd.wh_id = uom.wh_id)
            WHERE uom.uom IS NULL
                 AND planned_quantity > 0
                     --pkd.unplanned_quantity > 0

            -- Set @n_RowCount to the number of new PKD's records created.
            SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT    
            IF @v_nErrorNumber <> 0
                BEGIN 
                    SET @v_vchErrorMsg = 'An insert failed on t_pick_detail  '
                    SET @v_nErrorNumber = @e_InsPKDFailed_1
                    GOTO ErrorHandler
                END
        
            -- determine number of rows to loop on.
            SET @v_nCount = @v_nRowCount;
        
            IF (@v_nRowCount = 0 AND @v_nLogLevel = 1) 
            BEGIN
                PRINT 'No Records found for PKD without UoM'
                BREAK
            END
            
            -- Reduce the unplanned_quantity by the amount of the 'NEW' PKD records just inserted
            -- Wrong update qry !!Segun
            -- When no uom if found, update unplanned_qty field, not planned_qty. Then
            -- subtract unplanned_qty from planned_qty to reduce qty to Zero
            /*UPDATE pkd 
                SET pkd.unplanned_quantity = pkd.unplanned_quantity - pkd2.planned_quantity
                FROM #tmp_pick_detail pkd, #tmp_pick_detail pkd2
                WHERE pkd.item_number = pkd2.item_number
                    AND pkd.wh_id = pkd2.wh_id
                    AND pkd.order_number = pkd2.order_number
                    AND pkd.line_number = pkd2.line_number
                    AND pkd2.unplanned_quantity = 0
                    AND pkd.unplanned_quantity > 0
                    AND pkd2.status = 'NEW'*/

            UPDATE pkd 
                SET pkd.planned_quantity = pkd.planned_quantity - pkd2.unplanned_quantity
                FROM #tmp_pick_detail pkd, #tmp_pick_detail pkd2
                WHERE pkd.item_number = pkd2.item_number
                    AND pkd.wh_id = pkd2.wh_id
                    AND pkd.order_number = pkd2.order_number
                    AND pkd.line_number = pkd2.line_number
                    AND pkd2.planned_quantity = 0
                    AND pkd.planned_quantity > 0
                    AND pkd2.status = 'NEW'
        
            SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
            IF @v_nErrorNumber <> 0
            BEGIN 
                SET @v_vchErrorMsg = 'An update failed on t_pick_detail : '
                SET @v_nErrorNumber = @e_UpdPKDFailed_1
                GoTo ErrorHandler
            END
        
            UPDATE #tmp_pick_detail 
            SET status = 'UNPLANNED' WHERE status = 'NEW'
            
            -- Delete PKD records whose unplanned_quantity and unplanned_quantity = 0
            DELETE #tmp_pick_detail 
                WHERE unplanned_quantity = 0 
                AND planned_quantity = 0


    END --@v_nCount > 0 No UOM

    SET @v_nCount = 1  

    --With UOM
    -- Create entries in t_pick_detail for items that have t_item_uom entries.
    -- When a new PKD record is inserted the unplanned_qty is reduced.  Continue until all the
    -- PKD records with unplanned qty have been reduced below the top level UOM conversion factor.

    WHILE @v_nCount > 0
        BEGIN --@v_nCount > 0 With UOM
        -- PKD to be created are determined by locating PKD records where unplanned_qty > 0.
        -- Quantity for the PKD record is detemined by comarisin to the item max handling unit
        -- quantity.  A PKD record planned quantity cannot be larger that max_hand_qty unless the
        -- max_hand_qty is 0.
            INSERT #tmp_pick_detail ( 
                order_number, 
                line_number, 
                type, 
                uom, 
                work_type, 
                status, 
                item_number, 
                lot_number,  
                unplanned_quantity, 
                planned_quantity, 
                pick_location, 
                picking_flow, 
                staging_location, 
                zone, 
                wave_id, 
                load_id, 
                load_sequence, 
                stop_id, 
                pick_area, 
                wh_id,
		stored_attribute_id)
            SELECT 
                order_number, 
                line_number, 
                type, 
                uom.uom, 
                pkd.work_type, 
                'NEW', 
                pkd.item_number, 
                lot_number,  
    		    0, 
                CASE
					WHEN uom.shippable_uom = 'Y' and pkd.manifest_carrier_flag = 'Y' 
                        THEN cast (conversion_factor as BIGINT)
                    WHEN uom.max_hand_qty = 0 
                        THEN (conversion_factor * cast((unplanned_quantity/conversion_factor) as BIGINT))
                    WHEN unplanned_quantity <= (uom.max_hand_qty) 
	                    THEN (conversion_factor * cast((unplanned_quantity/conversion_factor) as BIGINT))
                    ELSE (conversion_factor * cast(((uom.max_hand_qty)/conversion_factor) as BIGINT)) 
                END AS planned_qty,
                pkd.pick_location, 
                picking_flow, 
                staging_location, 
                zone, 
                wave_id, 
                load_id, 
                load_sequence, 
                stop_id, 
                pick_area, 
                pkd.wh_id,
		pkd.stored_attribute_id
            FROM #tmp_pick_detail pkd
                JOIN t_item_uom uom ON (pkd.item_number = uom.item_number AND pkd.wh_id = uom.wh_id)
                     WHERE pkd.unplanned_quantity >= uom.conversion_factor
                       AND uom.conversion_factor = (SELECT MAX(uom2.conversion_factor) 
                                                    FROM t_item_uom uom2                                                     WHERE uom2.item_number = uom.item_number
                                                    AND uom2.wh_id = uom.wh_id
                                                    AND uom2.item_number = pkd.item_number
                                                    AND uom2.wh_id = pkd.wh_id
                                                    AND uom2.conversion_factor <= pkd.unplanned_quantity
                                                    AND uom2.priority = 1
                                                    AND uom2.priority = uom.priority
                                                    GROUP BY item_number)

    -- Set @n_RecCount to the number of new PKD's records created.
    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nErrorNumber <> 0
        BEGIN 
            SET @v_vchErrorMsg = 'An update failed on t_pick_detail : '
            SET @v_nErrorNumber = @e_InsPKDFailed_2
            GoTo ErrorHandler
        END


    -- Update the pkd records with a max hand qty of zero to the lowest uom to minimize risk
    -- of uneven divisor.
    /*UPDATE pkd
    SET uom = (SELECT TOP 1 (uom)
               FROM t_item_uom uom2
               WHERE uom2.item_number = pkd.item_number
                   AND uom2.wh_id = pkd.wh_id
                   AND uom2.conversion_factor <= pkd.planned_quantity
                ORDER BY conversion_factor  -- Is minimum conversion for the item
                   ) 
    FROM t_pick_detail_temp pkd, t_item_uom uom
    WHERE pkd.item_number = uom.item_number
        AND pkd.uom = uom.uom
        AND pkd.wh_id = uom.wh_id
        AND pkd.status = 'NEW'
        AND uom.max_hand_qty = 0*/

    SELECT @v_nErrorNumber = @@ERROR
    IF @v_nErrorNumber <> 0
        BEGIN 
            SET @v_vchErrorMsg = 'An attempt to update t_pick_detail.uom failed : '
            SET @v_nErrorNumber = @e_UpdPKDFailed_3
            GoTo ErrorHandler
        END


    /*
    IF @v_nRowCount = 0 
        BEGIN 
            IF @v_nLogLevel = 1 PRINT 'No UOM Items found for PKD'
               BREAK
       END
    */

  -- Reduce the unplanned_quantity by the amount of the 'NEW' PKD records just inserted
    UPDATE pkd set pkd.unplanned_quantity = pkd.unplanned_quantity - pkd2.planned_quantity
        FROM #tmp_pick_detail pkd, #tmp_pick_detail pkd2
        WHERE pkd.item_number = pkd2.item_number
              AND pkd.wh_id = pkd2.wh_id
              AND pkd.order_number = pkd2.order_number
              AND pkd.line_number = pkd2.line_number
              AND pkd2.unplanned_quantity = 0
              AND pkd.unplanned_quantity > 0
              AND pkd2.status = 'NEW'

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT
    IF @v_nErrorNumber <> 0
        BEGIN 
            SET @v_vchErrorMsg = 'An update failed on t_pick_detail : '
            SET @v_nErrorNumber = @e_UpdPKDFailed_3
            GoTo ErrorHandler
        END
  
   
    --Update the status 'NEW' PKD records to status 'CREATED'
    UPDATE #tmp_pick_detail SET status = 'CREATED' WHERE status = 'NEW'
    
    -- Delete PKD records whose unplanned_quantity and planned_quantity = 0
    DELETE #tmp_pick_detail WHERE unplanned_quantity =0 AND planned_quantity = 0
    
    -- determine number of rows to loop on.           
    SET @v_nCount = @v_nRowCount;

    SELECT @v_nErrorNumber = @@ERROR, @v_nRowCount = @@ROWCOUNT 
    IF @v_nErrorNumber <> 0
    BEGIN
        SET @v_vchErrorMsg = 'SQL Server System error occured!  Check SQL Server System Log for ' +
            'the exact nature of the error.'
        SET @v_nLogErrorNum = @e_GenSqlError
        GOTO ErrorHandler
    END

  END --@v_nCount > 0 With UOM

			
  GoTo ExitLabel

ErrorHandler:

    BEGIN -- SQL Server Error
   
       -- EXECUTE usp_log_message @c_nModuleNumber, @c_nFileNumber, @v_nErrorNumber, 1, @v_vchLogMsg, 1
       -- UPDATE t_employee SET sp_return = 'PROC ERROR' WHERE id = @in_vchEmpID AND @in_vchWhID = wh_id
        RAISERROR(@v_vchErrorMsg, 11, 1)

    END

    --THE PROCEDURE WHICH ALLOWS US TO DETERMINE WHETHER WE STARTED THE TRANSACTION OR NOT
    IF @v_nTranCount = 0 -- Pete ?
        ROLLBACK TRANSACTION


ExitLabel:
    RETURN

GRANT EXECUTE ON usp_breakdown_unplanned TO WA_USER,AAD_USER
