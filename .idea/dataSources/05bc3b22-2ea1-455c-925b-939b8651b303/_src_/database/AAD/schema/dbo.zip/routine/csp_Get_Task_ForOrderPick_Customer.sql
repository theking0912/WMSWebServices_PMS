




-- =======================================    
-- Author: Peter 
-- Create Date: 2016-01-19  
-- Description: Get pick task
--  
    
-- =======================================    
    
CREATE  PROCEDURE [dbo].[csp_Get_Task_ForOrderPick_Customer]    
     @wh_id					NVARCHAR(10)
	,@pick_key				NVARCHAR(30)	-- 
	,@user_id				NVARCHAR(30)
	,@pick_expiration_date	DATETIME		OUTPUT
	,@pick_loc				NVARCHAR(30)	OUTPUT
	,@pick_item_number		NVARCHAR(30)	OUTPUT
	,@pick_lot_number		NVARCHAR(30)	OUTPUT
	,@pick_sto_atrribute_id	NVARCHAR(30)	OUTPUT
	,@pick_qty				FLOAT			OUTPUT
	,@pick_hu_id			NVARCHAR(30)	OUTPUT
	,@pick_zone				NVARCHAR(10)	OUTPUT
	,@ref_number			NVARCHAR(30)	OUTPUT
	,@damage_flag			NVARCHAR(1)		OUTPUT
	,@order_number			NVARCHAR(30)	OUTPUT
	,@passornot				NVARCHAR(1)		OUTPUT
	,@msg					NVARCHAR(200)	OUTPUT
AS    
BEGIN    
    -- SET NOCOUNT ON added to prevent extra result sets from    
    SET NOCOUNT ON;    

	BEGIN TRY
		BEGIN TRY
			BEGIN TRANSACTION
			--DECLARE @pick_seq NVARCHAR(30)
			--Cancel the assgined information
			UPDATE tbl_allocation
			SET status ='U'
				,user_assign = NULL
			WHERE status ='A'
			AND wh_id = @wh_id
			AND user_assign = @user_id			

			COMMIT TRANSACTION
		END TRY

		BEGIN CATCH
			ROLLBACK
			SET @msg = ERROR_MESSAGE()
			SET @passornot = 1
			RETURN
		END CATCH

		SELECT TOP 1 @pick_loc = allo.location_id
			,@pick_item_number = allo.item_number
			,@pick_lot_number = allo.lot_number
			,@pick_sto_atrribute_id = allo.stored_attribute_id
			,@pick_qty = SUM(allo.allocated_qty - ISNULL(allo.picked_qty,0))
			,@pick_hu_id = allo.hu_id
			,@pick_zone = allo.zone
			,@ref_number = allo.ref_number
			,@damage_flag = allo.damage_flag
			,@order_number = allo.order_number
			,@pick_expiration_date = allo.expiration_date
		FROM dbo.tbl_allocation allo  
			INNER JOIN tbl_pick_list tpl WITH(NOLOCK) ON allo.wh_id = tpl.wh_id AND allo.seq_id = tpl.seq_id
			INNER JOIN t_location loc WITH(NOLOCK) ON allo.wh_id = loc.wh_id AND allo.location_id = loc.location_id					
		WHERE allo.wh_id = @wh_id
		AND (allo.status = 'U' OR (allo.status = 'A' and allo.user_assign =@user_id))
		AND allo.allo_type = 'O'	-- Order Picking 
		AND loc.status NOT IN ('H','I')
		AND allo.allocated_qty > ISNULL(allo.picked_qty,0)
		--修改清单号为门店号
		--AND (tpl.list_number = @pick_key)
        AND  EXISTS ( SELECT 1 FROM t_order o WITH(NOLOCK)
						WHERE o.wh_id = tpl.wh_id
							AND o.order_number = tpl.order_number
							AND (rtrim(tpl.wave_id)+rtrim(o.customer_id))=@pick_key)
		--The one loc can be allocated by one user
		AND NOT EXISTS ( SELECT 1 FROM tbl_allocation a WITH(NOLOCK)
						WHERE a.wh_id = allo.wh_id
							AND a.location_id = allo.location_id
							AND a.[status] = 'A'
							AND a.user_assign <> @user_id)
		GROUP BY allo.picking_flow,allo.location_id,allo.hu_id,allo.item_number,allo.lot_number,allo.expiration_date,allo.stored_attribute_id,allo.damage_flag,allo.ref_number,allo.zone,allo.order_number
		ORDER BY allo.picking_flow,allo.location_id,allo.hu_id,allo.item_number,allo.lot_number,allo.expiration_date,allo.stored_attribute_id,allo.damage_flag,allo.ref_number,allo.zone	,allo.order_number

	
		
		
		IF ISNULL(@pick_loc,'') <>''
			BEGIN TRY
				BEGIN TRANSACTION
				UPDATE tbl_allocation
				SET user_assign =@user_id
					,status ='A'
				WHERE wh_id = @wh_id
				and status = 'U'
				AND (hu_id = @pick_hu_id OR ISNULL(hu_id,'') = ISNULL(@pick_hu_id,''))
				--AND ref_number = @ref_number
				AND allo_type = 'O'
				AND location_id = @pick_loc
				AND item_number = @pick_item_number

				COMMIT TRANSACTION
			END TRY

			BEGIN CATCH
				ROLLBACK
				SET @msg = ERROR_MESSAGE()
				SET @passornot = 1
				RETURN
			END CATCH
-----------------------------------------------------------------------------------

		if not exists (select 1 from tbl_allocation
						where wh_id = @wh_id
						and user_assign =@user_id
						and status ='A') and isnull(@pick_loc,'') <> '' 
		begin
			SET @passornot = 1
			SET @msg = 'Miss assign task, pls try it again'
		end
		else
		begin
			SET @passornot = 0
			SET @msg = ''
		end

        RETURN

    END TRY

    BEGIN CATCH
        SET @msg = ERROR_MESSAGE()
        SET @passornot = 1
        RETURN
    END CATCH
  
END





